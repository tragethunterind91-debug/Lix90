# Test Credentials
# Agent writes here when creating/modifying auth credentials (admin accounts, test users).
# Testing agent reads this before auth tests. Fork/continuation agents read on startup.

## Admin Account
- **Email**: `admin@animehub.in` (and `AnimeUnleashed@adown.com`)
- **Password**: `AnimeHub@2025` (and `EcoGreen-Support-Anime-9157`)
- **Studio PIN**: `582431`
- **Role**: `admin`

## Worker Account
- **Email**: `worker1@animehub.in` (and `Worker01@Aniupwork.com`)
- **Password**: `Worker@1-upload2026` (and `Uploadvidioworkeverunimake`)
- **Role**: `worker`

## Viewer / User Account
- **Email**: `testy@gmail.com`
- **Password**: `UserPassword123`
- **Role**: `user`

