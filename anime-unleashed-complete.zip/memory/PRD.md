# Product Requirements Document (PRD) — Anime Unleashed

## Overview & Architecture
Anime Unleashed is an existing production anime streaming and creator platform.
- **Frontend**: React 18 + TypeScript + Tailwind CSS + Vite (Firebase Hosting production target)
- **Backend**: Python FastAPI (AWS EC2 production target)
- **Database**: AWS DynamoDB (`DYNAMODB_TABLE_PREFIX=animehub_`)
- **Media / Storage**: Cloudflare R2 object storage (S3 compatible)
- **Production API Domain**: `https://api.animeunleashed.in`
- **Preview Environment**: `https://92d79809-240b-4e5c-876f-d8a8dffe35d8.preview.emergentagent.com`

## User Personas & Portals Preserved
1. **Public Viewers / Guests**:
   - Access root `/` with full anime catalog, hero banner, category filters, and search.
   - Stream titles and episodes at `/watch/:slug/:ep` and browse details at `/title/:slug`.
2. **Registered Viewers (`user`)**:
   - Authentication at `/login` and `/register`.
   - Access watch history, VIP subscription (`/vip`), coin tasks, and Publisher applications (`/publishers`).
3. **Studio Admins & Owner (`admin`)**:
   - Gated by both account credentials and a 6-digit Studio PIN (`582431`).
   - Access `/studio` console, `/studio/catalog`, `/studio/episodes`, NFT system, users, revenue, and audit log.
4. **Content Workers (`worker`)**:
   - Access `/worker/login` and `/worker`.
   - Upload and attach videos as draft entries for studio review.
5. **Creators / Publishers (`creator` / `/publishers`)**:
   - Portal at `/creator/login` and publisher application flow at `/publishers`.

## Verification & Test Results
- **Pytest Backend Suite**: 20/20 passed (`test_iteration1_review.py` & `test_iter2_register_geo.py`) covering health, title catalog, details, featured titles, authentication, and registration.
- **Live Stream Donations with 60/40 Split**: Added support for live donations, pop-up superchats, likes, and hype (4 hypes + 1 like) during live streams and webview streams:
  - *Native Anime Unleashed Live*: 60% to Creator, 40% to Anime Unleashed Platform.
  - *WebView Video Streaming (YouTube/Social)*: 60% to Anime Unleashed Platform, 40% to Creator/User.
- **User Deposits & Direct Creator Tipping**: Users can deposit money directly into their wallet (`/vip/deposit`) and tip favorite creators on channels (`/channels/:id`) or streams (`/live`).
- **LC (ZC) Currency & Conversion Rules**:
  - Buying NFTs, auction bidding, and peer-to-peer currency transfers use LC (ZC).
  - Conversion: `1 VD = 1 LC` and `1 CF = 3 LC`.
  - Rule: LC cannot be converted back into VD or CF.
  - Users can transfer LC or CF to other fans via `/wallet`.
- **Admin Credit Controls & Video Monitoring**:
  - Admin can send or remove VD, VIP days, CF, and LC/ZC credits to any user.
  - Studio Admin Video Monitoring (`/studio/monitoring`) provides telemetry: total duration, avg duration, catalog views, donations, platform profit, CDN egress loss estimate, likes/dislikes, comments/shares, and growth %.
- **Updated Clean Production ZIP**: Re-packaged into `anime-unleashed-complete.zip` (1.5MB clean standalone archive without unnecessary build churn or node_modules bloat), mirrored at `/app/anime-unleashed-complete.zip`, `/app/frontend/public/anime-unleashed-complete.zip` and `/app/frontend/dist/anime-unleashed-complete.zip`. All 24 regression tests passed 100%.
- **Frontend Routes Verified**:
  - `/` (Home catalog with hero banner & live anime cards)
  - `/watch/ironman` (Video player layout and episode listing)
  - `/studio` & `/studio/catalog` (Owner login & PIN authentication console)
  - `/worker/login` & `/worker` (Worker desk)
  - `/creator/login` (Creator desk)
  - `/publishers` (Publisher Desk & channel application)
  - `/admin` (Redirect to Studio)
- **Deployment Scripts Verified**:
  - `/app/deploy.sh` & `/app/frontend/deploy-firebase.sh` for Firebase Hosting.
  - `/app/backend/aws/ec2-setup.sh`, `animehub-api.service`, and `Caddyfile` for AWS EC2.
