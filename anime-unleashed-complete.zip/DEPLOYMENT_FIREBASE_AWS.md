# Anime-Unleashed: Firebase Frontend & AWS Backend Setup

This document describes the 100% cloud architecture used by Anime-Unleashed:
- **Frontend**: Hosted on **Firebase Hosting** (`dist/` via `firebase.json` and `.firebaserc`).
- **Backend**: Hosted on **AWS EC2 Ubuntu** via systemd + Caddy HTTPS.
- **Database**: **AWS DynamoDB** (All 35+ tables in `ap-south-1`). Zero MongoDB.
- **Media Storage**: **Cloudflare R2** / S3 compatibility for direct video streaming and uploads.

---

## 1. Deploying Frontend to Firebase Hosting

In Termux or on your machine:
```bash
cd anime-unleashed/frontend
npm install -g firebase-tools
# Log in to your Firebase account once:
firebase login

# Set your AWS EC2 backend API URL and deploy:
chmod +x deploy-firebase.sh
./deploy-firebase.sh https://api.your-ec2-domain.com
```

Your web app will be live on Firebase at:
`https://anime-unleashed.web.app` / `https://anime-unleashed.firebaseapp.com`

---

## 2. Deploying Backend to AWS EC2 (Ubuntu)

On a fresh AWS EC2 Ubuntu instance:
```bash
sudo apt-get update && sudo apt-get install -y git
git clone <YOUR-REPO> ~/animehub && cd ~/animehub/backend/aws
# Fill in your AWS & Secret keys in ~/animehub/backend/.env
DOMAIN=api.your-domain.com REPO=/home/ubuntu/animehub sudo -E bash ec2-setup.sh
```

Everything runs automatically via `systemd` (`animehub-api.service`) with automatic free SSL managed by Caddy.

---

## 3. Verified Features Included

- **NFT Marketplace**: 50+ NFTs with Anime, Dragons, Creatures, Characters and Low/Mid/High/Limited tiers.
- **Limited Edition NFT Minting**: Admin controls for limit, start/end dates, video/HTML/animation media.
- **Auction House**: 48-Hour duration strictly for Limited Edition NFTs, cancelable within 24h, with early buyer confirmation and auto-settlement.
- **Ad Reward Conversion**: 1 Ad = 1 VD, 3 VD = 1 CF, 1 VD = 1 LC.
- **Donation System**: 80% ZNQ Network / 20% Environmental Protection split with currency support (₹10 / $0.10 min).
- **Responsive Navigation**: Full mobile drawer menu + single-line desktop bar.
- **Zero-gap Watch Theater**: Built-in mini-player toggle.
- **Admin-only Downloads**: Media download restricted from public viewers.
