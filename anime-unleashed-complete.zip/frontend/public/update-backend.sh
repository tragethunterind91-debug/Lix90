#!/usr/bin/env bash
# Anime-Unleashed — ONE-SHOT EC2 BACKEND UPDATER.
# Run this ONLY on EC2 (prompt: ubuntu@ip-...:~$). It never touches Termux machines.
#   curl -sL https://anime-stack.preview.emergentagent.com/update-backend.sh -o ub.sh && bash ub.sh
set -euo pipefail

BASE_URL="${1:-https://anime-stack.preview.emergentagent.com}"
API_HEALTH="http://127.0.0.1:8001/api/health"  # checked from the box itself — no DNS/TLS dependency

# ---- machine guards (the past two incidents) ----
if [ -d "/data/data/com.termux" ]; then
  echo "STOP: this is TERMUX (your phone). The backend update runs on EC2 only."
  echo "First:  ssh -i <your-key> ubuntu@13.127.205.138   then run this again there."
  exit 1
fi
if [ ! -d "$HOME/animehub/backend" ]; then
  echo "STOP: $HOME/animehub/backend not found — you may be on the wrong machine."
  echo "Expected the EC2 layout: /home/ubuntu/animehub/backend (prompt: ubuntu@ip-...)."
  exit 1
fi
if [ "$(id -u)" -eq 0 ]; then SUDO=""; else SUDO="sudo"; fi

echo "==> 1/6 Download fresh source"
curl -L -o /tmp/src.zip "$BASE_URL/anime-unleashed-src.zip"
rm -rf /tmp/ahnew && unzip -o /tmp/src.zip "backend/*" -d /tmp/ahnew > /dev/null
test -f /tmp/ahnew/backend/server.py || { echo "BAD ZIP — server.py missing"; exit 1; }

echo "==> 2/6 Stop service + back up .env and media"
$SUDO systemctl stop animehub-api
$SUDO cp "$HOME/animehub/backend/.env" /tmp/animehub.env.bak
$SUDO cp -r "$HOME/animehub/backend/media" /tmp/animehub-media.bak 2>/dev/null || true

echo "==> 3/6 Replace backend code"
$SUDO rm -rf "$HOME/animehub/backend"
mkdir -p "$HOME/animehub/backend"
$SUDO cp -r /tmp/ahnew/backend/* "$HOME/animehub/backend/"

echo "==> 4/6 Restore .env + media + ownership"
$SUDO cp /tmp/animehub.env.bak "$HOME/animehub/backend/.env"
$SUDO cp -r /tmp/animehub-media.bak "$HOME/animehub/backend/media" 2>/dev/null || true
$SUDO chown -R ubuntu:ubuntu "$HOME/animehub/backend"

echo "==> 5/6 Install deps (venv may need recreating — it lives inside backend/)"
# apt can hang forever on a dpkg lock (unattended-upgrades) — stop it, wait for
# any stuck apt, then install with a HARD timeout so the updater never stalls
sudo systemctl stop unattended-upgrades >/dev/null 2>&1 || true
for i in 1 2 3 4 5 6; do
  if ! sudo fuser /var/lib/dpkg/lock-frontend >/dev/null 2>&1; then break; fi
  echo "    waiting for another apt process…"
  sleep 10
done
sudo timeout 300 apt-get update -q >/dev/null 2>&1 || true
sudo timeout 300 apt-get install -y -q fonts-dejavu-core ffmpeg >/dev/null 2>&1 || true  # watermark burn + video conversion (never blocks the update)
cd "$HOME/animehub/backend"
# nightly catalog backup (free, scan-to-JSON, 7-night retention) at 2:30 AM
chmod +x aws/nightly-backup.sh 2>/dev/null || true
( crontab -l 2>/dev/null | grep -v nightly-backup.sh ; echo "30 2 * * * $HOME/animehub/backend/aws/nightly-backup.sh" ) | crontab - 2>/dev/null && echo "    nightly backup scheduled (2:30 AM)"
if [ ! -x "venv/bin/pip" ]; then
  echo "    venv missing — recreating (2-5 min, wait for it)"
  python3 -m venv venv
  venv/bin/pip install -q --upgrade pip
fi
grep -vE '^(emergentintegrations|pandas|numpy)' requirements.txt > /tmp/req-filtered.txt || true
venv/bin/pip install -q -r /tmp/req-filtered.txt

echo "==> 6/6 Start + health check"
$SUDO systemctl start animehub-api
sleep 3
HEALTH=$(curl -s "$API_HEALTH" || true)
if [ "$HEALTH" = '{"ok":true}' ]; then
  echo "BACKEND UPDATED AND LIVE — new endpoints (quota, creator, super-admin) are serving."
  echo "New DynamoDB tables auto-create on first use. Now update the Firebase sites from Termux."
else
  echo "HEALTH CHECK GOT: ${HEALTH:-<no response>} — check: journalctl -u animehub-api -n 30"
  exit 1
fi
