#!/usr/bin/env bash
# Deploy Anime-Unleashed Frontend to Firebase Hosting
# Usage:
#   ./deploy-firebase.sh [BACKEND_API_URL]
# Example:
#   ./deploy-firebase.sh https://api.yourdomain.com
set -euo pipefail

BACKEND_URL="${1:-}"

if [ -z "$BACKEND_URL" ]; then
  echo "Usage: ./deploy-firebase.sh <BACKEND_API_URL>"
  echo "Example: ./deploy-firebase.sh https://api.animeunleashed.com"
  exit 1
fi

cd /home/ubuntu/animehub/frontend || cd "$(dirname "$0")/../frontend"

echo "==> 1. Setting backend API target in .env..."
echo "REACT_APP_BACKEND_URL=$BACKEND_URL" > .env
echo "VITE_API_URL=$BACKEND_URL" >> .env

echo "==> 2. Installing dependencies and building production bundle..."
yarn install
yarn build

echo "==> 3. Deploying to Firebase Hosting..."
# Ensure you are logged into Firebase via: npx firebase login:ci
npx firebase deploy --only hosting

echo "==> DONE! Frontend live on Firebase Hosting wired to AWS Backend at $BACKEND_URL"
