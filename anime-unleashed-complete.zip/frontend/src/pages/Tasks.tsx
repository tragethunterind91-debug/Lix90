import { useEffect, useRef, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { CalendarClock, ExternalLink, Infinity as InfinityIcon, Loader2, Mail, PartyPopper, ShieldCheck } from "lucide-react";
import { useTasks } from "@/hooks/useSocial";
import { formatBalance } from "@/hooks/useQuota";
import { apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import { useMe } from "@/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import type { Task } from "@/lib/types";

const RULES = [
  "Only the ADMIN posts tasks here — nobody else can create them.",
  "You apply BY EMAIL only — no claiming on the website.",
  "In your mail: your ID no., your name, the task title, and why you fit it. No links.",
  "Visit-link tasks: open the link and stay on it — a 10s countdown runs in the background after 5s away. Come back and claim. Once per task.",
  "Duration = the task is either a countdown or permanent — apply before it ends.",
  "Reward = extra watch-duration. If the admin approves you, it lands on your account.",
];

const GATE_SECONDS = 5; // the countdown only starts after the user has been away 5s
const COUNT_SECONDS = 10; // …then this background countdown unlocks the claim

// Tasks — the notebook's TASK box. Admin posts tasks; viewers apply by email.
// Tasks WITH a link are visit-to-earn: click → stay on the link (the countdown
// runs in the background only while the user is away; pausing when they return,
// never restarting) → claim the reward once.
export default function Tasks() {
  const tasks = useTasks(true);
  const { data: me } = useMe();
  const queryClient = useQueryClient();
  const applyInfo = useQuery({
    queryKey: ["tasks", "apply-email"],
    queryFn: () => apiGet<{ email: string }>("/tasks/apply-email"),
    enabled: !!me,
  });
  const [email, setEmail] = useState("");
  const [linkTask, setLinkTask] = useState<Task | null>(null);
  const [awayCounted, setAwayCounted] = useState(0);
  const [claiming, setClaiming] = useState(false);
  const totalAwayMs = useRef(0);
  const hiddenAt = useRef<number | null>(null);

  useEffect(() => {
    if (applyInfo.data) setEmail(applyInfo.data.email);
  }, [applyInfo.data]);

  // The visit-link mechanic: away-time accumulates ONLY while this tab is hidden
  // (the user is on the link). First 5s away = gate (no countdown), then 10s
  // counted in the background. Returning FREEZES the progress — it resumes on the
  // next away-period, never restarts.
  useEffect(() => {
    if (!linkTask) return;
    totalAwayMs.current = 0;
    hiddenAt.current = null;
    setAwayCounted(0);
    const tick = setInterval(() => {
      if (document.hidden) {
        if (hiddenAt.current == null) hiddenAt.current = Date.now();
        totalAwayMs.current += 500;
      } else {
        hiddenAt.current = null; // back on site — paused, not reset
      }
      setAwayCounted(Math.max(0, Math.floor(totalAwayMs.current / 1000 - GATE_SECONDS)));
    }, 500);
    return () => clearInterval(tick);
  }, [linkTask]);

  function openLinkTask(t: Task) {
    window.open(t.link_url ?? "", "_blank", "noopener");
    setLinkTask(t);
    totalAwayMs.current = 0;
    hiddenAt.current = null;
    setAwayCounted(0);
  }

  async function claimLink(t: Task) {
    setClaiming(true);
    try {
      const res = await apiPost<{ balance_seconds: number }>(`/tasks/${t.id}/link-claim`, {});
      toast.success(`Reward unlocked — wallet: ${formatBalance(res.balance_seconds)}`);
      setLinkTask(null);
      await queryClient.invalidateQueries({ queryKey: ["tasks"] });
      await queryClient.invalidateQueries({ queryKey: ["quota"] });
      await queryClient.invalidateQueries({ queryKey: ["quota", "rewards"] });
    } catch (err) {
      toast.error(apiErrorMessage(err));
    } finally {
      setClaiming(false);
    }
  }

  function mailTo(title: string) {
    const subject = encodeURIComponent(`Task application — ${title}`);
    const body = encodeURIComponent(
      `Task: ${title}\n\nMy ID no.: ${""}\nMy name: ${me?.display_name ?? ""}\n\nWhy I fit this task:\n\n`,
    );
    return `mailto:${email}?subject=${subject}&body=${body}`;
  }

  return (
    <div className="mx-auto max-w-3xl px-0 py-10 sm:px-6" data-testid="tasks-page">
      <h1 className="font-heading text-3xl font-bold tracking-tight text-white" data-testid="tasks-heading">
        Tasks
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Posted by the admin — apply by email, earn extra watch-time.
      </p>

      {/* how to apply — the notebook rules */}
      <Card className="mt-6 border-emerald-500/30 bg-emerald-500/5">
        <CardContent className="px-5 py-5" data-testid="tasks-rules-card">
          <h2 className="flex items-center gap-2 font-heading text-sm font-bold text-white">
            <ShieldCheck className="h-4 w-4 text-emerald-400" aria-hidden /> How it works
          </h2>
          <ul className="mt-3 space-y-2 text-xs leading-relaxed text-zinc-300">
            {RULES.map((rule) => (
              <li key={rule} className="flex gap-2">
                <ShieldCheck className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-emerald-400" aria-hidden />
                {rule}
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <div className="mt-6 space-y-3" data-testid="tasks-list">
        {!me ? (
          <Card className="border-slate-800 bg-card/70">
            <CardContent className="px-5 py-10 text-center text-sm text-muted-foreground">
              Sign in to see open tasks and the application email.
            </CardContent>
          </Card>
        ) : (tasks.data ?? []).length === 0 ? (
          <Card className="border-slate-800 bg-card/70">
            <CardContent className="px-5 py-10 text-center text-sm text-muted-foreground">
              No tasks right now — the admin posts them here.
            </CardContent>
          </Card>
        ) : (
          (tasks.data ?? []).map((t) => {
            const left = t.expires_at ? Math.max(0, Math.floor((new Date(t.expires_at).getTime() - Date.now()) / 1000)) : null;
            const isLinkTask = !!t.link_url;
            const linkCounting = linkTask?.id === t.id;
            const linkReady = linkCounting && awayCounted >= COUNT_SECONDS;
            return (
              <Card key={t.id} className="border-slate-800 bg-card/70" data-testid={`task-${t.id}`}>
                <CardContent className="flex flex-wrap items-center gap-3 px-5 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-white" data-testid={`task-title-${t.id}`}>{t.title}</p>
                    {t.description ? <p className="mt-0.5 text-xs leading-relaxed text-zinc-400">{t.description}</p> : null}
                    <div className="mt-1.5 flex flex-wrap items-center gap-2 text-xs">
                      <Badge className="bg-emerald-500/15 text-emerald-300" data-testid={`task-reward-${t.id}`}>
                        Reward: +{formatBalance(t.reward_seconds)} watch-time
                      </Badge>
                      <Badge className={t.permanent ? "bg-slate-600/30 text-zinc-300" : "bg-amber-400/15 text-amber-300"} data-testid={`task-duration-${t.id}`}>
                        {t.permanent ? (
                          <><InfinityIcon className="mr-1 h-3 w-3" aria-hidden /> Permanent</>
                        ) : (
                          <><CalendarClock className="mr-1 h-3 w-3" aria-hidden /> {left !== null && left > 0 ? `${Math.ceil(left / 3600)}h left` : "ending"}</>
                        )}
                      </Badge>
                    </div>

                    {/* visit-link mechanic */}
                    {isLinkTask ? (
                      t.link_claimed_by_me ? (
                        <div className="mt-3" data-testid={`task-link-earned-${t.id}`}>
                          <Badge className="bg-emerald-500/15 text-emerald-300">
                            <PartyPopper className="mr-1 h-3 w-3" aria-hidden /> Link reward earned
                          </Badge>
                        </div>
                      ) : linkReady ? (
                        <button
                          onClick={() => void claimLink(t)}
                          disabled={claiming}
                          className="mt-3 inline-flex items-center gap-2 rounded-md bg-emerald-400 px-4 py-2 text-xs font-bold text-slate-950 hover:bg-emerald-300"
                          data-testid={`task-link-claim-${t.id}`}
                        >
                          {claiming ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <PartyPopper className="h-4 w-4" aria-hidden />}
                          Claim +{formatBalance(t.reward_seconds)}
                        </button>
                      ) : linkCounting ? (
                        <div className="mt-3" data-testid={`task-link-progress-${t.id}`}>
                          <p className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">
                            {document.hidden ? "counting while you're away…" : `stay on the link — ${Math.max(0, awayCounted)}/${COUNT_SECONDS}s`}
                          </p>
                          <span className="mt-1 block h-2 w-44 overflow-hidden rounded-full bg-slate-800">
                            <span
                              className="block h-full rounded-full bg-sky-400 transition-all"
                              style={{ width: `${(Math.max(0, awayCounted) / COUNT_SECONDS) * 100}%` }}
                            />
                          </span>
                          <p className="mt-1 text-[10px] text-zinc-500">Leaving the site pauses it — it never restarts.</p>
                        </div>
                      ) : (
                        <button
                          onClick={() => openLinkTask(t)}
                          className="mt-3 inline-flex items-center gap-2 rounded-md border border-sky-500/50 px-4 py-2 text-xs font-bold text-sky-300 hover:bg-sky-500/10"
                          data-testid={`task-link-open-${t.id}`}
                        >
                          <ExternalLink className="h-3.5 w-3.5" aria-hidden />
                          {t.link_label || "Open link & earn"}
                        </button>
                      )
                    ) : null}
                  </div>
                  {email ? (
                    <a
                      href={mailTo(t.title)}
                      className={buttonVariants({ className: "bg-sky-400 font-bold text-slate-950 hover:bg-sky-300" })}
                      data-testid={`task-apply-mail-${t.id}`}
                    >
                      <Mail className="mr-2 h-4 w-4" aria-hidden /> Apply by email
                    </a>
                  ) : null}
                </CardContent>
              </Card>
            );
          })
        )}
      </div>
    </div>
  );
}
