import { Link } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { BadgeCheck, Loader2, UserMinus, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { ChannelInfo } from "@/lib/types";
import { useMe } from "@/hooks/useAuth";

// Public channel directory — discover every verified publisher (logo, bio,
// followers, videos) and follow them; followed channels show up on Home.
export default function Channels() {
  const qc = useQueryClient();
  const { data: me } = useMe();
  const channels = useQuery({
    queryKey: ["channels"],
    queryFn: () => apiGet<ChannelInfo[]>("/channels"),
  });
  const follows = useQuery({
    queryKey: ["engagement", "my-follows"],
    queryFn: () => apiGet<string[]>("/engagement/my-follows"),
    enabled: !!me,
  });

  const follow = useMutation({
    mutationFn: (channelUserId: string) => apiPost<{ following: boolean }>("/engagement/follow", { channel_user_id: channelUserId }),
    onSuccess: (d) => {
      toast.success(d.following ? "Following — their videos now appear on your Home" : "Unfollowed");
      void qc.invalidateQueries({ queryKey: ["engagement", "my-follows"] });
      void qc.invalidateQueries({ queryKey: ["channels"] });
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8" data-testid="channels-page">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl">Publisher channels</h1>
      <p className="mt-1 text-sm text-zinc-400">
        Creators with their own space — follow a channel and its videos come to your Home.
      </p>

      {channels.isLoading ? (
        <p className="flex items-center gap-2 py-16 text-sm text-zinc-500" data-testid="channels-loading">
          <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Loading channels…
        </p>
      ) : !(channels.data ?? []).length ? (
        <Card className="mt-8 border-slate-800 bg-card/70">
          <CardContent className="p-10 text-center text-sm text-zinc-500" data-testid="channels-empty">
            No verified channels yet — publishers appear here the moment their channel is approved.
          </CardContent>
        </Card>
      ) : (
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3" data-testid="channels-grid">
          {(channels.data ?? []).map((c) => {
            const following = (follows.data ?? []).includes(c.user_id);
            return (
              <Card key={c.user_id} className="border-slate-800 bg-card/70 transition-colors hover:border-amber-400/30">
                <CardContent className="p-5">
                  <div className="flex items-center gap-3">
                    {c.logo ? (
                      <img src={c.logo} alt="" className="h-12 w-12 rounded-full border border-amber-400/40 object-cover" />
                    ) : (
                      <span className="flex h-12 w-12 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-rose-500 font-heading text-lg font-black text-white">
                        {(c.name || "?").slice(0, 1).toUpperCase()}
                      </span>
                    )}
                    <div className="min-w-0 flex-1">
                      <Link to={`/channel/${c.user_id}`} className="flex items-center gap-1 truncate font-heading font-bold text-white hover:text-amber-400" data-testid={`channel-link-${c.user_id}`}>
                        {c.name} <BadgeCheck className="h-4 w-4 flex-shrink-0 text-sky-400" aria-hidden />
                      </Link>
                      <p className="text-xs text-zinc-500">{c.followers.toLocaleString("en-IN")} followers · {c.videos ?? 0} videos</p>
                    </div>
                  </div>
                  {c.bio ? <p className="mt-3 line-clamp-2 text-xs text-zinc-400">{c.bio}</p> : null}
                  <div className="mt-4 flex gap-2">
                    <Button
                      size="sm"
                      onClick={() => follow.mutate(c.user_id)}
                      disabled={follow.isPending || !me}
                      className={following ? "flex-1 border border-slate-700 bg-transparent text-zinc-300 hover:bg-white/5" : "flex-1 bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"}
                      data-testid={`channel-follow-btn-${c.user_id}`}
                    >
                      {follow.isPending ? <Loader2 className="mr-1.5 h-3.5 w-3.5 animate-spin" aria-hidden /> : following ? <UserMinus className="mr-1.5 h-3.5 w-3.5" aria-hidden /> : <UserPlus className="mr-1.5 h-3.5 w-3.5" aria-hidden />}
                      {following ? "Following" : "Follow"}
                    </Button>
                    <Link
                      to={`/channel/${c.user_id}`}
                      className="inline-flex h-8 items-center justify-center rounded-md border border-slate-700 px-3 text-xs font-bold text-zinc-300 hover:bg-white/5"
                      data-testid={`channel-visit-${c.user_id}`}
                    >
                      Visit
                    </Link>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
      {!me ? (
        <p className="mt-6 text-center text-xs text-zinc-600">
          <Link to="/login" className="font-bold text-amber-400 hover:underline">Sign in</Link> to follow channels.
        </p>
      ) : null}
    </div>
  );
}
