import { useEffect, useMemo, useRef, useState } from "react";
import { Share2, ThumbsDown, ThumbsUp } from "lucide-react";
import { AudioLines, Captions, Lock } from "lucide-react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { themeClassFor } from "@/lib/kinds";
import { useMe } from "@/hooks/useAuth";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { ArrowLeft, ChevronLeft, ChevronRight, Download, Loader2, Music, Tv } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ApiError, apiGet, apiGetBlob, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { DirectDownload, DownloadCheckOut, DownloadLink, Episode, QuotaInfo, TitleDetail } from "@/lib/types";
import { formatBytes, formatCount, formatDate, formatDuration } from "@/lib/badges";
import EmptyState from "@/components/EmptyState";
import AdSlot from "@/components/AdSlot";
import RefillModal from "@/components/RefillModal";
import { useQuota } from "@/hooks/useQuota";
import { mediaUrl } from "@/lib/api";
import { HeroSkeleton } from "@/components/Skeletons";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";

import { Minimize2, Maximize2 } from "lucide-react";
// Theater mode: sticky-ish player + episode rail + time-limited signed download links.
export default function Watch() {
  const { slug, ep } = useParams<{ slug: string; ep: string }>();
  const navigate = useNavigate();
  const episodeNumber = Number.parseInt(ep ?? "1", 10);

  const title = useQuery({
    queryKey: ["title", slug],
    queryFn: () => apiGet<TitleDetail>(`/titles/${slug ?? ""}`),
    retry: false,
  });

  const episodes = useMemo(
    () => title.data?.episodes ?? [],
    [title.data],
  );
  const { data: me } = useMe();
  const isVip = !!me && (me.role === "admin" || (!!me.vip_until && new Date(me.vip_until) > new Date()));
  // watch-time economy: signed-in FREE viewers spend balance — VIP/staff/guests don't
  const limitedViewer = !!me && me.role === "user" && !isVip;
  const [refillOpen, setRefillOpen] = useState(false);
  const [refillNeeds, setRefillNeeds] = useState<number | null>(null);
  const [subLang, setSubLang] = useState<"en" | "hi">("en");
  const [isMiniPlayer, setIsMiniPlayer] = useState(false);
  const current =
    episodes.find((e) => e.id === ep) ??
    episodes.find((e) => e.number === Number.parseInt(ep ?? "1", 10)) ??
    episodes[0];

  // episodes grouped by season for the rail (S1, S2, …)
  const queryClient = useQueryClient();

  const translateHi = useMutation({
    mutationFn: () => apiPost(`/episodes/${current.id}/subtitles/translate`, { target: "hi" }),
    onSuccess: () => {
      toast.success("Subtitles translated to हिंदी — timings unchanged");
      setSubLang("hi");
      void queryClient.invalidateQueries({ queryKey: ["titles", slug] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });

  const seasonGroups = useMemo(() => {
    const map = new Map<number, Episode[]>();
    for (const item of episodes) {
      const s = item.season ?? 1;
      if (!map.has(s)) map.set(s, []);
      map.get(s)!.push(item);
    }
    return [...map.entries()]
      .sort((a, b) => a[0] - b[0])
      .map(([season, items]) => ({ season, items }));
  }, [episodes]);

  // ---- resume playback per episode (localStorage) ----
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !current) return;
    const saved = Number(localStorage.getItem(`ah-ep-${current.id}`) ?? "0");
    let lastSave = 0;
    const onLoaded = () => {
      if (saved > 5 && Number.isFinite(video.duration) && saved < video.duration - 5) {
        video.currentTime = saved;
      }
    };
    const onTimeUpdate = () => {
      const now = Date.now();
      if (now - lastSave > 5000) {
        lastSave = now;
        localStorage.setItem(`ah-ep-${current.id}`, String(Math.floor(video.currentTime)));
      }
    };
    video.addEventListener("loadedmetadata", onLoaded);
    video.addEventListener("timeupdate", onTimeUpdate);
    return () => {
      video.removeEventListener("loadedmetadata", onLoaded);
      video.removeEventListener("timeupdate", onTimeUpdate);
    };
  }, [current]);

  // ---- signed download link (video per-resolution / audio-only) ----
  const [link, setLink] = useState<DownloadLink | null>(null);
  const [remaining, setRemaining] = useState(0);
  const download = useMutation<DownloadLink, ApiError, { id: string; format: "video" | "audio"; resolution?: string }>({
    mutationFn: ({ id, format, resolution }) =>
      apiPost<DownloadLink>(`/videos/${id}/download-link`, { format, resolution: resolution ?? null }),
  });

  useEffect(() => {
    if (!link) return;
    const tick = () => {
      const ms = new Date(link.expires_at).getTime() - Date.now();
      setRemaining(Math.max(0, Math.floor(ms / 1000)));
      if (ms <= 0) setLink(null);
    };
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [link]);

  function triggerBrowserDownload(url: string) {
    const anchor = document.createElement("a");
    anchor.href = url;
    anchor.rel = "noreferrer";
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    toast.success("Download link ready — valid for 10 minutes");
  }

  async function requestDownload(episodeId: string, format: "video" | "audio" = "video", resolution?: string) {
    if (format === "video") {
      // DIRECT download — original file, no protected-copy processing.
      // 4 lifetime downloads per video for free users; VIP unlimited.
      try {
        const data = await apiGet<DirectDownload>(`/videos/${episodeId}/direct-download`);
        triggerBrowserDownload(mediaUrl(data.url));
        toast.success(
          data.remaining === null
            ? "Download started — VIP downloads are unlimited"
            : `Download started — ${data.remaining} left for this video (lifetime)`,
        );
      } catch (error) {
        if (error instanceof ApiError && error.status === 401) {
          toast.info("Sign in to download episodes");
          navigate("/login");
        } else {
          toast.error(apiErrorMessage(error));
        }
      }
      return;
    }
    setLink(null);
    download.mutate(
      { id: episodeId, format, resolution },
      {
        onSuccess: async (data) => {
          const url = mediaUrl(data.url);
          setLink({ ...data, url });
          triggerBrowserDownload(url);
        },
        onError: (error) => {
          if (error.status === 401) {
            toast.info("Sign in to download episodes");
            navigate("/login");
          } else if (error.status === 404) {
            toast.error("That variant isn't converted yet — it builds automatically after upload");
          } else {
            toast.error(apiErrorMessage(error));
          }
        },
      },
    );
  }

  async function downloadSubtitle(lang: "en" | "hi") {
    if (!current) return;
    try {
      const blob = await apiGetBlob(`/videos/${current.id}/subtitles/${lang}/download`);
      const url = URL.createObjectURL(blob);
      const anchor = document.createElement("a");
      anchor.href = url;
      anchor.download = `episode-${current.number}-${lang}.vtt`;
      document.body.appendChild(anchor);
      anchor.click();
      anchor.remove();
      URL.revokeObjectURL(url);
      toast.success(`Subtitles (${lang === "hi" ? "हिंदी" : "English"}) downloaded`);
    } catch (error) {
      if (error instanceof ApiError && error.status === 403) toast.error("Subtitle downloads are VIP-only — go VIP for ₹66/2 months");
      else toast.error(apiErrorMessage(error));
    }
  }

  // ---- resolution switcher (convert system) ----
  const [res, setRes] = useState("auto");
  useEffect(() => {
    setRes("auto");
  }, [current?.id]);
  const variants = current?.video_variants ?? {};
  const readyRes = Object.entries(variants).filter(([, v]) => v.status === "ready" && v.key !== variants.audio?.key);
  // switching quality keeps your place (resume checkpoint is saved every 5s)
  useEffect(() => {
    const video = videoRef.current;
    if (!video || !current) return;
    const saved = Number(localStorage.getItem(`ah-ep-${current.id}`) ?? "0");
    const restore = () => {
      if (saved > 5 && Number.isFinite(video.duration) && saved < video.duration - 5) video.currentTime = saved;
    };
    video.addEventListener("loadedmetadata", restore, { once: true });
    return () => video.removeEventListener("loadedmetadata", restore);
  }, [res, current?.id, current?.video_key]);

  const videoRef = useRef<HTMLVideoElement>(null);

  // Count a view + record watch history once per episode open (StrictMode double-fire guarded).
  const viewPingRef = useRef<string | null>(null);
  useEffect(() => {
    if (!title.data || !current || viewPingRef.current === current.id) return;
    viewPingRef.current = current.id;
    apiPost(`/titles/${title.data.id}/view`).catch(() => {});
    // history ping — guests get a silent 401
    apiPost("/history", {
      title_id: title.data.id,
      episode_id: current.id,
      position_seconds: videoRef.current?.currentTime ?? 0,
    }).catch(() => {});
  }, [current, title.data]);

  // Keep the resume position fresh in history while the video plays.
  useEffect(() => {
    if (!title.data || !current) return;
    const timer = setInterval(() => {
      const video = videoRef.current;
      if (video && video.currentTime > 0) {
        apiPost("/history", {
          title_id: title.data.id,
          episode_id: current.id,
          position_seconds: video.currentTime,
        }).catch(() => {});
      }
    }, 15000);
    return () => clearInterval(timer);
  }, [current, title.data]);

  // ---- watch-time metering: 15s of real playback spends 15s of balance (free accounts) ----
  const quota = useQuota(limitedViewer);
  useEffect(() => {
    if (!limitedViewer || !current) return;
    const timer = setInterval(() => {
      const video = videoRef.current;
      if (video && !video.paused && video.currentTime > 0) {
        // audio-only streams have no video track (videoWidth 0) — accrue at 0.5x (owner rule)
        const mode = video.videoWidth === 0 ? "audio" : "video";
        apiPost<QuotaInfo>("/quota/consume", { episode_id: current.id, seconds: 15, mode })
          .then((q) => {
            if (q.mode === "limited" && q.balance_seconds <= 0) {
              video.pause();
              setRefillNeeds(null);
              setRefillOpen(true);
            }
          })
          .catch(() => {});
      }
    }, 15000);
    return () => clearInterval(timer);
  }, [limitedViewer, current]);

  // out of time the moment they arrive → open the refill popup once
  const autoOpenedRef = useRef(false);
  useEffect(() => {
    if (!limitedViewer || autoOpenedRef.current || !quota.data) return;
    if (quota.data.balance_seconds <= 0) {
      autoOpenedRef.current = true;
      setRefillOpen(true);
    }
  }, [limitedViewer, quota.data]);

  if (title.isLoading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <HeroSkeleton />
      </div>
    );
  }
  if (title.isError || !title.data) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <EmptyState
          icon={Tv}
          title="Title not found"
          message="This anime may have been unpublished or the link is wrong."
          actionLabel="Back to Browse"
          onAction={() => window.location.assign("/browse")}
          testId="watch-not-found"
        />
      </div>
    );
  }
  if (!current) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <EmptyState
          icon={Tv}
          title="Episode not available"
          message={`That episode isn't published for ${title.data.name}.`}
          actionLabel="Back to title"
          onAction={() => navigate(`/title/${title.data!.slug}`)}
          testId="watch-episode-missing"
        />
      </div>
    );
  }

  const prev = episodes.find((e) => e.number === current.number - 1);
  const next = episodes.find((e) => e.number === current.number + 1);
  const mm = String(Math.floor(remaining / 60)).padStart(2, "0");
  const ss = String(remaining % 60).padStart(2, "0");

  return (
    <div className={`mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8 ${themeClassFor(title.data.kind)}`}>
      <div className="flex flex-col gap-6 lg:flex-row">
        {/* theater column */}
        <div className="min-w-0 flex-1">
          <div
            className={`overflow-hidden rounded-xl border border-slate-800 bg-[#030407] transition-all duration-300 ${
              isMiniPlayer
                ? "fixed bottom-6 right-6 z-50 w-80 sm:w-96 shadow-[0_20px_50px_rgba(0,0,0,0.8)] border-amber-400/40"
                : "w-full"
            }`}
            data-testid="player-container"
          >
            {isMiniPlayer && (
              <div className="flex items-center justify-between bg-slate-950/90 px-3 py-1.5 text-xs text-zinc-300 border-b border-slate-800">
                <span className="truncate font-semibold">{current.name}</span>
                <button
                  type="button"
                  onClick={() => setIsMiniPlayer(false)}
                  className="rounded p-1 hover:bg-white/10 hover:text-white"
                  aria-label="Expand player"
                >
                  <Maximize2 className="h-3.5 w-3.5 text-amber-400" />
                </button>
              </div>
            )}
            <video
              ref={videoRef}
              key={current.id}
              controls
              preload="metadata"
              poster={current.thumbnail_url || title.data.poster_url || undefined}
              src={mediaUrl(`/api/stream/${current.video_key}`)}
              onError={() =>
                toast.error("Video stream unavailable.")
              }
              className="aspect-video w-full bg-black"
              data-testid="player-video"
            >
              {isVip && current.subtitle_key ? (
                <track
                  key={subLang === "hi" && current.subtitle_variants?.hi ? "hi" : "en"}
                  kind="subtitles"
                  label={subLang === "hi" ? "हिंदी" : "English"}
                  srcLang={subLang === "hi" ? "hi" : "en"}
                  default
                  src={mediaUrl(`/api/episodes/${current.id}/subtitles${subLang === "hi" && current.subtitle_variants?.hi ? "?lang=hi" : ""}`)}
                  data-testid="vip-subtitle-track"
                />
              ) : (
                <track kind="captions" />
              )}
            </video>
          </div>

          {/* VIP dub-audio + subtitle tracks (locked for free users) */}
          {(current.audio_key || current.subtitle_key) && (
            <div className="mt-3 flex flex-wrap items-center gap-3" data-testid="vip-tracks-row">
              {current.audio_key ? (
                isVip ? (
                  <div className="flex items-center gap-2 rounded-xl border border-[#FF2A85]/40 bg-[#FF2A85]/10 px-3 py-2">
                    <AudioLines className="h-4 w-4 text-[#FF2A85]" aria-hidden />
                    <span className="text-xs font-bold text-white">Dub audio (VIP)</span>
                    <audio controls preload="none" src={mediaUrl(`/api/episodes/${current.id}/audio-stream`)} className="h-8 max-w-56" data-testid="vip-audio-player" />
                  </div>
                ) : (
                  <Link to="/vip" className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900/70 px-3 py-2 text-xs font-bold text-zinc-300 hover:border-[#FF2A85]/50" data-testid="vip-audio-locked">
                    <Lock className="h-3.5 w-3.5 text-[#FF2A85]" aria-hidden /> Dub audio — VIP only
                  </Link>
                )
              ) : null}
              {current.subtitle_key ? (
                isVip ? (
                  <div className="flex items-center gap-2 rounded-xl border border-emerald-500/40 bg-emerald-500/10 px-3 py-2" data-testid="vip-subs-box">
                    <Captions className="h-4 w-4 text-emerald-300" aria-hidden />
                    <button
                      onClick={() => setSubLang("en")}
                      className={`rounded px-2 py-0.5 text-xs font-bold ${subLang === "en" ? "bg-emerald-500/30 text-white" : "text-emerald-300/70 hover:text-emerald-200"}`}
                      data-testid="subs-lang-en"
                    >
                      EN
                    </button>
                    <button
                      onClick={() => (current.subtitle_variants?.hi ? setSubLang("hi") : translateHi.mutate())}
                      disabled={translateHi.isPending}
                      className={`flex items-center gap-1 rounded px-2 py-0.5 text-xs font-bold ${subLang === "hi" ? "bg-emerald-500/30 text-white" : "text-emerald-300/70 hover:text-emerald-200"}`}
                      data-testid="subs-lang-hi"
                    >
                      {translateHi.isPending ? <Loader2 className="h-3 w-3 animate-spin" aria-hidden /> : null}
                      हिं
                    </button>
                    <span className="text-xs font-bold text-emerald-300">
                      {subLang === "hi" ? "हिंदी अनुवाद" : "Subtitles on"}
                    </span>
                  </div>
                ) : (
                  <Link to="/vip" className="flex items-center gap-2 rounded-xl border border-slate-700 bg-slate-900/70 px-3 py-2 text-xs font-bold text-zinc-300 hover:border-emerald-500/50" data-testid="vip-subs-locked">
                    <Lock className="h-3.5 w-3.5 text-emerald-400" aria-hidden /> Subtitles — VIP only
                  </Link>
                )
              ) : null}
            </div>
          )}

          <div className="mt-4 flex flex-wrap items-center gap-3">
            <Button
              variant="ghost"
              size="sm"
              onClick={() => navigate(`/title/${title.data!.slug}`)}
              data-testid="player-back-btn"
              className="text-zinc-300"
            >
              <ArrowLeft className="mr-1.5 h-4 w-4" aria-hidden /> {title.data.name}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setIsMiniPlayer((m) => !m)}
              data-testid="player-mini-toggle-btn"
              className="border-slate-700 text-zinc-300"
            >
              {isMiniPlayer ? (
                <>
                  <Maximize2 className="mr-1.5 h-4 w-4" /> Expand Theater
                </>
              ) : (
                <>
                  <Minimize2 className="mr-1.5 h-4 w-4" /> Mini Player
                </>
              )}
            </Button>
            <div className="ml-auto flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                disabled={!prev}
                onClick={() => prev && navigate(`/watch/${slug}/${prev.number}`)}
                data-testid="player-prev-episode-btn"
                className="border-slate-700"
              >
                <ChevronLeft className="h-4 w-4" aria-hidden /> Prev
              </Button>
              <Button
                variant="outline"
                size="sm"
                disabled={!next}
                onClick={() => next && navigate(`/watch/${slug}/${next.number}`)}
                data-testid="player-next-episode-btn"
                className="border-slate-700"
              >
                Next <ChevronRight className="h-4 w-4" aria-hidden />
              </Button>
            </div>
          </div>

          <div className="mt-4 rounded-2xl border border-slate-800 bg-card/70 p-5" data-testid="watch-episode-info">
            <div className="flex flex-wrap items-center gap-2">
              <Badge className="bg-amber-400 text-slate-950">Episode {current.number}</Badge>
              <h1 className="font-heading text-lg font-bold text-white sm:text-xl">{current.name}</h1>
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
              {current.resolution ? (
                <span className="rounded bg-violet-500/20 px-2 py-0.5 font-bold text-violet-300" data-testid="watch-resolution-badge">
                  {current.resolution}
                </span>
              ) : null}
              {current.dub_tag ? (
                <span className="rounded bg-emerald-500/20 px-2 py-0.5 font-bold text-emerald-300" data-testid="watch-dubtag-badge">
                  D/C: {current.dub_tag}
                </span>
              ) : null}
              {current.duration_seconds ? <span>{formatDuration(current.duration_seconds)}</span> : null}
              {current.source ? (
                <span className="rounded bg-sky-500/20 px-2 py-0.5 font-bold text-sky-300" data-testid="watch-source-badge">
                  Source: {current.source}
                </span>
              ) : null}
              <span data-testid="watch-language-badge">Language: {title.data?.original_language || title.data?.audio.join(", ") || "Eng Sub"}</span>
              {title.data?.age_rating ? (
                <span className="rounded bg-rose-500/20 px-2 py-0.5 font-bold text-rose-300" data-testid="watch-age-badge">
                  {title.data.age_rating}
                </span>
              ) : null}
              {title.data?.studio ? (
                <span data-testid="watch-studio-badge">Studio: {title.data.studio}</span>
              ) : null}
              <span>Launched {title.data?.release_year}</span>
              {current.size_bytes ? <span>{formatBytes(current.size_bytes)}</span> : null}
              {title.data.views ? <span>{formatCount(title.data.views)} views</span> : null}
              {current.created_at ? <span>Added {formatDate(current.created_at)}</span> : null}
            </div>
            {current.description ? (
              <p className="mt-3 max-w-prose text-sm leading-relaxed text-zinc-300" data-testid="watch-episode-description">
                {current.description}
              </p>
            ) : null}
            {me?.role === "admin" && (
              <div className="mt-4 flex flex-wrap items-center gap-3">
                <DropdownMenu>
                  <DropdownMenuTrigger
                    disabled={download.isPending}
                    data-testid="player-download-btn"
                    className="inline-flex h-9 items-center justify-center gap-2 rounded-md bg-amber-400 px-4 text-sm font-bold text-slate-950 transition-colors hover:bg-amber-300 disabled:opacity-50"
                  >
                    {download.isPending ? (
                      <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                    ) : (
                      <Download className="h-4 w-4" aria-hidden />
                    )}
                    Admin Download
                  </DropdownMenuTrigger>
                  <DropdownMenuContent className="border-slate-800 bg-[#121622]" data-testid="download-menu">
                    <DropdownMenuGroup>
                      <DropdownMenuLabel className="text-xs text-zinc-400">Video</DropdownMenuLabel>
                      <DropdownMenuItem onClick={() => requestDownload(current.id, "video")} data-testid="download-video-original">
                        <Download className="mr-2 h-4 w-4" aria-hidden /> Original ({current.resolution || "source"})
                      </DropdownMenuItem>
                    </DropdownMenuGroup>
                    {variants.audio?.status === "ready" ? (
                      <DropdownMenuGroup>
                        <DropdownMenuLabel className="text-xs text-zinc-400">Audio</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => requestDownload(current.id, "audio")} data-testid="download-audio">
                          <Music className="mr-2 h-4 w-4" aria-hidden /> Audio only (m4a)
                        </DropdownMenuItem>
                      </DropdownMenuGroup>
                    ) : null}
                    {current.subtitle_key || (current.subtitle_variants && Object.keys(current.subtitle_variants).length > 0) ? (
                      <DropdownMenuGroup>
                        <DropdownMenuLabel className="text-xs text-zinc-400">Subtitles</DropdownMenuLabel>
                        <DropdownMenuItem onClick={() => void downloadSubtitle("en")} data-testid="download-subs-en">
                          <Captions className="mr-2 h-4 w-4" aria-hidden /> Subtitles · English (.vtt)
                        </DropdownMenuItem>
                        {current.subtitle_variants?.hi ? (
                          <DropdownMenuItem onClick={() => void downloadSubtitle("hi")} data-testid="download-subs-hi">
                            <Captions className="mr-2 h-4 w-4" aria-hidden /> Subtitles · हिंदी (.vtt)
                          </DropdownMenuItem>
                        ) : null}
                      </DropdownMenuGroup>
                    ) : null}
                  </DropdownMenuContent>
                </DropdownMenu>
                {remaining > 0 && link ? (
                  <span
                    className="rounded-full border border-emerald-500/40 bg-emerald-500/10 px-3 py-1 text-xs font-bold text-emerald-400"
                    data-testid="download-countdown-pill"
                  >
                    Link valid for {mm}:{ss} mins
                  </span>
                ) : null}
              </div>
            )}
          </div>

          <EngagementBar episodeId={current.id} />

          {/* ad: watch page (hidden for VIP) */}
          <AdSlot slot="watch" className="mb-4" />
        </div>

        {/* episode rail */}
        <aside className="w-full flex-shrink-0 lg:w-80">
          <h2 className="font-heading text-sm font-bold uppercase tracking-widest text-zinc-400">
            {title.data?.kind === "anime" ? "Chapters" : "Episodes"} ({episodes.length})
          </h2>
          {seasonGroups.map((group) => (
            <div key={group.season}>
              {seasonGroups.length > 1 ? (
                <h3
                  className="mt-4 flex items-center gap-2 font-heading text-xs font-bold uppercase tracking-widest text-amber-400/90"
                  data-testid={`season-heading-${group.season}`}
                >
                  <span className="h-px flex-1 bg-amber-400/20" /> Season {group.season} <span className="h-px flex-1 bg-amber-400/20" />
                </h3>
              ) : null}
              <ul className="mt-2 space-y-2" data-testid="watch-episode-list">
                {group.items.map((episode) => {
              const active = episode.id === current.id;
              return (
                <li key={episode.id} className="flex items-stretch gap-2">
                  <button
                    onClick={() => navigate(`/watch/${slug}/${episode.id}`)}
                    data-testid={`episode-switch-btn-${episode.id}`}
                    className={`flex-1 rounded-xl border px-3 py-2.5 text-left transition-colors ${
                      active
                        ? "border-amber-400/60 bg-amber-400/10"
                        : "border-slate-800 bg-card/70 hover:border-slate-600"
                    }`}
                  >
                    <p className={`text-sm font-semibold ${active ? "text-amber-400" : "text-white"}`}>
                      {title.data?.kind === "anime" ? "Ch." : "Ep."} {episode.number} · {episode.name}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      {episode.resolution ? `${episode.resolution} · ` : ""}
                      {episode.dub_tag ? `D/C ${episode.dub_tag} · ` : ""}
                      {formatDuration(episode.duration_seconds)}
                      {episode.size_bytes ? ` · ${formatBytes(episode.size_bytes)}` : ""}
                    </p>
                  </button>
                  {me?.role === "admin" && (
                    <button
                      onClick={() => requestDownload(episode.id)}
                      aria-label={`Download episode ${episode.number}`}
                      data-testid={`episode-download-btn-${episode.id}`}
                      className="flex w-10 items-center justify-center rounded-xl border border-slate-800 bg-card/70 text-zinc-400 transition-colors hover:border-amber-400/50 hover:text-amber-400"
                    >
                      <Download className="h-4 w-4" aria-hidden />
                    </button>
                  )}
                </li>
              );
              })}
              </ul>
            </div>
          ))}
        </aside>
      </div>

      <RefillModal open={refillOpen} onOpenChange={setRefillOpen} requiredSeconds={refillNeeds} />
    </div>
  );
}


// ---- engagement (owner batch): like / dislike / share / comments ----
type Engagement = { my_reaction: number; likes: number; dislikes: number; comments: { id: string; name: string; text: string; created_at: string }[] };

function EngagementBar({ episodeId }: { episodeId: string }) {
  const qc = useQueryClient();
  const { data: me } = useMe();
  const eng = useQuery({
    queryKey: ["engagement", episodeId],
    queryFn: () =>
      apiGet<{ my_reaction: number; likes: number; dislikes: number; comments: { id: string; name: string; text: string; created_at: string }[] }>(`/engagement/${episodeId}`),
    enabled: !!me,
  });
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);

  async function react(val: 1 | -1) {
    setBusy(true);
    try {
      await apiPost("/engagement/react", { episode_id: episodeId, val });
      void qc.invalidateQueries({ queryKey: ["engagement", episodeId] });
    } catch (e) {
      toast.error(apiErrorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  async function comment(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim()) return;
    setBusy(true);
    try {
      await apiPost(`/engagement/${episodeId}/comment`, { text: text.trim() });
      setText("");
      void qc.invalidateQueries({ queryKey: ["engagement", episodeId] });
    } catch (e) {
      toast.error(apiErrorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  if (!me) {
    return (
      <p className="mt-4 rounded-xl border border-slate-800 bg-card/60 p-4 text-xs text-zinc-500" data-testid="engagement-guest">
        <Link to="/login" className="font-bold text-amber-400 hover:underline" data-testid="engagement-login-link">Sign in</Link> to like, dislike and comment — it keeps the community clean.
      </p>
    );
  }

  const mine = eng.data?.my_reaction ?? 0;
  return (
    <section className="mt-4 rounded-xl border border-slate-800 bg-card/60 p-4" data-testid="engagement-bar">
      <div className="flex flex-wrap items-center gap-2">
        <Button
          size="sm"
          variant="outline"
          disabled={busy}
          onClick={() => void react(1)}
          className={mine === 1 ? "border-emerald-500/50 bg-emerald-500/10 text-emerald-300" : "border-slate-700 text-zinc-300"}
          data-testid="engagement-like-btn"
        >
          <ThumbsUp className="mr-1.5 h-3.5 w-3.5" aria-hidden /> {eng.data?.likes ?? 0}
        </Button>
        <Button
          size="sm"
          variant="outline"
          disabled={busy}
          onClick={() => void react(-1)}
          className={mine === -1 ? "border-rose-500/50 bg-rose-500/10 text-rose-300" : "border-slate-700 text-zinc-300"}
          data-testid="engagement-dislike-btn"
        >
          <ThumbsDown className="mr-1.5 h-3.5 w-3.5" aria-hidden /> {eng.data?.dislikes ?? 0}
        </Button>
        <Button
          size="sm"
          variant="outline"
          className="border-slate-700 text-zinc-300"
          onClick={() => {
            void navigator.clipboard.writeText(window.location.href);
            toast.success("Episode link copied — share it anywhere");
          }}
          data-testid="engagement-share-btn"
        >
          <Share2 className="mr-1.5 h-3.5 w-3.5" aria-hidden /> Share
        </Button>
      </div>

      <form onSubmit={comment} className="mt-3 flex gap-2" data-testid="engagement-comment-form">
        <Input
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Add a comment…"
          className="border-slate-700 bg-slate-900/70 text-sm"
          data-testid="engagement-comment-input"
        />
        <Button size="sm" type="submit" disabled={busy || !text.trim()} className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" data-testid="engagement-comment-submit">
          Post
        </Button>
      </form>

      <ul className="mt-3 space-y-2" data-testid="engagement-comments">
        {(eng.data?.comments ?? []).map((c) => (
          <li key={c.id} className="rounded-lg bg-slate-900/60 px-3 py-2 text-sm" data-testid="engagement-comment">
            <p className="text-xs font-bold text-amber-300">{c.name || "fan"} <span className="ml-1 font-normal text-zinc-600">{c.created_at.slice(0, 10)}</span></p>
            <p className="text-zinc-300">{c.text}</p>
          </li>
        ))}
        {!(eng.data?.comments ?? []).length ? <li className="text-xs text-zinc-600">Be the first to comment.</li> : null}
      </ul>
    </section>
  );
}
