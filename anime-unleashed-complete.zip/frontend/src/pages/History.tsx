import { useNavigate } from "react-router-dom";
import { History as HistoryIcon, LogIn, Play, Trash2 } from "lucide-react";
import { mediaUrl } from "@/lib/api";
import { useMe } from "@/hooks/useAuth";
import { useClearHistory, useHistory } from "@/hooks/useSocial";
import { formatDuration } from "@/lib/badges";
import EmptyState from "@/components/EmptyState";
import { CardGridSkeleton } from "@/components/Skeletons";
import { Button } from "@/components/ui/button";

// Watch history: resume anything you started. Recorded automatically on the watch page.
export default function History() {
  const { data: me, isLoading } = useMe();
  const history = useHistory(Boolean(me));
  const clear = useClearHistory();
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6 lg:px-8">
        <CardGridSkeleton count={3} />
      </div>
    );
  }

  if (!me) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <EmptyState
          icon={LogIn}
          title="Sign in to see your history"
          message="Everything you watch is saved here so you can pick up where you left off."
          actionLabel="Sign in"
          onAction={() => navigate("/login")}
          testId="history-signin-prompt"
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between">
        <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="history-heading">
          Watch History
        </h1>
        {history.data && history.data.items.length > 0 ? (
          <Button
            variant="ghost"
            size="sm"
            onClick={() => clear.mutate()}
            disabled={clear.isPending}
            data-testid="history-clear-btn"
            className="text-rose-400 hover:bg-rose-500/10"
          >
            <Trash2 className="mr-1.5 h-4 w-4" aria-hidden /> Clear all
          </Button>
        ) : null}
      </div>

      <div className="mt-6">
        {history.isLoading ? (
          <CardGridSkeleton count={3} />
        ) : history.data && history.data.items.length > 0 ? (
          <ul className="divide-y divide-slate-800/70 overflow-hidden rounded-2xl border border-slate-800 bg-card/70" data-testid="history-list">
            {history.data.items.map((item) => (
              <li key={item.episode_id} className="flex items-center gap-3 px-4 py-3">
                {item.title.poster_url ? (
                  <img src={mediaUrl(item.title.poster_url)} alt="" aria-hidden className="h-14 w-10 flex-shrink-0 rounded object-cover" />
                ) : (
                  <span className="h-14 w-10 flex-shrink-0 rounded bg-slate-800" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-white">{item.title.name}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground" data-testid={`history-position-${item.episode_id}`}>
                    EP {item.episode_number} · stopped at {formatDuration(item.position_seconds) || "start"}
                  </p>
                </div>
                <Button
                  size="sm"
                  onClick={() => navigate(`/watch/${item.title.slug}/${item.episode_id}`)}
                  data-testid={`history-resume-btn-${item.episode_id}`}
                  className="gap-1.5 bg-amber-400 text-xs font-bold text-slate-950 hover:bg-amber-300"
                >
                  <Play className="h-3.5 w-3.5 fill-current" aria-hidden /> Resume
                </Button>
              </li>
            ))}
          </ul>
        ) : (
          <EmptyState
            icon={HistoryIcon}
            title="No watch history yet"
            message="Press play on anything and it will show up here — perfect for resuming later."
            actionLabel="Browse catalog"
            onAction={() => navigate("/browse")}
            testId="history-empty"
          />
        )}
      </div>
    </div>
  );
}
