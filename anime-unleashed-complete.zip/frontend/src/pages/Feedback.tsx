import { useState } from "react";
import { CheckCircle2, Loader2, MessageSquare, Send } from "lucide-react";
import { apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

// Public feedback form — lands in the Studio Console inbox.
export default function Feedback() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [sending, setSending] = useState(false);
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");

  async function submit(event: React.FormEvent) {
    event.preventDefault();
    setSending(true);
    setError("");
    try {
      await apiPost("/feedback", {
        name: name.trim(),
        email: email.trim() || null,
        message: message.trim(),
      });
      setSent(true);
      setName("");
      setEmail("");
      setMessage("");
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setSending(false);
    }
  }

  return (
    <div className="mx-auto max-w-xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="feedback-heading">
        Send feedback
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Found a bug? Want a show added? The studio reads every message.
      </p>

      <Card className="mt-6 border-slate-800 bg-card/70">
        <CardHeader>
          <span className="mb-1 flex h-10 w-10 items-center justify-center rounded-lg bg-amber-400/10">
            <MessageSquare className="h-5 w-5 text-amber-400" aria-hidden />
          </span>
          <CardTitle className="font-heading text-lg text-white">We're listening</CardTitle>
          <CardDescription>Goes straight to the studio's inbox — no account needed.</CardDescription>
        </CardHeader>
        <CardContent>
          {sent ? (
            <div className="flex flex-col items-center gap-3 py-6 text-center" data-testid="feedback-success">
              <CheckCircle2 className="h-12 w-12 text-emerald-400" aria-hidden />
              <p className="font-heading text-lg font-bold text-white">Message received!</p>
              <p className="text-sm text-muted-foreground">Thank you — the studio team will review it shortly.</p>
              <Button variant="outline" onClick={() => setSent(false)} data-testid="feedback-send-another-btn" className="border-slate-700">
                Send another
              </Button>
            </div>
          ) : (
            <form className="space-y-4" onSubmit={submit} data-testid="feedback-form">
              <div className="space-y-2">
                <Label htmlFor="fb-name">Your name</Label>
                <Input id="fb-name" required minLength={2} value={name} onChange={(e) => setName(e.target.value)} className="border-slate-700 bg-slate-900/70" data-testid="feedback-name-input" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fb-email">Email (optional — if you want a reply)</Label>
                <Input id="fb-email" type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="you@example.com" className="border-slate-700 bg-slate-900/70" data-testid="feedback-email-input" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="fb-message">Message</Label>
                <Textarea id="fb-message" required minLength={5} rows={5} value={message} onChange={(e) => setMessage(e.target.value)} placeholder="Tell us what's on your mind…" className="border-slate-700 bg-slate-900/70" data-testid="feedback-message-input" />
              </div>
              {error ? (
                <p className="rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-300" role="alert">
                  {error}
                </p>
              ) : null}
              <Button
                type="submit"
                disabled={sending}
                data-testid="feedback-submit-btn"
                className="w-full bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
              >
                {sending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <Send className="mr-2 h-4 w-4" aria-hidden />}
                Send to the studio
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
