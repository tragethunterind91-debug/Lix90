import { Navigate } from "react-router-dom";

// The admin console is a fully separate app at /studio (own shell, own deploy target).
// Old /admin links land here and hand off.
export default function Admin() {
  return <Navigate to="/studio" replace />;
}
