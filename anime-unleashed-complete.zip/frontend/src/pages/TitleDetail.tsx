import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { labelFor, themeClassFor } from "@/lib/kinds";
import { CalendarClock } from "lucide-react";
import Countdown from "@/components/Countdown";
import {
  Bookmark,
  BookmarkCheck,
  Clock,
  ListPlus,
  Play,
  Share2,
  Star,
  Tv,
  TvMinimalPlay,
} from "lucide-react";
import { apiGet, mediaUrl } from "@/lib/api";
import type { Episode, TitleDetail } from "@/lib/types";
import { audioBadgeClass, formatBytes, formatCount, formatDate, formatDuration } from "@/lib/badges";
import { shareLink } from "@/lib/share";
import { HeroSkeleton } from "@/components/Skeletons";
import EmptyState from "@/components/EmptyState";
import { useToggleListGuard } from "@/hooks/useWatchlist";
import { useMe } from "@/hooks/useAuth";
import { useCreatePlaylist, usePlaylists, useUpdatePlaylist } from "@/hooks/useSocial";
import { Badge } from "@/components/ui/badge";
import { buttonVariants } from "@/components/ui/button";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";

// Split detail view: blurred backdrop + poster card + metadata + episode list.
export default function TitleDetail() {
  const { slug } = useParams<{ slug: string }>();
  const { inList, handle } = useToggleListGuard();
  const { data: me } = useMe();
  const playlists = usePlaylists(Boolean(me));
  const createPlaylist = useCreatePlaylist();
  const updatePlaylist = useUpdatePlaylist();
  const [plOpen, setPlOpen] = useState(false);
  const [newName, setNewName] = useState("");

  const title = useQuery({
    queryKey: ["title", slug],
    queryFn: () => apiGet<TitleDetail>(`/titles/${slug ?? ""}`),
    retry: false,
  });

  if (title.isLoading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <HeroSkeleton />
      </div>
    );
  }

  if (title.isError || !title.data) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <EmptyState
          icon={Tv}
          title="Title not found"
          message="This anime may have been unpublished or the link is wrong."
          actionLabel="Back to Browse"
          onAction={() => window.location.assign("/browse")}
          testId="detail-not-found"
        />
      </div>
    );
  }

  const data = title.data;
  const firstEpisode = data.episodes[0];
  const bookmarked = inList(data.id);
  const seasonGroups = [...new Set(data.episodes.map((e) => e.season ?? 1))]
    .sort((a, b) => a - b)
    .map((s) => ({ season: s, items: data.episodes.filter((e) => (e.season ?? 1) === s) }));

  return (
    <div className={`relative ${themeClassFor(data.kind)}`}>
      {/* backdrop */}
      {data.poster_url ? (
        <div className="absolute inset-x-0 top-0 h-[420px] overflow-hidden">
          <img src={mediaUrl(data.poster_url)} alt="" aria-hidden className="h-full w-full scale-110 object-cover opacity-25 blur-xl" />
          <div className="absolute inset-0 bg-gradient-to-b from-transparent via-[#07090E]/60 to-[#07090E]" />
        </div>
      ) : null}

      <div className="relative mx-auto max-w-7xl px-4 py-10 sm:px-6 lg:px-8">
        <div className="flex flex-col gap-8 md:flex-row">
          {/* poster card */}
          <div className="w-44 flex-shrink-0 sm:w-52 md:w-60" data-testid="detail-poster">
            {data.poster_url ? (
              <img
                src={mediaUrl(data.poster_url)}
                alt={data.name}
                className="aspect-[2/3] w-full rounded-2xl border border-slate-700 object-cover shadow-[0_20px_60px_rgba(0,0,0,0.6)]"
              />
            ) : (
              <div className="aspect-[2/3] w-full rounded-2xl border border-slate-700 bg-slate-900" />
            )}
          </div>

          {/* metadata */}
          <div className="min-w-0 flex-1" data-testid="detail-info">
            <div className="flex flex-wrap items-center gap-2">
              <Badge variant="outline" className="border-amber-400/50 bg-amber-400/10 text-amber-400">
                {data.type === "movie" ? "Movie" : "Series"}
              </Badge>
              <span className="text-sm text-zinc-400">{data.release_year}</span>
              {data.rating ? (
                <span className="flex items-center gap-1 text-sm font-bold text-amber-400">
                  <Star className="h-4 w-4 fill-amber-400" aria-hidden /> {data.rating.toFixed(1)}
                </span>
              ) : null}
              {data.audio.map((a) => (
                <span key={a} className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${audioBadgeClass(a)}`}>
                  {a}
                </span>
              ))}
            </div>

            <h1 className="mt-3 font-heading text-3xl font-black uppercase tracking-tight text-white sm:text-5xl lg:text-6xl" data-testid="detail-title-name">
              {data.name}
            </h1>

            <div className="mt-3 flex flex-wrap gap-2" data-testid="detail-genres">
              {data.genres.map((g) => (
                <Link
                  key={g}
                  to={`/browse?genre=${encodeURIComponent(g)}`}
                  className="rounded-full border border-slate-700 bg-card px-3 py-1 text-xs font-semibold text-zinc-300 transition-colors hover:border-amber-400/60 hover:text-amber-400"
                >
                  {g}
                </Link>
              ))}
            </div>

            <p className="mt-4 max-w-prose text-base leading-relaxed text-zinc-300" data-testid="detail-synopsis">
              {data.synopsis}
            </p>

            {/* full video info panel */}
            <div
              className="mt-6 grid w-full max-w-xl grid-cols-2 gap-x-6 gap-y-2.5 rounded-xl border border-slate-800 bg-card/50 p-4 text-sm sm:grid-cols-3"
              data-testid="detail-info-panel"
            >
              <InfoItem label="Type" value={data.type === "movie" ? "Movie" : "Series"} />
              <InfoItem label="Kind" value={labelFor(data.kind)} />
              <InfoItem label="Studio" value={data.studio || "—"} />
              <InfoItem label="Age rating" value={data.age_rating || "—"} />
              <InfoItem label="Language" value={data.original_language || data.audio.join(", ") || "—"} />
              <InfoItem label="Status" value={data.airing_status ? data.airing_status.charAt(0).toUpperCase() + data.airing_status.slice(1) : "—"} />
              <InfoItem label="Release year" value={String(data.release_year)} />
              <InfoItem label="Episodes" value={String(data.episode_count)} />
              <InfoItem label="Audio" value={data.audio.join(", ") || "—"} />
              <InfoItem label="Rating" value={data.rating ? `${data.rating.toFixed(1)} / 10` : "—"} />
              <InfoItem label="Views" value={data.views ? formatCount(data.views) : "New"} />
              <InfoItem label="Added" value={formatDate(data.created_at) || "—"} />
              <InfoItem label="Genres" value={data.genres.join(", ") || "—"} />
            </div>

            <div className="mt-6 flex flex-wrap gap-3">
              {firstEpisode ? (
                <Link
                  to={`/watch/${data.slug}/${firstEpisode.id}`}
                  data-testid="detail-play-btn"
                  className={buttonVariants({
                    className: "h-11 gap-2 bg-amber-400 px-6 text-sm font-bold text-slate-950 shadow-[0_0_28px_rgba(245,158,11,0.35)] hover:bg-amber-300",
                  })}
                >
                  <Play className="h-4 w-4 fill-current" aria-hidden />
                  {data.type === "movie" ? "Watch now" : "Play E1"}
                </Link>
              ) : (
                <span className="text-sm text-muted-foreground">No episodes published yet</span>
              )}
              <button
                onClick={() => handle(data)}
                data-testid="detail-bookmark-btn"
                className={`flex h-11 items-center gap-2 rounded-lg border px-5 text-sm font-semibold transition-colors ${
                  bookmarked
                    ? "border-amber-400/60 bg-amber-400/10 text-amber-400"
                    : "border-white/15 bg-black/30 text-white hover:bg-white/10"
                }`}
              >
                {bookmarked ? (
                  <BookmarkCheck className="h-4 w-4" aria-hidden />
                ) : (
                  <Bookmark className="h-4 w-4" aria-hidden />
                )}
                {bookmarked ? "In My List" : "Add to My List"}
              </button>
              <button
                onClick={() => shareLink(window.location.href, data.name)}
                data-testid="detail-share-btn"
                aria-label={`Share ${data.name}`}
                className="flex h-11 items-center gap-2 rounded-lg border border-white/15 bg-black/30 px-4 text-sm font-semibold text-white transition-colors hover:bg-white/10"
              >
                <Share2 className="h-4 w-4" aria-hidden /> Share
              </button>
              <button
                onClick={() => setPlOpen(true)}
                data-testid="detail-playlist-btn"
                aria-label={`Add ${data.name} to a playlist`}
                className="flex h-11 items-center gap-2 rounded-lg border border-white/15 bg-black/30 px-4 text-sm font-semibold text-white transition-colors hover:bg-white/10"
              >
                <ListPlus className="h-4 w-4" aria-hidden /> Playlist
              </button>
            </div>
          </div>
        </div>

        {/* upcoming mode — countdown instead of episode list */}
        {data.visibility === "upcoming" ? (
          <div
            className="mt-8 flex items-center gap-3 rounded-xl border border-amber-400/40 bg-amber-400/10 px-5 py-4"
            data-testid="detail-upcoming-banner"
          >
            <CalendarClock className="h-5 w-5 flex-shrink-0 text-amber-400" aria-hidden />
            <p className="text-sm font-semibold text-amber-300">
              Coming soon — releases in{" "}
              <Countdown to={data.release_at} testId="detail-upcoming-countdown" />
            </p>
          </div>
        ) : null}

        {/* episodes — grouped by season */}
        <section className="mt-12">
          {data.visibility === "upcoming" ? null : (
            <>
          <h2 className="flex items-center gap-2.5 font-heading text-2xl font-bold tracking-tight text-white">
            <TvMinimalPlay className="h-6 w-6 text-amber-400" aria-hidden /> {data.kind === "anime" ? "Chapters" : "Episodes"}
            <span className="text-sm font-normal text-muted-foreground">({data.episodes.length})</span>
          </h2>
          {data.episodes.length === 0 ? (
            <p className="mt-4 text-sm text-muted-foreground" data-testid="detail-episodes-empty">
              Episodes haven't been published yet. Bookmark the title and you'll be first to know.
            </p>
          ) : (
            seasonGroups.map(({ season, items }) => (
              <div key={season}>
                {seasonGroups.length > 1 ? (
                  <h3 className="mt-6 flex items-center gap-2 font-heading text-xs font-bold uppercase tracking-widest text-amber-400/90" data-testid={`detail-season-heading-${season}`}>
                    <span className="h-px flex-1 bg-amber-400/20" /> Season {season} <span className="h-px flex-1 bg-amber-400/20" />
                  </h3>
                ) : null}
                <ul className="mt-4 divide-y divide-slate-800/70 overflow-hidden rounded-2xl border border-slate-800 bg-card/70">
                  {items.map((episode) => (
                      <li
                        key={episode.id}
                        className="flex items-center gap-4 px-4 py-3 transition-colors hover:bg-slate-800/40 sm:px-5"
                        data-testid={`episode-item-${episode.id}`}
                      >
                        <span className="relative flex h-10 w-10 flex-shrink-0 items-center justify-center overflow-hidden rounded-lg bg-slate-800 font-heading text-sm font-bold text-amber-400">
                          {episode.thumbnail_url ? (
                            <>
                              <img src={mediaUrl(episode.thumbnail_url)} alt="" aria-hidden className="absolute inset-0 h-full w-full object-cover opacity-80" />
                              <span className="relative z-10 [text-shadow:0_1px_3px_rgba(0,0,0,0.9)]">{episode.number}</span>
                            </>
                          ) : (
                            episode.number
                          )}
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="truncate text-sm font-semibold text-white">{episode.name}</p>
                          <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-xs text-muted-foreground">
                            {episode.resolution ? (
                              <span className="rounded bg-violet-500/20 px-1.5 py-0.5 font-bold text-violet-300" data-testid={`episode-resolution-${episode.id}`}>
                                {episode.resolution}
                              </span>
                            ) : null}
                            {episode.dub_tag ? (
                              <span className="rounded bg-emerald-500/20 px-1.5 py-0.5 font-bold text-emerald-300">
                                D/C: {episode.dub_tag}
                              </span>
                            ) : null}
                            {episode.duration_seconds ? (
                              <span className="flex items-center gap-1">
                                <Clock className="h-3 w-3" aria-hidden /> {formatDuration(episode.duration_seconds)}
                              </span>
                            ) : null}
                            {episode.size_bytes ? <span>{formatBytes(episode.size_bytes)}</span> : null}
                          </div>
                        </div>
                        <Link
                          to={`/watch/${data.slug}/${episode.id}`}
                          data-testid={`watch-episode-btn-${episode.id}`}
                          className={buttonVariants({
                            size: "sm",
                            className: "gap-1.5 bg-amber-400 text-xs font-bold text-slate-950 hover:bg-amber-300",
                          })}
                        >
                          <Play className="h-3.5 w-3.5 fill-current" aria-hidden /> Play
                        </Link>
                      </li>
                  ))}
                </ul>
              </div>
            ))
          )}
            </>
          )}
        </section>
      </div>

      {/* playlist picker dialog */}
      <Dialog open={plOpen} onOpenChange={setPlOpen}>
        <DialogContent className="max-w-md border-slate-800 bg-[#121622]">
          <DialogHeader>
            <DialogTitle className="font-heading text-white">Add to playlist</DialogTitle>
            <DialogDescription>
              Playlists live on your account — share them with a link from the Playlists page.
            </DialogDescription>
          </DialogHeader>
          {me ? (
            <div className="space-y-3" data-testid="playlist-dialog">
              <div className="max-h-56 space-y-1 overflow-y-auto">
                {(playlists.data ?? []).map((pl) => (
                  <label
                    key={pl.id}
                    className="flex items-center gap-3 rounded-lg border border-slate-800 px-3 py-2 text-sm text-zinc-200"
                    data-testid={`playlist-option-${pl.id}`}
                  >
                    <Checkbox
                      checked={pl.title_ids.includes(data.id)}
                      onCheckedChange={(checked) =>
                        updatePlaylist.mutate(
                          checked
                            ? { id: pl.id, add_title_id: data.id }
                            : { id: pl.id, remove_title_id: data.id },
                        )
                      }
                    />
                    <span className="flex-1 truncate">{pl.name}</span>
                    <span className="text-xs text-muted-foreground">{pl.title_ids.length}</span>
                  </label>
                ))}
                {playlists.data && playlists.data.length === 0 ? (
                  <p className="px-1 py-2 text-sm text-muted-foreground">No playlists yet — create one below.</p>
                ) : null}
              </div>
              <form
                className="flex gap-2"
                onSubmit={(event) => {
                  event.preventDefault();
                  if (!newName.trim()) return;
                  createPlaylist.mutate(newName.trim(), { onSuccess: () => setNewName("") });
                }}
              >
                <Input
                  value={newName}
                  onChange={(event) => setNewName(event.target.value)}
                  placeholder="New playlist name"
                  maxLength={80}
                  className="border-slate-700 bg-slate-900/70"
                  data-testid="detail-playlist-create-input"
                />
                <Button
                  type="submit"
                  disabled={!newName.trim() || createPlaylist.isPending}
                  data-testid="detail-playlist-create-btn"
                  className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
                >
                  Create
                </Button>
              </form>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground" data-testid="playlist-dialog-signin-prompt">
              Sign in to build playlists and sync them across devices.
            </p>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Small labelled value cell for the info panel.
function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="text-[11px] uppercase tracking-widest text-muted-foreground">{label}</p>
      <p className="mt-0.5 truncate font-medium text-zinc-100" title={value}>{value}</p>
    </div>
  );
}
