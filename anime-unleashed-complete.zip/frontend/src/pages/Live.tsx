import { useState, useRef, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Radio,
  Users,
  Heart,
  Send,
  Sparkles,
  Share2,
  Tv,
  Crown,
  Play,
  Coins,
  Shield,
  MessageCircle,
  Calendar,
  Clock,
  Flame,
  Check,
  Volume2,
  VolumeX,
} from "lucide-react";
import { toast } from "sonner";
import { apiGet, apiPost, apiErrorMessage } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useMe } from "@/hooks/useAuth";

interface LiveStream {
  id: string;
  title: string;
  description: string;
  stream_url: string;
  thumbnail_url?: string;
  category: string;
  is_24_7: boolean;
  status: string;
  creator_name: string;
  creator_id: string;
  viewer_count: number;
  likes: number;
}

interface LiveChatMessage {
  id: string;
  stream_id: string;
  user_name: string;
  is_vip: boolean;
  role: string;
  text: string;
  is_superchat?: boolean;
  coins?: number;
  created_at: string;
}

interface ScheduleItem {
  id: string;
  title: string;
  subtitle: string;
  scheduled_time: string;
  thumbnail: string;
  category: string;
  subscribers: number;
}

function CountdownTimer({ targetDate }: { targetDate: string }) {
  const [timeLeft, setTimeLeft] = useState<{ d: number; h: number; m: number; s: number }>({
    d: 0,
    h: 0,
    m: 0,
    s: 0,
  });

  useEffect(() => {
    function calc() {
      const diff = new Date(targetDate).getTime() - Date.now();
      if (diff <= 0) {
        setTimeLeft({ d: 0, h: 0, m: 0, s: 0 });
        return;
      }
      const d = Math.floor(diff / (1000 * 60 * 60 * 24));
      const h = Math.floor((diff / (1000 * 60 * 60)) % 24);
      const m = Math.floor((diff / 1000 / 60) % 60);
      const s = Math.floor((diff / 1000) % 60);
      setTimeLeft({ d, h, m, s });
    }
    calc();
    const interval = setInterval(calc, 1000);
    return () => clearInterval(interval);
  }, [targetDate]);

  return (
    <div className="flex items-center gap-1 font-mono text-xs font-bold text-amber-300">
      <span className="rounded bg-black/60 px-1.5 py-0.5">{String(timeLeft.d).padStart(2, "0")}d</span>
      <span>:</span>
      <span className="rounded bg-black/60 px-1.5 py-0.5">{String(timeLeft.h).padStart(2, "0")}h</span>
      <span>:</span>
      <span className="rounded bg-black/60 px-1.5 py-0.5">{String(timeLeft.m).padStart(2, "0")}m</span>
      <span>:</span>
      <span className="rounded bg-black/60 px-1.5 py-0.5 text-rose-400">{String(timeLeft.s).padStart(2, "0")}s</span>
    </div>
  );
}

export default function Live() {
  const { data: me } = useMe();
  const queryClient = useQueryClient();
  const [selectedId, setSelectedId] = useState<string>("live-stream-247-lofi");
  const [msgText, setMsgText] = useState("");
  const [superChatOpen, setSuperChatOpen] = useState(false);
  const [superChatText, setSuperChatText] = useState("");
  const [superChatCoins, setSuperChatCoins] = useState<number>(50);
  const [isMuted, setIsMuted] = useState(true);
  const liveVideoRef = useRef<HTMLVideoElement>(null);
  const chatBottomRef = useRef<HTMLDivElement>(null);
  const chatContainerRef = useRef<HTMLDivElement>(null);
  const [depositOpen, setDepositOpen] = useState(false);
  const [depositAmount, setDepositAmount] = useState<number>(100);
  const [donateOpen, setDonateOpen] = useState(false);
  const [donateAmount, setDonateAmount] = useState<number>(50);
  const [donateMsg, setDonateMsg] = useState("");
  const [hypeCount, setHypeCount] = useState<number>(4);
  const [likesCount, setLikesCount] = useState<number>(1);
  const [isWebviewStream, setIsWebviewStream] = useState(false);

  const depositMutation = useMutation({
    mutationFn: (amount: number) => apiPost("/vip/deposit", { amount }),
    onSuccess: (data: any) => {
      toast.success(data?.message || "₹ deposited successfully!");
      setDepositOpen(false);
      void queryClient.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err: any) => {
      toast.error(apiErrorMessage(err));
    },
  });

  const donateMutation = useMutation({
    mutationFn: (data: any) => apiPost(`/live/${activeStream?.id}/donate`, data),
    onSuccess: (data: any) => {
      toast.success(data?.message || "Donation sent successfully! 🎉");
      setDonateOpen(false);
      setDonateMsg("");
      void queryClient.invalidateQueries({ queryKey: ["live", "chat", activeStream?.id] });
      void queryClient.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err: any) => {
      toast.error(apiErrorMessage(err));
    },
  });

  const reactionMutation = useMutation({
    mutationFn: (data: { hype_delta: number; likes_delta: number }) =>
      apiPost(`/live/${activeStream?.id}/reaction`, data),
    onSuccess: (res: any) => {
      toast.success(`Hype boosted! (💥 ${res.hypes || 0} Hypes / ❤️ ${res.likes || 0} Likes)`);
      void queryClient.invalidateQueries({ queryKey: ["live", "streams"] });
    },
  });
  // Fetch streams list
  const streams = useQuery({
    queryKey: ["live", "streams"],
    queryFn: () => apiGet<LiveStream[]>("/live"),
    refetchInterval: 15000,
  });

  // Fetch upcoming premiere schedule
  const schedule = useQuery({
    queryKey: ["live", "schedule"],
    queryFn: () => apiGet<ScheduleItem[]>("/live/schedule"),
  });

  const activeStream =
    (streams.data || []).find((s) => s.id === selectedId) || streams.data?.[0];

  // Fetch live chat
  const chat = useQuery({
    queryKey: ["live", "chat", activeStream?.id],
    queryFn: () => apiGet<LiveChatMessage[]>(`/live/${activeStream?.id}/chat`),
    enabled: !!activeStream?.id,
    refetchInterval: 3000,
  });

  // Auto-scroll chat without moving page viewport
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chat.data]);

  // Send normal chat message
  const sendMsg = useMutation({
    mutationFn: (text: string) =>
      apiPost(`/live/${activeStream?.id}/chat`, { text }),
    onSuccess: () => {
      setMsgText("");
      void queryClient.invalidateQueries({
        queryKey: ["live", "chat", activeStream?.id],
      });
    },
    onError: () => {
      toast.error("Failed to send message. Please try again.");
    },
  });

  // Send SuperChat Tip
  const sendSuperChat = useMutation({
    mutationFn: (data: { text: string; coins: number }) =>
      apiPost(`/live/${activeStream?.id}/superchat`, data),
    onSuccess: () => {
      setSuperChatText("");
      setSuperChatOpen(false);
      toast.success(`SuperChat of ${superChatCoins} coins sent! 🌟`);
      void queryClient.invalidateQueries({
        queryKey: ["live", "chat", activeStream?.id],
      });
      void queryClient.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err: any) => {
      toast.error(err?.message || "Failed to send SuperChat. Check your coin balance!");
    },
  });

  // Like stream
  const likeStream = useMutation({
    mutationFn: () => apiPost(`/live/${activeStream?.id}/like`, {}),
    onSuccess: () => {
      toast.success("Liked the live broadcast! ❤️");
      void queryClient.invalidateQueries({ queryKey: ["live", "streams"] });
    },
  });

  function handleSend(e: React.FormEvent) {
    e.preventDefault();
    if (!msgText.trim()) return;
    sendMsg.mutate(msgText.trim());
  }

  function handleSuperChatSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!superChatText.trim()) return;
    sendSuperChat.mutate({ text: superChatText.trim(), coins: superChatCoins });
  }

  return (
    <div className="mx-auto min-h-screen max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div className="flex items-center gap-3">
          <div className="relative flex h-10 w-10 items-center justify-center rounded-2xl bg-gradient-to-tr from-rose-500 to-amber-500 text-white shadow-lg shadow-rose-500/20">
            <Radio className="h-5 w-5 animate-pulse" />
            <span className="absolute -top-1 -right-1 flex h-3 w-3">
              <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-rose-400 opacity-75" />
              <span className="relative inline-flex h-3 w-3 rounded-full bg-rose-500" />
            </span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-heading text-2xl font-black text-white sm:text-3xl">
                Anime-Unleashed LIVE
              </h1>
              <span className="rounded-full bg-rose-500/20 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-rose-400 border border-rose-500/30">
                LIVE NOW
              </span>
            </div>
            <p className="text-xs text-zinc-400">
              Synchronized 24/7 anime broadcasts, premieres &amp; real-time otaku chatrooms.
            </p>
          </div>
        </div>

        {/* Global Stats & Deposit Wallet */}
        <div className="flex flex-wrap items-center gap-3 text-xs">
          <Button
            size="sm"
            onClick={() => setDepositOpen(true)}
            data-testid="live-deposit-modal-btn"
            className="h-8 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-bold text-white shadow-sm"
          >
            + Deposit Funds
          </Button>
          <div className="flex items-center gap-1.5 rounded-xl border border-emerald-500/30 bg-emerald-500/10 px-3 py-1.5 font-bold text-emerald-300">
            <span>₹{me?.deposit_balance || 0} Deposit Bal</span>
          </div>
          <div className="flex items-center gap-1.5 rounded-xl border border-amber-500/30 bg-amber-500/10 px-3 py-1.5 font-bold text-amber-300">
            <Coins className="h-4 w-4 text-amber-400" />
            <span>{me?.cf_balance || 0} CF / {me?.lc_balance || 0} LC</span>
          </div>
          <div className="flex items-center gap-1.5 rounded-xl border border-slate-800 bg-slate-900/60 px-3 py-1.5 text-zinc-300">
            <Users className="h-4 w-4 text-rose-400" />
            <span className="font-bold text-white">
              {(streams.data || []).reduce((acc, s) => acc + (s.viewer_count || 0), 0)}
            </span>{" "}
            viewers
          </div>
        </div>
      </div>

      {/* Main Grid: Player + Realtime Chat */}
      <div className="mt-6 grid gap-6 lg:grid-cols-12">
        {/* Left Column: Player & Meta (8 Cols) */}
        <div className="space-y-6 lg:col-span-8">
          {activeStream ? (
            <div className="overflow-hidden rounded-3xl border border-slate-800 bg-black shadow-2xl">
              {/* Native Live Video Player */}
              <div className="relative aspect-video w-full bg-black">
                <video
                  ref={liveVideoRef}
                  key={activeStream.id}
                  src={activeStream.stream_url}
                  controls
                  autoPlay
                  loop
                  muted={isMuted}
                  playsInline
                  className="h-full w-full object-contain"
                  poster={activeStream.thumbnail_url}
                />
                <div className="absolute top-4 left-4 flex items-center gap-2 rounded-lg bg-black/70 px-2.5 py-1 text-xs font-bold text-rose-400 backdrop-blur-md border border-white/10">
                  <span className="h-2 w-2 rounded-full bg-rose-500 animate-ping" />
                  LIVE STREAM
                </div>
                {/* Live unmute / sound toggle */}
                <button
                  type="button"
                  onClick={() => {
                    if (liveVideoRef.current) {
                      liveVideoRef.current.muted = !isMuted;
                      setIsMuted(!isMuted);
                    }
                  }}
                  className="absolute bottom-4 right-4 flex items-center gap-1.5 rounded-xl border border-white/20 bg-black/75 px-3 py-1.5 text-xs font-bold text-white backdrop-blur-md transition-all hover:bg-black/90"
                >
                  {isMuted ? (
                    <>
                      <VolumeX className="h-4 w-4 text-rose-400" />
                      <span>Unmute Live Broadcast</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="h-4 w-4 text-emerald-400" />
                      <span>Mute</span>
                    </>
                  )}
                </button>
              </div>

              {/* Stream Meta */}
              <div className="p-6 bg-gradient-to-b from-[#0B0F19] to-[#07090E]">
                <div className="flex flex-wrap items-start justify-between gap-4">
                  <div>
                    <span className="rounded bg-purple-500/20 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-purple-300">
                      {activeStream.category}
                    </span>
                    <h2 className="mt-2 font-heading text-xl font-bold text-white sm:text-2xl">
                      {activeStream.title}
                    </h2>
                    <p className="mt-1 text-xs text-zinc-400">
                      Broadcasted by <span className="font-bold text-zinc-200">{activeStream.creator_name}</span>
                    </p>
                  </div>

                  {/* Actions */}
                  <div className="flex flex-wrap items-center gap-2">
                    <Button
                      size="sm"
                      onClick={() => setDonateOpen(true)}
                      data-testid="live-donate-btn"
                      className="bg-gradient-to-r from-amber-400 to-amber-500 font-black text-slate-950 shadow-md shadow-amber-400/20 hover:bg-amber-300"
                    >
                      <Coins className="mr-1.5 h-4 w-4 fill-slate-950" /> Send Donation
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => reactionMutation.mutate({ hype_delta: 4, likes_delta: 1 })}
                      data-testid="live-hype-reaction-btn"
                      className="border-amber-400/30 bg-amber-400/10 text-amber-300 hover:bg-amber-400/20 font-bold"
                      title="Send 4 Hype & 1 Like"
                    >
                      <Flame className="mr-1 h-3.5 w-3.5 text-amber-400" /> 4 Hype + 1 Like
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => likeStream.mutate()}
                      className="border-rose-500/30 bg-rose-500/10 text-rose-300 hover:bg-rose-500/20"
                    >
                      <Heart className="mr-1.5 h-4 w-4 fill-rose-500/40 text-rose-400" />
                      <span>{activeStream.likes}</span>
                    </Button>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => {
                        void navigator.clipboard.writeText(window.location.href);
                        toast.success("Broadcast link copied to clipboard!");
                      }}
                      className="border-slate-800 bg-slate-900/60 text-zinc-300 hover:text-white"
                    >
                      <Share2 className="mr-1.5 h-4 w-4" /> Share
                    </Button>
                  </div>
                </div>

                <p className="mt-4 text-xs text-zinc-400 leading-relaxed border-t border-slate-800/60 pt-4">
                  {activeStream.description}
                </p>
              </div>
            </div>
          ) : null}

          {/* STREAM SCHEDULE COUNTDOWN CARDS */}
          <div className="rounded-3xl border border-slate-800 bg-[#0C101A]/80 p-6 backdrop-blur-md">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <Calendar className="h-5 w-5 text-amber-400" />
                <h3 className="font-heading text-lg font-bold text-white">
                  Weekend Premiere Schedule &amp; Countdowns
                </h3>
              </div>
              <span className="rounded-full bg-amber-400/10 px-2.5 py-0.5 text-[11px] font-bold text-amber-300 border border-amber-400/20">
                Auto-Synchronized
              </span>
            </div>

            <div className="mt-5 grid gap-4 sm:grid-cols-3">
              {(schedule.data || []).map((item) => (
                <div
                  key={item.id}
                  className="group relative overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/60 p-3 transition-all hover:border-amber-400/40"
                >
                  <div className="relative aspect-[16/9] w-full overflow-hidden rounded-xl bg-slate-950">
                    <img
                      src={item.thumbnail}
                      alt={item.title}
                      className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                    <div className="absolute top-2 left-2 rounded bg-black/70 px-2 py-0.5 text-[10px] font-bold text-amber-300 backdrop-blur-md">
                      {item.category}
                    </div>
                  </div>

                  <h4 className="mt-2.5 line-clamp-1 text-xs font-bold text-white group-hover:text-amber-400">
                    {item.title}
                  </h4>
                  <p className="line-clamp-1 text-[11px] text-zinc-400">{item.subtitle}</p>

                  <div className="mt-3 flex items-center justify-between border-t border-slate-800/80 pt-2.5">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 flex items-center gap-1">
                      <Clock className="h-3 w-3 text-amber-400" /> Starts in
                    </span>
                    <CountdownTimer targetDate={item.scheduled_time} />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Live Chatroom with SuperChat Tips (4 Cols) */}
        <div className="lg:col-span-4">
          <Card className="flex h-[740px] flex-col border-slate-800 bg-[#0A0D15]/95 shadow-2xl backdrop-blur-xl">
            {/* Chat Header */}
            <div className="flex items-center justify-between border-b border-slate-800/80 p-4">
              <div className="flex items-center gap-2">
                <MessageCircle className="h-4 w-4 text-rose-400" />
                <span className="font-heading text-sm font-bold text-white">Live Stream Chat</span>
              </div>
              
              {/* SuperChat Tip Trigger Dialog */}
              <Dialog open={superChatOpen} onOpenChange={setSuperChatOpen}>
                <DialogTrigger
                  render={
                    <Button
                      size="sm"
                      data-testid="live-superchat-trigger"
                      className="h-7 rounded-lg bg-gradient-to-r from-amber-400 to-amber-500 px-2.5 text-[11px] font-black text-slate-950 shadow-md shadow-amber-400/20 hover:bg-amber-300"
                    >
                      <Coins className="mr-1 h-3.5 w-3.5 fill-slate-950" /> SuperChat
                    </Button>
                  }
                />
                <DialogContent className="border-slate-800 bg-[#0D121F] text-white sm:max-w-md">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2 font-heading text-lg font-black text-white">
                      <Sparkles className="h-5 w-5 text-amber-400" /> Send SuperChat Tip
                    </DialogTitle>
                  </DialogHeader>

                  <form onSubmit={handleSuperChatSubmit} className="space-y-4 pt-2">
                    <div>
                      <label className="text-xs font-bold text-zinc-400">Select Coin Tip Tier</label>
                      <div className="mt-2 grid grid-cols-4 gap-2">
                        {[20, 50, 100, 250].map((c) => (
                          <button
                            type="button"
                            key={c}
                            onClick={() => setSuperChatCoins(c)}
                            className={`flex flex-col items-center justify-center rounded-xl border p-2.5 transition-all ${
                              superChatCoins === c
                                ? "border-amber-400 bg-amber-400/20 font-black text-amber-300 shadow-md shadow-amber-400/10"
                                : "border-slate-800 bg-slate-900/60 text-zinc-300 hover:border-slate-700"
                            }`}
                          >
                            <span className="text-sm font-bold">{c}</span>
                            <span className="text-[10px] text-zinc-400">Coins</span>
                          </button>
                        ))}
                      </div>
                    </div>

                    <div>
                      <label className="text-xs font-bold text-zinc-400">Highlighted Message</label>
                      <Input
                        value={superChatText}
                        onChange={(e) => setSuperChatText(e.target.value)}
                        placeholder="Your highlighted message displayed on stream…"
                        maxLength={200}
                        className="mt-1.5 h-11 rounded-xl border-slate-700 bg-slate-900 text-xs text-white placeholder:text-zinc-500 focus-visible:ring-amber-400"
                      />
                    </div>

                    {/* Preview Badge */}
                    <div className="rounded-xl border border-amber-400/40 bg-gradient-to-r from-amber-500/20 via-pink-500/20 to-purple-500/20 p-3">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-black text-amber-300">{me?.display_name || "You"}</span>
                        <span className="rounded bg-amber-400 px-2 py-0.5 text-[10px] font-black text-slate-950">
                          {superChatCoins} COINS
                        </span>
                      </div>
                      <p className="mt-1 text-xs text-white">
                        {superChatText || "Your message preview will glow here!"}
                      </p>
                    </div>

                    <Button
                      type="submit"
                      disabled={!superChatText.trim() || sendSuperChat.isPending}
                      className="h-11 w-full rounded-xl bg-gradient-to-r from-amber-400 via-rose-500 to-purple-600 font-black text-slate-950 hover:opacity-90"
                    >
                      Send {superChatCoins} Coin SuperChat ✨
                    </Button>
                  </form>
                </DialogContent>
              </Dialog>
            </div>

            {/* PINNED SUPERCHAT TOP 3 GOLD PODIUM */}
            <div className="border-b border-amber-400/30 bg-gradient-to-b from-amber-500/15 via-amber-500/5 to-transparent p-3">
              <div className="flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-[10px] font-black uppercase tracking-wider text-amber-300">
                  <Crown className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
                  Top SuperChat Tippers
                </span>
                <span className="rounded bg-amber-400/20 px-1.5 py-0.2 text-[9px] font-bold text-amber-300">
                  Live Podium
                </span>
              </div>
              
              <div className="mt-2.5 grid grid-cols-3 gap-2">
                {/* 2nd Place */}
                <div className="flex flex-col items-center justify-end rounded-xl border border-slate-700/60 bg-slate-900/60 p-2 text-center">
                  <span className="rounded-full bg-slate-700 px-1.5 py-0.2 text-[9px] font-bold text-zinc-300">#2</span>
                  <p className="mt-1 line-clamp-1 text-[11px] font-bold text-zinc-200">RoronoaZ</p>
                  <span className="text-[10px] font-mono font-bold text-amber-400">150 🪙</span>
                </div>

                {/* 1st Place Champion Podium */}
                <div className="flex flex-col items-center justify-end rounded-xl border-2 border-amber-400 bg-gradient-to-b from-amber-400/20 to-amber-950/30 p-2 text-center shadow-md shadow-amber-400/15">
                  <span className="rounded-full bg-amber-400 px-1.5 py-0.2 text-[9px] font-black text-slate-950">👑 #1</span>
                  <p className="mt-1 line-clamp-1 text-xs font-black text-amber-300">GojoFan</p>
                  <span className="text-[11px] font-mono font-black text-amber-400">250 🪙</span>
                </div>

                {/* 3rd Place */}
                <div className="flex flex-col items-center justify-end rounded-xl border border-amber-700/50 bg-slate-900/60 p-2 text-center">
                  <span className="rounded-full bg-amber-900/80 px-1.5 py-0.2 text-[9px] font-bold text-amber-400">#3</span>
                  <p className="mt-1 line-clamp-1 text-[11px] font-bold text-zinc-200">Zenitsu_99</p>
                  <span className="text-[10px] font-mono font-bold text-amber-400">100 🪙</span>
                </div>
              </div>
            </div>

            {/* Chat Messages Log */}
            <div ref={chatContainerRef} className="flex-1 space-y-3 overflow-y-auto p-4 text-xs">
              {(chat.data || []).map((msg) =>
                msg.is_superchat ? (
                  /* SuperChat Highlighted Card */
                  <div
                    key={msg.id}
                    className="overflow-hidden rounded-2xl border-2 border-amber-400/70 bg-gradient-to-r from-amber-500/20 via-pink-500/15 to-purple-500/20 p-3 shadow-lg shadow-amber-500/10"
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-1.5">
                        <span className="rounded-full bg-amber-400 p-1 text-slate-950">
                          <Coins className="h-3 w-3 fill-slate-950" />
                        </span>
                        <span className="font-black text-amber-300">{msg.user_name}</span>
                      </div>
                      <span className="rounded-full bg-amber-400 px-2.5 py-0.5 text-[10px] font-black text-slate-950 shadow-sm">
                        {msg.coins} COINS
                      </span>
                    </div>
                    <p className="mt-2 text-xs font-semibold text-white leading-relaxed">
                      {msg.text}
                    </p>
                  </div>
                ) : (
                  /* Regular Chat Message */
                  <div key={msg.id} className="rounded-xl bg-slate-900/40 p-2.5 border border-slate-800/50">
                    <div className="flex items-center gap-1.5">
                      {msg.role === "admin" && (
                        <span className="rounded bg-rose-500/20 px-1 py-0.2 text-[9px] font-black uppercase text-rose-300 flex items-center gap-0.5">
                          <Shield className="h-2.5 w-2.5" /> MOD
                        </span>
                      )}
                      {msg.is_vip && msg.role !== "admin" && (
                        <span className="rounded bg-amber-400/20 px-1 py-0.2 text-[9px] font-black uppercase text-amber-300 flex items-center gap-0.5">
                          <Crown className="h-2.5 w-2.5 fill-amber-300" /> VIP
                        </span>
                      )}
                      <span className="font-bold text-zinc-300">{msg.user_name}</span>
                    </div>
                    <p className="mt-1 text-zinc-200 leading-relaxed break-words">{msg.text}</p>
                  </div>
                )
              )}
              <div ref={chatBottomRef} />
            </div>

            {/* Chat Input */}
            <div className="border-t border-slate-800/80 p-3 bg-slate-950/60">
              <form onSubmit={handleSend} className="flex gap-2">
                <Input
                  value={msgText}
                  onChange={(e) => setMsgText(e.target.value)}
                  placeholder="Chat with live viewers…"
                  maxLength={300}
                  className="h-10 rounded-xl border-slate-800 bg-slate-900/80 text-xs text-white placeholder:text-zinc-600 focus-visible:ring-rose-500"
                />
                <Button
                  type="submit"
                  size="icon"
                  disabled={!msgText.trim() || sendMsg.isPending}
                  className="h-10 w-10 rounded-xl bg-gradient-to-r from-rose-500 to-amber-500 text-white hover:opacity-90"
                >
                  <Send className="h-4 w-4" />
                </Button>
              </form>
              <div className="mt-2 flex items-center justify-between text-[10px] text-zinc-500">
                <span>Earn coins in Tasks to send SuperChats</span>
                <span className="font-bold text-amber-400">{me?.cf_balance || 0} Coins</span>
              </div>
            </div>
          </Card>
        </div>
      </div>

      {/* DEPOSIT MODAL */}
      <Dialog open={depositOpen} onOpenChange={setDepositOpen}>
        <DialogContent className="border-slate-800 bg-[#0D121F] text-white sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading text-lg font-black text-white">
              Deposit Money to Your Account
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2">
            <p className="text-xs text-zinc-400">
              Deposit funds into your wallet to send live stream donations and tip your favorite creators.
            </p>
            <div className="grid grid-cols-4 gap-2">
              {[50, 100, 250, 500].map((amt) => (
                <button
                  type="button"
                  key={amt}
                  onClick={() => setDepositAmount(amt)}
                  className={`rounded-xl border p-2.5 text-center text-xs font-bold transition-all ${
                    depositAmount === amt
                      ? "border-emerald-400 bg-emerald-500/20 text-emerald-300"
                      : "border-slate-800 bg-slate-900/60 text-zinc-400"
                  }`}
                >
                  ₹{amt}
                </button>
              ))}
            </div>
            <Input
              type="number"
              min={1}
              value={depositAmount}
              onChange={(e) => setDepositAmount(Number(e.target.value))}
              placeholder="Or enter custom amount in ₹"
              className="border-slate-700 bg-slate-900 text-sm text-white"
            />
            <Button
              onClick={() => depositMutation.mutate(depositAmount)}
              disabled={depositAmount <= 0 || depositMutation.isPending}
              className="w-full h-11 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black"
            >
              Confirm Deposit of ₹{depositAmount} (Instant Demo Sandbox)
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* LIVE DONATION MODAL (60/40 Split Rule) */}
      <Dialog open={donateOpen} onOpenChange={setDonateOpen}>
        <DialogContent className="border-slate-800 bg-[#0D121F] text-white sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading text-lg font-black text-white">
              Send Live / Pop-up Stream Donation
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2 text-xs">
            {/* Split Indicator Banner */}
            <div className="rounded-xl border border-amber-400/30 bg-amber-500/10 p-3">
              <span className="font-bold text-amber-300">Revenue Distribution Split:</span>
              <p className="mt-1 text-zinc-300 text-[11px]">
                {isWebviewStream
                  ? "• WebView Video Stream: 60% Platform / 40% Creator"
                  : "• Anime Unleashed Live: 60% Creator / 40% Platform"}
              </p>
            </div>

            <div className="flex items-center gap-2">
              <input
                type="checkbox"
                id="check-webview"
                checked={isWebviewStream}
                onChange={(e) => setIsWebviewStream(e.target.checked)}
                className="h-4 w-4 rounded border-slate-700 bg-slate-900 text-amber-400"
              />
              <label htmlFor="check-webview" className="text-zinc-300 cursor-pointer">
                Stream is a WebView video (e.g. YouTube/Social Media)
              </label>
            </div>

            <div>
              <label className="text-zinc-400 font-bold">Select Donation Tier (₹)</label>
              <div className="mt-2 grid grid-cols-4 gap-2">
                {[25, 50, 100, 200].map((amt) => (
                  <button
                    type="button"
                    key={amt}
                    onClick={() => setDonateAmount(amt)}
                    className={`rounded-xl border p-2 text-center font-bold ${
                      donateAmount === amt
                        ? "border-amber-400 bg-amber-400/20 text-amber-300"
                        : "border-slate-800 bg-slate-900/60 text-zinc-400"
                    }`}
                  >
                    ₹{amt}
                  </button>
                ))}
              </div>
            </div>

            <Input
              value={donateMsg}
              onChange={(e) => setDonateMsg(e.target.value)}
              placeholder="Live pop-up message to creator…"
              maxLength={150}
              className="border-slate-700 bg-slate-900 text-xs text-white"
            />

            <div className="flex gap-2">
              <div className="flex-1">
                <label className="text-zinc-400 text-[11px]">Hype (default 4)</label>
                <Input
                  type="number"
                  min={0}
                  value={hypeCount}
                  onChange={(e) => setHypeCount(Number(e.target.value))}
                  className="mt-1 h-9 border-slate-700 bg-slate-900 text-xs"
                />
              </div>
              <div className="flex-1">
                <label className="text-zinc-400 text-[11px]">Likes (default 1)</label>
                <Input
                  type="number"
                  min={0}
                  value={likesCount}
                  onChange={(e) => setLikesCount(Number(e.target.value))}
                  className="mt-1 h-9 border-slate-700 bg-slate-900 text-xs"
                />
              </div>
            </div>

            <Button
              onClick={() =>
                donateMutation.mutate({
                  amount: donateAmount,
                  message: donateMsg,
                  is_webview: isWebviewStream,
                  creator_user_id: activeStream?.creator_id,
                  hype_count: hypeCount,
                  likes_count: likesCount,
                })
              }
              disabled={donateAmount <= 0 || donateMutation.isPending}
              className="w-full h-11 rounded-xl bg-gradient-to-r from-amber-400 via-rose-500 to-purple-600 font-black text-slate-950"
            >
              Send ₹{donateAmount} Live Pop-Up Donation
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
