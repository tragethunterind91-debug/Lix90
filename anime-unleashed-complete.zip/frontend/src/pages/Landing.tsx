import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import {
  Play,
  Sparkles,
  Zap,
  Users,
  Film,
  Download,
  Crown,
  ArrowRight,
  Flame,
  CheckCircle2,
  Tv,
  Star,
  Shield,
  HelpCircle,
  ChevronDown,
  Layers,
  MessageSquare,
  Gift,
  Check,
  X,
  TrendingUp,
} from "lucide-react";
import { apiGet, mediaUrl } from "@/lib/api";
import type { Title } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { useMe } from "@/hooks/useAuth";

export default function Landing() {
  const { data: me } = useMe();
  const [openFaq, setOpenFaq] = useState<number | null>(0);
  const [billingCycle, setBillingCycle] = useState<"monthly" | "yearly">("monthly");

  const featured = useQuery({
    queryKey: ["titles", "featured"],
    queryFn: () => apiGet<Title[]>("/titles/featured?limit=6"),
  });
  const latest = useQuery({
    queryKey: ["titles", "latest"],
    queryFn: () => apiGet<Title[]>("/titles?sort=latest&limit=12"),
  });

  const heroAnime = featured.data?.[0] || latest.data?.[0];

  const faqs = [
    {
      q: "Is Anime-Unleashed completely free to watch?",
      a: "Yes! You can stream hundreds of anime series and movies completely free with zero subscription requirements. Free users get high definition streaming, playlist creation, and community chat.",
    },
    {
      q: "What makes video streaming faster here than other sites?",
      a: "We deliver all video streams through Cloudflare R2 global edge object storage. Video seeks are instant, byte-ranges are cached at edge points closest to you, and we never use slow shady third-party embed players.",
    },
    {
      q: "Can I download anime episodes for offline viewing?",
      a: "Absolutely. Every episode provides secure direct download links in the original video resolution so you can store episodes directly onto your phone or laptop.",
    },
    {
      q: "What are Publisher Channels?",
      a: "Publisher Channels let community creators, subtitlers, and animators publish their own anime projects, build dedicated subscriber bases, and interact with viewers through comments, likes, and shares.",
    },
    {
      q: "What is included with VIP Membership?",
      a: "VIP members enjoy 100% ad-free playback, priority high-bandwidth download servers, exclusive golden chat badges, early access to new episode drops, and VIP community discussion rooms.",
    },
  ];

  return (
    <div className="relative min-h-screen overflow-hidden bg-[#05070B] text-white selection:bg-pink-500 selection:text-white">
      {/* Background Gradients & Glow Orbs */}
      <div className="pointer-events-none absolute -top-40 left-1/2 h-[600px] w-[1000px] -translate-x-1/2 rounded-full bg-gradient-to-b from-purple-600/25 via-pink-600/15 to-transparent blur-[140px]" />
      <div className="pointer-events-none absolute top-1/4 -left-40 h-[500px] w-[500px] rounded-full bg-amber-500/10 blur-[120px]" />
      <div className="pointer-events-none absolute top-1/2 -right-40 h-[600px] w-[600px] rounded-full bg-cyan-500/15 blur-[140px]" />

      {/* 1. HERO SECTION */}
      <section className="relative px-4 pt-6 pb-12 sm:px-6 md:pt-10 md:pb-16 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="grid items-center gap-8 lg:grid-cols-12">
            {/* Left Column */}
            <div className="text-center lg:col-span-7 lg:text-left">
              <div className="inline-flex items-center gap-2 rounded-full border border-purple-500/30 bg-purple-500/10 px-3.5 py-1 text-xs font-semibold text-purple-300 backdrop-blur-md">
                <span className="flex h-2 w-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>Next-Gen Anime Network &amp; Creator Channels</span>
                <span className="rounded bg-gradient-to-r from-amber-400 to-pink-500 px-1.5 py-0.2 text-[10px] font-black uppercase tracking-wider text-slate-950">
                  v2.0 LIVE
                </span>
              </div>

              <h1 className="mt-4 font-heading text-3xl font-black tracking-tight text-white sm:text-4xl md:text-5xl lg:text-6xl">
                The Ultimate <br />
                <span className="bg-gradient-to-r from-[#FF2A85] via-[#FF4655] to-[#FEE140] bg-clip-text text-transparent">
                  Anime Experience.
                </span>
              </h1>

              <p className="mt-4 max-w-2xl text-sm sm:text-base text-zinc-300 leading-relaxed">
                Stream anime episodes with zero popups, instant byte-range edge streaming, direct offline downloads, and YouTube-style publisher channels.
              </p>

              {/* CTAs */}
              <div className="mt-6 flex flex-wrap items-center justify-center gap-3 lg:justify-start">
                <Link to={me ? "/browse" : "/register"}>
                  <Button
                    size="lg"
                    className="h-12 rounded-xl bg-gradient-to-r from-[#FF2A85] via-[#FF4655] to-[#FEE140] px-6 text-sm font-black text-slate-950 shadow-xl shadow-pink-600/25 transition-all hover:scale-105 hover:opacity-95"
                    data-testid="landing-cta-start"
                  >
                    <Play className="mr-2 h-4 w-4 fill-slate-950" />
                    {me ? "Enter Catalog" : "Start Watching Free"}
                  </Button>
                </Link>
                <Link to="/browse">
                  <Button
                    size="lg"
                    variant="outline"
                    className="h-12 rounded-xl border-slate-700 bg-slate-900/80 px-6 text-sm font-bold text-zinc-200 backdrop-blur-md hover:bg-white/10 hover:text-white"
                    data-testid="landing-cta-catalog"
                  >
                    Browse Titles
                    <ArrowRight className="ml-1.5 h-4 w-4" />
                  </Button>
                </Link>
              </div>

              {/* Social Proof Stats */}
              <div className="mt-8 grid grid-cols-3 gap-3 border-t border-slate-800/80 pt-4 text-left">
                <div>
                  <div className="font-heading text-xl font-black text-white sm:text-2xl">50+</div>
                  <div className="text-[11px] text-zinc-400">Curated Titles</div>
                </div>
                <div>
                  <div className="font-heading text-xl font-black text-pink-400 sm:text-2xl">0 ms</div>
                  <div className="text-[11px] text-zinc-400">Edge Seeking</div>
                </div>
                <div>
                  <div className="font-heading text-xl font-black text-amber-400 sm:text-2xl">100%</div>
                  <div className="text-[11px] text-zinc-400">Direct Downloads</div>
                </div>
              </div>
            </div>

            {/* Right Column: Interactive Anime Glass Card */}
            <div className="lg:col-span-5">
              <div className="relative mx-auto max-w-md rounded-3xl border border-slate-700/60 bg-gradient-to-b from-slate-900/90 to-[#0A0D14]/95 p-3.5 shadow-2xl shadow-purple-950/50 backdrop-blur-2xl">
                <div className="relative aspect-[3/4] w-full overflow-hidden rounded-2xl bg-slate-950">
                  <img
                    src={heroAnime?.poster_url ? mediaUrl(heroAnime.poster_url) : "/logo-full-banner.webp"}
                    alt={heroAnime?.name || "Anime Unleashed"}
                    className="h-full w-full object-cover transition-transform duration-700 hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/40 to-transparent" />
                  
                  {/* Floating Quality Tag */}
                  <div className="absolute top-3 right-3 flex items-center gap-1.5 rounded-full border border-white/10 bg-black/60 px-3 py-1 text-[11px] font-bold text-amber-300 backdrop-blur-md">
                    <Zap className="h-3.5 w-3.5 text-amber-400" /> Original Quality
                  </div>

                  <div className="absolute bottom-4 left-4 right-4">
                    <span className="rounded bg-gradient-to-r from-pink-500 to-amber-500 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-slate-950">
                      {heroAnime?.kind || "Studio Portal"}
                    </span>
                    <h3 className="mt-2 text-2xl font-black text-white leading-tight">
                      {heroAnime?.name || "Anime-Unleashed Studio"}
                    </h3>
                    <p className="mt-1 line-clamp-2 text-xs text-zinc-300 leading-relaxed">
                      {heroAnime?.description || "Explore official trailers, studio creator releases, and anime movies in Ultra HD."}
                    </p>
                    
                    <div className="mt-4 flex gap-2">
                      <Link to={heroAnime?.slug ? `/watch/${heroAnime.slug}` : "/explore"} className="flex-1">
                        <Button size="sm" className="w-full rounded-xl bg-amber-400 font-bold text-slate-950 hover:bg-amber-300">
                          <Play className="mr-1.5 h-4 w-4 fill-slate-950" /> {heroAnime?.slug ? "Play Now" : "Explore Videos"}
                        </Button>
                      </Link>
                      <Link to={heroAnime?.slug ? `/title/${heroAnime.slug}` : "/browse"}>
                        <Button size="sm" variant="outline" className="rounded-xl border-slate-700 bg-white/5 text-white hover:bg-white/10">
                          Catalog
                        </Button>
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 2. ACCESS MODEL / FEATURES BREAKDOWN */}
      <section className="relative border-y border-slate-800/80 bg-[#080B12]/80 px-4 py-10 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="text-center">
            <span className="rounded-full border border-pink-500/30 bg-pink-500/10 px-3.5 py-1 text-xs font-bold uppercase tracking-widest text-pink-400">
              Platform Rules & Access
            </span>
            <h2 className="mt-3 font-heading text-3xl font-black text-white sm:text-4xl">
              Transparent Video & Creator System
            </h2>
            <p className="mt-3 max-w-xl mx-auto text-sm text-zinc-400">
              Free streaming for all viewers, with exclusive direct video publishing reserved for creators.
            </p>
          </div>

          <div className="mt-14 grid gap-8 md:grid-cols-3">
            {/* Rule 1 */}
            <div className="rounded-3xl border border-emerald-500/30 bg-emerald-500/5 p-8 backdrop-blur-md">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-emerald-500/20 text-emerald-400">
                <Check className="h-6 w-6 stroke-[3]" />
              </div>
              <div className="mt-6 inline-block rounded bg-emerald-500/20 px-2.5 py-0.5 text-xs font-black uppercase tracking-wider text-emerald-300">
                YES — 100% Free
              </div>
              <h3 className="mt-3 font-heading text-2xl font-black text-white">Free Video Streaming</h3>
              <p className="mt-2 text-sm text-zinc-300 leading-relaxed">
                Stream entire catalog seasons and anime movies completely free with zero subscription requirements or mandatory fees.
              </p>
            </div>

            {/* Rule 2 */}
            <div className="rounded-3xl border border-rose-500/30 bg-rose-500/5 p-8 backdrop-blur-md">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-rose-500/20 text-rose-400">
                <X className="h-6 w-6 stroke-[3]" />
              </div>
              <div className="mt-6 inline-block rounded bg-rose-500/20 px-2.5 py-0.5 text-xs font-black uppercase tracking-wider text-rose-300">
                NO Free Content
              </div>
              <h3 className="mt-3 font-heading text-2xl font-black text-white">Other Platforms (No Free Videos)</h3>
              <p className="mt-2 text-sm text-zinc-300 leading-relaxed">
                Unlike competitors who paywall their episodes, lock resolutions behind subscriptions, or force paid tiers to finish a series.
              </p>
            </div>

            {/* Rule 3 */}
            <div className="rounded-3xl border border-purple-500/30 bg-purple-500/5 p-8 backdrop-blur-md">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-purple-500/20 text-purple-400">
                <Film className="h-6 w-6" />
              </div>
              <div className="mt-6 inline-block rounded bg-purple-500/20 px-2.5 py-0.5 text-xs font-black uppercase tracking-wider text-purple-300">
                CREATOR EXCLUSIVE
              </div>
              <h3 className="mt-3 font-heading text-2xl font-black text-white">Direct Videos for Creators Only</h3>
              <p className="mt-2 text-sm text-zinc-300 leading-relaxed">
                No random raw video uploads. Direct video publishing is exclusively granted to verified Publisher Channels and Studio creators.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 3. SIX CORE FEATURE PILLARS */}
      <section className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="text-center">
            <span className="text-xs font-bold uppercase tracking-widest text-amber-400">Designed For Power Users</span>
            <h2 className="mt-2 font-heading text-3xl font-black text-white sm:text-5xl">
              Engineered For Pure Speed
            </h2>
            <p className="mt-3 text-zinc-400 max-w-xl mx-auto">
              Every feature was hand-built to give you the most satisfying anime binge-watching session possible.
            </p>
          </div>

          <div className="mt-16 grid gap-8 sm:grid-cols-2 lg:grid-cols-3">
            {/* 1 */}
            <div className="group rounded-3xl border border-slate-800 bg-[#0C101A]/80 p-8 backdrop-blur-md transition-all duration-300 hover:border-pink-500/50 hover:shadow-2xl hover:shadow-pink-500/10">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-pink-500/10 text-pink-400 transition-transform group-hover:scale-110">
                <Zap className="h-7 w-7" />
              </div>
              <h3 className="mt-6 font-heading text-xl font-bold text-white">Cloudflare R2 Edge</h3>
              <p className="mt-3 text-sm text-zinc-400 leading-relaxed">
                Videos stream natively using S3 presigned byte-range chunks directly from Cloudflare’s low-latency edge servers.
              </p>
            </div>

            {/* 2 */}
            <div className="group rounded-3xl border border-slate-800 bg-[#0C101A]/80 p-8 backdrop-blur-md transition-all duration-300 hover:border-amber-500/50 hover:shadow-2xl hover:shadow-amber-500/10">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-amber-500/10 text-amber-400 transition-transform group-hover:scale-110">
                <Download className="h-7 w-7" />
              </div>
              <h3 className="mt-6 font-heading text-xl font-bold text-white">Fast Direct Downloads</h3>
              <p className="mt-3 text-sm text-zinc-400 leading-relaxed">
                Save whole episodes to your phone or computer with high-speed direct downloads and a safe 4-download lifetime cap.
              </p>
            </div>

            {/* 3 */}
            <div className="group rounded-3xl border border-slate-800 bg-[#0C101A]/80 p-8 backdrop-blur-md transition-all duration-300 hover:border-purple-500/50 hover:shadow-2xl hover:shadow-purple-500/10">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-purple-500/10 text-purple-400 transition-transform group-hover:scale-110">
                <Users className="h-7 w-7" />
              </div>
              <h3 className="mt-6 font-heading text-xl font-bold text-white">Publisher Channels</h3>
              <p className="mt-3 text-sm text-zinc-400 leading-relaxed">
                Follow independent animators, subbers, and reviewers. Enjoy custom channel logos, subscriber feeds, and comment threads.
              </p>
            </div>

            {/* 4 */}
            <div className="group rounded-3xl border border-slate-800 bg-[#0C101A]/80 p-8 backdrop-blur-md transition-all duration-300 hover:border-cyan-500/50 hover:shadow-2xl hover:shadow-cyan-500/10">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-cyan-500/10 text-cyan-400 transition-transform group-hover:scale-110">
                <MessageSquare className="h-7 w-7" />
              </div>
              <h3 className="mt-6 font-heading text-xl font-bold text-white">Live Global Chat</h3>
              <p className="mt-3 text-sm text-zinc-400 leading-relaxed">
                Connect in real-time with fellow otaku in the global chatroom, discuss season finales, and share recommendations.
              </p>
            </div>

            {/* 5 */}
            <div className="group rounded-3xl border border-slate-800 bg-[#0C101A]/80 p-8 backdrop-blur-md transition-all duration-300 hover:border-emerald-500/50 hover:shadow-2xl hover:shadow-emerald-500/10">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-emerald-500/10 text-emerald-400 transition-transform group-hover:scale-110">
                <Gift className="h-7 w-7" />
              </div>
              <h3 className="mt-6 font-heading text-xl font-bold text-white">Coin Tasks & Rewards</h3>
              <p className="mt-3 text-sm text-zinc-400 leading-relaxed">
                Complete daily login streaks, invite friends, and watch episodes to earn platform coins for special perks.
              </p>
            </div>

            {/* 6 */}
            <div className="group rounded-3xl border border-slate-800 bg-[#0C101A]/80 p-8 backdrop-blur-md transition-all duration-300 hover:border-rose-500/50 hover:shadow-2xl hover:shadow-rose-500/10">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-rose-500/10 text-rose-400 transition-transform group-hover:scale-110">
                <Shield className="h-7 w-7" />
              </div>
              <h3 className="mt-6 font-heading text-xl font-bold text-white">Multi-Portal Network</h3>
              <p className="mt-3 text-sm text-zinc-400 leading-relaxed">
                Separated architecture powering streaming, creator channels, playlists, and backend cloud media management.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 4. ECOSYSTEM HIGHLIGHTS */}
      <section className="border-t border-slate-800/80 bg-[#080B12]/90 px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="text-center">
            <span className="text-xs font-bold uppercase tracking-widest text-pink-400">Complete Entertainment</span>
            <h2 className="mt-2 font-heading text-3xl font-black text-white sm:text-5xl">
              An All-In-One Anime Destination
            </h2>
            <p className="mt-3 text-zinc-400 max-w-xl mx-auto">
              Everything built into one sleek interface for viewing, tracking, community discussion, and creator interaction.
            </p>
          </div>

          <div className="mt-16 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {/* Feature 1 */}
            <div className="relative overflow-hidden rounded-3xl border border-purple-500/30 bg-purple-950/10 p-6 backdrop-blur-md">
              <div className="text-3xl font-black text-purple-400">01</div>
              <h3 className="mt-3 font-heading text-xl font-bold text-white">Full Anime Catalog</h3>
              <p className="mt-2 text-xs text-zinc-400 leading-relaxed">
                Stream trending subbed and dubbed series, movies, and special OVAs with personal watchlists and episode tracking.
              </p>
              <Link to="/login" className="mt-6 inline-flex items-center text-xs font-bold text-purple-300 hover:text-white">
                Start Watching <ArrowRight className="ml-1 h-3.5 w-3.5" />
              </Link>
            </div>

            {/* Feature 2 */}
            <div className="relative overflow-hidden rounded-3xl border border-pink-500/30 bg-pink-950/10 p-6 backdrop-blur-md">
              <div className="text-3xl font-black text-pink-400">02</div>
              <h3 className="mt-3 font-heading text-xl font-bold text-white">Publisher Channels</h3>
              <p className="mt-2 text-xs text-zinc-400 leading-relaxed">
                Follow verified community creators, discover indie anime shorts, review uploads, and support voice actors.
              </p>
              <Link to="/login" className="mt-6 inline-flex items-center text-xs font-bold text-pink-300 hover:text-white">
                Discover Creators <ArrowRight className="ml-1 h-3.5 w-3.5" />
              </Link>
            </div>

            {/* Feature 3 */}
            <div className="relative overflow-hidden rounded-3xl border border-amber-500/30 bg-amber-950/10 p-6 backdrop-blur-md">
              <div className="text-3xl font-black text-amber-400">03</div>
              <h3 className="mt-3 font-heading text-xl font-bold text-white">Community & Chat</h3>
              <p className="mt-2 text-xs text-zinc-400 leading-relaxed">
                Live global chatroom, friend lists, direct messaging, and daily community challenges to earn free rewards.
              </p>
              <Link to="/login" className="mt-6 inline-flex items-center text-xs font-bold text-amber-300 hover:text-white">
                Join Community <ArrowRight className="ml-1 h-3.5 w-3.5" />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 5. PRICING & VIP TIERS */}
      <section className="px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-5xl">
          <div className="text-center">
            <span className="text-xs font-bold uppercase tracking-widest text-amber-400">Simple & Fair Pricing</span>
            <h2 className="mt-2 font-heading text-3xl font-black text-white sm:text-5xl">
              Stream Free Forever or Go VIP
            </h2>
            <p className="mt-3 text-zinc-400">
              Pick the plan that works best for your binge habits. Cancel or renew anytime.
            </p>
          </div>

          <div className="mt-14 grid gap-8 md:grid-cols-2">
            {/* Free Tier */}
            <div className="rounded-3xl border border-slate-800 bg-[#0C101A]/90 p-8 backdrop-blur-md">
              <div className="text-xs font-bold uppercase tracking-widest text-zinc-400">Standard Plan</div>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="font-heading text-4xl font-black text-white">Free</span>
                <span className="text-sm text-zinc-500">forever</span>
              </div>
              <p className="mt-3 text-xs text-zinc-400">Perfect for casual anime viewers.</p>

              <ul className="mt-8 space-y-3 text-sm text-zinc-300">
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 flex-shrink-0" /> Full HD Anime Catalog Access
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 flex-shrink-0" /> Personal Watchlist & History
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 flex-shrink-0" /> Global Chat Access
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400 flex-shrink-0" /> 4 Downloads Per Episode
                </li>
              </ul>

              <Link to="/register" className="mt-8 block">
                <Button className="w-full h-12 rounded-xl border border-slate-700 bg-slate-800 text-white font-bold hover:bg-slate-700">
                  Create Free Account
                </Button>
              </Link>
            </div>

            {/* VIP Tier */}
            <div className="relative rounded-3xl border-2 border-amber-400/80 bg-gradient-to-b from-amber-500/10 via-[#0E121E] to-[#0A0D15] p-8 shadow-2xl shadow-amber-500/10 backdrop-blur-md">
              <div className="absolute -top-3.5 right-6 rounded-full bg-amber-400 px-3 py-1 text-[10px] font-black uppercase tracking-widest text-slate-950 shadow-md">
                Most Popular
              </div>

              <div className="text-xs font-bold uppercase tracking-widest text-amber-400">VIP Unleashed</div>
              <div className="mt-4 flex items-baseline gap-2">
                <span className="font-heading text-4xl font-black text-white">₹66</span>
                <span className="text-sm text-zinc-400">/ 60 days</span>
              </div>
              <p className="mt-3 text-xs text-zinc-400">For true anime fans who want pure uninterrupted quality.</p>

              <ul className="mt-8 space-y-3 text-sm text-zinc-200">
                <li className="flex items-center gap-2.5 font-semibold text-white">
                  <Crown className="h-4 w-4 text-amber-400 flex-shrink-0" /> 100% Ad-Free Streaming
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="h-4 w-4 text-amber-400 flex-shrink-0" /> Maximum Download Speeds
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="h-4 w-4 text-amber-400 flex-shrink-0" /> Golden Community Name Badge
                </li>
                <li className="flex items-center gap-2.5">
                  <CheckCircle2 className="h-4 w-4 text-amber-400 flex-shrink-0" /> Early Access to New Drops
                </li>
              </ul>

              <Link to="/vip" className="mt-8 block">
                <Button className="w-full h-12 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 text-slate-950 font-black hover:bg-amber-300 shadow-lg shadow-amber-400/20">
                  <Crown className="mr-2 h-4 w-4 fill-slate-950" /> Get VIP Membership
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* 6. FAQ ACCORDION SECTION */}
      <section className="border-t border-slate-800/80 bg-[#080B12]/80 px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-4xl">
          <div className="text-center">
            <span className="text-xs font-bold uppercase tracking-widest text-zinc-400">Got Questions?</span>
            <h2 className="mt-2 font-heading text-3xl font-black text-white sm:text-4xl">
              Frequently Asked Questions
            </h2>
          </div>

          <div className="mt-12 space-y-4">
            {faqs.map((faq, idx) => (
              <div
                key={idx}
                className="overflow-hidden rounded-2xl border border-slate-800 bg-[#0D121F]/60 backdrop-blur-sm transition-colors hover:border-slate-700"
              >
                <button
                  type="button"
                  onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                  className="flex w-full items-center justify-between p-5 text-left font-heading text-base font-bold text-white"
                >
                  <span>{faq.q}</span>
                  <ChevronDown
                    className={`h-5 w-5 text-zinc-400 transition-transform duration-300 ${
                      openFaq === idx ? "rotate-180 text-amber-400" : ""
                    }`}
                  />
                </button>
                {openFaq === idx && (
                  <div className="px-5 pb-5 text-sm text-zinc-300 leading-relaxed border-t border-slate-800/60 pt-3">
                    {faq.a}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 7. BOTTOM HIGH-CONVERSION CTA */}
      <section className="relative px-4 py-12 sm:px-6 lg:px-8">
        <div className="mx-auto max-w-5xl rounded-3xl border border-purple-500/30 bg-gradient-to-r from-purple-900/50 via-pink-900/40 to-amber-900/40 p-10 text-center shadow-2xl backdrop-blur-2xl md:p-16">
          <h2 className="font-heading text-3xl font-black tracking-tight text-white sm:text-5xl md:text-6xl">
            Start Streaming Today.
          </h2>
          <p className="mx-auto mt-4 max-w-xl text-base text-zinc-300 sm:text-lg">
            No credit card required. Jump straight into the action with instant edge playback.
          </p>
          <div className="mt-8 flex flex-wrap items-center justify-center gap-4">
            <Link to={me ? "/browse" : "/register"}>
              <Button
                size="lg"
                className="h-14 rounded-2xl bg-amber-400 px-8 text-base font-black text-slate-950 shadow-xl shadow-amber-400/20 hover:bg-amber-300"
              >
                {me ? "Open Anime Catalog" : "Create Free Account Now"}
              </Button>
            </Link>
            <Link to="/browse">
              <Button
                size="lg"
                variant="outline"
                className="h-14 rounded-2xl border-white/20 bg-black/40 px-8 text-base font-bold text-white hover:bg-white/10"
              >
                Explore Without Account
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
