import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Sparkles,
  Flame,
  Crown,
  Coins,
  Shield,
  Search,
  Filter,
  ArrowRight,
  Gavel,
  Gift,
  Layers,
  Check,
  Loader2,
  ExternalLink,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useMe } from "@/hooks/useAuth";
import { apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { NFTItem } from "@/lib/nftTypes";

const TIER_COLORS: Record<string, string> = {
  limited: "border-amber-400 bg-amber-400/10 text-amber-300",
  high: "border-purple-500 bg-purple-500/10 text-purple-300",
  mid: "border-sky-500 bg-sky-500/10 text-sky-300",
  low: "border-emerald-500 bg-emerald-500/10 text-emerald-300",
};

export default function NftMarketplace() {
  const { data: me } = useMe();
  const queryClient = useQueryClient();
  const [category, setCategory] = useState("all");
  const [tier, setTier] = useState("all");
  const [edition, setEdition] = useState("all");
  const [search, setSearch] = useState("");
  const [selectedNft, setSelectedNft] = useState<NFTItem | null>(null);

  const { data: catalog = [], isLoading } = useQuery<NFTItem[]>({
    queryKey: ["nft-catalog", category, tier, edition],
    queryFn: () => {
      const p = new URLSearchParams();
      if (category !== "all") p.set("category", category);
      if (tier !== "all") p.set("tier", tier);
      if (edition !== "all") p.set("edition", edition);
      return apiGet<NFTItem[]>(`/nft/catalog?${p.toString()}`);
    },
  });

  const buyMutation = useMutation({
    mutationFn: (nftId: string) => apiPost("/nft/buy", { nft_id: nftId }),
    onSuccess: (res: any) => {
      toast.success(res?.message || "NFT acquired!");
      setSelectedNft(null);
      void queryClient.invalidateQueries({ queryKey: ["nft-catalog"] });
      void queryClient.invalidateQueries({ queryKey: ["my-nfts"] });
      void queryClient.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  });

  const filtered = catalog.filter((it) => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      it.name.toLowerCase().includes(q) ||
      it.category.toLowerCase().includes(q) ||
      it.tier.toLowerCase().includes(q)
    );
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8" data-testid="nft-marketplace-page">
      {/* Top Banner / Hero */}
      <div className="relative overflow-hidden rounded-3xl border border-amber-400/30 bg-gradient-to-r from-amber-500/15 via-purple-500/15 to-pink-500/15 p-6 sm:p-10 backdrop-blur-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/40 bg-amber-400/10 px-3.5 py-1 text-xs font-black uppercase tracking-wider text-amber-300">
              <Sparkles className="h-3.5 w-3.5 animate-spin" />
              Anime-Unleashed Digital Collectibles
            </div>
            <h1 className="font-heading text-3xl font-black text-white sm:text-5xl">
              NFT Marketplace
            </h1>
            <p className="max-w-2xl text-xs sm:text-sm text-zinc-300">
              Explore 50+ collectible cards across Low, Mid &amp; High tiers including legendary Dragons,
              Creatures, and Anime heroes. Purchase with coins or place bids in the 48h Auction House!
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5">
            <Link to="/auctions">
              <Button
                variant="outline"
                className="border-amber-400/40 bg-slate-900/80 font-bold text-amber-300 hover:bg-amber-400/10"
                data-testid="marketplace-to-auctions-btn"
              >
                <Gavel className="mr-2 h-4 w-4" /> 48h Auction House
              </Button>
            </Link>
            <Link to="/inventory">
              <Button
                className="bg-gradient-to-r from-amber-400 to-amber-500 font-black text-slate-950 hover:bg-amber-300"
                data-testid="marketplace-my-nfts-btn"
              >
                <Layers className="mr-2 h-4 w-4" /> My Inventory
              </Button>
            </Link>
          </div>
        </div>

        {/* User Coin Balance display */}
        {me && (
          <div className="mt-6 flex flex-wrap items-center gap-4 rounded-2xl border border-slate-800 bg-slate-950/80 px-4 py-2.5 text-xs">
            <div className="flex items-center gap-1.5 font-bold text-zinc-300">
              <Coins className="h-4 w-4 text-amber-400" />
              <span>Your Coin Balance:</span>
              <span className="font-mono text-sm font-black text-amber-400">
                {me.cf_balance ?? 0} Coins (LC: Leashed Coins / CF: Conversation Fees)
              </span>
            </div>
            <Link
              to="/earn"
              className="ml-auto text-xs font-bold text-amber-400 hover:underline"
            >
              Earn more coins via ads &amp; tasks &rarr;
            </Link>
          </div>
        )}
      </div>

      {/* Filters & Search */}
      <div className="mt-8 space-y-4">
        {/* Category Pills */}
        <div className="flex flex-wrap items-center gap-2" data-testid="nft-category-filters">
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 mr-2">Category:</span>
          {[
            { id: "all", label: "🌟 All (50+)" },
            { id: "anime", label: "⛩️ Anime (25+)" },
            { id: "dragon", label: "🐉 Dragons" },
            { id: "creature", label: "⚡ Creatures / Pokémon" },
            { id: "character", label: "🎭 Characters" },
          ].map((c) => (
            <button
              key={c.id}
              onClick={() => setCategory(c.id)}
              data-testid={`cat-filter-${c.id}`}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition-all ${
                category === c.id
                  ? "bg-amber-400 text-slate-950 font-black shadow-md shadow-amber-400/20"
                  : "border border-slate-800 bg-slate-900/60 text-zinc-300 hover:border-slate-700"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Tier & Edition Filters + Search bar */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 mr-2">Tier:</span>
            {[
              { id: "all", label: "All Tiers" },
              { id: "limited", label: "✨ Limited Edition" },
              { id: "high", label: "🟣 High-Tier" },
              { id: "mid", label: "🔵 Mid-Tier" },
              { id: "low", label: "🟢 Low-Tier" },
            ].map((t) => (
              <button
                key={t.id}
                onClick={() => setTier(t.id)}
                data-testid={`tier-filter-${t.id}`}
                className={`rounded-xl px-3 py-1 text-xs font-semibold transition-all ${
                  tier === t.id
                    ? "bg-purple-500 text-white font-bold"
                    : "border border-slate-800 bg-slate-900/50 text-zinc-400 hover:text-white"
                }`}
              >
                {t.label}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-64">
            <Search className="absolute left-3 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-zinc-500" />
            <Input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by NFT name..."
              className="h-9 border-slate-800 bg-slate-900 pl-8 text-xs text-white"
              data-testid="nft-search-input"
            />
          </div>
        </div>
      </div>

      {/* NFT Cards Grid */}
      {isLoading ? (
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="h-64 animate-pulse rounded-2xl bg-slate-800/50" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="mt-12 rounded-2xl border border-slate-800 bg-slate-900/30 py-16 text-center">
          <p className="text-sm font-bold text-zinc-400">No NFTs matched your filters.</p>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-3.5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {filtered.map((nft) => {
            const isSoldOut = nft.edition === "limited" && nft.supply > 0 && nft.minted >= nft.supply;
            return (
              <Card
                key={nft.id}
                onClick={() => setSelectedNft(nft)}
                data-testid={`nft-card-${nft.id}`}
                className="group cursor-pointer overflow-hidden rounded-2xl border-slate-800/80 bg-slate-900/60 transition-all hover:scale-[1.02] hover:border-amber-400/50 hover:shadow-xl hover:shadow-amber-400/10"
              >
                {/* Media Container */}
                <div className="relative aspect-square w-full overflow-hidden bg-slate-950">
                  {nft.media_type === "html" && nft.html ? (
                    <div
                      dangerouslySetInnerHTML={{ __html: nft.html }}
                      className="h-full w-full flex items-center justify-center p-2 text-center text-xs overflow-hidden"
                    />
                  ) : nft.media_type === "video" && nft.media_url ? (
                    <video
                      src={nft.media_url}
                      autoPlay
                      loop
                      muted
                      playsInline
                      className="h-full w-full object-cover"
                    />
                  ) : (
                    <img
                      src={nft.media_url || "/logo-app-icon.png"}
                      alt={nft.name}
                      loading="lazy"
                      className="h-full w-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                  )}

                  {/* Tier / Edition Badge */}
                  <span
                    className={`absolute top-2 left-2 rounded-lg border px-2 py-0.5 text-[10px] font-black uppercase tracking-wider backdrop-blur-md ${
                      TIER_COLORS[nft.tier] || "border-slate-700 bg-slate-900 text-zinc-300"
                    }`}
                  >
                    {nft.tier}
                  </span>

                  {nft.edition === "limited" && (
                    <span className="absolute top-2 right-2 rounded-lg border border-amber-400/60 bg-amber-400 px-1.5 py-0.5 text-[9px] font-black uppercase text-slate-950 shadow">
                      Limited
                    </span>
                  )}
                </div>

                <CardContent className="p-3 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-400">
                      {nft.category}
                    </span>
                    {nft.edition === "limited" ? (
                      <span className="text-[10px] font-mono text-amber-400">
                        {nft.minted}/{nft.supply}
                      </span>
                    ) : (
                      <span className="text-[10px] text-zinc-400">Minted: {nft.minted}</span>
                    )}
                  </div>

                  <h3 className="line-clamp-1 font-heading text-sm font-bold text-white group-hover:text-amber-300">
                    {nft.name}
                  </h3>

                  <div className="flex items-center justify-between pt-1">
                    <div className="flex items-center gap-1 font-mono text-xs font-black text-amber-400">
                      <Coins className="h-3 w-3" />
                      <span>{nft.price_lc}</span>
                    </div>

                    <Button
                      size="sm"
                      disabled={isSoldOut}
                      className="h-6 rounded-lg px-2 text-[10px] font-bold bg-amber-400 text-slate-950 hover:bg-amber-300"
                    >
                      {isSoldOut ? "Sold Out" : "Buy"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* NFT Detail / Purchase Modal */}
      {selectedNft && (
        <Dialog open={!!selectedNft} onOpenChange={() => setSelectedNft(null)}>
          <DialogContent className="max-w-md border-slate-800 bg-[#0B0F19] text-white p-6" data-testid="nft-buy-modal">
            <DialogHeader>
              <div className="flex items-center justify-between">
                <DialogTitle className="font-heading text-xl font-black text-white">
                  {selectedNft.name}
                </DialogTitle>
                <Badge className={TIER_COLORS[selectedNft.tier] || ""}>
                  {selectedNft.tier.toUpperCase()}
                </Badge>
              </div>
              <DialogDescription className="text-xs text-zinc-400">
                Category: {selectedNft.category.toUpperCase()} · {selectedNft.edition.toUpperCase()} EDITION
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 pt-2">
              <div className="relative aspect-square w-full overflow-hidden rounded-2xl border border-slate-800 bg-slate-950">
                {selectedNft.media_type === "html" && selectedNft.html ? (
                  <div
                    dangerouslySetInnerHTML={{ __html: selectedNft.html }}
                    className="h-full w-full flex items-center justify-center p-4 text-center overflow-auto"
                  />
                ) : selectedNft.media_type === "video" && selectedNft.media_url ? (
                  <video
                    src={selectedNft.media_url}
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <img
                    src={selectedNft.media_url || "/logo-app-icon.png"}
                    alt={selectedNft.name}
                    className="h-full w-full object-cover"
                  />
                )}
              </div>

              {selectedNft.description && (
                <p className="text-xs leading-relaxed text-zinc-300">
                  {selectedNft.description}
                </p>
              )}

              <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3 text-xs space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-zinc-400">Purchase Price:</span>
                  <span className="font-mono font-bold text-amber-400">
                    {selectedNft.price_lc} Coins
                  </span>
                </div>
                {selectedNft.edition === "limited" && (
                  <div className="flex justify-between">
                    <span className="text-zinc-400">Available Supply:</span>
                    <span className="font-mono font-bold text-purple-300">
                      {selectedNft.minted} / {selectedNft.supply} Minted
                    </span>
                  </div>
                )}
                {me && (
                  <div className="flex justify-between border-t border-slate-800 pt-1.5">
                    <span className="text-zinc-400">Your Coin Balance:</span>
                    <span className="font-mono font-bold text-white">
                      {me.cf_balance ?? 0} Coins
                    </span>
                  </div>
                )}
              </div>

              <div className="flex gap-2">
                <Button
                  variant="outline"
                  onClick={() => setSelectedNft(null)}
                  className="w-1/3 border-slate-800 text-zinc-300"
                >
                  Cancel
                </Button>
                <Button
                  onClick={() => buyMutation.mutate(selectedNft.id)}
                  disabled={
                    buyMutation.isPending ||
                    (selectedNft.edition === "limited" &&
                      selectedNft.supply > 0 &&
                      selectedNft.minted >= selectedNft.supply)
                  }
                  className="w-2/3 bg-gradient-to-r from-amber-400 to-amber-500 font-heading font-black text-slate-950 hover:bg-amber-300"
                  data-testid="confirm-buy-nft-btn"
                >
                  {buyMutation.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Purchasing...
                    </>
                  ) : (
                    <>
                      <Coins className="mr-2 h-4 w-4" /> Purchase ({selectedNft.price_lc} Coins)
                    </>
                  )}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
