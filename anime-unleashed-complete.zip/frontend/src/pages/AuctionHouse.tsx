import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Gavel,
  Clock,
  Coins,
  ShieldAlert,
  UserCheck,
  CheckCircle2,
  XCircle,
  AlertCircle,
  Plus,
  Loader2,
  ArrowRight,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useMe } from "@/hooks/useAuth";
import { apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { AuctionItem, NFTOwnedItem } from "@/lib/nftTypes";

function formatTimeLeft(endsAtStr: string): string {
  const diff = new Date(endsAtStr).getTime() - Date.now();
  if (diff <= 0) return "Ended";
  const hours = Math.floor(diff / (1000 * 60 * 60));
  const mins = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
  return `${hours}h ${mins}m left`;
}

function canCancel(cancelUntilStr: string): boolean {
  return new Date(cancelUntilStr).getTime() > Date.now();
}

export default function AuctionHouse() {
  const { data: me } = useMe();
  const queryClient = useQueryClient();
  const [activeTab, setActiveTab] = useState<"active" | "sold" | "all">("active");
  const [selectedAuction, setSelectedAuction] = useState<AuctionItem | null>(null);
  const [bidAmount, setBidAmount] = useState<string>("");
  const [createOpen, setCreateOpen] = useState(false);
  const [selectedOwnedId, setSelectedOwnedId] = useState("");
  const [startPrice, setStartPrice] = useState("50");

  const { data: auctions = [], isLoading } = useQuery<AuctionItem[]>({
    queryKey: ["auctions", activeTab],
    queryFn: () => apiGet<AuctionItem[]>(`/nft/auctions?status=${activeTab}`),
    refetchInterval: 10000,
  });

  // User's owned Limited Edition NFTs eligible for auction
  const { data: myInventory = [] } = useQuery<NFTOwnedItem[]>({
    queryKey: ["my-nfts"],
    queryFn: () => apiGet<NFTOwnedItem[]>("/nft/my/inventory"),
    enabled: !!me,
  });

  const eligibleForAuction = myInventory.filter(
    (item) => item.nft?.edition === "limited" && !item.in_auction
  );

  // Place Bid Mutation
  const bidMutation = useMutation({
    mutationFn: ({ auctionId, amount }: { auctionId: string; amount: number }) =>
      apiPost(`/nft/auctions/${auctionId}/bid`, { amount }),
    onSuccess: (res: any) => {
      toast.success(res?.message || "Bid placed successfully!");
      setBidAmount("");
      setSelectedAuction(null);
      void queryClient.invalidateQueries({ queryKey: ["auctions"] });
      void queryClient.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  });

  // Create Auction Mutation
  const createMutation = useMutation({
    mutationFn: (data: { owned_id: string; start_price: number }) =>
      apiPost("/nft/auctions/create", data),
    onSuccess: () => {
      toast.success("Limited Edition NFT successfully listed in Auction House for 48 hours!");
      setCreateOpen(false);
      setSelectedOwnedId("");
      void queryClient.invalidateQueries({ queryKey: ["auctions"] });
      void queryClient.invalidateQueries({ queryKey: ["my-nfts"] });
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  });

  // Cancel Auction Mutation (within first 24h)
  const cancelMutation = useMutation({
    mutationFn: (auctionId: string) => apiPost(`/nft/auctions/${auctionId}/cancel`, {}),
    onSuccess: () => {
      toast.success("Auction cancelled! NFT returned to your inventory.");
      setSelectedAuction(null);
      void queryClient.invalidateQueries({ queryKey: ["auctions"] });
      void queryClient.invalidateQueries({ queryKey: ["my-nfts"] });
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  });

  // Confirm Buyer Early Mutation
  const confirmBuyerMutation = useMutation({
    mutationFn: ({ auctionId, buyerId }: { auctionId: string; buyerId: string }) =>
      apiPost(`/nft/auctions/${auctionId}/confirm-buyer`, { buyer_id: buyerId }),
    onSuccess: (res: any) => {
      toast.success(res?.message || "Sale confirmed!");
      setSelectedAuction(null);
      void queryClient.invalidateQueries({ queryKey: ["auctions"] });
      void queryClient.invalidateQueries({ queryKey: ["my-nfts"] });
      void queryClient.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  });

  function handleBidSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!selectedAuction) return;
    const val = parseInt(bidAmount, 10);
    if (!val || val <= 0) {
      toast.error("Please enter a valid bid amount");
      return;
    }
    bidMutation.mutate({ auctionId: selectedAuction.id, amount: val });
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8" data-testid="auction-house-page">
      {/* Top Banner */}
      <div className="relative overflow-hidden rounded-3xl border border-purple-500/30 bg-gradient-to-r from-purple-500/15 via-rose-500/15 to-amber-500/15 p-6 sm:p-10 backdrop-blur-xl">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="space-y-3">
            <div className="inline-flex items-center gap-2 rounded-full border border-purple-500/40 bg-purple-500/10 px-3.5 py-1 text-xs font-black uppercase tracking-wider text-purple-300">
              <Gavel className="h-3.5 w-3.5" /> 48-Hour Official Auction House
            </div>
            <h1 className="font-heading text-3xl font-black text-white sm:text-5xl">
              NFT Live Auctions
            </h1>
            <p className="max-w-2xl text-xs sm:text-sm text-zinc-300">
              Exclusive 48-hour auctions strictly for <strong className="text-amber-400">Limited Edition NFTs</strong>.
              Sellers can cancel during the first 24 hours or confirm buyers early. The highest bidder automatically wins!
            </p>
          </div>

          <div className="flex flex-wrap gap-2.5">
            <Button
              onClick={() => {
                if (!me) {
                  toast.error("Please sign in to list an NFT for auction");
                  return;
                }
                setCreateOpen(true);
              }}
              className="bg-gradient-to-r from-purple-500 to-amber-400 font-heading font-black text-slate-950 hover:opacity-95"
              data-testid="list-auction-btn"
            >
              <Plus className="mr-2 h-4 w-4" /> List NFT for Auction
            </Button>
            <Link to="/nft">
              <Button
                variant="outline"
                className="border-slate-800 bg-slate-900/80 text-zinc-300 hover:text-white"
              >
                Marketplace &rarr;
              </Button>
            </Link>
          </div>
        </div>

        {/* Rules Reminder Pill */}
        <div className="mt-6 grid grid-cols-1 gap-2.5 sm:grid-cols-3 text-xs">
          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3 text-zinc-300">
            <span className="font-bold text-amber-400">⏱️ 48-Hour Max:</span> Continuous countdown with automatic highest bidder settlement.
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3 text-zinc-300">
            <span className="font-bold text-rose-400">🔒 24h Lock:</span> Seller can cancel within first 24h. No cancellations after 24h.
          </div>
          <div className="rounded-xl border border-slate-800 bg-slate-950/60 p-3 text-zinc-300">
            <span className="font-bold text-emerald-400">🤝 Confirm Buyer:</span> Seller can choose and confirm any bidder early to close deal.
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="mt-8 flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex gap-2">
          {[
            { id: "active", label: "🔥 Live Auctions" },
            { id: "sold", label: "🏆 Completed & Sold" },
            { id: "all", label: "All History" },
          ].map((t) => (
            <button
              key={t.id}
              onClick={() => setActiveTab(t.id as any)}
              className={`rounded-xl px-4 py-2 text-xs font-bold transition-all ${
                activeTab === t.id
                  ? "bg-purple-600 text-white shadow-md shadow-purple-600/30"
                  : "text-zinc-400 hover:text-white"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Auctions Grid */}
      {isLoading ? (
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-72 animate-pulse rounded-2xl bg-slate-800/50" />
          ))}
        </div>
      ) : auctions.length === 0 ? (
        <div className="mt-12 rounded-2xl border border-slate-800 bg-slate-900/30 py-16 text-center">
          <Gavel className="mx-auto h-10 w-10 text-zinc-600 mb-3" />
          <p className="text-sm font-bold text-zinc-400">No auctions currently {activeTab}.</p>
          <p className="text-xs text-zinc-500 mt-1">Be the first to list a Limited Edition NFT above!</p>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {auctions.map((auc) => {
            const timeLeft = formatTimeLeft(auc.ends_at);
            const isSeller = me && me.id === auc.seller_id;
            const cancellable = isSeller && canCancel(auc.can_cancel_until) && auc.status === "active";

            return (
              <Card
                key={auc.id}
                className="overflow-hidden rounded-2xl border-slate-800/80 bg-slate-900/60 transition-all hover:border-purple-500/50 hover:shadow-xl"
                data-testid={`auction-card-${auc.id}`}
              >
                <div className="relative aspect-video w-full overflow-hidden bg-slate-950">
                  <img
                    src={auc.nft?.media_url || "/logo-app-icon.png"}
                    alt={auc.nft_name}
                    className="h-full w-full object-cover"
                  />
                  <div className="absolute top-3 left-3 flex items-center gap-1.5 rounded-lg border border-purple-500/40 bg-black/75 px-2.5 py-1 text-xs font-black text-purple-300 backdrop-blur-md">
                    <Clock className="h-3.5 w-3.5" />
                    <span>{timeLeft}</span>
                  </div>
                  <div className="absolute top-3 right-3 rounded-lg border border-amber-400/50 bg-amber-400/90 px-2 py-0.5 text-[10px] font-black text-slate-950 shadow">
                    Serial #{auc.serial}
                  </div>
                </div>

                <CardContent className="p-4 space-y-3">
                  <div className="flex items-start justify-between">
                    <div>
                      <h3 className="font-heading text-lg font-bold text-white">{auc.nft_name}</h3>
                      <p className="text-xs text-zinc-400">Seller: <strong className="text-zinc-200">{auc.seller_name}</strong></p>
                    </div>
                    <Badge variant={auc.status === "active" ? "default" : "secondary"}>
                      {auc.status.toUpperCase()}
                    </Badge>
                  </div>

                  {/* Pricing info */}
                  <div className="grid grid-cols-2 gap-2 rounded-xl border border-slate-800 bg-slate-950/70 p-2.5 text-xs">
                    <div>
                      <span className="text-[10px] text-zinc-500 uppercase">Starting Price</span>
                      <p className="font-mono font-bold text-zinc-300">{auc.start_price} Coins</p>
                    </div>
                    <div>
                      <span className="text-[10px] text-zinc-500 uppercase">Current Top Bid</span>
                      <p className="font-mono font-bold text-amber-400 text-sm">
                        {auc.current_price} Coins
                      </p>
                    </div>
                  </div>

                  {/* Top Bidder */}
                  <div className="flex items-center justify-between text-xs text-zinc-300">
                    <span className="text-zinc-500">Highest Bidder:</span>
                    <span className="font-bold text-purple-300">
                      {auc.top_bidder_name || "No bids placed yet"}
                    </span>
                  </div>

                  {/* Top 3 Bidders Preview */}
                  {auc.top_bids && auc.top_bids.length > 0 && (
                    <div className="rounded-xl border border-slate-800/80 bg-slate-900/40 p-2 text-[11px] space-y-1">
                      <span className="text-[10px] font-bold text-zinc-500 uppercase tracking-wider">Top 3 Bidders:</span>
                      {auc.top_bids.map((b, idx) => (
                        <div key={idx} className="flex justify-between items-center text-zinc-300">
                          <span>#{idx + 1} {b.user_name}</span>
                          <span className="font-mono font-bold text-amber-400">{b.amount} coins</span>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Action buttons */}
                  <div className="flex gap-2 pt-1">
                    <Button
                      onClick={() => {
                        setSelectedAuction(auc);
                        setBidAmount((auc.current_price + (auc.bid_count > 0 ? 5 : 0)).toString());
                      }}
                      className="flex-1 bg-gradient-to-r from-purple-500 to-amber-400 font-bold text-slate-950 hover:opacity-95"
                      data-testid={`bid-btn-${auc.id}`}
                    >
                      <Gavel className="mr-1.5 h-4 w-4" /> {auc.status === "active" ? "Place Bid" : "View Auction"}
                    </Button>

                    {cancellable && (
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => cancelMutation.mutate(auc.id)}
                        disabled={cancelMutation.isPending}
                        className="text-xs"
                        title="Cancel within 24h"
                        data-testid={`cancel-auction-btn-${auc.id}`}
                      >
                        Cancel (24h)
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}

      {/* Place Bid & Seller Management Modal */}
      {selectedAuction && (
        <Dialog open={!!selectedAuction} onOpenChange={() => setSelectedAuction(null)}>
          <DialogContent className="max-w-lg border-slate-800 bg-[#0B0F19] text-white p-6" data-testid="auction-detail-modal">
            <DialogHeader>
              <DialogTitle className="font-heading text-xl font-black text-white">
                {selectedAuction.nft_name}
              </DialogTitle>
              <DialogDescription className="text-xs text-zinc-400">
                Seller: {selectedAuction.seller_name} · Serial #{selectedAuction.serial} · Ends in: {formatTimeLeft(selectedAuction.ends_at)}
              </DialogDescription>
            </DialogHeader>

            <div className="space-y-4 pt-2">
              <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-zinc-400">Current Highest Price:</span>
                  <span className="font-mono text-base font-black text-amber-400">
                    {selectedAuction.current_price} Coins
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Top Bidder:</span>
                  <span className="font-bold text-purple-300">
                    {selectedAuction.top_bidder_name || "None yet"}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-zinc-400">Total Bids Placed:</span>
                  <span className="font-mono text-white">{selectedAuction.bid_count}</span>
                </div>
              </div>

              {/* Top 3 Bidders detailed list with Confirm Buyer option for Seller */}
              <div className="space-y-1.5">
                <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                  Top 3 Bidders List
                </label>
                {selectedAuction.top_bids.length === 0 ? (
                  <p className="rounded-xl border border-slate-800 bg-slate-900/40 p-3 text-xs text-zinc-500">
                    No bids have been recorded yet. Place the opening bid!
                  </p>
                ) : (
                  <div className="space-y-2">
                    {selectedAuction.top_bids.map((b, i) => (
                      <div
                        key={i}
                        className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-900/60 p-2.5 text-xs"
                      >
                        <div>
                          <span className="font-bold text-white">#{i + 1} {b.user_name}</span>
                          <span className="ml-2 font-mono text-amber-400 font-bold">{b.amount} Coins</span>
                        </div>
                        {/* Seller confirmation button */}
                        {me && me.id === selectedAuction.seller_id && selectedAuction.status === "active" && (
                          <Button
                            size="sm"
                            onClick={() =>
                              confirmBuyerMutation.mutate({
                                auctionId: selectedAuction.id,
                                buyerId: b.user_id,
                              })
                            }
                            disabled={confirmBuyerMutation.isPending}
                            className="h-7 text-[10px] font-bold bg-emerald-500 text-slate-950 hover:bg-emerald-400"
                            data-testid={`confirm-buyer-btn-${b.user_id}`}
                          >
                            <UserCheck className="mr-1 h-3 w-3" /> Confirm This Buyer
                          </Button>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Bidding Form for normal users */}
              {selectedAuction.status === "active" && (!me || me.id !== selectedAuction.seller_id) && (
                <form onSubmit={handleBidSubmit} className="space-y-3 pt-2">
                  <div>
                    <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                      Your Bid (Must exceed {selectedAuction.current_price} Coins)
                    </label>
                    <div className="relative mt-1">
                      <Coins className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-amber-400" />
                      <Input
                        type="number"
                        min={selectedAuction.current_price + (selectedAuction.bid_count > 0 ? 1 : 0)}
                        value={bidAmount}
                        onChange={(e) => setBidAmount(e.target.value)}
                        className="border-slate-800 bg-slate-900 pl-9 font-mono font-bold text-white"
                        placeholder="Enter bid amount"
                        required
                        data-testid="bid-amount-input"
                      />
                    </div>
                  </div>

                  <Button
                    type="submit"
                    disabled={bidMutation.isPending}
                    className="w-full bg-gradient-to-r from-purple-500 to-amber-400 font-heading font-black text-slate-950 hover:opacity-95"
                    data-testid="submit-bid-btn"
                  >
                    {bidMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Placing Bid...
                      </>
                    ) : (
                      <>
                        <Gavel className="mr-2 h-4 w-4" /> Confirm Bid
                      </>
                    )}
                  </Button>
                </form>
              )}
            </div>
          </DialogContent>
        </Dialog>
      )}

      {/* List Limited NFT for Auction Modal */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-md border-slate-800 bg-[#0B0F19] text-white p-6" data-testid="create-auction-modal">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl font-black text-white">
              List Limited Edition NFT for Auction
            </DialogTitle>
            <DialogDescription className="text-xs text-zinc-400">
              Only Limited Edition NFTs are eligible. Maximum auction duration is 48 hours.
            </DialogDescription>
          </DialogHeader>

          {eligibleForAuction.length === 0 ? (
            <div className="py-6 text-center space-y-3">
              <ShieldAlert className="mx-auto h-10 w-10 text-amber-400" />
              <p className="text-sm font-bold text-zinc-300">No Limited Edition NFTs Available</p>
              <p className="text-xs text-zinc-400">
                You do not currently own any unlisted Limited Edition NFTs. Visit the Marketplace to purchase one!
              </p>
              <Link to="/nft" onClick={() => setCreateOpen(false)}>
                <Button className="mt-2 bg-amber-400 text-slate-950 font-bold hover:bg-amber-300">
                  Explore Limited NFTs
                </Button>
              </Link>
            </div>
          ) : (
            <form
              onSubmit={(e) => {
                e.preventDefault();
                createMutation.mutate({
                  owned_id: selectedOwnedId || eligibleForAuction[0].id,
                  start_price: parseInt(startPrice, 10),
                });
              }}
              className="space-y-4 pt-2"
            >
              <div>
                <label className="text-xs font-bold text-zinc-400">Select Limited Edition NFT</label>
                <select
                  value={selectedOwnedId || eligibleForAuction[0]?.id}
                  onChange={(e) => setSelectedOwnedId(e.target.value)}
                  className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 p-2.5 text-xs text-white"
                  data-testid="select-auction-nft"
                >
                  {eligibleForAuction.map((item) => (
                    <option key={item.id} value={item.id}>
                      {item.nft?.name} (Serial #{item.serial})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-zinc-400">Starting Price (Coins)</label>
                <Input
                  type="number"
                  min={1}
                  value={startPrice}
                  onChange={(e) => setStartPrice(e.target.value)}
                  className="mt-1 border-slate-800 bg-slate-900 font-mono text-xs text-white"
                  data-testid="auction-start-price"
                  required
                />
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-3 text-[11px] text-zinc-400 space-y-1">
                <p>• Auction duration: <strong>48 hours</strong></p>
                <p>• Cancellation allowed: <strong>First 24 hours only</strong></p>
                <p>• Highest bidder automatically wins after 48h</p>
              </div>

              <Button
                type="submit"
                disabled={createMutation.isPending}
                className="w-full bg-gradient-to-r from-purple-500 to-amber-400 font-heading font-black text-slate-950 hover:opacity-95"
                data-testid="submit-create-auction-btn"
              >
                {createMutation.isPending ? "Listing..." : "Confirm & Launch 48h Auction"}
              </Button>
            </form>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
