import { useState } from "react";
import { useParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { BadgeCheck, Loader2, UserMinus, UserPlus, Heart, Coins } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Card, CardContent } from "@/components/ui/card";
import AnimeCard from "@/components/AnimeCard";
import { apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { ChannelInfo, Title } from "@/lib/types";
import { useMe } from "@/hooks/useAuth";

// Public channel page — YouTube-style: logo, bio, follower count and every
// published video from this publisher.
export default function Channel() {
  const { userId } = useParams();
  const qc = useQueryClient();
  const { data: me } = useMe();
  const [tipOpen, setTipOpen] = useState(false);
  const [tipAmount, setTipAmount] = useState<number>(50);
  const [tipMsg, setTipMsg] = useState("");

  const channel = useQuery({
    queryKey: ["channel", userId],
    queryFn: () => apiGet<ChannelInfo>(`/channels/${userId}`),
    enabled: !!userId,
  });
  const follows = useQuery({
    queryKey: ["engagement", "my-follows"],
    queryFn: () => apiGet<string[]>("/engagement/my-follows"),
    enabled: !!me,
  });
  const [busy, setBusy] = useState(false);
  const following = (follows.data ?? []).includes(userId ?? "");

  const follow = useMutation({
    mutationFn: () => apiPost<{ following: boolean }>("/engagement/follow", { channel_user_id: userId }),
    onSuccess: (d) => {
      toast.success(d.following ? "Following — their videos now appear on your Home" : "Unfollowed");
      void qc.invalidateQueries({ queryKey: ["engagement", "my-follows"] });
      void qc.invalidateQueries({ queryKey: ["channel", userId] });
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });

  const tipMutation = useMutation({
    mutationFn: (data: any) => apiPost("/vip/tip-creator", data),
    onSuccess: (res: any) => {
      toast.success(res.message || "Tip sent successfully! 🎉");
      setTipOpen(false);
      setTipMsg("");
      void qc.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err: any) => {
      toast.error(apiErrorMessage(err));
    },
  });

  if (channel.isLoading) {
    return (
      <p className="flex items-center justify-center gap-2 py-20 text-sm text-zinc-500" data-testid="channel-loading">
        <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Loading channel…
      </p>
    );
  }
  if (channel.isError) {
    return <p className="py-20 text-center text-sm text-zinc-500" data-testid="channel-missing">Channel not found.</p>;
  }
  const ch = channel.data;
  if (!ch) return null;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8" data-testid="channel-page">
      <Card className="border-slate-800 bg-card/70">
        <CardContent className="flex flex-wrap items-center gap-5 p-6">
          <div className="relative h-20 w-20 shrink-0">
            {/* initial-letter placeholder sits underneath; a dead logo URL (expired
                presign, failed upload) errors and hides itself, revealing it */}
            <div className="flex h-20 w-20 items-center justify-center rounded-full border-2 border-amber-400/40 bg-slate-900 font-heading text-3xl font-black text-amber-400" data-testid="channel-logo-placeholder">
              {(ch.name || "?").slice(0, 1).toUpperCase()}
            </div>
            {ch.logo && (
              <img
                src={ch.logo}
                alt={`${ch.name} logo`}
                onError={(e) => { e.currentTarget.style.display = "none"; }}
                className="absolute inset-0 h-20 w-20 rounded-full border-2 border-amber-400/50 object-cover"
                data-testid="channel-logo"
              />
            )}
          </div>
          <div className="min-w-0 flex-1">
            <h1 className="flex items-center gap-2 font-heading text-2xl font-bold text-white" data-testid="channel-name">
              {ch.name} <BadgeCheck className="h-5 w-5 text-sky-400" aria-hidden />
            </h1>
            <p className="text-xs text-zinc-500" data-testid="channel-stats">
              {ch.followers.toLocaleString("en-IN")} followers · {ch.titles?.length ?? 0} uploads
            </p>
            {ch.bio ? <p className="mt-2 max-w-2xl text-sm text-zinc-400" data-testid="channel-bio">{ch.bio}</p> : null}
          </div>
          {me && me.id !== ch.user_id ? (
            <div className="flex items-center gap-2">
              <Button
                onClick={() => setTipOpen(true)}
                className="bg-emerald-500 hover:bg-emerald-400 font-bold text-slate-950"
                data-testid="channel-tip-btn"
              >
                <Coins className="mr-1.5 h-4 w-4 fill-slate-950" /> Tip Creator
              </Button>
              <Button
                onClick={() => follow.mutate()}
                disabled={follow.isPending || busy}
                className={following ? "border border-slate-700 bg-transparent text-zinc-300 hover:bg-white/5" : "bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"}
                data-testid="channel-follow-btn"
              >
                {follow.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : following ? <UserMinus className="mr-2 h-4 w-4" aria-hidden /> : <UserPlus className="mr-2 h-4 w-4" aria-hidden />}
                {following ? "Following" : "Follow"}
              </Button>
            </div>
          ) : null}
        </CardContent>
      </Card>

      <h2 className="mt-10 font-heading text-lg font-bold text-white" data-testid="channel-videos-heading">Videos</h2>
      {(ch.titles ?? []).length ? (
        <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5" data-testid="channel-videos-grid">
          {(ch.titles as Title[]).map((t) => <AnimeCard key={t.id} title={t} />)}
        </div>
      ) : (
        <p className="mt-4 text-sm text-zinc-500" data-testid="channel-videos-empty">No published videos yet.</p>
      )}
      {/* Tip Creator Modal */}
      <Dialog open={tipOpen} onOpenChange={setTipOpen}>
        <DialogContent className="border-slate-800 bg-[#0D121F] text-white sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading text-lg font-black text-white">
              Tip {ch.name} Directly
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2 text-xs">
            <p className="text-zinc-400">
              Use your deposited balance (₹{me?.deposit_balance ?? 0}) to send appreciation and tip this creator.
            </p>
            <div className="grid grid-cols-4 gap-2">
              {[20, 50, 100, 200].map((amt) => (
                <button
                  type="button"
                  key={amt}
                  onClick={() => setTipAmount(amt)}
                  className={`rounded-xl border p-2 text-center font-bold ${
                    tipAmount === amt
                      ? "border-emerald-400 bg-emerald-500/20 text-emerald-300"
                      : "border-slate-800 bg-slate-900/60 text-zinc-400"
                  }`}
                >
                  ₹{amt}
                </button>
              ))}
            </div>
            <Input
              value={tipMsg}
              onChange={(e) => setTipMsg(e.target.value)}
              placeholder="Leave a message with your tip…"
              className="border-slate-700 bg-slate-900 text-xs text-white"
            />
            <Button
              onClick={() =>
                tipMutation.mutate({
                  creator_user_id: ch.user_id,
                  amount: tipAmount,
                  message: tipMsg,
                })
              }
              disabled={tipAmount <= 0 || tipMutation.isPending}
              className="w-full h-11 rounded-xl bg-emerald-500 hover:bg-emerald-400 font-black text-slate-950"
            >
              Confirm Tip of ₹{tipAmount}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
