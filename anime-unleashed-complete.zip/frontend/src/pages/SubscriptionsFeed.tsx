import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import {
  Users,
  Film,
  Sparkles,
  Heart,
  Play,
  TrendingUp,
  Clock,
  Compass,
  CheckCircle2,
  Tv,
  Star,
  Clapperboard,
} from "lucide-react";
import { apiGet, apiPost, mediaUrl, apiErrorMessage } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import EmptyState from "@/components/EmptyState";
import AnimeCard from "@/components/AnimeCard";
import { toast } from "sonner";
import { useToggleListGuard } from "@/hooks/useWatchlist";

interface ChannelItem {
  user_id: string;
  name: string;
  bio: string;
  logo: string;
  followers: number;
  videos: number;
  email?: string;
}

interface FollowedVideo {
  id: string;
  slug: string;
  name: string;
  poster_url: string;
  kind?: string;
  audio?: string[];
  views?: number;
  created_at: string;
  channel_name: string;
  channel_logo?: string;
  channel_id: string;
}

interface FeedData {
  followed_channels: ChannelItem[];
  followed_videos: FollowedVideo[];
  suggested_videos: any[];
  social_suggestions: any[];
  total_following: number;
}

export default function SubscriptionsFeed() {
  const [activeTab, setActiveTab] = useState<"all" | "videos" | "channels" | "suggested">("all");
  const qc = useQueryClient();
  const { inList, handle: handleToggle } = useToggleListGuard();

  const { data, isLoading } = useQuery<FeedData>({
    queryKey: ["subscriptions-feed"],
    queryFn: () => apiGet<FeedData>("/engagement/subscriptions-feed"),
  });

  const toggleFollow = useMutation({
    mutationFn: (channelUserId: string) =>
      apiPost<{ following: boolean }>("/engagement/follow", { channel_user_id: channelUserId }),
    onSuccess: (res) => {
      toast.success(res.following ? "Channel followed!" : "Unfollowed channel");
      void qc.invalidateQueries({ queryKey: ["subscriptions-feed"] });
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err));
    },
  });

  if (isLoading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <div className="h-8 w-48 animate-pulse rounded-lg bg-slate-800" />
        <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4 lg:grid-cols-6">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="aspect-[3/4] animate-pulse rounded-2xl bg-slate-900" />
          ))}
        </div>
      </div>
    );
  }

  const channels = data?.followed_channels ?? [];
  const videos = data?.followed_videos ?? [];
  const suggestions = data?.suggested_videos ?? [];
  const socialWebviews = data?.social_suggestions ?? [];

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      {/* Header Banner */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-pink-500/30 bg-pink-500/10 px-3 py-1 text-xs font-bold text-pink-400">
            <Users className="h-3.5 w-3.5" />
            <span>YouTube-Style Creator Subscriptions</span>
          </div>
          <h1 className="mt-2 font-heading text-2xl sm:text-3xl font-black text-white" data-testid="subscriptions-heading">
            Followed Channels &amp; Loved Videos
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-zinc-400">
            Keep up with your favorite publisher channels, watch their newest uploads, and get YouTube-style recommendations.
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={(v: any) => setActiveTab(v)}>
          <TabsList className="bg-slate-900 border border-slate-800">
            <TabsTrigger value="all" className="text-xs">All</TabsTrigger>
            <TabsTrigger value="videos" className="text-xs">Videos ({videos.length})</TabsTrigger>
            <TabsTrigger value="channels" className="text-xs">Channels ({channels.length})</TabsTrigger>
            <TabsTrigger value="suggested" className="text-xs">Loved For You</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* 1. HORIZONTAL CHANNEL STORIES BAR */}
      {channels.length > 0 && (activeTab === "all" || activeTab === "channels") && (
        <section className="mt-5" data-testid="followed-channels-bar">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold uppercase tracking-wider text-zinc-400">
              Followed Creators ({channels.length})
            </span>
            <Link to="/channels" className="text-xs font-bold text-pink-400 hover:underline">
              Find More Channels &rarr;
            </Link>
          </div>
          <div className="mt-3 flex gap-3 overflow-x-auto pb-2 scrollbar-none">
            {channels.map((c) => (
              <Link
                key={c.user_id}
                to={`/channel/${c.user_id}`}
                className="group flex flex-col items-center flex-shrink-0 w-24 p-2 rounded-2xl border border-slate-800/80 bg-slate-900/40 hover:bg-slate-800/60 transition-all text-center"
              >
                <div className="relative h-14 w-14 rounded-full p-0.5 bg-gradient-to-tr from-pink-500 to-amber-400 shadow-md">
                  {c.logo ? (
                    <img src={c.logo} alt={c.name} className="h-full w-full rounded-full object-cover" />
                  ) : (
                    <div className="flex h-full w-full items-center justify-center rounded-full bg-slate-950 font-black text-pink-400 text-base">
                      {c.name.slice(0, 1).toUpperCase()}
                    </div>
                  )}
                  <span className="absolute bottom-0 right-0 h-3.5 w-3.5 rounded-full bg-emerald-500 ring-2 ring-slate-950" />
                </div>
                <p className="mt-2 text-xs font-bold text-white truncate w-full group-hover:text-pink-300">
                  {c.name}
                </p>
                <p className="text-[10px] text-zinc-400">{c.videos} videos</p>
              </Link>
            ))}
          </div>
        </section>
      )}

      {/* 2. LATEST VIDEOS FROM FOLLOWED CHANNELS */}
      {(activeTab === "all" || activeTab === "videos") && (
        <section className="mt-8" data-testid="followed-videos-section">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="flex items-center gap-2 font-heading text-xl font-bold text-white">
                <Film className="h-5 w-5 text-pink-400" /> Latest Uploads From Your Channels
              </h2>
              <p className="text-xs text-zinc-400">Newly released episodes and anime series from creators you follow</p>
            </div>
          </div>

          <div className="mt-4">
            {videos.length > 0 ? (
              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
                {videos.map((vid) => (
                  <div key={vid.id} className="group relative flex flex-col overflow-hidden rounded-2xl border border-slate-800 bg-[#07090E]/80 transition-all hover:border-pink-500/40">
                    <Link to={`/watch/${vid.slug}/1`} className="relative aspect-[3/4] w-full overflow-hidden bg-slate-950">
                      {vid.poster_url ? (
                        <img src={mediaUrl(vid.poster_url)} alt={vid.name} className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105" />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center bg-slate-900 text-zinc-600">
                          <Film className="h-10 w-10" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent" />
                      <div className="absolute top-2 left-2 rounded bg-pink-600/90 px-1.5 py-0.5 text-[10px] font-black uppercase text-white">
                        {vid.kind || "Anime"}
                      </div>
                    </Link>
                    <div className="p-3 flex flex-col flex-1 justify-between">
                      <div>
                        <Link to={`/watch/${vid.slug}/1`} className="font-heading text-sm font-bold text-white hover:text-pink-400 line-clamp-1">
                          {vid.name}
                        </Link>
                        <Link to={`/channel/${vid.channel_id}`} className="mt-1 flex items-center gap-1.5 text-xs text-zinc-400 hover:text-white">
                          <span className="truncate">{vid.channel_name}</span>
                          <CheckCircle2 className="h-3 w-3 text-pink-400 flex-shrink-0" />
                        </Link>
                      </div>
                      <div className="mt-2.5 flex items-center justify-between text-[11px] text-zinc-400 border-t border-slate-800/80 pt-2">
                        <span>{vid.views ?? 0} views</span>
                        <Link to={`/title/${vid.slug}`} className="text-pink-400 hover:underline">
                          Details
                        </Link>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <Card className="border-slate-800 bg-card/60 p-8 text-center">
                <Users className="mx-auto h-12 w-12 text-zinc-600" />
                <h3 className="mt-3 font-heading text-lg font-bold text-white">No followed videos yet</h3>
                <p className="mt-1 text-xs text-zinc-400 max-w-md mx-auto">
                  Follow your favorite publishers and creators on Anime-Unleashed. Their latest video uploads will show up right here on your feed.
                </p>
                <Link to="/channels" className="mt-4 inline-block">
                  <Button size="sm" className="rounded-xl bg-pink-600 hover:bg-pink-500 font-bold text-white">
                    Explore Publisher Channels
                  </Button>
                </Link>
              </Card>
            )}
          </div>
        </section>
      )}

      {/* 3. YOUTUBE-STYLE "LOVED VIDEOS & SUGGESTED FOR YOU" */}
      {(activeTab === "all" || activeTab === "suggested") && (
        <section className="mt-10 border-t border-slate-800 pt-8" data-testid="suggested-videos-section">
          <div className="flex items-center justify-between">
            <div>
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-rose-500/20 text-rose-400">
                  <Heart className="h-3.5 w-3.5 fill-rose-500" />
                </span>
                <h2 className="font-heading text-xl sm:text-2xl font-black text-white">
                  Loved &amp; Suggested For You
                </h2>
              </div>
              <p className="mt-1 text-xs text-zinc-400">
                AI recommendations powered by your watch history, liked genres, and top trending community favorites.
              </p>
            </div>
            <Link to="/browse" className="text-xs font-bold text-amber-400 hover:underline">
              Full Catalog &rarr;
            </Link>
          </div>

          <div className="mt-5">
            {suggestions.length > 0 ? (
              <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6">
                {suggestions.map((title) => (
                  <AnimeCard
                    key={title.id}
                    title={title}
                    inList={inList(title.id)}
                    onToggleList={handleToggle}
                  />
                ))}
              </div>
            ) : (
              <div className="rounded-2xl border border-slate-800 bg-[#07090E]/80 p-6 text-center text-xs text-zinc-400">
                Start watching or liking anime to get personalized suggestions.
              </div>
            )}
          </div>
        </section>
      )}

      {/* 4. CURATED EXPLORE / SOCIAL MEDIA WEBVIEWS SUGGESTIONS */}
      {(activeTab === "all" || activeTab === "suggested") && socialWebviews.length > 0 && (
        <section className="mt-10 border-t border-slate-800 pt-8" data-testid="suggested-social-section">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="flex items-center gap-2 font-heading text-lg font-bold text-white">
                <Clapperboard className="h-4 w-4 text-sky-400" /> Recommended Social &amp; YouTube Webviews
              </h3>
              <p className="text-xs text-zinc-400">Official trailers and creator clips handpicked from Explore</p>
            </div>
            <Link to="/explore" className="text-xs font-bold text-sky-400 hover:underline">
              Explore All Videos &rarr;
            </Link>
          </div>

          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {socialWebviews.map((emb: any) => (
              <div key={emb.id} className="overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/40">
                <div className="relative aspect-video w-full bg-black">
                  <iframe
                    src={emb.embed_url}
                    title={emb.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="absolute inset-0 h-full w-full border-0"
                  />
                </div>
                <div className="p-3">
                  <span className="rounded bg-sky-500/20 px-2 py-0.5 text-[10px] font-black uppercase text-sky-300">
                    {emb.platform}
                  </span>
                  <p className="mt-1 text-xs font-bold text-white line-clamp-1">{emb.title}</p>
                  <p className="text-[11px] text-zinc-400">By {emb.creator_name}</p>
                </div>
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
