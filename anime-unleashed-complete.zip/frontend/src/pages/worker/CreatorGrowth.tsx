import { Clock, Download, Eye, Film, Globe, TrendingDown, TrendingUp } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useGrowth } from "@/hooks/usePublisher";

function Stat({
  icon: Icon,
  label,
  value,
  hint,
  testid,
}: {
  icon: typeof Eye;
  label: string;
  value: string;
  hint?: string;
  testid: string;
}) {
  return (
    <Card className="border-slate-800 bg-card/70">
      <CardContent className="flex items-center gap-3 px-4 py-4">
        <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-sky-400/10 text-sky-300">
          <Icon className="h-5 w-5" aria-hidden />
        </span>
        <div className="min-w-0">
          <p className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">{label}</p>
          <p className="truncate font-heading text-xl font-bold text-white" data-testid={testid}>
            {value}
          </p>
          {hint ? <p className="truncate text-[11px] text-zinc-500">{hint}</p> : null}
        </div>
      </CardContent>
    </Card>
  );
}

function Bars({
  points,
  field,
  testid,
}: {
  points: { date?: string; month?: string; views: number }[];
  field: "date" | "month";
  testid: string;
}) {
  const max = Math.max(1, ...points.map((p) => p.views));
  return (
    <div className="flex h-28 items-stretch gap-1" data-testid={testid}>
      {points.map((p) => {
        const key = field === "date" ? p.date : p.month;
        return (
          <div key={key} className="group relative flex flex-1 flex-col justify-end" title={`${key}: ${p.views} views`}>
            <div
              className="w-full rounded-t bg-sky-400/70 transition-colors group-hover:bg-sky-300"
              style={{ height: `${Math.max(3, (p.views / max) * 100)}%` }}
            />
          </div>
        );
      })}
    </div>
  );
}

// CREATOR DESK > Growth — the publisher's monetization screen, YT-Studio style:
// total views / location / daily + monthly views, watch duration, downloads
// (video + audio + subtitles), uploads and the month-over-month %.
export default function CreatorGrowth() {
  const growth = useGrowth();
  const data = growth.data;
  const t = data?.totals;
  const up = (data?.trend_pct ?? 0) >= 0;

  return (
    <div className="mx-auto max-w-5xl">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="growth-heading">
            Growth
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Your publisher numbers — views, watch-time, downloads across the content you supplied.
          </p>
        </div>
        {data ? (
          <span
            className={`flex items-center gap-1 rounded-full px-3 py-1.5 text-xs font-bold ${
              up ? "bg-emerald-500/10 text-emerald-300" : "bg-rose-500/10 text-rose-300"
            }`}
            data-testid="growth-trend"
          >
            {up ? <TrendingUp className="h-4 w-4" aria-hidden /> : <TrendingDown className="h-4 w-4" aria-hidden />}
            {data.trend_pct > 0 ? "+" : ""}
            {data.trend_pct}% vs last month
          </span>
        ) : null}
      </div>

      <div className="mt-6 grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <Stat icon={Eye} label="Total views" value={String(t?.views ?? 0)} testid="growth-total-views" />
        <Stat
          icon={Clock}
          label="Watch duration"
          value={`${t?.watch_hours ?? 0} h`}
          hint={`${t?.watch_minutes ?? 0} minutes total`}
          testid="growth-watch-hours"
        />
        <Stat
          icon={Download}
          label="Downloads"
          value={String(t?.downloads_total ?? 0)}
          hint={`video ${t?.downloads_video ?? 0} · audio ${t?.downloads_audio ?? 0} · subs ${t?.downloads_subtitle ?? 0}`}
          testid="growth-downloads"
        />
        <Stat icon={Film} label="Videos uploaded" value={String(data?.uploads ?? 0)} testid="growth-uploads" />
        <Stat
          icon={Globe}
          label="Top location"
          value={data?.locations[0]?.country ?? "—"}
          hint={data?.locations[0] ? `${data.locations[0].views} views` : "no views yet"}
          testid="growth-top-location"
        />
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        <Card className="border-slate-800 bg-card/70">
          <CardContent className="px-5 py-5">
            <p className="mb-3 text-sm font-bold text-white">Daily views · last 30 days</p>
            <Bars points={data?.daily ?? []} field="date" testid="growth-daily-bars" />
          </CardContent>
        </Card>
        <Card className="border-slate-800 bg-card/70">
          <CardContent className="px-5 py-5">
            <p className="mb-3 text-sm font-bold text-white">Monthly views · last 12 months</p>
            <Bars points={data?.monthly ?? []} field="month" testid="growth-monthly-bars" />
          </CardContent>
        </Card>
      </div>

      <Card className="mt-4 border-slate-800 bg-card/70">
        <CardContent className="px-5 py-5">
          <p className="mb-3 flex items-center gap-2 text-sm font-bold text-white">
            <Globe className="h-4 w-4 text-sky-300" aria-hidden /> Views by location
          </p>
          <div className="space-y-2" data-testid="growth-locations">
            {(data?.locations ?? []).length === 0 ? (
              <p className="text-sm text-zinc-500">Locations show up as people watch your content.</p>
            ) : (
              data!.locations.map((loc) => {
                const top = Math.max(1, data!.locations[0].views);
                return (
                  <div key={loc.country} className="flex items-center gap-3 text-sm">
                    <span className="w-28 shrink-0 truncate text-zinc-300">{loc.country}</span>
                    <span className="h-2.5 flex-1 overflow-hidden rounded-full bg-slate-800">
                      <span className="block h-full rounded-full bg-sky-400/80" style={{ width: `${(loc.views / top) * 100}%` }} />
                    </span>
                    <span className="w-12 shrink-0 text-right text-zinc-400">{loc.views}</span>
                  </div>
                );
              })
            )}
          </div>
        </CardContent>
      </Card>

      {data && (t?.views ?? 0) === 0 && (t?.downloads_total ?? 0) === 0 ? (
        <p className="mt-4 text-center text-sm text-zinc-500" data-testid="growth-empty-hint">
          No activity yet — once your submissions go live and people watch, everything shows up here.
        </p>
      ) : null}
    </div>
  );
}
