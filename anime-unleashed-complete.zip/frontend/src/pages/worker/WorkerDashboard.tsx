import { useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Clock3, ExternalLink, FileVideo, Send, ShieldCheck, Timer } from "lucide-react";
import { apiGet } from "@/lib/api";
import type { SupplierMeOut } from "@/lib/types";
import { formatDate } from "@/lib/badges";
import { Badge } from "@/components/ui/badge";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-amber-400/15 text-amber-300",
  approved: "bg-emerald-500/15 text-emerald-300",
  converted: "bg-emerald-500/15 text-emerald-300",
  rejected: "bg-rose-500/15 text-rose-300",
};

const STATUS_LABELS: Record<string, string> = {
  pending: "In review",
  approved: "Approved",
  converted: "Launched as draft",
  rejected: "Rejected",
};

// Staff desks — the owner's distinction:
//   worker  → upload the owner's videos as drafts (the owner reviews + publishes)
//   creator → YouTube-style: submit their own content by link, track review status
export default function WorkerDashboard({ variant = "worker" }: { variant?: "worker" | "creator" }) {
  const isCreator = variant === "creator";
  const desk = useQuery({
    queryKey: ["supplier", "me"],
    queryFn: () => apiGet<SupplierMeOut>("/supplier/me"),
    enabled: isCreator,
  });
  const application = desk.data?.application ?? null;
  const submissions = desk.data?.submissions ?? [];

  if (!isCreator) {
    return (
      <div className="mx-auto max-w-5xl">
        <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="worker-heading">
          My desk
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          You upload the owner's videos — everything saves as a DRAFT for review.
        </p>

        <div className="mt-6 rounded-xl border border-sky-500/30 bg-sky-500/5 px-4 py-3 text-sm text-sky-300" data-testid="worker-dash-note">
          Worker mode — upload titles, episodes and videos as drafts. The owner adds the final details
          and launches them (Upcoming countdown or Home listing). You can't publish or delete.
        </div>

        <div className="mt-6 grid gap-3 sm:grid-cols-2">
          <Link
            to="/worker/upload"
            data-testid="worker-quick-upload-link"
            className="group rounded-2xl border border-slate-800 bg-card/70 p-5 transition-colors hover:border-emerald-400/40"
          >
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-400/10">
              <FileVideo className="h-5 w-5 text-emerald-400" aria-hidden />
            </span>
            <p className="mt-3 font-heading text-base font-bold text-white">Upload a video</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Create a draft title, attach the episode file, done — no re-upload needed later.
            </p>
          </Link>
          <div className="rounded-2xl border border-slate-800 bg-card/70 p-5">
            <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-400/10">
              <ShieldCheck className="h-5 w-5 text-emerald-400" aria-hidden />
            </span>
            <p className="mt-3 font-heading text-base font-bold text-white">Your limits</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Drafts only — publishing, deleting and account tools live in the owner's Studio.
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="creator-heading">
        My desk
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Submit your own content by link — the owner reviews everything before it goes live.
      </p>

      {application ? (
        <div
          className={`mt-6 rounded-xl border px-4 py-3 text-sm ${
            application.status === "approved"
              ? "border-emerald-500/30 bg-emerald-500/5 text-emerald-300"
              : application.status === "rejected"
                ? "border-rose-500/30 bg-rose-500/5 text-rose-300"
                : "border-amber-500/30 bg-amber-500/5 text-amber-300"
          }`}
          data-testid="worker-application-status"
        >
          <b>Creator application: {application.status}</b>
          {application.status === "pending" ? " — the owner is reviewing your channel." : ""}
          {application.status === "rejected" && application.admin_note ? ` — ${application.admin_note}` : ""}
        </div>
      ) : null}

      <div className="mt-6 grid gap-4 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <div className="flex items-center justify-between">
            <h2 className="font-heading text-sm font-bold uppercase tracking-widest text-zinc-400">
              My submissions ({submissions.length})
            </h2>
            <Link
              to="/creator/submit"
              data-testid="worker-quick-submit-link"
              className={buttonVariants({ size: "sm", className: "bg-sky-400 font-bold text-slate-950 hover:bg-sky-300" })}
            >
              <Send className="mr-1.5 h-3.5 w-3.5" aria-hidden /> Submit content
            </Link>
          </div>
          <div className="mt-3 space-y-3" data-testid="worker-submissions-list">
            {submissions.length === 0 ? (
              <Card className="border-slate-800 bg-card/70">
                <CardContent className="px-5 py-8 text-center text-sm text-muted-foreground">
                  Nothing submitted yet — send your first video link from “Submit content”.
                </CardContent>
              </Card>
            ) : (
              submissions.map((sub) => (
                <Card key={sub.id} className="border-slate-800 bg-card/70" data-testid={`worker-submission-${sub.id}`}>
                  <CardContent className="flex flex-wrap items-start gap-3 px-5 py-4">
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm font-bold text-white">{sub.title}</p>
                      <p className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                        <span className="capitalize">{sub.kind}</span>
                        {sub.language ? <span>· {sub.language}</span> : null}
                        <span>· {formatDate(sub.created_at)}</span>
                      </p>
                      {sub.admin_note ? (
                        <p className="mt-1 text-xs text-zinc-500">Owner note: {sub.admin_note}</p>
                      ) : null}
                    </div>
                    <a
                      href={sub.source_url}
                      target="_blank"
                      rel="noreferrer"
                      className="flex items-center gap-1 text-xs font-bold text-sky-400 hover:text-sky-300"
                      data-testid={`worker-submission-link-${sub.id}`}
                    >
                      <ExternalLink className="h-3.5 w-3.5" aria-hidden /> Link
                    </a>
                    <Badge className={STATUS_STYLES[sub.status] ?? "bg-slate-600/30 text-zinc-300"} data-testid={`worker-submission-status-${sub.id}`}>
                      {STATUS_LABELS[sub.status] ?? sub.status}
                    </Badge>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </div>

        <Card className="h-fit border-slate-800 bg-card/70" data-testid="worker-rules-card">
          <CardContent className="px-5 py-5">
            <h2 className="flex items-center gap-2 font-heading text-sm font-bold text-white">
              <ShieldCheck className="h-4 w-4 text-sky-400" aria-hidden /> House rules
            </h2>
            <ul className="mt-3 space-y-3 text-xs leading-relaxed text-zinc-400">
              <li className="flex gap-2">
                <ShieldCheck className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-sky-400" aria-hidden />
                Only content you own or have rights to — add proof in your application (your channel).
              </li>
              <li className="flex gap-2">
                <ShieldCheck className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-sky-400" aria-hidden />
                No illegal, toxic or copied content — anything infringing is rejected.
              </li>
              <li className="flex gap-2">
                <Timer className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-sky-400" aria-hidden />
                3-month rule — a title with no response (0 views) for 90 days is removed.
              </li>
              <li className="flex gap-2">
                <Clock3 className="mt-0.5 h-3.5 w-3.5 flex-shrink-0 text-sky-400" aria-hidden />
                The owner finishes details and launches — Upcoming (countdown) or listed on Home.
              </li>
            </ul>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
