import { useState, type FormEvent } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { FileVideo, Loader2, UploadCloud } from "lucide-react";
import { toast } from "sonner";
import { ApiError, apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import { uploadVideo } from "@/lib/uploadVideo";
import type { Title } from "@/lib/types";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

const KINDS = [
  { value: "anime", label: "Anime" },
  { value: "movie", label: "Movie" },
  { value: "cartoon", label: "Cartoon" },
  { value: "kdrama", label: "K-Drama" },
  { value: "webseries", label: "Web Series" },
] as const;

function formatBytes(bytes: number): string {
  if (bytes >= 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024 * 1024)).toFixed(1)} GB`;
  if (bytes >= 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(0)} MB`;
  if (bytes >= 1024) return `${(bytes / 1024).toFixed(0)} KB`;
  return `${bytes} B`;
}

// WORKER upload desk — the owner's upload staff: pick the PLAYLIST the video belongs
// to (an existing series/movie title) or create a new one, attach the real video file
// (multipart, with progress), save the episode as a DRAFT. The video uploads ONCE —
// the owner then attaches/edits it in the Studio without any re-upload or re-download.
export default function WorkerUpload() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    titleId: "new",
    name: "",
    kind: "anime",
    year: "2025",
    language: "",
    epName: "",
    resolution: "",
  });
  const [file, setFile] = useState<File | null>(null);
  const [progress, setProgress] = useState({ percent: 0, loadedBytes: 0, totalBytes: 0 });
  const existingTitles = useQuery({
    queryKey: ["titles", "worker-list"],
    queryFn: () => apiGet<Title[]>("/titles?all=1"),
  });

  const uploadDraft = useMutation({
    mutationFn: async () => {
      let titleId: string;
      let number: number;
      if (form.titleId !== "new") {
        // group under the EXISTING playlist — the video joins the next episode slot
        const picked = (existingTitles.data ?? []).find((t) => t.id === form.titleId);
        if (!picked) throw new Error("Picked playlist no longer exists — refresh and try again");
        titleId = picked.id;
        const detail = await apiGet<{ episodes: { number: number }[] }>(`/titles/${picked.slug}`).catch(() => ({ episodes: [] }));
        number = detail.episodes.length ? Math.max(...detail.episodes.map((e) => Number(e.number) || 0)) + 1 : 1;
      } else {
        const title = await apiPost<Title>("/titles", {
          name: form.name,
          kind: form.kind,
          release_year: Number(form.year),
          synopsis: "",
          type: form.kind === "movie" ? "movie" : "series",
          genres: [],
          studio: "",
          age_rating: "",
          original_language: form.language,
          airing_status: "",
          audio: ["Eng Sub"],
          rating: null,
          featured: false,
          poster_url: "",
          status: "draft",
        });
        titleId = title.id;
        number = 1;
      }
      const upload = await uploadVideo(file!, setProgress);
      return apiPost(`/titles/${titleId}/episodes`, {
        number,
        season: 1,
        name: form.epName || `Episode ${number}`,
        description: "",
        source: "Custom",
        video_key: upload.video_key,
        duration_seconds: null,
        status: "draft",
        resolution: form.resolution || null,
        dub_tag: null,
        thumbnail_url: null,
      });
    },
    onSuccess: () => {
      toast.success("Draft uploaded — the owner will review and launch it");
      navigate("/worker");
    },
    onError: (error) => toast.error(error instanceof ApiError ? apiErrorMessage(error) : "Upload failed"),
  });

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    if (!file) {
      toast.error("Pick a video file first");
      return;
    }
    uploadDraft.mutate();
  }

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="worker-upload-heading">
        Upload video
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Saves as a DRAFT under a playlist — only the owner can publish. No re-upload needed later.
      </p>

      <Card className="mt-6 border-slate-800 bg-card/70" data-testid="worker-upload-card">
        <CardContent className="px-6 py-6">
          <form className="space-y-3" onSubmit={onSubmit} data-testid="worker-upload-form">
            <div className="space-y-1.5">
              <Label htmlFor="wu-playlist">Playlist (series / movie the video belongs to)</Label>
              <Select value={form.titleId} onValueChange={(value) => setForm({ ...form, titleId: value })}>
                <SelectTrigger id="wu-playlist" className="border-slate-700 bg-slate-900/70" data-testid="worker-upload-playlist-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="new">+ New playlist / title</SelectItem>
                  {(existingTitles.data ?? []).map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.name} {t.status === "draft" ? "(draft)" : ""}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-zinc-500">
                Videos group under their playlist — pick the series/movie this file belongs to. Ask the admin to create one if it doesn't exist yet.
              </p>
            </div>
            {form.titleId === "new" ? (
              <>
                <div className="space-y-1.5">
                  <Label htmlFor="wu-name">Title name</Label>
                  <Input id="wu-name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="worker-upload-name-input" />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1.5">
                    <Label htmlFor="wu-kind">Category</Label>
                    <Select value={form.kind} onValueChange={(value) => setForm({ ...form, kind: value })}>
                      <SelectTrigger id="wu-kind" className="border-slate-700 bg-slate-900/70" data-testid="worker-upload-kind-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {KINDS.map((k) => (
                          <SelectItem key={k.value} value={k.value}>{k.label}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="wu-year">Year</Label>
                    <Input id="wu-year" type="number" min={1930} max={2100} required value={form.year} onChange={(e) => setForm({ ...form, year: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="worker-upload-year-input" />
                  </div>
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="wu-lang">Language</Label>
                  <Input id="wu-lang" placeholder="Hindi Dub" value={form.language} onChange={(e) => setForm({ ...form, language: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="worker-upload-language-input" />
                </div>
              </>
            ) : null}
            <div className="space-y-1.5">
              <Label htmlFor="wu-res">Resolution</Label>
              <Input id="wu-res" placeholder="1080p" value={form.resolution} onChange={(e) => setForm({ ...form, resolution: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="worker-upload-resolution-input" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="wu-ep">Episode name (optional)</Label>
              <Input id="wu-ep" placeholder="Episode 1" value={form.epName} onChange={(e) => setForm({ ...form, epName: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="worker-upload-epname-input" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="wu-file">Video file</Label>
              <Input
                id="wu-file"
                type="file"
                accept="video/*"
                required
                onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                className="border-slate-700 bg-slate-900/70 file:mr-3 file:rounded-md file:border-0 file:bg-emerald-400/20 file:px-3 file:py-1 file:text-xs file:font-bold file:text-emerald-300"
                data-testid="worker-upload-file-input"
              />
            </div>
            {uploadDraft.isPending ? (
              <div data-testid="worker-upload-progress">
                <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                  <div className="h-full rounded-full bg-emerald-400 transition-all" style={{ width: `${progress.percent}%` }} />
                </div>
                <p className="mt-1.5 text-xs text-zinc-400" data-testid="worker-upload-progress-label">
                  {progress.percent >= 100
                    ? "Stored on the server — saving to cloud storage… (a few minutes for big files)"
                    : `Uploading… ${progress.percent}% · ${formatBytes(progress.loadedBytes)} of ${formatBytes(progress.totalBytes)}`}
                </p>
              </div>
            ) : null}
            <Button
              type="submit"
              disabled={uploadDraft.isPending}
              className="w-full bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300"
              data-testid="worker-upload-btn"
            >
              {uploadDraft.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <FileVideo className="mr-2 h-4 w-4" aria-hidden />}
              {uploadDraft.isPending ? `Uploading… ${progress}%` : "Upload draft"}
            </Button>
            <p className="flex items-center justify-center gap-1.5 text-center text-[11px] text-zinc-500">
              <UploadCloud className="h-3 w-3" aria-hidden /> Max 2 GB · mp4/mkv/webm/mov · magic-byte checked
            </p>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
