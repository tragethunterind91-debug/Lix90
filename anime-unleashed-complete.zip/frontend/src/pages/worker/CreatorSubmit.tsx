import { useState, type FormEvent } from "react";
import { useMutation } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { Link2, Loader2, Send } from "lucide-react";
import { toast } from "sonner";
import { ApiError, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";

const KINDS = [
  { value: "anime", label: "Anime" },
  { value: "movie", label: "Movie" },
  { value: "cartoon", label: "Cartoon" },
  { value: "kdrama", label: "K-Drama" },
  { value: "webseries", label: "Web Series" },
] as const;

// CREATOR submit desk (YouTube-style) — creators hand in their OWN content by LINK only
// (title, category, language, thumb, description). No video uploads here: the owner
// reviews the link, then builds and launches the title. Workers are a different role.
export default function CreatorSubmit() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    title: "",
    kind: "anime",
    language: "",
    description: "",
    source_url: "",
    thumbnail_url: "",
  });
  const submitLink = useMutation({
    mutationFn: () => apiPost("/supplier/submissions", form),
    onSuccess: () => {
      toast.success("Submitted — the owner will review your link");
      navigate("/creator");
    },
    onError: (error) => toast.error(error instanceof ApiError ? apiErrorMessage(error) : "Submit failed"),
  });

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    submitLink.mutate();
  }

  return (
    <div className="mx-auto max-w-2xl">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="creator-submit-heading">
        Submit content
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Send your video link — the owner reviews it and builds the title.
      </p>

      <Card className="mt-6 border-slate-800 bg-card/70" data-testid="creator-submit-card">
        <CardContent className="px-6 py-6">
          <h2 className="flex items-center gap-2 font-heading text-base font-bold text-white">
            <Link2 className="h-4 w-4 text-sky-400" aria-hidden /> Submit by link
          </h2>
          <p className="mt-1 text-xs text-muted-foreground">
            YouTube / Drive / any video link — reviewed before anything goes live.
          </p>
          <form className="mt-4 space-y-3" onSubmit={onSubmit} data-testid="creator-submit-form">
            <div className="space-y-1.5">
              <Label htmlFor="cs-title">Title</Label>
              <Input id="cs-title" required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="creator-submit-title-input" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="cs-kind">Category</Label>
                <Select value={form.kind} onValueChange={(value) => setForm({ ...form, kind: value })}>
                  <SelectTrigger id="cs-kind" className="border-slate-700 bg-slate-900/70" data-testid="creator-submit-kind-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {KINDS.map((k) => (
                      <SelectItem key={k.value} value={k.value}>{k.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="cs-lang">Language</Label>
                <Input id="cs-lang" placeholder="Hindi Dub" value={form.language} onChange={(e) => setForm({ ...form, language: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="creator-submit-language-input" />
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cs-url">Video link</Label>
              <Input id="cs-url" type="url" required placeholder="https://…" value={form.source_url} onChange={(e) => setForm({ ...form, source_url: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="creator-submit-url-input" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cs-thumb">Thumbnail URL (optional)</Label>
              <Input id="cs-thumb" type="url" placeholder="https://… poster image" value={form.thumbnail_url} onChange={(e) => setForm({ ...form, thumbnail_url: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="creator-submit-thumb-input" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="cs-desc">Description</Label>
              <Textarea id="cs-desc" rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="creator-submit-desc-input" />
            </div>
            <Button
              type="submit"
              disabled={submitLink.isPending}
              className="w-full bg-sky-400 font-bold text-slate-950 hover:bg-sky-300"
              data-testid="creator-submit-btn"
            >
              {submitLink.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <Send className="mr-2 h-4 w-4" aria-hidden />}
              Send for review
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
