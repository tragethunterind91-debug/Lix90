import { NavLink, Outlet, Link } from "react-router-dom";
import { ExternalLink, LayoutDashboard, LogOut, Send, TrendingUp, UploadCloud } from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import { useLogout, useMe } from "@/hooks/useAuth";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

// TWO STAFF WEBS sharing this shell — the owner's distinction:
//   worker  → WORKER DESK: the owner's own upload staff (upload anime/videos as drafts)
//   creator → CREATOR DESK: YouTube-style suppliers (submit their OWN content by link)
// Admins belong in /studio, plain viewers on /supplier.
export default function WorkerLayout({ variant = "worker" }: { variant?: "worker" | "creator" }) {
  const { data: me, isLoading } = useMe();
  const logout = useLogout();
  const isCreator = variant === "creator";
  const brand = isCreator ? "Creator Desk" : "Worker Desk";
  const wantRole = isCreator ? "creator" : "worker";
  const T = isCreator
    ? {
        chip: "bg-sky-400 text-slate-950 shadow-[0_0_24px_rgba(56,189,248,0.35)]",
        tag: "text-sky-400",
        navActive: "bg-sky-400/10 text-sky-300",
        avatar: "from-sky-400 to-blue-500",
        btn: "bg-sky-400 font-bold text-slate-950 hover:bg-sky-300",
      }
    : {
        chip: "bg-emerald-400 text-slate-950 shadow-[0_0_24px_rgba(16,185,129,0.35)]",
        tag: "text-emerald-400",
        navActive: "bg-emerald-400/10 text-emerald-300",
        avatar: "from-emerald-400 to-teal-500",
        btn: "bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300",
      };
  const loginPath = isCreator ? "/creator/login" : "/worker/login";

  const navItems = isCreator
    ? [
        { to: "/creator", label: "My desk", icon: LayoutDashboard, end: true, testid: "creator-nav-dashboard" },
        { to: "/creator/submit", label: "Submit content", icon: Send, end: false, testid: "creator-nav-submit" },
        { to: "/creator/growth", label: "Growth", icon: TrendingUp, end: false, testid: "creator-nav-growth" },
      ]
    : [
        { to: "/worker", label: "My desk", icon: LayoutDashboard, end: true, testid: "worker-nav-dashboard" },
        { to: "/worker/upload", label: "Upload video", icon: UploadCloud, end: false, testid: "worker-nav-upload" },
      ];

  if (isLoading) {
    return (
      <div className="flex min-h-svh items-center justify-center bg-[#07090E]">
        <div className="w-full max-w-md space-y-4 px-6" data-testid="worker-skeleton">
          <div className="h-10 w-52 animate-pulse rounded-lg bg-slate-800/70" />
          <div className="h-24 w-full animate-pulse rounded-xl bg-slate-800/70" />
          <div className="h-64 w-full animate-pulse rounded-xl bg-slate-800/70" />
        </div>
      </div>
    );
  }

  if (!me || (me.role !== wantRole && !(isCreator && me.role === "admin"))) {
    const message = !me
      ? `Sign in with your ${wantRole} account to open the desk.`
      : me.role === "admin" && isCreator
        ? "Admins can view creator analytics — or manage everything from the Studio Console."
        : me.role === "admin"
          ? "Admins manage everything from the Studio Console."
          : me.role === "worker"
          ? "You're staff (Worker Desk) — this is the Creator Desk."
          : me.role === "creator"
            ? "You're a creator (Creator Desk) — this is the Worker Desk."
            : isCreator
              ? "You're not an approved creator yet — apply from the Creator page."
              : "The Worker Desk is for the owner's upload staff — accounts are minted in the Studio.";
    return (
      <div className="flex min-h-svh items-center justify-center bg-[#07090E] px-4">
        <Card className="w-full max-w-md border-slate-800 bg-card/80">
          <CardContent className="flex flex-col items-center gap-4 px-8 py-14 text-center">
            <span className={`flex h-12 w-12 items-center justify-center rounded-xl ${T.chip}`}>
              <UploadCloud className="h-6 w-6" aria-hidden />
            </span>
            <span className="font-heading text-lg font-black tracking-tight text-white">
              Anime-Unleashed <span className={T.tag}>{brand}</span>
            </span>
            <h1 className="text-sm text-muted-foreground" data-testid="worker-gate-message">
              {message}
            </h1>
            {!me ? (
              <Link to={loginPath} data-testid="worker-gate-login-link" className={buttonVariants({ className: T.btn })}>
                Sign in
              </Link>
            ) : me.role === "admin" ? (
              <Link to="/studio" data-testid="worker-gate-studio-link" className={buttonVariants({ className: "bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" })}>
                Open Studio Console
              </Link>
            ) : me.role === "worker" ? (
              <Link to="/worker" data-testid="worker-gate-worker-link" className={buttonVariants({ className: T.btn })}>
                Open Worker Desk
              </Link>
            ) : me.role === "creator" ? (
              <Link to="/creator" data-testid="worker-gate-creator-link" className={buttonVariants({ className: T.btn })}>
                Open Creator Desk
              </Link>
            ) : (
              <Link to="/supplier" data-testid="worker-gate-supplier-link" className={buttonVariants({ className: T.btn })}>
                Become a creator
              </Link>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div className="flex min-h-svh bg-[#07090E] text-zinc-100" data-testid="worker-layout">
      {/* sidebar (desktop) */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-slate-800/80 bg-[#0A1210] p-5 md:flex">
        <div className="flex items-center gap-2.5">
          <img
            src="/logo-app-icon.png"
            alt="Anime-Unleashed"
            className="h-9 w-9 rounded-xl object-contain shadow-[0_0_20px_rgba(16,185,129,0.35)]"
          />
          <div>
            <p className="font-heading text-sm font-bold leading-tight text-white">Anime-Unleashed</p>
            <p className={`text-[10px] font-bold uppercase tracking-[0.2em] ${T.tag}`}>{brand}</p>
          </div>
        </div>

        <nav className="mt-8 space-y-1">
          {navItems.map(({ to, label, icon: Icon, end, testid }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                  isActive ? T.navActive : "text-zinc-400 hover:bg-white/5 hover:text-white"
                }`
              }
              data-testid={testid}
            >
              <Icon className="h-4.5 w-4.5" aria-hidden /> {label}
            </NavLink>
          ))}
        </nav>

        <div className="mt-auto space-y-3 border-t border-slate-800/80 pt-4">
          <Link
            to="/"
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-zinc-400 transition-colors hover:bg-white/5 hover:text-white"
            data-testid="worker-view-site-link"
          >
            <ExternalLink className="h-4 w-4" aria-hidden /> View live site
          </Link>
          <div className="flex items-center gap-2 rounded-lg bg-slate-900/70 px-3 py-2">
            <span className={`flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br ${T.avatar} text-xs font-bold text-slate-950`}>
              {me.display_name.slice(0, 1).toUpperCase()}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-semibold text-white">{me.display_name}</p>
              <p className="truncate text-[10px] text-muted-foreground">{me.email}</p>
            </div>
            <button
              onClick={() => logout.mutate()}
              aria-label="Sign out"
              data-testid="worker-signout-btn"
              className="rounded-md p-1.5 text-zinc-400 transition-colors hover:bg-white/5 hover:text-rose-400"
            >
              <LogOut className="h-4 w-4" aria-hidden />
            </button>
          </div>
        </div>
      </aside>

      {/* content column */}
      <div className="flex min-h-svh flex-1 flex-col md:ml-64">
        <div className="border-b border-slate-800/80 bg-[#0A1210] px-4 py-3 md:hidden">
          <div className="flex items-center justify-between">
            <p className="font-heading text-sm font-bold text-white">
              Anime-Unleashed <span className={T.tag}>{brand}</span>
            </p>
            <div className="flex items-center gap-2">
              <Link to="/" data-testid="worker-mobile-site-link" className="text-xs text-zinc-400">
                View site
              </Link>
              <button onClick={() => logout.mutate()} data-testid="worker-mobile-signout-btn" className="text-xs text-rose-400">
                Sign out
              </button>
            </div>
          </div>
          <nav className="mt-3 flex gap-2">
            {navItems.map(({ to, label, end, testid }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) =>
                  `flex-1 rounded-full border px-3.5 py-1.5 text-center text-xs font-semibold ${
                    isActive ? "border-slate-500 bg-white/10 text-white" : "border-slate-700 text-zinc-300"
                  }`
                }
                data-testid={testid}
              >
                {label}
              </NavLink>
            ))}
          </nav>
        </div>

        <main className="flex-1 px-4 py-6 sm:px-6 md:px-8" data-testid="worker-main">
          <Outlet />
        </main>
      </div>

      <Toaster position="bottom-right" richColors />
    </div>
  );
}
