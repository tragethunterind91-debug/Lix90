import { useState, type FormEvent } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Loader2, UploadCloud } from "lucide-react";
import { toast } from "sonner";
import { ApiError } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import { useLogin } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

// Staff sign-in for BOTH staff webs — the owner's distinction:
//   worker  → Worker Desk (owner's upload staff: uploads anime/videos as drafts)
//   creator → Creator Desk (YouTube-style: submits their OWN content by link)
// Admins bounce to /studio, plain viewers to the creator application.
// No Studio PIN here — that gate is admin-only.
export default function WorkerLogin({ variant = "worker" }: { variant?: "worker" | "creator" }) {
  const login = useLogin();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: "", password: "" });
  const isCreator = variant === "creator";
  const brand = isCreator ? "Creator Desk" : "Worker Desk";

  function submit(event: FormEvent) {
    event.preventDefault();
    login.mutate(form, {
      onSuccess: (user) => {
        if (user.role === "worker") navigate("/worker");
        else if (user.role === "creator") navigate("/creator");
        else if (user.role === "admin") {
          toast.info("Admin account — opening the Studio Console");
          navigate("/studio");
        } else {
          toast.info("Apply as a creator to get a desk");
          navigate("/supplier");
        }
      },
      onError: (error) =>
        toast.error(error instanceof ApiError ? apiErrorMessage(error) : "Sign-in failed"),
    });
  }

  return (
    <div
      className={`flex min-h-svh items-center justify-center px-4 ${isCreator ? "bg-[#070B12]" : "bg-[#07090E]"}`}
      data-testid={`${variant}-login-page`}
    >
      <Card className="w-full max-w-md border-slate-800 bg-card/80">
        <CardContent className="px-8 py-10">
          <div className="flex flex-col items-center text-center">
            <span className={`flex h-12 w-12 items-center justify-center rounded-xl ${isCreator ? "bg-sky-400 text-slate-950 shadow-[0_0_24px_rgba(56,189,248,0.35)]" : "bg-emerald-400 text-slate-950 shadow-[0_0_24px_rgba(16,185,129,0.35)]"}`}>
              <UploadCloud className="h-6 w-6" aria-hidden />
            </span>
            <h1 className="mt-4 font-heading text-xl font-black tracking-tight text-white">
              Anime-Unleashed <span className={isCreator ? "text-sky-400" : "text-emerald-400"}>{brand}</span>
            </h1>
            <p className="mt-1 text-xs text-muted-foreground">
              {isCreator
                ? "Creator sign-in — submit your own content by link for review."
                : "Worker sign-in — upload the owner's videos as drafts for review."}
            </p>
          </div>
          <form className="mt-8 space-y-4" onSubmit={submit} data-testid={`${variant}-login-form`}>
            <div className="space-y-2">
              <Label htmlFor="wl-email">Email</Label>
              <Input
                id="wl-email"
                type="email"
                required
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                className="border-slate-700 bg-slate-900/70"
                placeholder="you@example.com"
                data-testid={`${variant}-login-email-input`}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="wl-password">Password</Label>
              <Input
                id="wl-password"
                type="password"
                required
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
                className="border-slate-700 bg-slate-900/70"
                data-testid={`${variant}-login-password-input`}
              />
            </div>
            <Button
              type="submit"
              disabled={login.isPending}
              className={`w-full ${isCreator ? "bg-sky-400 font-bold text-slate-950 hover:bg-sky-300" : "bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300"}`}
              data-testid={`${variant}-login-submit-btn`}
            >
              {login.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : null}
              Enter the desk
            </Button>
          </form>
          <p className="mt-6 text-center text-xs text-muted-foreground">
            {isCreator ? (
              <>
                Not a creator yet?{" "}
                <Link to="/supplier" className="font-bold text-sky-400 hover:text-sky-300" data-testid="worker-login-supplier-link">
                  Apply as a creator
                </Link>
              </>
            ) : (
              <>Worker accounts are minted by the owner in Studio → Accounts.</>
            )}
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
