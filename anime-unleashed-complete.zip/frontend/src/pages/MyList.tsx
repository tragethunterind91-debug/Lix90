import { Link, useNavigate } from "react-router-dom";
import { BookmarkX, LogIn, Tv } from "lucide-react";
import { useMe } from "@/hooks/useAuth";
import { useToggleListGuard } from "@/hooks/useWatchlist";
import type { Title } from "@/lib/types";
import AnimeCard from "@/components/AnimeCard";
import { CardGridSkeleton } from "@/components/Skeletons";
import EmptyState from "@/components/EmptyState";
import { buttonVariants } from "@/components/ui/button";

// My List: personal watchlist; requires sign-in (watching never does).
export default function MyList() {
  const { data: me, isLoading } = useMe();
  const { inList, handle, watchlist } = useToggleListGuard();
  const navigate = useNavigate();

  if (isLoading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <CardGridSkeleton count={6} />
      </div>
    );
  }

  if (!me) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <EmptyState
          icon={LogIn}
          title="Sign in to see your list"
          message="Your watchlist follows your account. Sign in — or create a free one — to bookmark titles."
          actionLabel="Sign in"
          onAction={() => navigate("/login")}
          testId="mylist-signin-prompt"
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="mylist-heading">
        My List
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Bookmarked by {me.display_name} — click the bookmark to remove.
      </p>

      <div className="mt-6">
        {watchlist === undefined ? (
          <CardGridSkeleton count={6} />
        ) : watchlist.items.length > 0 ? (
          <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 md:gap-5 xl:grid-cols-6">
            {watchlist.items.map((title: Title) => (
              <AnimeCard key={title.id} title={title} inList={inList(title.id)} onToggleList={handle} />
            ))}
          </div>
        ) : (
          <EmptyState
            icon={BookmarkX}
            title="No video, Coming Soon"
            message="No video saved to your watchlist yet. Tap the bookmark on any poster or explore upcoming releases."
            actionLabel="Explore catalog"
            onAction={() => navigate("/browse")}
            testId="mylist-empty"
          />
        )}
      </div>

      <div className="mt-10 text-center">
        <Link to="/" className={buttonVariants({ variant: "ghost", className: "text-zinc-400" })} data-testid="mylist-home-link">
          <Tv className="mr-2 h-4 w-4" aria-hidden /> Back to home
        </Link>
      </div>
    </div>
  );
}
