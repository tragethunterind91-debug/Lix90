import { useState, useEffect } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  KeyRound,
  ShieldCheck,
  Mail,
  Send,
  AlertCircle,
  CheckCircle2,
  Sparkles,
  HelpCircle,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { apiPost, apiGet, apiErrorMessage } from "@/lib/api";
import { firebaseGoogleSignIn } from "@/lib/firebase";
import { useQueryClient } from "@tanstack/react-query";

export default function ForgotPassword() {
  const navigate = useNavigate();
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const [autoIpTried, setAutoIpTried] = useState(false);

  // Admin recovery request states
  const [accountIdentifier, setAccountIdentifier] = useState("");
  const [recoveryNote, setRecoveryNote] = useState("");
  const [submittedResult, setSubmittedResult] = useState<string | null>(null);

  // AUTOMATIC DEVICE / IP LOGIN: Runs automatically in background on mount
  useEffect(() => {
    let mounted = true;
    async function attemptAutoIpLogin() {
      try {
        const res: any = await apiGet("/auth/auto-login-ip");
        if (mounted && res && res.email) {
          await qc.invalidateQueries({ queryKey: ["me"] });
          toast.success(`Recognized your device & IP! Signed in as ${res.display_name || res.email}`);
          navigate("/");
        }
      } catch {
        if (mounted) setAutoIpTried(true);
      }
    }
    void attemptAutoIpLogin();
    return () => {
      mounted = false;
    };
  }, [navigate, qc]);

  // 1. Recover via Google Auth
  async function handleGoogleVerify() {
    setBusy(true);
    try {
      const fbUser = await firebaseGoogleSignIn();
      const idToken = await fbUser.getIdToken();
      await apiPost("/auth/firebase-login", { id_token: idToken });
      await qc.invalidateQueries({ queryKey: ["me"] });
      toast.success("Identity verified via Google! Signed in successfully.");
      navigate("/");
    } catch (err) {
      toast.error(apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  // 2. Request Admin Account Recovery via Email
  async function handleAdminRecovery(e: React.FormEvent) {
    e.preventDefault();
    if (!accountIdentifier.trim() || !recoveryNote.trim()) {
      toast.error("Please provide your email/user ID and a note.");
      return;
    }
    setBusy(true);
    try {
      const res: any = await apiPost("/auth/recover-request", {
        email_or_id: accountIdentifier.trim(),
        user_note: recoveryNote.trim(),
        device_info: `${navigator.userAgent} · Screen: ${window.innerWidth}x${window.innerHeight}`,
      });
      setSubmittedResult(
        `Request dispatched! Admin (AnimeUnleashed@adown.com) will review your verified IP (${res.verified_ip}) and contact you to ask security questions.`
      );
      toast.success("Recovery request sent directly to AnimeUnleashed@adown.com!");
    } catch (err) {
      toast.error(apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex min-h-[calc(100vh-8rem)] items-center justify-center px-4 py-12">
      <Card className="w-full max-w-lg border-slate-800 bg-card/90 shadow-2xl backdrop-blur-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-2 flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-amber-500 text-slate-950 shadow-lg shadow-amber-400/20">
            <KeyRound className="h-6 w-6" aria-hidden />
          </div>
          <CardTitle className="font-heading text-2xl font-black tracking-tight text-white">
            Account Recovery
          </CardTitle>
          <CardDescription className="text-zinc-300">
            Verify with your Google account, or submit a recovery request to the admin.
          </CardDescription>

          {/* Contact Admin Email Badge */}
          <div className="mt-3 flex items-center justify-center gap-2 rounded-xl border border-amber-400/30 bg-amber-400/10 p-2.5 text-xs text-amber-200">
            <Mail className="h-4 w-4 text-amber-400" />
            <span>Direct Support Email: </span>
            <a href="mailto:AnimeUnleashed@adown.com" className="font-bold text-amber-300 underline">
              AnimeUnleashed@adown.com
            </a>
          </div>
        </CardHeader>

        <CardContent className="space-y-6">
          {/* Method 1: Google Verification */}
          <div className="rounded-2xl border border-slate-800 bg-slate-900/60 p-5">
            <div className="flex items-center gap-3">
              <ShieldCheck className="h-5 w-5 text-emerald-400 flex-shrink-0" />
              <div>
                <h4 className="text-sm font-bold text-white">Verify via Google Account</h4>
                <p className="text-xs text-zinc-400">
                  Instant 1-click verification. If your account matches your Google email, you are logged in right away.
                </p>
              </div>
            </div>
            <Button
              onClick={handleGoogleVerify}
              disabled={busy}
              className="mt-4 w-full h-11 rounded-xl bg-white text-slate-950 font-bold hover:bg-zinc-200"
            >
              Verify &amp; Sign In with Google
            </Button>
          </div>

          <div className="relative flex items-center justify-center text-xs text-zinc-500 uppercase">
            <span className="w-full border-t border-slate-800" />
            <span className="bg-card px-3 text-zinc-400 font-bold">OR ASK ADMIN</span>
            <span className="w-full border-t border-slate-800" />
          </div>

          {/* Method 2: Request Admin Recovery with Security Questions */}
          <form onSubmit={handleAdminRecovery} className="space-y-4 rounded-2xl border border-slate-800 bg-slate-900/40 p-5">
            <div className="flex items-start gap-2.5 text-xs text-zinc-300">
              <HelpCircle className="h-4 w-4 text-amber-400 flex-shrink-0 mt-0.5" />
              <p>
                Submit your User ID or email below. The administrator (<span className="text-amber-300 font-mono">AnimeUnleashed@adown.com</span>) will review your device IP and contact you with identity questions. Once answered correctly, your access will be restored.
              </p>
            </div>

            <div>
              <label className="text-xs font-semibold text-zinc-300">Account Email or User ID</label>
              <Input
                value={accountIdentifier}
                onChange={(e) => setAccountIdentifier(e.target.value)}
                placeholder="Enter your user email or ID"
                required
                className="mt-1 h-11 border-slate-700 bg-slate-900 text-xs"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-zinc-300">
                Note / Details for Admin (Recent episodes watched, favorite anime, etc.)
              </label>
              <textarea
                value={recoveryNote}
                onChange={(e) => setRecoveryNote(e.target.value)}
                placeholder="Tell the admin details only the real owner knows..."
                rows={3}
                required
                className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-900 p-3 text-xs text-white placeholder:text-zinc-600 focus:outline-none focus:ring-2 focus:ring-purple-500"
              />
            </div>

            {submittedResult && (
              <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs text-emerald-300">
                <CheckCircle2 className="mb-1 inline-block h-4 w-4 mr-1 text-emerald-400" />
                {submittedResult}
              </div>
            )}

            <Button
              type="submit"
              disabled={busy}
              className="w-full h-11 rounded-xl bg-gradient-to-r from-[#FF2A85] to-[#FF4655] font-black text-white hover:opacity-90"
            >
              <Send className="mr-2 h-4 w-4" /> Send Request to Admin
            </Button>
          </form>

          <div className="border-t border-slate-800/80 pt-4 text-center">
            <Link to="/login" className="text-xs text-zinc-400 hover:text-white">
              Remember your password? <span className="font-bold text-amber-400">Sign in here</span>
            </Link>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
