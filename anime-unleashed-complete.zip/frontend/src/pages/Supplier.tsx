import { useState, type FormEvent } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { BadgeCheck, Loader2, Send, ShieldCheck, Timer } from "lucide-react";
import { toast } from "sonner";
import { ApiError, apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import { useMe } from "@/hooks/useAuth";
import { Badge } from "@/components/ui/badge";
import { buttonVariants } from "@/components/ui/button";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import type { SupplierMeOut } from "@/lib/types";

const RULES = [
  { icon: ShieldCheck, title: "Own your content", text: "Only videos you made or have rights to — prove it with your channel when you apply." },
  { icon: ShieldCheck, title: "No illegal or toxic content", text: "Anything unlawful, hateful or harmful is rejected on sight." },
  { icon: BadgeCheck, title: "No copyright infringement", text: "Copied uploads are banned — creators keep full ownership of their originals." },
  { icon: Timer, title: "The 3-month rule", text: "A title with no response (0 views) for 90 days is removed automatically on purge." },
];

const CONTENT_TYPES = ["Anime", "Movie", "Cartoon", "K-Drama", "Web Series", "Other"] as const;

// Supplier landing page — the notes' "distribution" program: viewers apply, the owner
// approves them into the Worker Desk (worker role), then content flows by link.
export default function Supplier() {
  const { data: me } = useMe();
  const desk = useQuery({
    queryKey: ["supplier", "me"],
    queryFn: () => apiGet<SupplierMeOut>("/supplier/me"),
    enabled: !!me,
  });
  const [form, setForm] = useState({ channel_name: "", channel_url: "", content_type: "Anime", note: "" });
  const apply = useMutation({
    mutationFn: () => apiPost("/supplier/apply", form),
    onSuccess: () => {
      toast.success("Application sent — the owner will review your channel");
      void desk.refetch();
    },
    onError: (error) => toast.error(error instanceof ApiError ? apiErrorMessage(error) : "Application failed"),
  });

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    apply.mutate();
  }

  const application = desk.data?.application ?? null;

  return (
    <div className="mx-auto max-w-5xl px-0 py-10 sm:px-6" data-testid="supplier-page">
      <div className="text-center">
        <Badge className="border border-emerald-500/40 bg-emerald-500/10 text-emerald-300" data-testid="supplier-badge">
          <BadgeCheck className="mr-1 h-3 w-3" aria-hidden /> CREATOR PROGRAM
        </Badge>
        <h1 className="mt-3 font-heading text-3xl font-bold tracking-tight text-white sm:text-4xl" data-testid="supplier-heading">
          Become a <span className="text-emerald-400">Creator</span>
        </h1>
        <p className="mx-auto mt-2 max-w-2xl text-sm text-zinc-400">
          Got anime, cartoons, movies or series of your own? Submit by link, we review it, and approved
          creators get the Creator Desk — your content goes live after the owner's launch review.
        </p>
      </div>

      {/* rules */}
      <div className="mt-8 grid gap-3 sm:grid-cols-2 lg:grid-cols-4" data-testid="supplier-rules">
        {RULES.map((rule) => (
          <Card key={rule.title} className="border-slate-800 bg-card/70">
            <CardContent className="p-5">
              <rule.icon className="h-5 w-5 text-emerald-400" aria-hidden />
              <p className="mt-3 font-heading text-sm font-bold text-white">{rule.title}</p>
              <p className="mt-1 text-xs leading-relaxed text-zinc-400">{rule.text}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* state panel */}
      <Card className="mx-auto mt-10 max-w-2xl border-slate-800 bg-card/80" data-testid="supplier-panel">
        <CardContent className="px-6 py-8 sm:px-8">
          {!me ? (
            <div className="text-center" data-testid="supplier-gate">
              <p className="text-sm text-zinc-300">Sign in first, then apply with your channel.</p>
              <Link
                to="/login"
                data-testid="supplier-login-link"
                className={buttonVariants({ className: "mt-4 bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300" })}
              >
                Sign in to apply
              </Link>
            </div>
          ) : me.role === "creator" ? (
            <div className="text-center" data-testid="supplier-approved">
              <BadgeCheck className="mx-auto h-8 w-8 text-emerald-400" aria-hidden />
              <p className="mt-3 font-heading text-base font-bold text-white">You're an approved creator</p>
              <p className="mt-1 text-sm text-zinc-400">Head to the Creator Desk to submit content.</p>
              <Link
                to="/creator"
                data-testid="supplier-desk-link"
                className={buttonVariants({ className: "mt-4 bg-sky-400 font-bold text-slate-950 hover:bg-sky-300" })}
              >
                Open Creator Desk
              </Link>
            </div>
          ) : me.role === "worker" ? (
            <div className="text-center" data-testid="supplier-worker-note">
              <p className="text-sm text-zinc-300">You're on the owner's upload staff — use the Worker Desk.</p>
              <Link
                to="/worker"
                data-testid="supplier-worker-link"
                className={buttonVariants({ className: "mt-4 bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300" })}
              >
                Open Worker Desk
              </Link>
            </div>
          ) : me.role === "admin" ? (
            <div className="text-center" data-testid="supplier-admin-note">
              <p className="text-sm text-zinc-300">You're staff — review supplier applications in the Studio.</p>
              <Link
                to="/studio/suppliers"
                data-testid="supplier-studio-link"
                className={buttonVariants({ className: "mt-4 bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" })}
              >
                Open Studio review
              </Link>
            </div>
          ) : application && application.status === "pending" ? (
            <div className="text-center" data-testid="supplier-pending">
              <Timer className="mx-auto h-8 w-8 text-amber-400" aria-hidden />
              <p className="mt-3 font-heading text-base font-bold text-white">Application in review</p>
              <p className="mt-1 text-sm text-zinc-400">
                {application.channel_name} — the owner is checking your channel. You'll get Creator Desk
                access the moment it's approved.
              </p>
            </div>
          ) : application && application.status === "rejected" ? (
            <div className="text-center" data-testid="supplier-rejected">
              <p className="font-heading text-base font-bold text-white">Application declined</p>
              {application.admin_note ? <p className="mt-1 text-sm text-zinc-400">{application.admin_note}</p> : null}
              <p className="mt-3 text-xs text-zinc-500">Fix the issue and apply again below.</p>
            </div>
          ) : (
            <form className="space-y-4" onSubmit={onSubmit} data-testid="supplier-apply-form">
              <h2 className="font-heading text-base font-bold text-white">Apply as a supplier</h2>
              <div className="grid gap-3 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="sp-channel">Channel / brand name</Label>
                  <Input id="sp-channel" required minLength={2} value={form.channel_name} onChange={(e) => setForm({ ...form, channel_name: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="supplier-channel-input" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="sp-type">Content type</Label>
                  <Select value={form.content_type} onValueChange={(value) => setForm({ ...form, content_type: value })}>
                    <SelectTrigger id="sp-type" className="border-slate-700 bg-slate-900/70" data-testid="supplier-type-select">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CONTENT_TYPES.map((t) => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="sp-url">Channel link (ownership proof)</Label>
                <Input id="sp-url" type="url" required placeholder="https://youtube.com/@yourchannel" value={form.channel_url} onChange={(e) => setForm({ ...form, channel_url: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="supplier-url-input" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="sp-note">What will you supply? (min 10 chars)</Label>
                <Textarea id="sp-note" required minLength={10} rows={3} placeholder="e.g. I make original anime AMVs and Hindi-dubbed shorts — 40+ videos ready" value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="supplier-note-input" />
              </div>
              <Button
                type="submit"
                disabled={apply.isPending}
                className="w-full bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300"
                data-testid="supplier-apply-btn"
              >
                {apply.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <Send className="mr-2 h-4 w-4" aria-hidden />}
                Send application
              </Button>
            </form>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
