import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { BadgeCheck, Check, Copy, Crown, Globe2, Loader2, Save, ShieldCheck, Timer } from "lucide-react";
import { Sparkles as NftIcon } from "lucide-react";
import type { NFTOwnedItem } from "@/lib/nftTypes";
import { toast } from "sonner";
import { apiGet, apiPatch, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import { useAccount, useUpdateAccount } from "@/hooks/useSocial";
import { useMe } from "@/hooks/useAuth";
import { useFriends } from "@/hooks/useSocial";
import { formatDate } from "@/lib/badges";
import type { Region } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

// cool avatars: initial + gradient — zero emojis (owner rule)
export const AVATAR_STYLES: Record<string, string> = {
  sunset: "from-amber-400 via-orange-500 to-rose-500",
  ocean: "from-sky-400 via-cyan-500 to-blue-600",
  violet: "from-violet-400 via-purple-500 to-fuchsia-600",
  forest: "from-emerald-400 via-green-500 to-teal-600",
  candy: "from-pink-400 via-rose-500 to-red-500",
  gold: "from-yellow-300 via-amber-500 to-orange-600",
  ice: "from-slate-300 via-sky-400 to-indigo-500",
  flame: "from-red-500 via-orange-600 to-amber-500",
};

function avatarInitial(name: string): string {
  return (name || "?").trim().slice(0, 1).toUpperCase();
}

// Account hub — professional profile: banner header with avatar/ID, profile editor,
// preferences (region room, VIP with instant downgrade).
const REGIONS = [
  { value: "asia", label: "Asia" },
  { value: "americas", label: "Americas" },
  { value: "europe", label: "Europe" },
] as const;

export default function Account() {
  const account = useAccount();
  const friends = useFriends(!!account.data);
  const save = useUpdateAccount();
  const [name, setName] = useState("");
  const [avatar, setAvatar] = useState("sunset");
  const [country, setCountry] = useState<Region>("asia");
  const [phone, setPhone] = useState("");
  const [dirty, setDirty] = useState(false);
  const [smsCode, setSmsCode] = useState("");
  const [codeSent, setCodeSent] = useState(false);
  const [busy, setBusy] = useState(false);
  const { data: me } = useMe();

  const [showcaseNfts, setShowcaseNfts] = useState<NFTOwnedItem[]>([]);

  useEffect(() => {
    if (me?.id) {
      apiGet<NFTOwnedItem[]>(`/nft/user/${me.id}/showcase`)
        .then((res) => setShowcaseNfts(res))
        .catch(() => {});
    }
  }, [me?.id]);

  async function sendPhoneCode() {
    setBusy(true);
    setDirty(true);
    try {
      await apiPatch("/me/account", { phone: phone.replace(/\s/g, "") });  // save it as MINE first
      await apiPost("/auth/otp/phone/send", { phone: phone.replace(/\s/g, "") });
      setCodeSent(true);
      toast.success("SMS code sent to your number");
    } catch (err) {
      toast.error(apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function verifyPhone() {
    setBusy(true);
    try {
      await apiPost("/auth/otp/phone/verify", { phone: phone.replace(/\s/g, ""), code: smsCode });
      toast.success("Number verified!");
      setCodeSent(false);
      setSmsCode("");
      void account.refetch?.();
      window.location.reload();  // refreshes the session badge everywhere
    } catch (err) {
      toast.error(apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    if (account.data && !dirty) {
      setName(account.data.display_name);
      const cur = account.data.avatar_url || "";
      setAvatar(cur.startsWith("grad:") ? cur.slice(5) : "sunset");
      setCountry(account.data.country);
      setPhone(me?.phone ?? "");
    }
  }, [account.data, dirty, me?.phone]);

  function onSave() {
    save.mutate(
      { display_name: name, avatar_url: `grad:${avatar}`, country, phone: phone.replace(/\s/g, "") },
      { onSuccess: () => setDirty(false) },
    );
  }

  const acc = account.data;
  const friendCount = friends.data?.friends.length ?? 0;

  return (
    <div className="mx-auto max-w-3xl px-0 py-10 sm:px-6" data-testid="account-page">
      {/* profile banner */}
      <div className="relative overflow-hidden rounded-2xl border border-slate-800 bg-gradient-to-br from-[#1a1206] via-[#12100b] to-[#0a0a0f]" data-testid="account-banner">
        <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-[#F59E0B]/10 blur-3xl" />
        <div className="relative flex flex-wrap items-center gap-5 px-6 py-7 sm:px-8">
          <span className={`flex h-16 w-16 items-center justify-center rounded-2xl border-2 border-[#FBBF24]/50 bg-gradient-to-br sm:h-20 sm:w-20 sm:text-4xl text-2xl font-black text-white shadow-[0_0_40px_rgba(245,158,11,0.15)] ${AVATAR_STYLES[avatar] ?? AVATAR_STYLES.sunset}`} data-testid="account-banner-avatar">
            {avatarInitial(name)}
          </span>
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="font-heading text-2xl font-bold tracking-tight text-white" data-testid="account-banner-name">
                {acc?.display_name ?? "…"}
              </h1>
              {acc?.vip_active ? (
                <Badge className="border border-[#FBBF24]/40 bg-[#F59E0B]/10 text-[#FDE047]" data-testid="account-vip-badge">
                  <BadgeCheck className="mr-1 h-3 w-3" aria-hidden /> VIP
                </Badge>
              ) : null}
              {acc && acc.role !== "user" ? (
                <Badge className="bg-[#FF4655]/15 capitalize text-[#FF4655]">{acc.role}</Badge>
              ) : null}
            </div>
            <div className="mt-2 flex flex-wrap items-center gap-2 text-xs text-zinc-400">
              <button
                onClick={() => {
                  navigator.clipboard.writeText(acc?.account_id ?? "");
                  toast.success("ID copied");
                }}
                className="flex items-center gap-1.5 rounded-full border border-slate-700 bg-slate-900/60 px-3 py-1 font-bold text-amber-400 transition-colors hover:border-amber-400/40"
                data-testid="account-id-chip"
              >
                ID {acc?.account_id ?? "…"} <Copy className="h-3 w-3" aria-hidden />
              </button>
              <span className="flex items-center gap-1 rounded-full border border-slate-700 bg-slate-900/60 px-3 py-1" data-testid="account-region-chip">
                <Globe2 className="h-3 w-3" aria-hidden /> {REGIONS.find((r) => r.value === country)?.label ?? country}
              </span>
              <span className="flex items-center gap-1 rounded-full border border-slate-700 bg-slate-900/60 px-3 py-1" data-testid="account-friends-chip">
                {friendCount} / {acc?.friends_limit ?? 15} friends
              </span>
              {acc?.member_since ? (
                <span className="hidden items-center gap-1 rounded-full border border-slate-700 bg-slate-900/60 px-3 py-1 sm:flex">
                  Since {formatDate(acc.member_since)}
                </span>
              ) : null}
            </div>
          </div>
        </div>
      </div>

      <div className="mt-5 grid gap-5 md:grid-cols-2">
        {/* profile editor */}
        <Card className="border-slate-800 bg-card/80">
          <CardContent className="space-y-5 px-6 py-6">
            <h2 className="font-heading text-sm font-bold uppercase tracking-widest text-zinc-400">Profile</h2>
            <div>
              <Label>Avatar — pick your vibe</Label>
              <div className="mt-2 grid grid-cols-4 gap-2 sm:grid-cols-8" data-testid="account-avatar-grid">
                {Object.entries(AVATAR_STYLES).map(([key, grad]) => (
                  <button
                    key={key}
                    onClick={() => {
                      setAvatar(key);
                      setDirty(true);
                    }}
                    aria-label={`Pick ${key} avatar`}
                    className={`flex h-11 w-full items-center justify-center rounded-xl border text-lg font-black text-white bg-gradient-to-br transition-all ${grad} ${
                      avatar === key
                        ? "border-amber-400/70 shadow-[0_0_16px_rgba(245,158,11,0.35)] scale-105"
                        : "border-slate-700/80 hover:border-slate-500"
                    }`}
                    data-testid={`account-avatar-${key}`}
                  >
                    {avatarInitial(name)}
                  </button>
                ))}
              </div>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="acc-name">Display name</Label>
              <Input
                id="acc-name"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setDirty(true);
                }}
                maxLength={40}
                className="border-slate-700 bg-slate-900/70"
                data-testid="account-name-input"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="account-phone">Mobile number — one number, one account</Label>
              <div className="flex gap-2">
                <Input
                  id="account-phone"
                  type="tel"
                  value={phone}
                  onChange={(e) => {
                    setPhone(e.target.value);
                    setDirty(true);
                  }}
                  placeholder="98765 43210"
                  className="border-slate-700 bg-slate-900/70"
                  data-testid="account-phone-input"
                />
                <Button
                  type="button"
                  size="sm"
                  variant="outline"
                  disabled={busy || !phone}
                  onClick={() => void sendPhoneCode()}
                  className="border-amber-400/50 text-amber-300"
                  data-testid="account-phone-send-btn"
                >
                  {busy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : "Send code"}
                </Button>
              </div>
              {codeSent ? (
                <div className="mt-2 flex gap-2" data-testid="account-phone-verify-row">
                  <Input
                    value={smsCode}
                    onChange={(e) => setSmsCode(e.target.value.replace(/\D/g, ""))}
                    inputMode="numeric"
                    maxLength={6}
                    placeholder="6-digit SMS code"
                    className="border-slate-700 bg-slate-900/70"
                    data-testid="account-phone-code-input"
                  />
                  <Button
                    type="button"
                    size="sm"
                    onClick={() => void verifyPhone()}
                    disabled={busy || smsCode.length < 4}
                    className="bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300"
                    data-testid="account-phone-verify-btn"
                  >
                    Verify
                  </Button>
                </div>
              ) : null}
              {me?.phone_verified ? (
                <p className="mt-1 flex items-center gap-1 text-xs text-emerald-400" data-testid="account-phone-verified-badge">
                  <ShieldCheck className="h-3.5 w-3.5" aria-hidden /> Number verified
                </p>
              ) : null}
            </div>
            <Button
              onClick={onSave}
              disabled={save.isPending || !dirty}
              className="w-full bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
              data-testid="account-save-btn"
            >
              <Save className="mr-2 h-4 w-4" aria-hidden /> Save profile
            </Button>
          </CardContent>
        </Card>

        {/* preferences */}
        {/* NFT Showcase Section */}
        <div className="col-span-full mt-4">
          <Card className="border-slate-800 bg-card/80" data-testid="account-nft-showcase">
            <CardContent className="p-6 space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <NftIcon className="h-5 w-5 text-amber-400" />
                  <h2 className="font-heading text-base font-bold text-white">
                    NFT Profile Showcase
                  </h2>
                </div>
                <Link to="/inventory">
                  <Button variant="outline" size="sm" className="h-8 border-slate-700 text-xs text-amber-300">
                    Manage Inventory &rarr;
                  </Button>
                </Link>
              </div>

              {showcaseNfts.length === 0 ? (
                <div className="rounded-2xl border border-dashed border-slate-800 p-6 text-center text-xs text-zinc-500">
                  No NFTs currently displayed on your profile. Pin cards from your Inventory!
                </div>
              ) : (
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 lg:grid-cols-6">
                  {showcaseNfts.map((item) => (
                    <div
                      key={item.id}
                      className="overflow-hidden rounded-xl border border-slate-800 bg-slate-900/60 p-2 text-center text-xs"
                    >
                      <img
                        src={item.nft?.media_url || "/logo-app-icon.png"}
                        alt={item.nft?.name}
                        className="aspect-square w-full rounded-lg object-cover mb-1.5"
                      />
                      <p className="line-clamp-1 font-bold text-white text-[11px]">{item.nft?.name}</p>
                      <span className="text-[10px] text-amber-400 font-mono">#{item.serial}</span>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-5">
          <Card className="border-slate-800 bg-card/80">
            <CardContent className="space-y-4 px-6 py-6">
              <h2 className="font-heading text-sm font-bold uppercase tracking-widest text-zinc-400">Preferences</h2>
              <div className="space-y-1.5">
                <Label>Your region (global chat room)</Label>
                <Select
                  value={country}
                  onValueChange={(value) => {
                    setCountry(value as Region);
                    setDirty(true);
                  }}
                >
                  <SelectTrigger className="border-slate-700 bg-slate-900/70" data-testid="account-region-select">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {REGIONS.map((r) => (
                      <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-[11px] text-zinc-500">Global chat rooms only keep the last 5 minutes of messages.</p>
              </div>
            </CardContent>
          </Card>

          <Card className="border-slate-800 bg-card/80">
            <CardContent className="px-6 py-6">
              <div className="flex items-start gap-3">
                <Crown className="mt-0.5 h-5 w-5 text-amber-400" aria-hidden />
                <div className="min-w-0 flex-1">
                  <p className="font-heading text-sm font-bold text-white">
                    {acc?.vip_active ? "VIP is active" : "Free plan"}
                  </p>
                  <p className="mt-1 text-xs leading-relaxed text-zinc-400">
                    {acc?.vip_active
                      ? "Ad-free · unlimited watch-time · 30 friends · 300 free chat messages a day."
                      : "15 friends · chat costs 3 min per message · ads on. Go VIP to drop all of it."}
                  </p>
                </div>
              </div>
              <div className="mt-4">
                {acc?.vip_active ? (
                  <Button
                    variant="outline"
                    onClick={() => save.mutate({ downgrade_vip: true })}
                    disabled={save.isPending}
                    className="w-full border-rose-500/40 text-rose-300 hover:bg-rose-500/10"
                    data-testid="account-downgrade-btn"
                  >
                    <ShieldCheck className="mr-2 h-4 w-4" aria-hidden /> Downgrade VIP
                  </Button>
                ) : (
                  <Link
                    to="/vip"
                    className="flex w-full items-center justify-center rounded-lg bg-gradient-to-r from-[#F59E0B] to-[#d97706] px-4 py-2.5 text-sm font-bold text-slate-950 transition-opacity hover:opacity-90"
                    data-testid="account-vip-link"
                  >
                    <Timer className="mr-2 h-4 w-4" aria-hidden /> Go VIP — ₹66 / 2 months
                  </Link>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
