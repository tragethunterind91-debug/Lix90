import { useState } from "react";
import { Link } from "react-router-dom";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Layers,
  Send,
  Star,
  Gavel,
  ShieldCheck,
  Loader2,
  ExternalLink,
  Coins,
  ArrowRight,
  Sparkles,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { useMe } from "@/hooks/useAuth";
import { apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { NFTOwnedItem } from "@/lib/nftTypes";

export default function NftInventory() {
  const { data: me } = useMe();
  const queryClient = useQueryClient();
  const [transferItem, setTransferItem] = useState<NFTOwnedItem | null>(null);
  const [recipientEmail, setRecipientEmail] = useState("");

  const { data: items = [], isLoading } = useQuery<NFTOwnedItem[]>({
    queryKey: ["my-nfts"],
    queryFn: () => apiGet<NFTOwnedItem[]>("/nft/my/inventory"),
    enabled: !!me,
  });

  // Showcase toggle
  const toggleShowcase = useMutation({
    mutationFn: (ownedId: string) => apiPost(`/nft/my/${ownedId}/toggle-showcase`, {}),
    onSuccess: (res: any) => {
      toast.success(res?.showcase ? "Pinned to profile showcase!" : "Unpinned from showcase");
      void queryClient.invalidateQueries({ queryKey: ["my-nfts"] });
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  });

  // Transfer mutation
  const transferMutation = useMutation({
    mutationFn: ({ ownedId, email }: { ownedId: string; email: string }) =>
      apiPost("/nft/transfer", { owned_id: ownedId, recipient_email: email }),
    onSuccess: (res: any) => {
      toast.success(res?.message || "Transfer completed!");
      setTransferItem(null);
      setRecipientEmail("");
      void queryClient.invalidateQueries({ queryKey: ["my-nfts"] });
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  });

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8" data-testid="nft-inventory-page">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <h1 className="font-heading text-3xl font-black text-white">My NFT Inventory</h1>
          <p className="text-xs sm:text-sm text-zinc-400">
            Manage your digital collection, display cards on your public profile, or transfer to friends.
          </p>
        </div>

        <div className="flex gap-2">
          <Link to="/nft">
            <Button className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300">
              Marketplace &rarr;
            </Button>
          </Link>
          <Link to="/auctions">
            <Button variant="outline" className="border-purple-500/40 text-purple-300 hover:bg-purple-500/10">
              <Gavel className="mr-1.5 h-4 w-4" /> Auctions
            </Button>
          </Link>
        </div>
      </div>

      {isLoading ? (
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-64 animate-pulse rounded-2xl bg-slate-800/50" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <div className="mt-12 rounded-3xl border border-slate-800 bg-slate-900/30 py-16 text-center">
          <Layers className="mx-auto h-12 w-12 text-zinc-600 mb-3" />
          <p className="text-base font-bold text-zinc-300">Your Inventory is Empty</p>
          <p className="text-xs text-zinc-500 mt-1 max-w-sm mx-auto">
            You don't own any NFTs yet. Visit the Marketplace to explore 50+ anime, dragon and creature cards!
          </p>
          <Link to="/nft">
            <Button className="mt-4 bg-amber-400 font-black text-slate-950 hover:bg-amber-300">
              Explore Marketplace
            </Button>
          </Link>
        </div>
      ) : (
        <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4">
          {items.map((it) => (
            <Card
              key={it.id}
              className="overflow-hidden rounded-2xl border-slate-800 bg-slate-900/60 transition-all hover:border-amber-400/40"
              data-testid={`owned-nft-${it.id}`}
            >
              <div className="relative aspect-square w-full overflow-hidden bg-slate-950">
                <img
                  src={it.nft?.media_url || "/logo-app-icon.png"}
                  alt={it.nft?.name}
                  className="h-full w-full object-cover"
                />
                <span className="absolute top-2 left-2 rounded-lg bg-black/75 px-2 py-0.5 text-[10px] font-mono font-bold text-amber-400 backdrop-blur-md">
                  Serial #{it.serial}
                </span>

                {it.showcase && (
                  <span className="absolute top-2 right-2 flex items-center gap-1 rounded-lg bg-amber-400 px-2 py-0.5 text-[9px] font-black text-slate-950 shadow">
                    <Star className="h-3 w-3 fill-slate-950" /> Profile
                  </span>
                )}
                {it.in_auction && (
                  <span className="absolute bottom-2 left-2 rounded-lg bg-purple-600 px-2 py-0.5 text-[9px] font-bold text-white shadow">
                    In Auction
                  </span>
                )}
              </div>

              <CardContent className="p-3 space-y-2">
                <div>
                  <h3 className="line-clamp-1 font-heading text-sm font-bold text-white">
                    {it.nft?.name}
                  </h3>
                  <p className="text-[10px] text-zinc-400">
                    Acquired via: <span className="capitalize">{it.acquired_via}</span>
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-1.5 pt-1">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => toggleShowcase.mutate(it.id)}
                    className="h-7 text-[10px] border-slate-700 text-zinc-300"
                    data-testid={`toggle-showcase-${it.id}`}
                  >
                    <Star className={`mr-1 h-3 w-3 ${it.showcase ? "fill-amber-400 text-amber-400" : ""}`} />
                    {it.showcase ? "Pinned" : "Showcase"}
                  </Button>

                  <Button
                    size="sm"
                    variant="outline"
                    disabled={it.in_auction}
                    onClick={() => setTransferItem(it)}
                    className="h-7 text-[10px] border-slate-700 text-zinc-300 hover:text-white"
                    data-testid={`transfer-btn-${it.id}`}
                  >
                    <Send className="mr-1 h-3 w-3" /> Transfer
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {/* Transfer NFT Modal */}
      {transferItem && (
        <Dialog open={!!transferItem} onOpenChange={() => setTransferItem(null)}>
          <DialogContent className="max-w-md border-slate-800 bg-[#0B0F19] text-white p-6" data-testid="transfer-nft-modal">
            <DialogHeader>
              <DialogTitle className="font-heading text-xl font-black text-white">
                Transfer NFT
              </DialogTitle>
              <DialogDescription className="text-xs text-zinc-400">
                Send <strong>{transferItem.nft?.name}</strong> (#{transferItem.serial}) to another user by entering their account email.
              </DialogDescription>
            </DialogHeader>

            <form
              onSubmit={(e) => {
                e.preventDefault();
                transferMutation.mutate({
                  ownedId: transferItem.id,
                  email: recipientEmail,
                });
              }}
              className="space-y-4 pt-2"
            >
              <div>
                <label className="text-xs font-bold text-zinc-400">Recipient Email Address</label>
                <Input
                  type="email"
                  value={recipientEmail}
                  onChange={(e) => setRecipientEmail(e.target.value)}
                  placeholder="recipient@example.com"
                  className="mt-1 border-slate-800 bg-slate-900 text-xs text-white"
                  data-testid="transfer-email-input"
                  required
                />
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-950/70 p-3 text-[11px] text-zinc-400">
                ⚠️ Transferred NFTs immediately leave your inventory and cannot be revoked unless transferred back.
              </div>

              <div className="flex gap-2">
                <Button
                  type="button"
                  variant="outline"
                  onClick={() => setTransferItem(null)}
                  className="w-1/3 border-slate-800 text-zinc-300"
                >
                  Cancel
                </Button>
                <Button
                  type="submit"
                  disabled={transferMutation.isPending || !recipientEmail}
                  className="w-2/3 bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
                  data-testid="confirm-transfer-btn"
                >
                  {transferMutation.isPending ? "Transferring..." : "Confirm Transfer"}
                </Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
