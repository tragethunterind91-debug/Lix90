import { Card, CardContent } from "@/components/ui/card";

function LegalPageShell({
  title,
  updated,
  children,
}: {
  title: string;
  updated: string;
  children: React.ReactNode;
}) {
  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6 lg:px-8">
      <h1 className="font-heading text-3xl font-black tracking-tight text-white sm:text-4xl">{title}</h1>
      <p className="mt-2 text-xs uppercase tracking-widest text-muted-foreground">Last updated: {updated}</p>
      <Card className="mt-6 border-slate-800 bg-card/70">
        <CardContent className="prose-invert space-y-4 px-6 py-6 text-sm leading-relaxed text-zinc-300 [&_h2]:mt-6 [&_h2]:font-heading [&_h2]:text-base [&_h2]:font-bold [&_h2]:text-white [&_li]:ml-5 [&_li]:list-disc">
          {children}
        </CardContent>
      </Card>
    </div>
  );
}

export function Privacy() {
  return (
    <LegalPageShell title="Privacy Policy" updated="October 2026">
      <p>
        Anime-Unleashed Entertainment (“we”, “the platform”) is an anime streaming and discovery service built for
        Indian fans. This policy explains what we collect and why. We keep it short on purpose.
      </p>
      <h2>What we collect</h2>
      <ul>
        <li><strong>Account details:</strong> email address, display name, and a secure password (hashed) when you create an account.</li>
        <li><strong>View counts:</strong> anonymous view counters for each episode, used for “trending” and admin analytics. We do not sell this data.</li>
        <li><strong>Watchlist and resume points:</strong> stored so your list and “continue watching” follow your account.</li>
      </ul>
      <h2>What we don’t do</h2>
      <ul>
        <li>No selling of personal data, no third-party ad trackers beyond what you explicitly allow.</li>
        <li>No payment data is stored on our servers — payments (VIP tier) are handled by the payment provider.</li>
      </ul>
      <h2>Content takedown &amp; rights</h2>
      <p>
        We only host videos we own, license, or that are provided by rights holders (see Terms).
        If you believe content infringes your copyright, contact the studio admin via the About page
        and we will remove it promptly after verification.
      </p>
      <h2>Contact &amp; deletion</h2>
      <p>
        You can request account or data deletion at any time — write to the studio admin from the
        email registered on your account and we will erase your data within 30 days.
      </p>
    </LegalPageShell>
  );
}

export function Terms() {
  return (
    <LegalPageShell title="Terms & Conditions" updated="October 2026">
      <p>
        By using Anime-Unleashed Entertainment you agree to these terms. If you don’t agree, please don’t use the platform.
      </p>
      <h2>1. Watching and downloads</h2>
      <ul>
        <li>Watching requires no account. Downloads require an account and generate a private link that expires in 10 minutes.</li>
        <li>Download links are for <strong>personal, offline viewing only</strong>. Re-uploading, reselling, or public redistribution of downloaded files is strictly prohibited.</li>
      </ul>
      <h2>2. Content and rights</h2>
      <ul>
        <li>All videos are owned or licensed by the studio (“Supplier”) or are original/homemade works uploaded with permission.</li>
        <li>We do not host pirated anime. Rights holders can request takedowns, honoured within 7 days.</li>
      </ul>
      <h2>3. Accounts</h2>
      <ul>
        <li>One account per person. Don’t share passwords. We may suspend accounts that abuse the service (automated scraping, link harvesting, DRM circumvention).</li>
        <li>VIP members (₹66/year) get an ad-free experience. VIP is non-transferable; refunds within 7 days of purchase if the service is materially unavailable.</li>
      </ul>
      <h2>4. Uploads by distributors</h2>
      <ul>
        <li>Distributors may upload videos only with proof of ownership or written permission from the rights holder.</li>
        <li>By uploading you grant the platform a non-exclusive licence to stream and distribute that content to users under these terms.</li>
      </ul>
      <h2>5. Changes</h2>
      <p>We may update these terms; continued use after an update means you accept the new version.</p>
    </LegalPageShell>
  );
}

export function About() {
  return (
    <LegalPageShell title="About Anime-Unleashed Entertainment" updated="October 2026">
      <p>
        Anime-Unleashed Entertainment is a small, independent streaming platform made for Indian anime fans —
        a clean place to discover, watch, and download anime with Hindi dubs, subtitles, and
        expiring download links that respect the studio’s rights.
      </p>
      <h2>What you’ll find here</h2>
      <ul>
        <li>Anime series and movies (Hindi Dub, Tamil Dub, English Sub/Dub, Japanese audio).</li>
        <li>Original and homemade productions, documentaries, and curated scenes from our licensed partners.</li>
        <li>A fast, lightweight site — no clutter, no aggressive pop-ups, works great on mobile data.</li>
      </ul>
      <h2>Contact the studio</h2>
      <p>
        Rights holders, distributors, and fans can reach the studio admin through the
        contact email listed on our official channels. Business enquiries: use the subject line
        “Anime-Unleashed — Distributor”.
      </p>
      <h2>The stack</h2>
      <p>
        Built on a React frontend with Firebase authentication, an AWS database for the catalog,
        and Cloudflare R2 for video delivery — so downloads are fast and files stay protected.
      </p>
    </LegalPageShell>
  );
}
