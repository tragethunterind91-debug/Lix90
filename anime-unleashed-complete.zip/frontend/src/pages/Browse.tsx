import { useEffect, useMemo, useState } from "react";
import { useQuery, keepPreviousData } from "@tanstack/react-query";
import KindBanner from "@/components/KindBanner";
import { useSearchParams } from "react-router-dom";
import { RotateCcw, Search, SlidersHorizontal, Tv } from "lucide-react";
import { apiGet } from "@/lib/api";
import type { Title } from "@/lib/types";
import AnimeCard from "@/components/AnimeCard";
import Reveal from "@/components/Reveal";
import { KIND_WATERMARKS, themeClassFor } from "@/lib/kinds";
import type { TitleKind } from "@/lib/types";
import { CardGridSkeleton } from "@/components/Skeletons";
import EmptyState from "@/components/EmptyState";
import { useToggleListGuard } from "@/hooks/useWatchlist";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

const YEARS = [2026, 2025, 2024, 2023, 2022, 2021, 2020, 2019];

// Sticky multi-facet filter bar + responsive poster grid, debounced search.
export default function Browse() {
  const [searchParams] = useSearchParams();
  const { inList, handle } = useToggleListGuard();

  const [searchInput, setSearchInput] = useState(searchParams.get("q") ?? "");
  const [search, setSearch] = useState(searchParams.get("q") ?? "");
  const [genre, setGenre] = useState("all");
  const [year, setYear] = useState("all");
  const [type, setType] = useState("all");
  const [kind, setKind] = useState(searchParams.get("kind") ?? "all");
  const [sort, setSort] = useState("latest");

  // sync navbar search → local input when the URL param changes
  useEffect(() => {
    const q = searchParams.get("q") ?? "";
    setSearchInput(q);
    setSearch(q);
  }, [searchParams]);

  // debounce typing
  useEffect(() => {
    const timer = setTimeout(() => setSearch(searchInput.trim()), 300);
    return () => clearTimeout(timer);
  }, [searchInput]);

  const params = useMemo(() => {
    const p = new URLSearchParams();
    if (search) p.set("q", search);
    if (genre !== "all") p.set("genre", genre);
    if (year !== "all") p.set("year", year);
    if (type !== "all") p.set("type", type);
    if (kind !== "all") p.set("kind", kind);
    p.set("sort", sort);
    return p.toString();
  }, [search, genre, year, type, kind, sort]);

  const titles = useQuery({
    queryKey: ["titles", "browse", params],
    queryFn: () => apiGet<Title[]>(`/titles?${params}`),
    placeholderData: keepPreviousData,
  });
  const genres = useQuery({ queryKey: ["genres"], queryFn: () => apiGet<string[]>("/titles/genres") });

  const hasFilters =
    Boolean(search) || genre !== "all" || year !== "all" || type !== "all" || kind !== "all" || sort !== "latest";
  function resetFilters() {
    setSearchInput("");
    setSearch("");
    setGenre("all");
    setYear("all");
    setType("all");
    setKind("all");
    setSort("latest");
  }

  const mark = kind !== "all" ? KIND_WATERMARKS[kind as TitleKind] : "";

  return (
    <div data-kind-mark={mark} className={`mx-auto max-w-7xl px-4 py-4 sm:px-6 md:py-6 lg:px-8 ${kind !== "all" ? themeClassFor(kind) : ""}`}>
      <h1 className="font-heading text-xl font-bold tracking-tight text-white sm:text-2xl md:text-3xl">
        Browse Catalog
      </h1>

      {kind !== "all" ? (
        <KindBanner
          kind={kind as TitleKind}
          posters={(titles.data ?? []).filter((t2) => t2.poster_url).map((t2) => t2.poster_url)}
        />
      ) : null}

      {/* kind tabs — anime / movies / cartoons */}
      <div className="mt-4 flex flex-wrap gap-2" data-testid="kind-tabs">
        {[
          { v: "all", label: "All" },
          { v: "anime", label: "Anime" },
          { v: "movie", label: "Movies" },
          { v: "cartoon", label: "Cartoons" },
          { v: "kdrama", label: "K-Dramas" },
          { v: "webseries", label: "Web Series" },
        ].map((k) => (
          <button
            key={k.v}
            onClick={() => setKind(k.v)}
            className={`rounded-full px-4 py-1.5 text-xs font-bold uppercase tracking-wide transition-all duration-200 ${
              kind === k.v
                ? "bg-amber-400 text-slate-950 shadow-[0_0_18px_rgba(245,158,11,0.35)]"
                : "border border-slate-700 text-zinc-400 hover:border-amber-400/50 hover:text-amber-300"
            }`}
            data-testid={`kind-tab-${k.v}`}
          >
            {k.label}
          </button>
        ))}
      </div>

      {/* sticky filter bar */}
      <div
        className="sticky top-16 z-30 -mx-4 mt-3 border-b border-slate-800/70 bg-[#07090E]/90 px-4 py-2.5 backdrop-blur-md sm:-mx-6 sm:px-6"
        data-testid="browse-filter-bar"
      >
        <div className="flex flex-wrap items-center gap-2">
          <div className="relative min-w-[180px] flex-1">
            <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <Input
              value={searchInput}
              onChange={(event) => setSearchInput(event.target.value)}
              placeholder="Search by title…"
              className="border-slate-700 bg-slate-900/70 pl-8"
              data-testid="browse-search-input"
              aria-label="Search by title"
            />
          </div>

          <Select value={genre} onValueChange={(value: string) => setGenre(value)}>
            <SelectTrigger className="w-[150px] border-slate-700 bg-slate-900/70" data-testid="filter-genre-select" aria-label="Filter by genre">
              <SelectValue>{(v: string) => (v && v !== "all" ? v : "All genres")}</SelectValue>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All genres</SelectItem>
              {(genres.data ?? []).map((g) => (
                <SelectItem key={g} value={g}>{g}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={year} onValueChange={(value: string) => setYear(value)}>
            <SelectTrigger className="w-[130px] border-slate-700 bg-slate-900/70" data-testid="filter-year-select" aria-label="Filter by year">
              <SelectValue>{(v: string) => (v && v !== "all" ? v : "All years")}</SelectValue>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All years</SelectItem>
              {YEARS.map((y) => (
                <SelectItem key={y} value={String(y)}>{y}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select value={type} onValueChange={(value: string) => setType(value)}>
            <SelectTrigger className="w-[130px] border-slate-700 bg-slate-900/70" data-testid="filter-type-select" aria-label="Filter by type">
              <SelectValue>{(v: string) => (v === "movie" ? "Movies" : v === "series" ? "Series" : "All types")}</SelectValue>
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All types</SelectItem>
              <SelectItem value="series">Series</SelectItem>
              <SelectItem value="movie">Movies</SelectItem>
            </SelectContent>
          </Select>

          <Select value={sort} onValueChange={(value: string) => setSort(value)}>
            <SelectTrigger className="w-[160px] border-slate-700 bg-slate-900/70" data-testid="filter-sort-select" aria-label="Sort catalog">
              <SelectValue>{(v: string) => SORT_LABELS[v] ?? "Latest"}</SelectValue>
            </SelectTrigger>
            <SelectContent>
              {Object.entries(SORT_LABELS).map(([value, label]) => (
                <SelectItem key={value} value={value}>{label}</SelectItem>
              ))}
            </SelectContent>
          </Select>

          {hasFilters ? (
            <Button
              variant="ghost"
              size="sm"
              onClick={resetFilters}
              data-testid="filter-reset-btn"
              className="text-zinc-300"
            >
              <RotateCcw className="mr-1.5 h-4 w-4" aria-hidden /> Reset
            </Button>
          ) : null}
        </div>
      </div>

      <Reveal className="mt-4" testId="browse-grid-reveal">
        {titles.isLoading ? (
          <CardGridSkeleton />
        ) : titles.data && titles.data.length > 0 ? (
          <div
            className="stagger grid grid-cols-2 gap-3.5 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 md:gap-5 xl:grid-cols-6"
            data-testid="browse-results-grid"
          >
            {titles.data.map((title) => (
              <AnimeCard key={title.id} title={title} inList={inList(title.id)} onToggleList={handle} />
            ))}
          </div>
        ) : (
          <EmptyState
            icon={hasFilters ? SlidersHorizontal : Tv}
            title={hasFilters ? "No titles found matching your filters" : "The catalog is empty"}
            message={
              hasFilters
                ? "Nothing matches this combination of search and filters. Try loosening one of them."
                : "No titles have been published yet — check back soon."
            }
            actionLabel={hasFilters ? "Reset filters" : undefined}
            onAction={hasFilters ? resetFilters : undefined}
            testId="browse-empty"
          />
        )}
      </Reveal>
    </div>
  );
}

const SORT_LABELS: Record<string, string> = {
  latest: "Latest added",
  rating: "Highest rated",
  year: "Newest release",
  az: "A-Z",
};
