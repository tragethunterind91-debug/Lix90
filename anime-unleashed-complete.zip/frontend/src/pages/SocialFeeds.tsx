import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Share2,
  Tv,
  Youtube,
  Twitter,
  Plus,
  ShieldAlert,
  Sparkles,
  ExternalLink,
  Trash2,
  CheckCircle2,
  BadgeCheck,
} from "lucide-react";
import { toast } from "sonner";
import { apiGet, apiPost, apiPatch, apiDelete, apiErrorMessage } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { useMe } from "@/hooks/useAuth";

interface SocialEmbed {
  id: string;
  title: string;
  bio: string;
  platform: string;
  source_url: string;
  embed_url: string;
  creator_name: string;
  creator_handle: string;
  tags: string[];
  featured_on_home?: boolean;
  created_at: string;
}

export default function SocialFeeds() {
  const { data: me } = useMe();
  const qc = useQueryClient();
  const isAdmin = me?.role === "admin";
  const [tvMode, setTvMode] = useState<boolean>(false);

  const [addOpen, setAddOpen] = useState(false);
  const [title, setTitle] = useState("");
  const [bio, setBio] = useState("");
  const [platform, setPlatform] = useState("youtube");
  const [sourceUrl, setSourceUrl] = useState("");
  const [creatorName, setCreatorName] = useState("");
  const [creatorHandle, setCreatorHandle] = useState("");
  const [tagInput, setTagInput] = useState("");
  const [featuredOnHome, setFeaturedOnHome] = useState(false);

  // TV remote navigation listener (keyboard / D-pad arrow keys)
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
        if (!tvMode) setTvMode(true);
      }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [tvMode]);

  const { data: embeds = [] } = useQuery({
    queryKey: ["social-embeds"],
    queryFn: () => apiGet<SocialEmbed[]>("/social-embeds"),
  });

  const createEmbed = useMutation({
    mutationFn: (data: any) => apiPost("/social-embeds", data),
    onSuccess: () => {
      toast.success("Social embed added legally!");
      setAddOpen(false);
      setTitle("");
      setBio("");
      setSourceUrl("");
      setCreatorName("");
      setCreatorHandle("");
      setTagInput("");
      setFeaturedOnHome(false);
      void qc.invalidateQueries({ queryKey: ["social-embeds"] });
      void qc.invalidateQueries({ queryKey: ["social-embeds-featured"] });
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err));
    },
  });

  const toggleFeature = useMutation({
    mutationFn: (id: string) => apiPatch<SocialEmbed>(`/social-embeds/${id}/featured`, {}),
    onSuccess: (data: SocialEmbed) => {
      toast.success(data?.featured_on_home ? "Listed on Main Home!" : "Removed from Main Home");
      void qc.invalidateQueries({ queryKey: ["social-embeds"] });
      void qc.invalidateQueries({ queryKey: ["social-embeds-featured"] });
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err));
    },
  });

  const deleteEmbed = useMutation({
    mutationFn: (id: string) => apiDelete(`/social-embeds/${id}`),
    onSuccess: () => {
      toast.success("Embed removed.");
      void qc.invalidateQueries({ queryKey: ["social-embeds"] });
      void qc.invalidateQueries({ queryKey: ["social-embeds-featured"] });
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err));
    },
  });

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!title.trim() || !sourceUrl.trim() || !creatorName.trim()) {
      toast.error("Please fill title, source link, and creator name.");
      return;
    }
    const tags = tagInput
      .split(",")
      .map((t) => t.trim())
      .filter(Boolean)
      .map((t) => (t.startsWith("#") ? t : `#${t}`));

    createEmbed.mutate({
      title: title.trim(),
      bio: bio.trim(),
      platform,
      source_url: sourceUrl.trim(),
      creator_name: creatorName.trim(),
      creator_handle: creatorHandle.trim(),
      tags,
      featured_on_home: featuredOnHome,
    });
  }

  return (
    <div className={`mx-auto min-h-screen max-w-7xl px-4 py-10 sm:px-6 lg:px-8 ${tvMode ? "tv-remote-active" : ""}`}>
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-6">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-sky-400/30 bg-sky-400/10 px-3.5 py-1 text-xs font-bold text-sky-300">
            <Tv className="h-4 w-4 text-sky-400" />
            <span>Official Embedded Video Feeds (Zero Copyright Infringement)</span>
            {tvMode && (
              <span className="ml-2 rounded bg-sky-400 px-1.5 py-0.2 text-[10px] font-black text-slate-950 flex items-center gap-1">
                <Tv className="h-3 w-3" /> TV Remote D-Pad Active
              </span>
            )}
          </div>
          <h1 className="mt-3 font-heading text-3xl font-black text-white sm:text-4xl">
            Explore: Social Media &amp; Creator Video Hub
          </h1>
          <p className="mt-2 text-xs text-zinc-400 max-w-2xl">
            Explore official YouTube and social media webviews alongside creator videos. Responsive on Mobile, Desktop &amp; Smart TVs.
          </p>
        </div>

        {/* Admin Add Button */}
        {isAdmin && (
          <Dialog open={addOpen} onOpenChange={setAddOpen}>
            <DialogTrigger asChild>
              <Button tabIndex={0} className="rounded-xl bg-gradient-to-r from-purple-600 to-pink-600 font-bold text-white hover:opacity-90 focus:ring-4 focus:ring-purple-400">
                <Plus className="mr-1.5 h-4 w-4" /> Add Official Embed Link
              </Button>
            </DialogTrigger>
            <DialogContent className="border-slate-800 bg-[#0D121F] text-white sm:max-w-lg">
              <DialogHeader>
                <DialogTitle className="font-heading text-xl font-bold text-white">
                  Add Legal Social Media Embed (No Video Stored)
                </DialogTitle>
              </DialogHeader>

              <form onSubmit={handleSubmit} className="space-y-4 pt-3 text-xs">
                <div>
                  <label className="font-bold text-zinc-300">Video / Clip Title</label>
                  <Input
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="e.g. Chainsaw Man Reze Arc - Official Movie Teaser"
                    required
                    className="mt-1 h-10 border-slate-700 bg-slate-900 text-xs"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-zinc-300">Platform</label>
                    <select
                      value={platform}
                      onChange={(e) => setPlatform(e.target.value)}
                      className="mt-1 h-10 w-full rounded-xl border border-slate-700 bg-slate-900 px-3 text-xs text-white"
                    >
                      <option value="youtube">YouTube</option>
                      <option value="x">X / Twitter</option>
                      <option value="twitch">Twitch</option>
                    </select>
                  </div>

                  <div>
                    <label className="font-bold text-zinc-300">Creator / Studio Name</label>
                    <Input
                      value={creatorName}
                      onChange={(e) => setCreatorName(e.target.value)}
                      placeholder="e.g. MAPPA CHANNEL"
                      required
                      className="mt-1 h-10 border-slate-700 bg-slate-900 text-xs"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold text-zinc-300">Official Link (YouTube / X URL)</label>
                  <Input
                    value={sourceUrl}
                    onChange={(e) => setSourceUrl(e.target.value)}
                    placeholder="https://www.youtube.com/watch?v=..."
                    required
                    className="mt-1 h-10 border-slate-700 bg-slate-900 text-xs"
                  />
                </div>

                <div>
                  <label className="font-bold text-zinc-300">Description / Bio</label>
                  <textarea
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Short description or studio notes..."
                    rows={2}
                    className="mt-1 w-full rounded-xl border border-slate-700 bg-slate-900 p-2.5 text-xs text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="font-bold text-zinc-300">Tags (comma-separated)</label>
                  <Input
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    placeholder="anime, trailer, mappa"
                    className="mt-1 h-10 border-slate-700 bg-slate-900 text-xs"
                  />
                </div>

                <div className="rounded-xl border border-sky-400/20 bg-sky-400/5 p-3 text-[11px] text-zinc-300">
                  <ShieldAlert className="mb-1 inline-block h-3.5 w-3.5 mr-1 text-sky-400" />
                  We only store the public link and render via official HTML5 embeds. No local video storage or copyright infringement.
                </div>

                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="emb-featured-home"
                    checked={featuredOnHome}
                    onChange={(e) => setFeaturedOnHome(e.target.checked)}
                    className="h-4 w-4 rounded border-slate-700 bg-slate-900 text-amber-400 focus:ring-amber-400"
                  />
                  <label htmlFor="emb-featured-home" className="text-xs font-bold text-amber-400 cursor-pointer">
                    List / Feature on Main Home page
                  </label>
                </div>

                <Button
                  type="submit"
                  disabled={createEmbed.isPending}
                  className="w-full h-11 rounded-xl bg-gradient-to-r from-amber-400 to-amber-500 font-black text-slate-950 hover:bg-amber-300"
                >
                  Save &amp; Publish Official Embed
                </Button>
              </form>
            </DialogContent>
          </Dialog>
        )}
      </div>

      {/* Embeds Grid with TV D-Pad Focus and Verified Studio Badges */}
      <div className="mt-8 grid gap-8 md:grid-cols-2">
        {embeds.map((emb) => (
          <Card
            key={emb.id}
            tabIndex={0}
            className="overflow-hidden border-slate-800 bg-[#0A0D15]/90 shadow-2xl backdrop-blur-xl transition-all duration-300 focus:scale-[1.01] focus:border-sky-400 focus:ring-4 focus:ring-sky-400/50 focus:outline-none"
          >
            {/* Responsive Iframe Embed with native 16:9 Aspect Ratio (TV & Mobile ready) */}
            <div className="relative aspect-video w-full bg-black">
              {emb.embed_url.includes("youtube") ? (
                <iframe
                  src={emb.embed_url}
                  title={emb.title}
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
                  allowFullScreen
                  className="h-full w-full border-0"
                />
              ) : (
                <div className="flex h-full w-full flex-col items-center justify-center p-6 text-center bg-slate-950">
                  <ExternalLink className="h-10 w-10 text-sky-400 mb-2" />
                  <p className="font-bold text-white">{emb.title}</p>
                  <a
                    href={emb.source_url}
                    target="_blank"
                    rel="noreferrer"
                    tabIndex={0}
                    className="mt-3 rounded-xl bg-sky-500 px-4 py-2 text-xs font-bold text-white hover:bg-sky-400 focus:ring-2 focus:ring-white"
                  >
                    View Official Post on {emb.platform.toUpperCase()}
                  </a>
                </div>
              )}
            </div>

            {/* Video Bio & Creator info with Verified Studio Tick Badge */}
            <CardContent className="p-5">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="rounded bg-sky-500/20 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-sky-400">
                      {emb.platform}
                    </span>

                    {/* Verified Studio Creator Badge */}
                    <span className="flex items-center gap-1 text-xs font-bold text-zinc-200">
                      <span>{emb.creator_name}</span>
                      <BadgeCheck className="h-4 w-4 fill-sky-400 text-slate-950" />
                      {emb.creator_handle && <span className="text-zinc-500 text-[11px]">{emb.creator_handle}</span>}
                    </span>
                  </div>

                  <h3 className="mt-2 font-heading text-lg font-bold text-white leading-snug">
                    {emb.title}
                  </h3>
                </div>

                {isAdmin && (
                  <div className="flex items-center gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => toggleFeature.mutate(emb.id)}
                      data-testid={`toggle-home-feature-${emb.id}`}
                      className={`h-8 px-2 text-xs font-bold rounded-lg ${
                        emb.featured_on_home
                          ? "bg-amber-400/20 text-amber-300 hover:bg-amber-400/30"
                          : "text-zinc-400 hover:bg-slate-800 hover:text-white"
                      }`}
                      title="List/Unlist on Main Home"
                    >
                      <Sparkles className={`mr-1 h-3.5 w-3.5 ${emb.featured_on_home ? "fill-amber-400 text-amber-400" : ""}`} />
                      {emb.featured_on_home ? "Listed on Home" : "List on Home"}
                    </Button>
                    <Button
                      size="icon"
                      variant="ghost"
                      onClick={() => deleteEmbed.mutate(emb.id)}
                      className="h-8 w-8 text-rose-400 hover:bg-rose-500/10 focus:ring-2 focus:ring-rose-400"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                )}
              </div>

              {emb.bio && (
                <p className="mt-2 text-xs leading-relaxed text-zinc-400">
                  {emb.bio}
                </p>
              )}

              {/* Tags */}
              <div className="mt-4 flex flex-wrap gap-1.5 border-t border-slate-800/60 pt-3">
                {emb.tags.map((t) => (
                  <span
                    key={t}
                    className="rounded bg-slate-800/80 px-2 py-0.5 text-[10px] font-medium text-zinc-400"
                  >
                    {t}
                  </span>
                ))}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
