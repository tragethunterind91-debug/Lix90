import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Sparkles,
  Plus,
  Send,
  Trash2,
  Image,
  Video,
  Code,
  Calendar,
  Coins,
  Layers,
  CheckCircle2,
  Loader2,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import { apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { NFTItem } from "@/lib/nftTypes";

export default function StudioNfts() {
  const queryClient = useQueryClient();
  const [createOpen, setCreateOpen] = useState(false);
  const [grantOpen, setGrantOpen] = useState(false);
  const [revokeOpen, setRevokeOpen] = useState(false);

  // Form states for creation
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [mediaUrl, setMediaUrl] = useState("");
  const [mediaType, setMediaType] = useState<"image" | "video" | "html" | "animation">("image");
  const [htmlCode, setHtmlCode] = useState("");
  const [category, setCategory] = useState("anime");
  const [price, setPrice] = useState("100");
  const [supply, setSupply] = useState("20");
  const [startFrom, setStartFrom] = useState("");
  const [endAt, setEndAt] = useState("");

  // Grant / Revoke form states
  const [grantNftId, setGrantNftId] = useState("");
  const [grantEmail, setGrantEmail] = useState("");
  const [revokeOwnedId, setRevokeOwnedId] = useState("");

  const { data: nfts = [], isLoading } = useQuery<NFTItem[]>({
    queryKey: ["studio-nfts"],
    queryFn: () => apiGet<NFTItem[]>("/nft/catalog"),
  });

  // Create Limited NFT Mutation
  const createMutation = useMutation({
    mutationFn: (data: any) => apiPost("/nft/admin/create", data),
    onSuccess: () => {
      toast.success("Limited Edition NFT created successfully!");
      setCreateOpen(false);
      setName("");
      setDescription("");
      setMediaUrl("");
      setHtmlCode("");
      void queryClient.invalidateQueries({ queryKey: ["studio-nfts"] });
      void queryClient.invalidateQueries({ queryKey: ["nft-catalog"] });
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  });

  // Grant NFT to User Mutation
  const grantMutation = useMutation({
    mutationFn: (data: { nft_id: string; user_email: string }) =>
      apiPost("/nft/admin/grant", data),
    onSuccess: (res: any) => {
      toast.success(res?.message || "NFT granted to user!");
      setGrantOpen(false);
      setGrantEmail("");
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  });

  // Revoke NFT from User Mutation
  const revokeMutation = useMutation({
    mutationFn: (data: { owned_id: string }) => apiPost("/nft/admin/revoke", data),
    onSuccess: (res: any) => {
      toast.success(res?.message || "NFT revoked from user!");
      setRevokeOpen(false);
      setRevokeOwnedId("");
    },
    onError: (err) => toast.error(apiErrorMessage(err)),
  });

  function handleCreateSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim()) {
      toast.error("Please enter an NFT name");
      return;
    }
    createMutation.mutate({
      name: name.trim(),
      description: description.trim(),
      media_url: mediaUrl.trim(),
      media_type: mediaType,
      html: htmlCode,
      category,
      tier: "limited",
      edition: "limited",
      price_lc: parseInt(price, 10) || 50,
      supply: parseInt(supply, 10) || 10,
      start_from: startFrom ? new Date(startFrom).toISOString() : undefined,
      end_at: endAt ? new Date(endAt).toISOString() : undefined,
    });
  }

  return (
    <div className="space-y-6" data-testid="studio-nft-management">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h1 className="font-heading text-2xl font-black text-white sm:text-3xl">
            NFT &amp; Auction Studio System
          </h1>
          <p className="text-xs text-zinc-400">
            Create Limited Edition NFTs, configure limits &amp; end dates, grant/revoke NFTs, and monitor collections.
          </p>
        </div>

        <div className="flex flex-wrap gap-2">
          <Button
            onClick={() => setCreateOpen(true)}
            className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
            data-testid="admin-create-nft-btn"
          >
            <Plus className="mr-1.5 h-4 w-4" /> Create Limited NFT
          </Button>
          <Button
            onClick={() => setGrantOpen(true)}
            variant="outline"
            className="border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/10"
            data-testid="admin-grant-nft-btn"
          >
            <Send className="mr-1.5 h-4 w-4" /> Grant to User
          </Button>
          <Button
            onClick={() => setRevokeOpen(true)}
            variant="outline"
            className="border-rose-500/40 text-rose-300 hover:bg-rose-500/10"
            data-testid="admin-revoke-nft-btn"
          >
            <Trash2 className="mr-1.5 h-4 w-4" /> Revoke NFT
          </Button>
        </div>
      </div>

      {/* NFT Catalog table / cards */}
      <Card className="border-slate-800 bg-slate-900/60">
        <CardContent className="p-4 sm:p-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="font-heading text-base font-bold text-white">
              All Marketplace NFTs ({nfts.length})
            </h2>
            <span className="text-xs text-zinc-400">50+ Common &amp; Limited Cards</span>
          </div>

          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
            {nfts.map((nft) => (
              <div
                key={nft.id}
                className="overflow-hidden rounded-xl border border-slate-800 bg-slate-950/70 p-2 text-xs space-y-1.5"
                data-testid={`studio-nft-item-${nft.id}`}
              >
                <div className="aspect-square w-full overflow-hidden rounded-lg bg-black">
                  <img
                    src={nft.media_url || "/logo-app-icon.png"}
                    alt={nft.name}
                    className="h-full w-full object-cover"
                  />
                </div>
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white truncate">{nft.name}</span>
                  <Badge variant={nft.edition === "limited" ? "default" : "secondary"} className="text-[9px] px-1 py-0">
                    {nft.tier}
                  </Badge>
                </div>
                <div className="flex items-center justify-between text-[11px] text-zinc-400">
                  <span>{nft.price_lc} coins</span>
                  <span>{nft.minted}{nft.supply > 0 ? `/${nft.supply}` : ""}</span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* CREATE NFT MODAL */}
      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent className="max-w-lg border-slate-800 bg-[#0B0F19] text-white p-6 max-h-[90vh] overflow-y-auto" data-testid="create-nft-dialog">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl font-black text-white">
              Create Limited Edition NFT
            </DialogTitle>
            <DialogDescription className="text-xs text-zinc-400">
              Provide complete NFT details: media link/HTML code, limits, dates, and price.
            </DialogDescription>
          </DialogHeader>

          <form onSubmit={handleCreateSubmit} className="space-y-3.5 pt-2">
            <div>
              <label className="text-xs font-bold text-zinc-400">NFT Name</label>
              <Input
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="e.g. Celestial Dragon Lord"
                className="mt-1 border-slate-800 bg-slate-900 text-xs"
                required
                data-testid="admin-nft-name-input"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-400">Category &amp; Media Type</label>
              <div className="grid grid-cols-2 gap-2 mt-1">
                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                  className="rounded-xl border border-slate-800 bg-slate-900 p-2 text-xs text-white"
                  data-testid="admin-nft-category-select"
                >
                  <option value="anime">Anime Character</option>
                  <option value="dragon">Dragon</option>
                  <option value="creature">Creature / Pokémon</option>
                  <option value="character">General Character</option>
                </select>

                <select
                  value={mediaType}
                  onChange={(e) => setMediaType(e.target.value as any)}
                  className="rounded-xl border border-slate-800 bg-slate-900 p-2 text-xs text-white"
                  data-testid="admin-nft-mediatype-select"
                >
                  <option value="image">Image (URL)</option>
                  <option value="video">Video (MP4/WebM URL)</option>
                  <option value="animation">Animation / GIF</option>
                  <option value="html">Custom HTML / Code</option>
                </select>
              </div>
            </div>

            {mediaType === "html" ? (
              <div>
                <label className="text-xs font-bold text-zinc-400">Custom HTML / Canvas Code</label>
                <Textarea
                  value={htmlCode}
                  onChange={(e) => setHtmlCode(e.target.value)}
                  placeholder="<div style='background: linear-gradient(...)'>...</div>"
                  rows={4}
                  className="mt-1 border-slate-800 bg-slate-900 font-mono text-xs"
                  data-testid="admin-nft-html-input"
                />
              </div>
            ) : (
              <div>
                <label className="text-xs font-bold text-zinc-400">Media URL (Image / Video Link)</label>
                <Input
                  value={mediaUrl}
                  onChange={(e) => setMediaUrl(e.target.value)}
                  placeholder="https://..."
                  className="mt-1 border-slate-800 bg-slate-900 text-xs"
                  data-testid="admin-nft-mediaurl-input"
                />
              </div>
            )}

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-bold text-zinc-400">Price (Coins)</label>
                <Input
                  type="number"
                  min={1}
                  value={price}
                  onChange={(e) => setPrice(e.target.value)}
                  className="mt-1 border-slate-800 bg-slate-900 text-xs font-mono"
                  data-testid="admin-nft-price-input"
                  required
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-400">Limit (Max Supply)</label>
                <Input
                  type="number"
                  min={1}
                  value={supply}
                  onChange={(e) => setSupply(e.target.value)}
                  className="mt-1 border-slate-800 bg-slate-900 text-xs font-mono"
                  data-testid="admin-nft-supply-input"
                  required
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="text-xs font-bold text-zinc-400">Start From (Date)</label>
                <Input
                  type="datetime-local"
                  value={startFrom}
                  onChange={(e) => setStartFrom(e.target.value)}
                  className="mt-1 border-slate-800 bg-slate-900 text-xs"
                  data-testid="admin-nft-startfrom-input"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-zinc-400">End (Fixed Time Limit)</label>
                <Input
                  type="datetime-local"
                  value={endAt}
                  onChange={(e) => setEndAt(e.target.value)}
                  className="mt-1 border-slate-800 bg-slate-900 text-xs"
                  data-testid="admin-nft-endat-input"
                />
              </div>
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-400">Description (Optional)</label>
              <Textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Story, lore, or special perks..."
                rows={2}
                className="mt-1 border-slate-800 bg-slate-900 text-xs"
              />
            </div>

            <Button
              type="submit"
              disabled={createMutation.isPending}
              className="w-full bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
              data-testid="admin-submit-create-nft"
            >
              {createMutation.isPending ? "Creating..." : "Mint Limited Edition NFT"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* GRANT NFT MODAL */}
      <Dialog open={grantOpen} onOpenChange={setGrantOpen}>
        <DialogContent className="max-w-md border-slate-800 bg-[#0B0F19] text-white p-6" data-testid="grant-nft-dialog">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl font-black text-white">
              Grant NFT to Any User
            </DialogTitle>
            <DialogDescription className="text-xs text-zinc-400">
              Admin control: gift an NFT directly into any user's inventory.
            </DialogDescription>
          </DialogHeader>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              grantMutation.mutate({
                nft_id: grantNftId || nfts[0]?.id,
                user_email: grantEmail,
              });
            }}
            className="space-y-3.5 pt-2"
          >
            <div>
              <label className="text-xs font-bold text-zinc-400">Select NFT</label>
              <select
                value={grantNftId || nfts[0]?.id}
                onChange={(e) => setGrantNftId(e.target.value)}
                className="mt-1 w-full rounded-xl border border-slate-800 bg-slate-900 p-2.5 text-xs text-white"
                data-testid="admin-grant-select-nft"
              >
                {nfts.map((nft) => (
                  <option key={nft.id} value={nft.id}>
                    {nft.name} ({nft.tier} - {nft.edition})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-zinc-400">User Email Address</label>
              <Input
                type="email"
                value={grantEmail}
                onChange={(e) => setGrantEmail(e.target.value)}
                placeholder="user@example.com"
                className="mt-1 border-slate-800 bg-slate-900 text-xs text-white"
                data-testid="admin-grant-email-input"
                required
              />
            </div>

            <Button
              type="submit"
              disabled={grantMutation.isPending || !grantEmail}
              className="w-full bg-emerald-500 font-bold text-slate-950 hover:bg-emerald-400"
              data-testid="admin-confirm-grant-btn"
            >
              {grantMutation.isPending ? "Granting..." : "Confirm Grant"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* REVOKE NFT MODAL */}
      <Dialog open={revokeOpen} onOpenChange={setRevokeOpen}>
        <DialogContent className="max-w-md border-slate-800 bg-[#0B0F19] text-white p-6" data-testid="revoke-nft-dialog">
          <DialogHeader>
            <DialogTitle className="font-heading text-xl font-black text-white">
              Remove NFT from User's Account
            </DialogTitle>
            <DialogDescription className="text-xs text-zinc-400">
              Admin control: enter the Owned NFT ID (e.g. <code>own-xxxxxxxx</code>) to revoke.
            </DialogDescription>
          </DialogHeader>

          <form
            onSubmit={(e) => {
              e.preventDefault();
              revokeMutation.mutate({ owned_id: revokeOwnedId.trim() });
            }}
            className="space-y-3.5 pt-2"
          >
            <div>
              <label className="text-xs font-bold text-zinc-400">Owned NFT ID</label>
              <Input
                value={revokeOwnedId}
                onChange={(e) => setRevokeOwnedId(e.target.value)}
                placeholder="own-xxxxxxxxxxxx"
                className="mt-1 border-slate-800 bg-slate-900 text-xs text-white font-mono"
                data-testid="admin-revoke-id-input"
                required
              />
            </div>

            <Button
              type="submit"
              disabled={revokeMutation.isPending || !revokeOwnedId}
              variant="destructive"
              className="w-full font-bold"
              data-testid="admin-confirm-revoke-btn"
            >
              {revokeMutation.isPending ? "Revoking..." : "Revoke & Delete from Account"}
            </Button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
