import { useState, type FormEvent } from "react";
import { formatDistanceToNowStrict } from "date-fns";
import { Loader2, Megaphone, Trash2, Wrench } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useAirdrop, useAdminAnalytics, useAdminNotices, useCreateNotice, useDeleteNotice, useUpdatePlatform } from "@/hooks/useAdminControls";
import { usePlatform } from "@/hooks/usePlatform";

// STUDIO > Platform — the owner's control room: maintenance mode, airdrops,
// the VIP plan (price/duration/features), notices + global growth numbers.
export default function StudioPlatform() {
  const platform = usePlatform();
  const update = useUpdatePlatform();
  const airdrop = useAirdrop();
  const analytics = useAdminAnalytics();
  const notices = useAdminNotices();
  const createNotice = useCreateNotice();
  const deleteNotice = useDeleteNotice();

  const [air, setAir] = useState({ watch_minutes: 15, cf: 0 });
  const [plan, setPlan] = useState({ price_inr: 66, duration_days: 60, features_text: "" });
  const [notice, setNotice] = useState({ title: "", body: "" });

  const planLoaded = platform.data?.vip_plan;
  const planFeaturesText = plan.features_text || (planLoaded?.features ?? []).join("\n");
  const t = analytics.data?.totals;

  function submitAirdrop(e: FormEvent) {
    e.preventDefault();
    airdrop.mutate({ watch_minutes: Number(air.watch_minutes) || 0, cf: Number(air.cf) || 0 });
  }

  function submitPlan(e: FormEvent) {
    e.preventDefault();
    update.mutate({
      vip_plan: {
        price_inr: Number(plan.price_inr) || planLoaded?.price_inr || 66,
        duration_days: Number(plan.duration_days) || planLoaded?.duration_days || 60,
        features: planFeaturesText.split("\n").map((f) => f.trim()).filter(Boolean),
      },
    });
  }

  function submitNotice(e: FormEvent) {
    e.preventDefault();
    createNotice.mutate(notice, { onSuccess: () => setNotice({ title: "", body: "" }) });
  }

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="studio-platform-heading">
        Platform
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Maintenance mode, airdrops, the VIP plan and site-wide notices — all live for every user instantly.
      </p>

      {/* global growth numbers */}
      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        {[
          { label: "Views", value: t?.views ?? 0, testid: "platform-stat-views" },
          { label: "Watch hours", value: t?.watch_hours ?? 0, testid: "platform-stat-hours" },
          { label: "Downloads", value: t?.downloads_total ?? 0, testid: "platform-stat-downloads" },
          { label: "Video DLs", value: t?.downloads_video ?? 0, testid: "platform-stat-dl-video" },
          { label: "Audio DLs", value: t?.downloads_audio ?? 0, testid: "platform-stat-dl-audio" },
          { label: "Sub DLs", value: t?.downloads_subtitle ?? 0, testid: "platform-stat-dl-subs" },
        ].map((s) => (
          <Card key={s.label} className="border-slate-800 bg-card/70">
            <CardContent className="px-4 py-3">
              <p className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">{s.label}</p>
              <p className="font-heading text-lg font-bold text-white" data-testid={s.testid}>{s.value}</p>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-2">
        {/* maintenance */}
        <Card className="border-slate-800 bg-card/70">
          <CardContent className="px-6 py-6">
            <p className="flex items-center gap-2 font-bold text-white">
              <Wrench className="h-4 w-4 text-amber-400" aria-hidden /> Maintenance mode
            </p>
            <p className="mt-1 text-sm text-muted-foreground">
              When ON, every viewer and guest sees a maintenance screen instead of the site. Admins keep access.
            </p>
            <div className="mt-4 flex items-center gap-3">
              <Badge variant={platform.data?.maintenance ? "destructive" : "secondary"} data-testid="platform-maintenance-state">
                {platform.data?.maintenance ? "MAINTENANCE ON" : "SITE LIVE"}
              </Badge>
              <Button
                size="sm"
                variant={platform.data?.maintenance ? "default" : "destructive"}
                disabled={update.isPending}
                onClick={() => update.mutate({ maintenance: !platform.data?.maintenance })}
                data-testid="platform-maintenance-toggle"
              >
                {update.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : null}
                {platform.data?.maintenance ? "Turn maintenance OFF" : "Turn maintenance ON"}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* airdrop */}
        <Card className="border-slate-800 bg-card/70">
          <CardContent className="px-6 py-6">
            <p className="font-bold text-white">Airdrop</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Send watch-duration (each account stores max 3h 30m) and CF to EVERY account at once.
            </p>
            <form className="mt-4 grid grid-cols-2 gap-3" onSubmit={submitAirdrop} data-testid="platform-airdrop-form">
              <div className="space-y-1.5">
                <Label htmlFor="air-vd">View duration (min)</Label>
                <Input id="air-vd" type="number" min={0} max={210} value={air.watch_minutes} onChange={(e) => setAir({ ...air, watch_minutes: Number(e.target.value) })} className="border-slate-700 bg-slate-900/70" data-testid="platform-airdrop-vd-input" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="air-cf">CF</Label>
                <Input id="air-cf" type="number" min={0} max={1000} value={air.cf} onChange={(e) => setAir({ ...air, cf: Number(e.target.value) })} className="border-slate-700 bg-slate-900/70" data-testid="platform-airdrop-cf-input" />
              </div>
              <Button type="submit" className="col-span-2 bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" disabled={airdrop.isPending} data-testid="platform-airdrop-button">
                {airdrop.isPending ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : null}
                Airdrop to all accounts
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* VIP plan editor */}
        <Card className="border-slate-800 bg-card/70">
          <CardContent className="px-6 py-6">
            <p className="font-bold text-white">VIP plan</p>
            <p className="mt-1 text-sm text-muted-foreground">The Vip page and its checkout read this plan live.</p>
            <form className="mt-4 space-y-3" onSubmit={submitPlan} data-testid="platform-vip-form">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="vip-price">Price (₹)</Label>
                  <Input id="vip-price" type="number" min={1} value={plan.price_inr} onChange={(e) => setPlan({ ...plan, price_inr: Number(e.target.value) })} className="border-slate-700 bg-slate-900/70" data-testid="platform-vip-price-input" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="vip-days">Duration (days)</Label>
                  <Input id="vip-days" type="number" min={1} value={plan.duration_days} onChange={(e) => setPlan({ ...plan, duration_days: Number(e.target.value) })} className="border-slate-700 bg-slate-900/70" data-testid="platform-vip-days-input" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="vip-feats">Features (one per line)</Label>
                <Textarea
                  id="vip-feats"
                  rows={4}
                  value={planFeaturesText}
                  onChange={(e) => setPlan({ ...plan, features_text: e.target.value })}
                  placeholder={"Zero ads\nUnlimited watch time\nHindi dub + subtitles"}
                  className="border-slate-700 bg-slate-900/70"
                  data-testid="platform-vip-features-input"
                />
              </div>
              <Button type="submit" className="w-full bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" disabled={update.isPending} data-testid="platform-vip-save">
                Save VIP plan
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* notices */}
        <Card className="border-slate-800 bg-card/70">
          <CardContent className="px-6 py-6">
            <p className="flex items-center gap-2 font-bold text-white">
              <Megaphone className="h-4 w-4 text-amber-400" aria-hidden /> Notices
            </p>
            <p className="mt-1 text-sm text-muted-foreground">The latest notice shows as a banner on the user site.</p>
            <form className="mt-4 space-y-3" onSubmit={submitNotice} data-testid="platform-notice-form">
              <Input required minLength={3} placeholder="Title" value={notice.title} onChange={(e) => setNotice({ ...notice, title: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="platform-notice-title-input" />
              <Textarea required minLength={3} rows={2} placeholder="What should users know?" value={notice.body} onChange={(e) => setNotice({ ...notice, body: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="platform-notice-body-input" />
              <Button type="submit" className="w-full bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" disabled={createNotice.isPending} data-testid="platform-notice-post">
                Post notice
              </Button>
            </form>
            <div className="mt-4 space-y-2" data-testid="platform-notice-list">
              {(notices.data ?? []).map((n) => (
                <div key={n.id} className="flex items-start justify-between gap-2 rounded-lg border border-slate-800 bg-slate-900/60 px-3 py-2">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-bold text-white">{n.title}</p>
                    <p className="text-xs text-zinc-400">{n.body}</p>
                    <p className="text-[10px] text-zinc-600">
                      {formatDistanceToNowStrict(new Date(n.created_at), { addSuffix: true })}
                    </p>
                  </div>
                  <Button size="icon" variant="ghost" onClick={() => deleteNotice.mutate(n.id)} aria-label={`Delete notice ${n.title}`} data-testid={`platform-notice-delete-${n.id}`}>
                    <Trash2 className="h-4 w-4 text-rose-400" aria-hidden />
                  </Button>
                </div>
              ))}
              {(notices.data ?? []).length === 0 ? <p className="text-sm text-zinc-500">No notices posted yet.</p> : null}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
