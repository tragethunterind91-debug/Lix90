import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  BarChart3,
  TrendingUp,
  Clock,
  Eye,
  Heart,
  Share2,
  DollarSign,
  AlertTriangle,
  Play,
  Film,
  Sparkles,
  ArrowUpRight,
  TrendingDown,
  Layers,
} from "lucide-react";
import { apiGet } from "@/lib/api";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";

export default function AdminMonitoring() {
  const [tab, setTab] = useState<"overview" | "videos" | "webviews">("overview");

  const { data, isLoading } = useQuery<any>({
    queryKey: ["admin-video-monitoring"],
    queryFn: () => apiGet("/admin/video-monitoring"),
  });

  if (isLoading) {
    return (
      <div className="space-y-4">
        <div className="h-8 w-48 animate-pulse rounded bg-slate-800" />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div key={i} className="h-24 animate-pulse rounded-2xl bg-slate-900" />
          ))}
        </div>
      </div>
    );
  }

  const summary = data?.summary ?? {};
  const videos = data?.videos ?? [];
  const webviews = data?.social_webviews ?? [];

  return (
    <div className="space-y-6">
      {/* Title & Scope */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div>
          <div className="inline-flex items-center gap-1.5 rounded-full border border-amber-400/30 bg-amber-400/10 px-3 py-0.5 text-xs font-bold text-amber-400">
            <BarChart3 className="h-3.5 w-3.5" />
            <span>Owner Executive Telemetry</span>
          </div>
          <h1 className="mt-2 font-heading text-2xl font-black text-white">
            Admin Video Monitoring &amp; Financial Analytics
          </h1>
          <p className="text-xs text-zinc-400">
            Comprehensive audit of every video, duration, profit, donation split (60/40), likes, dislikes, shares &amp; egress loss.
          </p>
        </div>

        <Tabs value={tab} onValueChange={(v: any) => setTab(v)}>
          <TabsList className="bg-slate-900 border border-slate-800">
            <TabsTrigger value="overview" className="text-xs">Overview</TabsTrigger>
            <TabsTrigger value="videos" className="text-xs">Videos ({videos.length})</TabsTrigger>
            <TabsTrigger value="webviews" className="text-xs">WebViews ({webviews.length})</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Metric Cards Grid */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <Card className="border-slate-800 bg-[#07090E]/80">
          <CardContent className="p-4">
            <div className="flex items-center justify-between text-zinc-400">
              <span className="text-[11px] font-bold">Total Duration</span>
              <Clock className="h-4 w-4 text-sky-400" />
            </div>
            <p className="mt-2 font-heading text-xl font-bold text-white">
              {summary.total_duration_hours ?? 0} hrs
            </p>
            <p className="text-[10px] text-zinc-500">Avg {summary.average_duration_minutes ?? 0}m / ep</p>
          </CardContent>
        </Card>

        <Card className="border-slate-800 bg-[#07090E]/80">
          <CardContent className="p-4">
            <div className="flex items-center justify-between text-zinc-400">
              <span className="text-[11px] font-bold">Catalog Views</span>
              <Eye className="h-4 w-4 text-pink-400" />
            </div>
            <p className="mt-2 font-heading text-xl font-bold text-white">
              {summary.total_views ?? 0}
            </p>
            <p className="text-[10px] text-emerald-400">+{summary.growth_percentage ?? 0}% growth</p>
          </CardContent>
        </Card>

        <Card className="border-slate-800 bg-[#07090E]/80">
          <CardContent className="p-4">
            <div className="flex items-center justify-between text-zinc-400">
              <span className="text-[11px] font-bold">Total Donations</span>
              <DollarSign className="h-4 w-4 text-amber-400" />
            </div>
            <p className="mt-2 font-heading text-xl font-bold text-white">
              ₹{summary.total_donations ?? 0}
            </p>
            <p className="text-[10px] text-zinc-500">Live &amp; Webviews</p>
          </CardContent>
        </Card>

        <Card className="border-slate-800 bg-[#07090E]/80">
          <CardContent className="p-4">
            <div className="flex items-center justify-between text-zinc-400">
              <span className="text-[11px] font-bold">Platform Profits</span>
              <ArrowUpRight className="h-4 w-4 text-emerald-400" />
            </div>
            <p className="mt-2 font-heading text-xl font-bold text-emerald-400">
              ₹{summary.total_platform_profit ?? 0}
            </p>
            <p className="text-[10px] text-zinc-500">Net platform cut</p>
          </CardContent>
        </Card>

        <Card className="border-slate-800 bg-[#07090E]/80">
          <CardContent className="p-4">
            <div className="flex items-center justify-between text-zinc-400">
              <span className="text-[11px] font-bold">Egress Loss Est.</span>
              <TrendingDown className="h-4 w-4 text-rose-400" />
            </div>
            <p className="mt-2 font-heading text-xl font-bold text-rose-400">
              ₹{summary.estimated_loss ?? 0}
            </p>
            <p className="text-[10px] text-zinc-500">CDN bandwidth</p>
          </CardContent>
        </Card>

        <Card className="border-slate-800 bg-[#07090E]/80">
          <CardContent className="p-4">
            <div className="flex items-center justify-between text-zinc-400">
              <span className="text-[11px] font-bold">Engagement</span>
              <Heart className="h-4 w-4 text-rose-400 fill-rose-500" />
            </div>
            <p className="mt-2 font-heading text-xl font-bold text-white">
              {summary.total_likes ?? 0} L / {summary.total_dislikes ?? 0} D
            </p>
            <p className="text-[10px] text-zinc-500">Likes &amp; Dislikes</p>
          </CardContent>
        </Card>
      </div>

      {/* Videos Table */}
      {(tab === "overview" || tab === "videos") && (
        <Card className="border-slate-800 bg-card/70">
          <CardContent className="p-5">
            <div className="flex items-center justify-between pb-3">
              <h2 className="font-heading text-base font-bold text-white">
                Detailed Video Telemetry &amp; Performance
              </h2>
              <span className="text-xs text-zinc-400">{videos.length} Titles Loaded</span>
            </div>
            {videos.length > 0 ? (
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs">
                  <thead className="border-b border-slate-800 text-zinc-400">
                    <tr>
                      <th className="py-2.5 font-bold">Anime / Title</th>
                      <th className="py-2.5 font-bold">Category</th>
                      <th className="py-2.5 font-bold">Episodes</th>
                      <th className="py-2.5 font-bold">Duration</th>
                      <th className="py-2.5 font-bold">Views</th>
                      <th className="py-2.5 font-bold">Likes/Dislikes</th>
                      <th className="py-2.5 font-bold">Comments/Shares</th>
                      <th className="py-2.5 font-bold">Est. Revenue</th>
                      <th className="py-2.5 font-bold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-zinc-300">
                    {videos.map((v: any) => (
                      <tr key={v.id} className="hover:bg-slate-800/30">
                        <td className="py-3 font-bold text-white">{v.name}</td>
                        <td className="py-3 uppercase text-[10px] text-zinc-400">{v.kind || "Anime"}</td>
                        <td className="py-3">{v.episodes_count} eps</td>
                        <td className="py-3">{v.total_duration_minutes}m</td>
                        <td className="py-3 font-semibold text-pink-400">{v.views}</td>
                        <td className="py-3">{v.likes} 👍 / {v.dislikes} 👎</td>
                        <td className="py-3">{v.comments} 💬 / {v.shares} 🔗</td>
                        <td className="py-3 font-bold text-emerald-400">₹{v.estimated_revenue}</td>
                        <td className="py-3">
                          <span className="rounded bg-emerald-500/10 px-2 py-0.5 text-[10px] font-bold text-emerald-300">
                            {v.status || "Published"}
                          </span>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            ) : (
              <div className="py-10 text-center text-xs text-zinc-500">
                No videos in catalog yet. Content added in Studio will populate here automatically.
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {/* Webviews Tab */}
      {(tab === "overview" || tab === "webviews") && (
        <Card className="border-slate-800 bg-card/70">
          <CardContent className="p-5">
            <h2 className="font-heading text-base font-bold text-white">
              Social Media &amp; Creator Webview Streams (60% Ad / 40% User Split)
            </h2>
            <p className="mt-1 text-xs text-zinc-400">
              WebViews streaming via YouTube, X, or Twitch. 60% of all user donations go to Anime Unleashed platform, 40% to user/creator.
            </p>
            <div className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-3">
              {webviews.map((w: any) => (
                <div key={w.id} className="rounded-xl border border-slate-800 bg-slate-900/50 p-3">
                  <div className="flex items-center justify-between text-xs">
                    <span className="rounded bg-sky-500/20 px-2 py-0.5 font-bold uppercase text-sky-300 text-[10px]">
                      {w.platform}
                    </span>
                    <span className="text-[11px] text-zinc-400">{w.creator_name}</span>
                  </div>
                  <p className="mt-2 font-bold text-sm text-white line-clamp-1">{w.title}</p>
                  <div className="mt-3 flex items-center justify-between border-t border-slate-800 pt-2 text-[11px]">
                    <span className="text-amber-400 font-semibold">60% Platform Split</span>
                    <span className="text-zinc-400">{w.featured_on_home ? "Listed on Home" : "In Explore"}</span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
