import { useQuery } from "@tanstack/react-query";
import { Activity, ShieldCheck } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { apiGet } from "@/lib/api";
import type { AuditEntry } from "@/lib/types";

// Append-only trail of sensitive admin actions (accounts, revenue, feedback).
// Newest first; nothing in here is editable by design.
const ACTION_TONE: Record<string, string> = {
  "user.create": "bg-emerald-500/15 text-emerald-300",
  "user.update": "bg-sky-500/15 text-sky-300",
  "user.delete": "bg-rose-500/15 text-rose-300",
  "revenue.add": "bg-[#F59E0B]/15 text-[#FDE047]",
  "revenue.delete": "bg-orange-500/15 text-orange-300",
  "feedback.delete": "bg-slate-500/20 text-slate-300",
};

export default function AuditLog() {
  const audit = useQuery<AuditEntry[]>({
    queryKey: ["admin", "audit"],
    queryFn: () => apiGet<AuditEntry[]>("/admin/audit"),
  });

  return (
    <div>
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="flex items-center gap-2.5 font-heading text-2xl font-bold tracking-tight text-white">
            <Activity className="h-6 w-6 text-[#FF4655]" aria-hidden /> Audit log
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Every sensitive action is recorded automatically — accounts, revenue and feedback changes.
          </p>
        </div>
        <ShieldCheck className="h-8 w-8 text-emerald-400/70" aria-hidden />
      </div>

      <Card className="mt-6 border-[#222D42]/70 bg-[#0D111A]/80">
        <CardContent className="p-0" data-testid="admin-audit-list">
          {audit.isLoading ? (
            <div className="space-y-2 p-5">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="skeleton-shimmer h-10 w-full rounded-md" />
              ))}
            </div>
          ) : (audit.data?.length ?? 0) === 0 ? (
            <p className="p-10 text-center text-sm text-muted-foreground" data-testid="admin-audit-empty">
              Nothing logged yet — actions appear here the moment they happen.
            </p>
          ) : (
            <ul className="divide-y divide-[#222D42]/60">
              {audit.data!.map((entry) => (
                <li key={entry.id} className="flex flex-wrap items-center gap-3 px-5 py-3" data-testid={`audit-item-${entry.id}`}>
                  <Badge className={`font-mono text-[11px] ${ACTION_TONE[entry.action] ?? "bg-slate-700/40 text-slate-300"}`}>
                    {entry.action}
                  </Badge>
                  <span className="text-sm text-white">{entry.target}</span>
                  <span className="ml-auto text-xs text-muted-foreground">
                    {entry.actor} · {new Date(entry.created_at).toLocaleString("en-IN", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" })}
                  </span>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
