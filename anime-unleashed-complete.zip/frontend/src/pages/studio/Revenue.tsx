import { useState } from "react";
import { IndianRupee, Loader2, Plus, Trash2, Wallet } from "lucide-react";
import { useAddRevenue, useDeleteRevenue, useRevenue } from "@/hooks/useStudio";
import { formatDate } from "@/lib/badges";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

// Profit ledger: the notebook's "total profit" — manual income entries (UPI/VIP) until
// automatic payments go live.
export default function StudioRevenue() {
  const revenue = useRevenue();
  const add = useAddRevenue();
  const remove = useDeleteRevenue();
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="studio-revenue-heading">
        Revenue
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Log income you receive manually (UPI, VIP passes, distributor deals). Automatic payment
        tracking arrives with the VIP tier.
      </p>

      <Card className="mt-6 border-amber-400/30 bg-gradient-to-br from-amber-400/10 to-transparent">
        <CardContent className="flex items-center gap-4 px-6 py-6">
          <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-amber-400/20">
            <Wallet className="h-6 w-6 text-amber-400" aria-hidden />
          </span>
          <div>
            <p className="text-xs uppercase tracking-widest text-muted-foreground">Total profit</p>
            <p className="font-heading text-3xl font-black text-white" data-testid="revenue-total">
              ₹{(revenue.data?.total ?? 0).toLocaleString("en-IN")}
            </p>
          </div>
        </CardContent>
      </Card>

      <form
        className="mt-6 flex flex-wrap items-end gap-3"
        onSubmit={(event) => {
          event.preventDefault();
          const value = Number(amount);
          if (!value || value <= 0) return;
          add.mutate(
            { amount: value, note: note.trim() },
            { onSuccess: () => { setAmount(""); setNote(""); } },
          );
        }}
        data-testid="revenue-add-form"
      >
        <div className="space-y-2">
          <Label htmlFor="rf-amount">Amount (₹)</Label>
          <Input
            id="rf-amount"
            type="number"
            min={1}
            step="0.01"
            required
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            placeholder="66"
            className="w-32 border-slate-700 bg-slate-900/70"
            data-testid="revenue-amount-input"
          />
        </div>
        <div className="min-w-[200px] flex-1 space-y-2">
          <Label htmlFor="rf-note">Note</Label>
          <Input
            id="rf-note"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="e.g. VIP pass — October UPI"
            maxLength={200}
            className="border-slate-700 bg-slate-900/70"
            data-testid="revenue-note-input"
          />
        </div>
        <Button
          type="submit"
          disabled={add.isPending || !amount}
          data-testid="revenue-add-btn"
          className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
        >
          {add.isPending ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" aria-hidden /> : <Plus className="mr-1.5 h-4 w-4" aria-hidden />}
          Add entry
        </Button>
      </form>

      <ul className="mt-6 divide-y divide-slate-800/70 overflow-hidden rounded-2xl border border-slate-800 bg-card/70" data-testid="revenue-list">
        {(revenue.data?.entries ?? []).map((entry) => (
          <li key={entry.id} className="flex items-center gap-3 px-4 py-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-500/10">
              <IndianRupee className="h-4 w-4 text-emerald-400" aria-hidden />
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-sm font-semibold text-white">₹{entry.amount.toLocaleString("en-IN")}</p>
              <p className="truncate text-xs text-muted-foreground">{entry.note || "No note"} · {formatDate(entry.created_at)}</p>
            </div>
            <Button variant="ghost" size="icon-sm" onClick={() => remove.mutate(entry.id)} data-testid={`revenue-delete-btn-${entry.id}`} aria-label="Delete entry">
              <Trash2 className="h-4 w-4 text-rose-400" aria-hidden />
            </Button>
          </li>
        ))}
        {revenue.data && revenue.data.entries.length === 0 ? (
          <li className="px-4 py-8 text-center text-sm text-muted-foreground">
            No entries yet — add your first income record above.
          </li>
        ) : null}
      </ul>
    </div>
  );
}
