import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Film, Loader2, Pencil, Plus, Search, Trash2 } from "lucide-react";
import { apiDelete, apiGet, apiPatch, apiPost, mediaUrl } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import { AUDIO_OPTIONS, type AniListResult, type Title, type TitleIn } from "@/lib/types";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import ImageUploadField from "@/components/ImageUploadField";
import { useMe } from "@/hooks/useAuth";

interface TitleForm {
  name: string;
  synopsis: string;
  genres: string;
  release_year: string;
  type: "series" | "movie" | "short" | "documentary" | "thriller" | "ova";
  kind: "anime" | "movie" | "cartoon" | "kdrama" | "webseries";
  studio: string;
  age_rating: string;
  original_language: string;
  airing_status: string;
  audio: string[];
  rating: string;
  poster_url: string;
  featured: boolean;
  status: "published" | "draft";
  // launch option — the two published states are mutually exclusive (single field):
  // "draft" = workers/owner only · "upcoming" = Coming Soon + countdown · "listed" = Home
  visibility: "draft" | "upcoming" | "listed";
  release_at: string; // datetime-local value for the upcoming countdown
}

const EMPTY_TITLE: TitleForm = {
  name: "",
  synopsis: "",
  genres: "",
  release_year: String(new Date().getFullYear()),
  type: "series",
  kind: "anime",
  studio: "",
  age_rating: "",
  original_language: "",
  airing_status: "",
  audio: ["Eng Sub"],
  rating: "",
  poster_url: "",
  featured: false,
  status: "draft",
  visibility: "draft",
  release_at: "",
};

// Catalog management: create/edit titles, launch options (draft/upcoming/listed), safe deletes.
const SUBTYPE_LABELS: Record<string, string> = {
  series: "Series (episodes)",
  movie: "Movie",
  short: "Short",
  documentary: "Documentary",
  thriller: "Thriller",
  ova: "OVA / Special",
};

export default function StudioCatalog() {
  const queryClient = useQueryClient();
  const { data: me } = useMe();
  const isAdmin = me?.role === "admin";
  const titles = useQuery({
    queryKey: ["admin", "titles"],
    queryFn: () => apiGet<Title[]>("/titles?all=1&sort=latest"),
  });

  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<Title | null>(null);
  const [form, setForm] = useState<TitleForm>(EMPTY_TITLE);
  const [deleteTarget, setDeleteTarget] = useState<Title | null>(null);  const invalidate = () => {
    void queryClient.invalidateQueries({ queryKey: ["admin", "titles"] });
    void queryClient.invalidateQueries({ queryKey: ["admin", "stats"] });
    void queryClient.invalidateQueries({ queryKey: ["titles"] });
    void queryClient.invalidateQueries({ queryKey: ["title"] });
  };

  const save = useMutation<Title, Error, { id: string | null; form: TitleForm }>({
    mutationFn: ({ id, form }) => {
      const payload: TitleIn = {
        name: form.name.trim(),
        synopsis: form.synopsis.trim(),
        genres: form.genres.split(",").map((g) => g.trim()).filter(Boolean),
        release_year: Number(form.release_year),
        type: form.type,
        kind: form.kind,
        studio: form.studio.trim(),
        age_rating: form.age_rating.trim(),
        original_language: form.original_language.trim(),
        airing_status: form.airing_status.trim(),
        audio: form.audio,
        rating: form.rating === "" ? null : Number(form.rating),
        poster_url: form.poster_url.trim(),
        featured: form.featured,
        status: form.status,
        visibility: form.visibility === "draft" ? null : form.visibility,
        release_at: form.visibility === "upcoming" && form.release_at ? new Date(form.release_at).toISOString() : null,
      };
      return id
        ? apiPatch<Title>(`/titles/${id}`, payload)
        : apiPost<Title>("/titles", payload);
    },
    onSuccess: (_data, variables) => {
      const v = variables.form.visibility;
      toast.success(
        variables.id
          ? "Title updated"
          : v === "upcoming"
            ? "Saved — it shows under Coming Soon with a countdown"
            : v === "listed"
              ? "Title created — it's live on Home"
              : "Draft saved — hidden from viewers until you launch it",
      );
      setFormOpen(false);
      invalidate();
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });

  const remove = useMutation<null, Error, string>({
    mutationFn: (id) => apiDelete<null>(`/titles/${id}`),
    onSuccess: () => {
      toast.success("Title deleted");
      setDeleteTarget(null);
      invalidate();
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });

  function openCreate() {
    setEditing(null);
    setForm(EMPTY_TITLE);
    setFormOpen(true);
  }

  // ---- AniList one-click import ----
  const [importOpen, setImportOpen] = useState(false);
  const [importQuery, setImportQuery] = useState("");
  const [importResults, setImportResults] = useState<AniListResult[] | null>(null);
  const [importBusy, setImportBusy] = useState(false);

  async function runImportSearch() {
    if (importQuery.trim().length < 2) return;
    setImportBusy(true);
    try {
      setImportResults(await apiGet<AniListResult[]>(`/import/search?q=${encodeURIComponent(importQuery.trim())}`));
    } catch (error) {
      toast.error(apiErrorMessage(error));
    } finally {
      setImportBusy(false);
    }
  }

  const importOne = useMutation<Title, Error, AniListResult>({
    mutationFn: (result) => apiPost<Title>("/import/title", result),
    onSuccess: (title) => {
      toast.success(`"${title.name}" imported as a draft — add episodes and a poster next`);
      setImportOpen(false);
      setImportResults(null);
      setImportQuery("");
      void queryClient.invalidateQueries({ queryKey: ["admin", "titles"] });
      void queryClient.invalidateQueries({ queryKey: ["admin", "stats"] });
      void queryClient.invalidateQueries({ queryKey: ["titles"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
  function openEdit(title: Title) {
    setEditing(title);
    setForm({
      name: title.name,
      synopsis: title.synopsis,
      kind: title.kind,
      studio: title.studio ?? "",
      age_rating: title.age_rating ?? "",
      original_language: title.original_language ?? "",
      airing_status: title.airing_status ?? "",
      genres: title.genres.join(", "),
      release_year: String(title.release_year),
      type: title.type,
      audio: title.audio,
      rating: title.rating === null ? "" : String(title.rating),
      poster_url: title.poster_url,
      featured: title.featured,
      status: title.status,
      visibility: title.visibility ?? (title.status === "published" ? "listed" : "draft"),
      release_at: title.release_at ? title.release_at.slice(0, 16) : "",
    });
    setFormOpen(true);
  }

  return (
    <div className="mx-auto max-w-5xl">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="studio-catalog-heading">
            Catalog
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">Titles ({titles.data?.length ?? 0}) — drafts are hidden from viewers until published.</p>
        </div>
        {isAdmin ? (
          <Button
            onClick={() => setImportOpen(true)}
            variant="outline"
            data-testid="admin-import-btn"
            className="border-slate-700 text-zinc-200 hover:bg-slate-800"
          >
            <Search className="mr-1.5 h-4 w-4" aria-hidden /> Import from AniList
          </Button>
        ) : null}
        <Button
          onClick={openCreate}
          data-testid="admin-add-anime-btn"
          className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
        >
          <Plus className="mr-1.5 h-4 w-4" aria-hidden /> {isAdmin ? "Add title" : "Add draft title"}
        </Button>
      </div>

      <div className="mt-4 overflow-hidden rounded-2xl border border-slate-800" data-testid="admin-catalog-table">
        <Table>
          <TableHeader>
            <TableRow className="border-slate-800">
              <TableHead>Title</TableHead>
              <TableHead>Type</TableHead>
              <TableHead>Year</TableHead>
              <TableHead>Episodes</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {(titles.data ?? []).map((title) => (
              <TableRow key={title.id} className="border-slate-800/70">
                <TableCell>
                  <div className="flex items-center gap-3">
                    {title.poster_url ? (
                      <img src={mediaUrl(title.poster_url)} alt="" aria-hidden className="h-12 w-8 rounded object-cover" />
                    ) : (
                      <span className="flex h-12 w-8 items-center justify-center rounded bg-slate-800">
                        <Film className="h-4 w-4 text-zinc-500" aria-hidden />
                      </span>
                    )}
                    <div className="min-w-0">
                      <p className="truncate text-sm font-semibold text-white">{title.name}</p>
                      <p className="truncate text-xs text-muted-foreground">{title.genres.join(", ")}</p>
                    </div>
                  </div>
                </TableCell>
                <TableCell className="text-sm capitalize">{title.type}</TableCell>
                <TableCell className="text-sm">{title.release_year}</TableCell>
                <TableCell className="text-sm">{title.episode_count}</TableCell>
                <TableCell>
                  <Badge
                    className={
                      title.visibility === "upcoming"
                        ? "bg-amber-500/15 text-amber-400"
                        : title.status === "published"
                          ? "bg-emerald-500/15 text-emerald-400"
                          : "bg-slate-600/30 text-zinc-300"
                    }
                    data-testid={`admin-visibility-badge-${title.id}`}
                  >
                    {title.visibility === "upcoming" ? "Upcoming" : title.status === "published" ? "Listed" : "Draft"}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-1.5">
                    <Button variant="ghost" size="icon-sm" onClick={() => openEdit(title)} data-testid={`admin-edit-btn-${title.id}`} aria-label={`Edit ${title.name}`}>
                      <Pencil className="h-4 w-4" aria-hidden />
                    </Button>
                    <Button variant="ghost" size="icon-sm" onClick={() => setDeleteTarget(title)} data-testid={`admin-delete-btn-${title.id}`} aria-label={`Delete ${title.name}`}>
                      <Trash2 className="h-4 w-4 text-rose-400" aria-hidden />
                    </Button>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>

      {/* create/edit dialog */}
      <Dialog open={formOpen} onOpenChange={setFormOpen}>
        <DialogContent className="max-h-[85svh] max-w-xl overflow-y-auto border-slate-800 bg-[#121622]">
          <DialogHeader>
            <DialogTitle className="font-heading text-white">{editing ? "Edit title" : "New title"}</DialogTitle>
            <DialogDescription>Metadata is stored in the catalog DB and appears instantly once published.</DialogDescription>
          </DialogHeader>
          <form
            className="space-y-4"
            data-testid="admin-anime-form"
            onSubmit={(event) => {
              event.preventDefault();
              save.mutate({ id: editing?.id ?? null, form });
            }}
          >
            <div className="space-y-2">
              <Label htmlFor="af-name">Name</Label>
              <Input id="af-name" required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} className="border-slate-700 bg-slate-900/70" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="af-kind">Category</Label>
              <Select value={form.kind} onValueChange={(value: string) => setForm({ ...form, kind: value as typeof form.kind })}>
                <SelectTrigger id="af-kind" className="border-slate-700 bg-slate-900/70" data-testid="admin-kind-select">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="anime">Anime</SelectItem>
                  <SelectItem value="movie">Movie</SelectItem>
                  <SelectItem value="cartoon">Cartoon</SelectItem>
                  <SelectItem value="kdrama">K-Drama</SelectItem>
                  <SelectItem value="webseries">Web Series</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label htmlFor="af-synopsis">Synopsis</Label>
              <Textarea id="af-synopsis" rows={4} value={form.synopsis} onChange={(e) => setForm({ ...form, synopsis: e.target.value })} className="border-slate-700 bg-slate-900/70" />
            </div>
            <div className="space-y-2">
              <Label>Launch option — pick ONE (they can't both be on)</Label>
              {isAdmin ? (
                <>
                  <div className="grid grid-cols-3 gap-2" data-testid="admin-visibility-control">
                    {([
                      { v: "draft", label: "Save as draft", hint: "Hidden — finish details later" },
                      { v: "upcoming", label: "Upcoming", hint: "Coming Soon + countdown" },
                      { v: "listed", label: "List on home", hint: "Live for viewers" },
                    ] as const).map((opt) => (
                      <button
                        key={opt.v}
                        type="button"
                        onClick={() =>
                          setForm({ ...form, visibility: opt.v, status: opt.v === "draft" ? "draft" : "published" })
                        }
                        data-testid={`admin-visibility-option-${opt.v}`}
                        aria-pressed={form.visibility === opt.v}
                        className={`rounded-lg border px-3 py-2.5 text-left transition-all ${
                          form.visibility === opt.v
                            ? "border-amber-400 bg-amber-400/10 shadow-[0_0_0_1px_rgba(245,158,11,.6)]"
                            : "border-slate-700 bg-slate-900/60 hover:border-slate-500"
                        }`}
                      >
                        <span className={`block text-xs font-bold ${form.visibility === opt.v ? "text-amber-300" : "text-zinc-200"}`}>
                          {opt.label}
                        </span>
                        <span className="mt-0.5 block text-[11px] leading-tight text-muted-foreground">{opt.hint}</span>
                      </button>
                    ))}
                  </div>
                  {form.visibility === "upcoming" ? (
                    <div className="space-y-1.5">
                      <Label htmlFor="af-release-at">Release date &amp; time (drives the countdown)</Label>
                      <Input
                        id="af-release-at"
                        type="datetime-local"
                        required
                        value={form.release_at}
                        onChange={(e) => setForm({ ...form, release_at: e.target.value })}
                        className="border-slate-700 bg-slate-900/70"
                        data-testid="admin-release-at-input"
                      />
                    </div>
                  ) : null}
                </>
              ) : (
                <p className="text-xs text-muted-foreground" data-testid="worker-visibility-note">
                  Workers save drafts only — the owner picks the launch option and publishes.
                </p>
              )}
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="af-genres">Genres (comma-separated)</Label>
                <Input id="af-genres" value={form.genres} onChange={(e) => setForm({ ...form, genres: e.target.value })} placeholder="Action, Sci-Fi" className="border-slate-700 bg-slate-900/70" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="af-year">Release year</Label>
                <Input id="af-year" type="number" min={1960} max={2100} required value={form.release_year} onChange={(e) => setForm({ ...form, release_year: e.target.value })} className="border-slate-700 bg-slate-900/70" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="af-type">Type</Label>
                <Select value={form.type} onValueChange={(value: string) => setForm({ ...form, type: value as "series" | "movie" | "short" | "documentary" | "thriller" | "ova" })}>
                  <SelectTrigger id="af-type" className="border-slate-700 bg-slate-900/70">
                    <SelectValue>{SUBTYPE_LABELS[form.type] ?? form.type}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="series">Series (episodes)</SelectItem>
                    <SelectItem value="movie">Movie</SelectItem>
                    <SelectItem value="short">Short</SelectItem>
                    <SelectItem value="documentary">Documentary</SelectItem>
                    <SelectItem value="thriller">Thriller</SelectItem>
                    <SelectItem value="ova">OVA / Special</SelectItem>
                    <SelectItem value="movie">Movie</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="af-rating">Rating (0-10)</Label>
                <Input id="af-rating" type="number" step="0.1" min={0} max={10} value={form.rating} onChange={(e) => setForm({ ...form, rating: e.target.value })} className="border-slate-700 bg-slate-900/70" />
              </div>
            </div>
              <div className="space-y-2">
                <Label htmlFor="af-studio">Studio</Label>
                <Input id="af-studio" value={form.studio} onChange={(e) => setForm({ ...form, studio: e.target.value })} placeholder="e.g. MAPPA, Toei Animation, Studio Ghibli" maxLength={80} className="border-slate-700 bg-slate-900/70" data-testid="admin-studio-input" />
              </div>
              <div className="grid grid-cols-3 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="af-age">Age rating</Label>
                  <Input id="af-age" value={form.age_rating} onChange={(e) => setForm({ ...form, age_rating: e.target.value })} placeholder="13+" maxLength={10} className="border-slate-700 bg-slate-900/70" data-testid="admin-age-input" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="af-olang">Original language</Label>
                  <Input id="af-olang" value={form.original_language} onChange={(e) => setForm({ ...form, original_language: e.target.value })} placeholder="Japanese" maxLength={30} className="border-slate-700 bg-slate-900/70" data-testid="admin-olang-input" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="af-airstatus">Airing status</Label>
                  <Input id="af-airstatus" list="airstatus-options" value={form.airing_status} onChange={(e) => setForm({ ...form, airing_status: e.target.value })} placeholder="Ongoing" maxLength={12} className="border-slate-700 bg-slate-900/70" data-testid="admin-airstatus-input" />
                  <datalist id="airstatus-options">
                    <option value="Ongoing" />
                    <option value="Completed" />
                    <option value="Upcoming" />
                  </datalist>
                </div>
              </div>
              <div className="space-y-2">
                <Label htmlFor="af-poster">Poster URL</Label>
              <ImageUploadField id="af-poster" value={form.poster_url} onChange={(url) => setForm({ ...form, poster_url: url })} testid="admin-poster-input" />
            </div>
            <div className="space-y-2">
              <Label>Audio options</Label>
              <div className="flex flex-wrap gap-4">
                {AUDIO_OPTIONS.map((option) => (
                  <label key={option} className="flex items-center gap-2 text-sm text-zinc-300">
                    <Checkbox
                      checked={form.audio.includes(option)}
                      onCheckedChange={(checked) => {
                        setForm({
                          ...form,
                          audio: checked
                            ? [...form.audio, option]
                            : form.audio.filter((a) => a !== option),
                        });
                      }}
                      data-testid={`admin-audio-checkbox-${option.replace(/\s+/g, "-").toLowerCase()}`}
                    />
                    {option}
                  </label>
                ))}
              </div>
            </div>
            <div className="flex items-center gap-6">
              <label className="flex items-center gap-2 text-sm text-zinc-300">
                <Checkbox
                  checked={form.featured}
                  onCheckedChange={(checked) => setForm({ ...form, featured: checked === true })}
                  data-testid="admin-featured-checkbox"
                />
                Featured on home
              </label>
              <div className="space-y-1">
                <Label htmlFor="af-status">Status</Label>
                <Select value={form.status} onValueChange={(value: string) => setForm({ ...form, status: value as "published" | "draft" })}>
                  <SelectTrigger id="af-status" className="w-40 border-slate-700 bg-slate-900/70">
                    <SelectValue>{form.status === "published" ? "Published" : "Draft"}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="draft">Draft</SelectItem>
                    <SelectItem value="published">Published</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setFormOpen(false)}>Cancel</Button>
              <Button type="submit" disabled={save.isPending} data-testid="admin-save-anime-btn" className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300">
                {save.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : null}
                {editing ? "Save changes" : "Create title"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* AniList import dialog */}
      <Dialog open={importOpen} onOpenChange={setImportOpen}>
        <DialogContent className="max-w-lg border-slate-800 bg-[#121622]">
          <DialogHeader>
            <DialogTitle className="text-white">Import from AniList</DialogTitle>
            <DialogDescription>
              Pull real metadata — synopsis, genres, poster, episode count — then upload episodes yourself.
            </DialogDescription>
          </DialogHeader>
          <div className="flex gap-2">
            <Input
              value={importQuery}
              onChange={(e) => setImportQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && void runImportSearch()}
              placeholder="Search anime, e.g. Demon Slayer"
              className="border-slate-700 bg-slate-900/70"
              data-testid="anilist-search-input"
            />
            <Button onClick={() => void runImportSearch()} disabled={importBusy} className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" data-testid="anilist-search-btn">
              {importBusy ? <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> : <Search className="h-4 w-4" aria-hidden />}
            </Button>
          </div>
          <div className="max-h-80 space-y-2 overflow-y-auto pr-1" data-testid="anilist-results">
            {(importResults ?? []).map((r) => (
              <div key={r.anilist_id} className="flex items-center gap-3 rounded-xl border border-slate-800 bg-slate-900/50 p-2.5" data-testid={`anilist-result-${r.anilist_id}`}>
                {r.poster_url ? (
                  <img src={mediaUrl(r.poster_url)} alt="" aria-hidden className="h-14 w-10 shrink-0 rounded object-cover" />
                ) : (
                  <div className="h-14 w-10 shrink-0 rounded bg-slate-800" />
                )}
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm font-semibold text-white">
                    {r.name} <span className="font-normal text-zinc-500">{r.release_year ?? ""} · {r.type === "movie" ? "Movie" : "Series"}{r.episodes_count ? ` · ${r.episodes_count} ep` : ""}</span>
                  </p>
                  <p className="line-clamp-1 text-xs text-zinc-400">{r.synopsis}</p>
                  <span className="mt-0.5 inline-block rounded bg-slate-800 px-1.5 text-[10px] uppercase tracking-wide text-zinc-400">
                    {r.source === "offline" ? "offline sample" : "AniList"}
                  </span>
                </div>
                <Button
                  size="sm"
                  onClick={() => importOne.mutate(r)}
                  disabled={importOne.isPending}
                  className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
                  data-testid={`anilist-import-${r.anilist_id}`}
                >
                  {importOne.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden /> : null}
                  Import
                </Button>
              </div>
            ))}
            {importResults && importResults.length === 0 ? (
              <p className="py-6 text-center text-sm text-zinc-500">No matches — try another name.</p>
            ) : null}
          </div>
        </DialogContent>
      </Dialog>

      {/* delete confirm */}
      <Dialog open={deleteTarget !== null} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <DialogContent className="border-slate-800 bg-[#121622]">
          <DialogHeader>
            <DialogTitle className="text-white">Delete “{deleteTarget?.name}”?</DialogTitle>
            <DialogDescription>
              This removes the title, all its episodes, and their video files. This cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setDeleteTarget(null)}>Cancel</Button>
            <Button
              variant="destructive"
              onClick={() => deleteTarget && remove.mutate(deleteTarget.id)}
              data-testid="admin-delete-confirm-btn"
            >
              {remove.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : null}
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
