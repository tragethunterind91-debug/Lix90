import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Bot, Check, Copy, Loader2, ShieldCheck, ShieldOff, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { apiDelete, apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { AiAuditInfo } from "@/lib/types";

// AI Auditor — mint ONE link+pass for an AI agent (like the builder assistant)
// to inspect the PUBLIC catalog and suggest upgrades. The key can reach exactly
// one endpoint that returns titles/bios only — never secrets, users or env.
// Deleting is forever.
export default function AiAudit() {
  const qc = useQueryClient();
  const audits = useQuery({
    queryKey: ["studio", "ai-audits"],
    queryFn: () => apiGet<AiAuditInfo[]>("/ai-audit"),
  });
  const [label, setLabel] = useState("");
  const [minted, setMinted] = useState<{ token: string; how_to_use: string; warning: string; url?: string } | null>(null);
  const [copied, setCopied] = useState(false);
  const [busy, setBusy] = useState(false);

  // Keep minted persistent in sessionStorage so it doesn't disappear on query refetch
  useState(() => {
    try {
      const saved = sessionStorage.getItem("anime_minted_ai_audit");
      if (saved) setMinted(JSON.parse(saved));
    } catch {}
  });

  const active = (audits.data ?? []).find((a) => a.active);

  async function create() {
    setBusy(true);
    try {
      const res = await apiPost<{ id: string; token: string; how_to_use: string; warning: string; url?: string }>(
        `/ai-audit?label=${encodeURIComponent(label || "AI review")}`,
        {},
      );
      setMinted(res);
      try {
        sessionStorage.setItem("anime_minted_ai_audit", JSON.stringify(res));
      } catch {}
      toast.success("AI link created");
      void qc.invalidateQueries({ queryKey: ["studio", "ai-audits"] });
    } catch (e) {
      toast.error(apiErrorMessage(e));
    } finally {
      setBusy(false);
    }
  }

  async function revoke(id: string) {
    try {
      await apiDelete(`/ai-audit/${id}`);
      setMinted(null);
      try {
        sessionStorage.removeItem("anime_minted_ai_audit");
      } catch {}
      toast.success("Deleted forever — that link and password can never work again");
      void qc.invalidateQueries({ queryKey: ["studio", "ai-audits"] });
    } catch (e) {
      toast.error(apiErrorMessage(e));
    }
  }

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="ai-audit-heading">
        AI Auditor
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Let an AI assistant (like your builder) review the site to upgrade it — on YOUR terms.
      </p>

      <Card className="mt-6 border-slate-800 bg-card/70" data-testid="ai-audit-rules">
        <CardContent className="p-5 text-sm">
          <p className="flex items-center gap-2 font-heading font-bold text-emerald-400" data-testid="ai-audit-can">
            <ShieldCheck className="h-4 w-4" aria-hidden /> The AI CAN see
          </p>
          <ul className="mt-2 space-y-1 text-zinc-400">
            <li>· Which videos exist, their bios, episode counts, ratings and years</li>
            <li>· Enough public surface to suggest catalog and UX upgrades</li>
          </ul>
          <p className="mt-4 flex items-center gap-2 font-heading font-bold text-rose-400" data-testid="ai-audit-cannot">
            <ShieldOff className="h-4 w-4" aria-hidden /> The AI can NEVER see
          </p>
          <ul className="mt-2 space-y-1 text-zinc-400">
            <li>· Passwords, API keys, database names, session secrets — server-side only</li>
            <li>· User accounts, emails, revenue, admin routes, analytics internals</li>
            <li>· Your source code or web patterns that could enable copying</li>
          </ul>
        </CardContent>
      </Card>

      {active ? (
        <Card className="mt-6 border-amber-400/40 bg-amber-400/5" data-testid="ai-audit-active-card">
          <CardContent className="space-y-4 p-5">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="font-heading text-base font-bold text-white">
                  Active: {active.label} <span className="text-xs font-normal text-zinc-500">· created {active.created_at.slice(0, 10)}</span>
                </p>
                <p className="text-xs text-zinc-500">Key: au_•••••••• (stored hashed) · last used: {active.last_used || "never"}</p>
                <p className="mt-1 text-xs text-amber-300">Only one AI link can exist at a time — delete it before creating another.</p>
              </div>
              <Button
                size="sm"
                variant="outline"
                onClick={() => void revoke(active.id)}
                className="border-rose-500/50 text-rose-300 hover:bg-rose-500/10"
                data-testid="ai-audit-delete-btn"
              >
                <Trash2 className="mr-2 h-4 w-4" aria-hidden /> Delete forever
              </Button>
            </div>

            {minted ? (
              <div className="rounded-xl border border-emerald-500/40 bg-emerald-500/10 p-4" data-testid="ai-audit-minted">
                <p className="text-xs font-bold uppercase tracking-widest text-emerald-400">Your AI Access Token (Saved in Session)</p>
                <div className="mt-2 flex items-center gap-2">
                  <code className="min-w-0 flex-1 break-all rounded-lg bg-slate-900/90 px-3 py-2 text-xs font-mono text-emerald-300" data-testid="ai-audit-token">
                    {minted.token}
                  </code>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      void navigator.clipboard.writeText(minted.token);
                      setCopied(true);
                      toast.success("Copied to clipboard!");
                    }}
                    data-testid="ai-audit-copy-btn"
                  >
                    {copied ? <Check className="h-4 w-4" aria-hidden /> : <Copy className="h-4 w-4" aria-hidden />}
                  </Button>
                </div>
                <p className="mt-2 text-xs text-zinc-300">{minted.how_to_use}</p>
              </div>
            ) : null}
          </CardContent>
        </Card>
      ) : (
        <Card className="mt-6 border-slate-800 bg-card/70" data-testid="ai-audit-create-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 font-heading text-base font-bold text-white">
              <Bot className="h-5 w-5 text-amber-400" aria-hidden /> Create the AI access link
            </CardTitle>
            <CardDescription>One link + password. Shown ONCE. Deletable any time — forever.</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap items-end gap-3">
              <div className="min-w-0 flex-1 space-y-2">
                <Label htmlFor="ai-audit-label">Label (who/what is this AI?)</Label>
                <Input
                  id="ai-audit-label"
                  value={label}
                  onChange={(e) => setLabel(e.target.value)}
                  placeholder="e.g. Emergent builder — Oct upgrade"
                  className="border-slate-700 bg-slate-900/70"
                  data-testid="ai-audit-label-input"
                />
              </div>
              <Button
                onClick={() => void create()}
                disabled={busy}
                className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
                data-testid="ai-audit-create-btn"
              >
                {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <Bot className="mr-2 h-4 w-4" aria-hidden />}
                Create link
              </Button>
            </div>

            {minted ? (
              <div className="mt-4 rounded-xl border border-emerald-500/40 bg-emerald-500/5 p-4" data-testid="ai-audit-minted">
                <p className="text-xs font-bold uppercase tracking-widest text-emerald-400">Copy now — shown only once</p>
                <div className="mt-2 flex items-center gap-2">
                  <code className="min-w-0 flex-1 break-all rounded-lg bg-slate-900/80 px-3 py-2 text-xs text-emerald-300" data-testid="ai-audit-token">
                    {minted.token}
                  </code>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => {
                      void navigator.clipboard.writeText(minted.token);
                      setCopied(true);
                      toast.success("Copied");
                    }}
                    data-testid="ai-audit-copy-btn"
                  >
                    {copied ? <Check className="h-4 w-4" aria-hidden /> : <Copy className="h-4 w-4" aria-hidden />}
                  </Button>
                </div>
                <p className="mt-2 text-xs text-zinc-500">{minted.how_to_use}</p>
                <p className="mt-1 text-xs text-amber-300">{minted.warning}</p>
              </div>
            ) : null}
          </CardContent>
        </Card>
      )}

      {(audits.data ?? []).some((a) => !a.active) ? (
        <Card className="mt-6 border-slate-800 bg-card/70" data-testid="ai-audit-history">
          <CardContent className="p-5">
            <p className="font-heading text-sm font-bold text-white">Deleted audits (dead forever)</p>
            <ul className="mt-2 space-y-1 text-xs text-zinc-500">
              {(audits.data ?? [])
                .filter((a) => !a.active)
                .slice(0, 6)
                .map((a) => (
                  <li key={a.id} data-testid="ai-audit-history-row">
                    {a.label} · created {a.created_at.slice(0, 10)} · dead forever
                  </li>
                ))}
            </ul>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
