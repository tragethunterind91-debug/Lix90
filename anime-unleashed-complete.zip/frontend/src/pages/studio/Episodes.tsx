import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Eye, EyeOff, FolderInput, Link2, Loader2, Pencil, Plus, Trash2, UploadCloud, Wand2 } from "lucide-react";
import ImageUploadField from "@/components/ImageUploadField";
import { useMe } from "@/hooks/useAuth";
import { useAttachVideo, useConvertVideo, useVideoLibrary } from "@/hooks/useVideo";
import { uploadEpisodeAudio, uploadEpisodeSubtitles } from "@/lib/tracks";
import { apiDelete, apiGet, apiPatch, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import { uploadVideo } from "@/lib/uploadVideo";
import type { Episode, Title, TitleDetail, UploadOut } from "@/lib/types";
import { formatBytes } from "@/lib/badges";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";

interface EpisodeForm {
  number: string;
  season: string;
  name: string;
  description: string;
  status: "published" | "draft";
  file: File | null;
  resolution: string;
  dub_tag: string;
  thumbnail_url: string;
  source: string;
}

const EMPTY_EPISODE: EpisodeForm = {
  number: "1",
  season: "1",
  name: "",
  description: "",
  status: "draft",
  file: null,
  resolution: "",
  dub_tag: "",
  thumbnail_url: "",
  source: "",
};

// Episode manager: pick a title, upload videos through the backend, set extras, publish.
export default function StudioEpisodes() {
  const queryClient = useQueryClient();
  const { data: me } = useMe();
  const isAdmin = me?.role === "admin";
  const titles = useQuery({
    queryKey: ["admin", "titles"],
    queryFn: () => apiGet<Title[]>("/titles?all=1&sort=latest"),
  });
  const [selectedId, setSelectedId] = useState<string>("");
  const selected = (titles.data ?? []).find((t) => t.id === selectedId) ?? null;

  const episodes = useQuery({
    queryKey: ["admin", "episodes", selectedId],
    queryFn: () => apiGet<TitleDetail>(`/titles/${selected?.slug ?? ""}?all=1`),
    enabled: Boolean(selected),
  });

  const [addOpen, setAddOpen] = useState(false);
  const [form, setForm] = useState<EpisodeForm>(EMPTY_EPISODE);
  const [progress, setProgress] = useState<number | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Episode | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  // convert system (video): one upload → resolution variants + audio-only
  const convertVideo = useConvertVideo();
  const videoLibrary = useVideoLibrary();
  const attachVideo = useAttachVideo();
  const [convertTarget, setConvertTarget] = useState<Episode | null>(null);
  const [convertRes, setConvertRes] = useState<string[]>([]);
  const [convertAudio, setConvertAudio] = useState(false);
  const [attachTarget, setAttachTarget] = useState<Episode | null>(null);

  const invalidate = () => {
    if (selectedId) void queryClient.invalidateQueries({ queryKey: ["admin", "episodes", selectedId] });
    void queryClient.invalidateQueries({ queryKey: ["admin", "titles"] });
    void queryClient.invalidateQueries({ queryKey: ["admin", "stats"] });
    void queryClient.invalidateQueries({ queryKey: ["titles"] });
    void queryClient.invalidateQueries({ queryKey: ["title"] });
  };

  const create = useMutation<Episode, Error, { form: EpisodeForm; videoKey: string }>({
    mutationFn: ({ form, videoKey }) =>
      apiPost<Episode>(`/titles/${selected!.id}/episodes`, {
        number: Number(form.number),
        season: Number(form.season),
        name: form.name.trim(),
        description: form.description.trim(),
        source: form.source.trim(),
        video_key: videoKey,
        duration_seconds: null,
        status: form.status,
        resolution: form.resolution || null,
        dub_tag: form.dub_tag.trim() || null,
        thumbnail_url: form.thumbnail_url.trim() || null,
      }),
    onSuccess: () => {
      toast.success("Episode added");
      setAddOpen(false);
      setForm(EMPTY_EPISODE);
      setProgress(null);
      invalidate();
    },
    onError: (error) => {
      setProgress(null);
      toast.error(apiErrorMessage(error));
    },
  });

  const togglePublish = useMutation<Episode, Error, Episode>({
    mutationFn: (episode) =>
      apiPatch<Episode>(`/episodes/${episode.id}`, {
        status: episode.status === "published" ? "draft" : "published",
      }),
    onSuccess: () => {
      toast.success("Episode status updated");
      invalidate();
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });

  const remove = useMutation<null, Error, string>({
    mutationFn: (id) => apiDelete<null>(`/episodes/${id}`),
    onSuccess: () => {
      toast.success("Episode deleted");
      setDeleteTarget(null);
      invalidate();
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });

  // ---- move episode to ANOTHER playlist (title) at any time — no re-upload ----
  const [moveTarget, setMoveTarget] = useState<Episode | null>(null);
  const [moveToId, setMoveToId] = useState<string>("");
  const allTitles = useQuery({
    queryKey: ["titles", "all-admin"],
    queryFn: () => apiGet<Title[]>("/titles?all=1"),
  });
  const moveTo = useMutation<Episode, Error, { id: string; titleId: string }>({
    mutationFn: ({ id, titleId }) => apiPatch<Episode>(`/episodes/${id}`, { title_id: titleId }),
    onSuccess: () => {
      toast.success("Episode moved to the other playlist");
      setMoveTarget(null);
      invalidate();
      void queryClient.invalidateQueries({ queryKey: ["titles"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });

  // ---- full episode editing (all fields + optional video replacement) ----
  const [editTarget, setEditTarget] = useState<Episode | null>(null);
  const [editForm, setEditForm] = useState<EpisodeForm>(EMPTY_EPISODE);
  const [editProgress, setEditProgress] = useState<number | null>(null);

  const update = useMutation<Episode, Error, { id: string; form: EpisodeForm; videoKey: string | null }>({
    mutationFn: ({ id, form, videoKey }) => {
      const payload: Record<string, unknown> = {
        number: Number(form.number),
        season: Number(form.season),
        name: form.name.trim(),
        description: form.description.trim(),
        source: form.source.trim(),
        status: form.status,
        resolution: form.resolution || null,
        dub_tag: form.dub_tag.trim() || null,
        thumbnail_url: form.thumbnail_url.trim() || null,
      };
      if (videoKey) payload.video_key = videoKey;
      return apiPatch<Episode>(`/episodes/${id}`, payload);
    },
    onSuccess: () => {
      toast.success("Episode updated");
      setEditTarget(null);
      setEditProgress(null);
      invalidate();
    },
    onError: (error) => {
      setEditProgress(null);
      toast.error(apiErrorMessage(error));
    },
  });

  const [trackBusy, setTrackBusy] = useState(false);

  async function handleTrackUpload(file: File | undefined | null, kind: "audio" | "subs") {
    if (!file || !editTarget) return;
    setTrackBusy(true);
    try {
      if (kind === "audio") {
        await uploadEpisodeAudio(editTarget.id, file);
        setEditTarget({ ...editTarget, audio_key: "uploaded" });
        toast.success("Dub audio attached — VIP members can hear it");
      } else {
        await uploadEpisodeSubtitles(editTarget.id, file);
        setEditTarget({ ...editTarget, subtitle_key: "uploaded" });
        toast.success("Subtitles attached — VIP members can read them");
      }
      void queryClient.invalidateQueries({ queryKey: ["admin", "titles"] });
    } catch (error) {
      toast.error(apiErrorMessage(error));
    } finally {
      setTrackBusy(false);
    }
  }

  function openEdit(episode: Episode) {    setEditTarget(episode);
    setEditForm({
      number: String(episode.number),
      season: String(episode.season ?? 1),
      name: episode.name,
      description: episode.description,
      status: episode.status,
      file: null,
      resolution: episode.resolution ?? "",
      dub_tag: episode.dub_tag ?? "",
      thumbnail_url: episode.thumbnail_url ?? "",
      source: episode.source ?? "",
    });
  }

  async function submitEdit(event: React.FormEvent) {
    event.preventDefault();
    if (!editTarget) return;
    let videoKey: string | null = null;
    if (editForm.file) {
      try {
        const uploaded: UploadOut = await uploadVideo(editForm.file, (p) => setEditProgress(p.percent));
        videoKey = uploaded.video_key;
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Upload failed");
        return;
      }
    }
    update.mutate({ id: editTarget.id, form: editForm, videoKey });
  }

  async function submitEpisode(event: React.FormEvent) {
    event.preventDefault();
    if (!selected) return;
    let videoKey = "";
    if (form.file) {
      try {
        const uploaded: UploadOut = await uploadVideo(form.file, (p) => setProgress(p.percent));
        videoKey = uploaded.video_key;
      } catch (error) {
        toast.error(error instanceof Error ? error.message : "Upload failed");
        return;
      }
    }
    create.mutate({ form, videoKey });
  }

  return (
    <div className="mx-auto max-w-5xl">
      <div className="flex flex-wrap items-center gap-3">
        <div>
          <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="studio-episodes-heading">
            Episodes &amp; Uploads
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">Videos upload through the backend to the media store — never via the browser.</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Select value={selectedId} onValueChange={(value: string) => setSelectedId(value)}>
            <SelectTrigger className="w-64 border-slate-700 bg-slate-900/70" data-testid="admin-episodes-title-select" aria-label="Choose a title">
              <SelectValue>{(v: string) => (titles.data ?? []).find((t) => t.id === v)?.name ?? "Choose a title"}</SelectValue>
            </SelectTrigger>
            <SelectContent>
              {(titles.data ?? []).map((t) => (
                <SelectItem key={t.id} value={t.id}>{t.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            onClick={() => {
              setForm({ ...EMPTY_EPISODE, number: String((episodes.data?.episodes.length ?? 0) + 1) });
              setAddOpen(true);
            }}
            disabled={!selected}
            data-testid="admin-add-episode-btn"
            className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
          >
            <Plus className="mr-1.5 h-4 w-4" aria-hidden /> Add episode
          </Button>
        </div>
      </div>

      {selected ? (
        <div className="mt-4 overflow-hidden rounded-2xl border border-slate-800">
          <Table>
            <TableHeader>
              <TableRow className="border-slate-800">
                <TableHead className="w-16">#</TableHead>
                <TableHead>Name</TableHead>
                <TableHead>Extras</TableHead>
                <TableHead>Video</TableHead>
                <TableHead>Status</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {(episodes.data?.episodes ?? []).map((episode) => (
                <TableRow key={episode.id} className="border-slate-800/70" data-testid={`admin-episode-row-${episode.id}`}>
                  <TableCell className="font-heading font-bold text-amber-400">S{episode.season ?? 1} · Ep {episode.number}</TableCell>
                  <TableCell className="text-sm">{episode.name || "Untitled"}</TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {episode.resolution || episode.dub_tag ? (
                      <span>
                        {episode.resolution ? `${episode.resolution}` : "auto"}
                        {episode.dub_tag ? ` · D/C ${episode.dub_tag}` : ""}
                      </span>
                    ) : (
                      "—"
                    )}
                  </TableCell>
                  <TableCell className="text-xs text-muted-foreground">
                    {episode.video_key ? formatBytes(episode.size_bytes) : "not uploaded"}
                    {episode.video_variants && Object.keys(episode.video_variants).length > 0 ? (
                      <span className="mt-1 flex flex-wrap gap-1" data-testid={`episode-variants-${episode.id}`}>
                        {Object.entries(episode.video_variants).map(([tag, v]) => (
                          <Badge key={tag} className={v.status === "ready" ? "bg-emerald-500/15 text-emerald-300" : v.status === "processing" ? "bg-amber-400/15 text-amber-300" : "bg-rose-500/15 text-rose-300"}>
                            {tag}{v.status === "ready" ? " ✓" : v.status === "processing" ? " …" : " ✕"}
                          </Badge>
                        ))}
                      </span>
                    ) : null}
                  </TableCell>
                  <TableCell>
                    {isAdmin ? (
                      <button
                        onClick={() => togglePublish.mutate(episode)}
                        data-testid={`admin-episode-publish-toggle-${episode.id}`}
                        className="inline-flex"
                        aria-label={episode.status === "published" ? "Unpublish episode" : "Publish episode"}
                      >
                        <Badge
                          className={episode.status === "published"
                            ? "cursor-pointer bg-emerald-500/15 text-emerald-400 hover:bg-emerald-500/25"
                            : "cursor-pointer bg-slate-600/30 text-zinc-300 hover:bg-slate-600/50"}
                        >
                          {episode.status === "published" ? (
                            <Eye className="mr-1 h-3 w-3" aria-hidden />
                          ) : (
                            <EyeOff className="mr-1 h-3 w-3" aria-hidden />
                          )}
                          {episode.status}
                        </Badge>
                      </button>
                    ) : (
                      <Badge className={episode.status === "published" ? "bg-emerald-500/15 text-emerald-400" : "bg-slate-600/30 text-zinc-300"}>
                        {episode.status}
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1.5">
                      <Button variant="ghost" size="icon-sm" onClick={() => { setConvertTarget(episode); setConvertRes([]); setConvertAudio(false); }} disabled={!episode.video_key} data-testid={`admin-episode-convert-btn-${episode.id}`} aria-label={`Convert episode ${episode.number}`} title="Convert to other resolutions + audio">
                        <Wand2 className="h-4 w-4 text-sky-400" aria-hidden />
                      </Button>
                      <Button variant="ghost" size="icon-sm" onClick={() => openEdit(episode)} data-testid={`admin-episode-edit-btn-${episode.id}`} aria-label={`Edit episode ${episode.number}`}>
                        <Pencil className="h-4 w-4" aria-hidden />
                      </Button>
                      {isAdmin ? (
                        <>
                          <Button variant="ghost" size="icon-sm" onClick={() => { setMoveTarget(episode); setMoveToId(""); }} data-testid={`admin-episode-move-btn-${episode.id}`} aria-label={`Move episode ${episode.number} to another playlist`} title="Move to another playlist — no re-upload">
                            <FolderInput className="h-4 w-4 text-amber-400" aria-hidden />
                          </Button>
                          <Button variant="ghost" size="icon-sm" onClick={() => setDeleteTarget(episode)} data-testid={`admin-episode-delete-btn-${episode.id}`} aria-label={`Delete episode ${episode.number}`}>
                            <Trash2 className="h-4 w-4 text-rose-400" aria-hidden />
                          </Button>
                        </>
                      ) : null}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      ) : (
        <p className="mt-6 text-sm text-muted-foreground">Pick a title above to manage its episodes.</p>
      )}

      {/* add episode dialog */}
      <Dialog open={addOpen} onOpenChange={(open) => { if (!open) { setAddOpen(false); setProgress(null); } }}>
        <DialogContent className="max-h-[85svh] max-w-xl overflow-y-auto border-slate-800 bg-[#121622]">
          <DialogHeader>
            <DialogTitle className="font-heading text-white">Add episode — {selected?.name}</DialogTitle>
            <DialogDescription>
              The video is uploaded through the backend to the media store, then attached to this episode.
            </DialogDescription>
          </DialogHeader>
          <form className="space-y-4" data-testid="admin-episode-form" onSubmit={submitEpisode}>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="ef-number">Episode number</Label>
                <Input id="ef-number" type="number" min={1} required value={form.number} onChange={(e) => setForm({ ...form, number: e.target.value })} className="border-slate-700 bg-slate-900/70" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ef-season">Season</Label>
                <Input id="ef-season" type="number" min={1} max={99} required value={form.season} onChange={(e) => setForm({ ...form, season: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="admin-episode-season-input" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ef-source">Video source</Label>
                <Input id="ef-source" list="source-options" value={form.source} onChange={(e) => setForm({ ...form, source: e.target.value })} placeholder="Google / YouTube / Custom" maxLength={40} className="border-slate-700 bg-slate-900/70" data-testid="admin-episode-source-input" />
                <datalist id="source-options">
                  <option value="Google" />
                  <option value="YouTube" />
                  <option value="Dailymotion" />
                  <option value="R2" />
                  <option value="Custom" />
                </datalist>
              </div>
              <div className="space-y-2">
                {isAdmin ? (
                  <>
                    <Label htmlFor="ef-status">Status</Label>
                    <Select value={form.status} onValueChange={(value: string) => setForm({ ...form, status: value as "published" | "draft" })}>
                      <SelectTrigger id="ef-status" className="border-slate-700 bg-slate-900/70">
                        <SelectValue>{form.status === "published" ? "Published" : "Draft"}</SelectValue>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="published">Published</SelectItem>
                      </SelectContent>
                    </Select>
                  </>
                ) : null}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ef-name">Episode name</Label>
              <Input id="ef-name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="The Neon Overture" className="border-slate-700 bg-slate-900/70" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ef-desc">Description</Label>
              <Textarea id="ef-desc" rows={3} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="border-slate-700 bg-slate-900/70" />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <Label htmlFor="ef-res">Resolution</Label>
                <Select
                  value={form.resolution || "auto"}
                  onValueChange={(value: string) => setForm({ ...form, resolution: value === "auto" ? "" : value })}
                >
                  <SelectTrigger id="ef-res" className="border-slate-700 bg-slate-900/70" data-testid="admin-episode-resolution-select">
                    <SelectValue>{(v: string) => (v && v !== "auto" ? v : "Auto")}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Auto</SelectItem>
                    {["360p", "480p", "720p", "1080p", "1440p", "2160p"].map((res) => (
                      <SelectItem key={res} value={res}>{res}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="ef-dub">D/C tag</Label>
                <Input
                  id="ef-dub"
                  value={form.dub_tag}
                  onChange={(e) => setForm({ ...form, dub_tag: e.target.value })}
                  placeholder="D / C / D+C"
                  maxLength={20}
                  className="border-slate-700 bg-slate-900/70"
                  data-testid="admin-episode-dubtag-input"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ef-thumb">Thumbnail URL</Label>
                <ImageUploadField id="ef-thumb" value={form.thumbnail_url} onChange={(url) => setForm({ ...form, thumbnail_url: url })} testid="admin-episode-thumbnail-input" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ef-file">Video file (mp4 / webm / mkv / mov)</Label>
              <input
                id="ef-file"
                ref={fileInputRef}
                type="file"
                accept="video/mp4,video/webm,video/x-matroska,video/quicktime,.mp4,.webm,.mkv,.mov"
                onChange={(e) => setForm({ ...form, file: e.target.files?.[0] ?? null })}
                data-testid="admin-video-upload-input"
                className="block w-full rounded-lg border border-slate-700 bg-slate-900/70 p-2 text-sm text-zinc-300 file:mr-3 file:rounded-md file:border-0 file:bg-amber-400 file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-slate-950"
              />
            </div>
            {progress !== null ? (
              <div data-testid="admin-upload-progress" className="space-y-1">
                <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                  <div className="h-full rounded-full bg-amber-400 transition-all duration-200" style={{ width: `${progress}%` }} />
                </div>
                <p className="text-xs text-muted-foreground">
                  {form.file ? `Uploading ${form.file.name}… ${progress}%` : "Finishing up…"}
                </p>
              </div>
            ) : null}
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setAddOpen(false)}>Cancel</Button>
              <Button
                type="submit"
                disabled={create.isPending || progress !== null}
                data-testid="admin-episode-save-btn"
                className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
              >
                {create.isPending || progress !== null ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden />
                ) : (
                  <UploadCloud className="mr-2 h-4 w-4" aria-hidden />
                )}
                Upload &amp; save
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* edit episode dialog */}
      <Dialog open={editTarget !== null} onOpenChange={(open) => { if (!open) { setEditTarget(null); setEditProgress(null); } }}>
        <DialogContent className="max-h-[85svh] max-w-xl overflow-y-auto border-slate-800 bg-[#121622]">
          <DialogHeader>
            <DialogTitle className="font-heading text-white">Edit episode {editTarget?.number} — {selected?.name}</DialogTitle>
            <DialogDescription>Change any field. Uploading a new file replaces the current video.</DialogDescription>
          </DialogHeader>
          <form className="space-y-4" data-testid="admin-episode-edit-form" onSubmit={submitEdit}>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label htmlFor="ef-edit-number">Episode number</Label>
                <Input id="ef-edit-number" type="number" min={1} required value={editForm.number} onChange={(e) => setEditForm({ ...editForm, number: e.target.value })} className="border-slate-700 bg-slate-900/70" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ef-edit-season">Season</Label>
                <Input id="ef-edit-season" type="number" min={1} max={99} required value={editForm.season} onChange={(e) => setEditForm({ ...editForm, season: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="admin-episode-edit-season-input" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ef-edit-source">Video source</Label>
                <Input id="ef-edit-source" list="source-options" value={editForm.source} onChange={(e) => setEditForm({ ...editForm, source: e.target.value })} placeholder="Google / Custom" maxLength={40} className="border-slate-700 bg-slate-900/70" data-testid="admin-episode-edit-source-input" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-2">
                  <Label htmlFor="ef-edit-audio">Dub audio (VIP-only)</Label>
                  <input
                    id="ef-edit-audio"
                    type="file"
                    accept="audio/mpeg,audio/mp4,audio/ogg,audio/wav,.mp3,.m4a,.ogg,.wav"
                    className="w-full rounded-md border border-slate-700 bg-slate-900/70 p-2 text-xs text-zinc-300"
                    onChange={(e) => void handleTrackUpload(e.target.files?.[0], "audio")}
                    data-testid="admin-episode-audio-input"
                  />
                  {editTarget?.audio_key ? <p className="text-[11px] text-emerald-400">Audio track attached ✓</p> : <p className="text-[11px] text-zinc-500">No audio yet</p>}
                </div>
                <div className="space-y-2">
                  <Label htmlFor="ef-edit-subs">Subtitles (VIP-only)</Label>
                  <input
                    id="ef-edit-subs"
                    type="file"
                    accept=".vtt,.srt,text/vtt"
                    className="w-full rounded-md border border-slate-700 bg-slate-900/70 p-2 text-xs text-zinc-300"
                    onChange={(e) => void handleTrackUpload(e.target.files?.[0], "subs")}
                    data-testid="admin-episode-subs-input"
                  />
                  {editTarget?.subtitle_key ? <p className="text-[11px] text-emerald-400">Subtitles attached ✓ (.srt auto-converts)</p> : <p className="text-[11px] text-zinc-500">No subtitles yet</p>}
                </div>
              </div>
              <div className="space-y-2">
                {isAdmin ? (
                  <>
                    <Label htmlFor="ef-edit-status">Status</Label>
                    <Select value={editForm.status} onValueChange={(value: string) => setEditForm({ ...editForm, status: value as "published" | "draft" })}>
                      <SelectTrigger id="ef-edit-status" className="border-slate-700 bg-slate-900/70">
                        <SelectValue>{editForm.status === "published" ? "Published" : "Draft"}</SelectValue>
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="draft">Draft</SelectItem>
                        <SelectItem value="published">Published</SelectItem>
                      </SelectContent>
                    </Select>
                  </>
                ) : null}
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ef-edit-name">Episode name</Label>
              <Input id="ef-edit-name" value={editForm.name} onChange={(e) => setEditForm({ ...editForm, name: e.target.value })} className="border-slate-700 bg-slate-900/70" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="ef-edit-desc">Description</Label>
              <Textarea id="ef-edit-desc" rows={3} value={editForm.description} onChange={(e) => setEditForm({ ...editForm, description: e.target.value })} className="border-slate-700 bg-slate-900/70" />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-2">
                <Label htmlFor="ef-edit-res">Resolution</Label>
                <Select
                  value={editForm.resolution || "auto"}
                  onValueChange={(value: string) => setEditForm({ ...editForm, resolution: value === "auto" ? "" : value })}
                >
                  <SelectTrigger id="ef-edit-res" className="border-slate-700 bg-slate-900/70">
                    <SelectValue>{(v: string) => (v && v !== "auto" ? v : "Auto")}</SelectValue>
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="auto">Auto</SelectItem>
                    {["360p", "480p", "720p", "1080p", "1440p", "2160p"].map((res) => (
                      <SelectItem key={res} value={res}>{res}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="ef-edit-dub">D/C tag</Label>
                <Input id="ef-edit-dub" value={editForm.dub_tag} onChange={(e) => setEditForm({ ...editForm, dub_tag: e.target.value })} placeholder="D / C / D+C" maxLength={20} className="border-slate-700 bg-slate-900/70" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="ef-edit-thumb">Thumbnail URL</Label>
                <ImageUploadField id="ef-edit-thumb" value={editForm.thumbnail_url} onChange={(url) => setEditForm({ ...editForm, thumbnail_url: url })} testid="admin-episode-edit-thumbnail-input" />
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="ef-edit-file">Replace video (optional)</Label>
              <input
                id="ef-edit-file"
                type="file"
                accept="video/mp4,video/webm,video/x-matroska,video/quicktime,.mp4,.webm,.mkv,.mov"
                onChange={(e) => setEditForm({ ...editForm, file: e.target.files?.[0] ?? null })}
                data-testid="admin-episode-replace-input"
                className="block w-full rounded-lg border border-slate-700 bg-slate-900/70 p-2 text-sm text-zinc-300 file:mr-3 file:rounded-md file:border-0 file:bg-amber-400 file:px-3 file:py-1.5 file:text-xs file:font-bold file:text-slate-950"
              />
            </div>
            {editProgress !== null ? (
              <div data-testid="admin-edit-upload-progress" className="space-y-1">
                <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                  <div className="h-full rounded-full bg-amber-400 transition-all duration-200" style={{ width: `${editProgress}%` }} />
                </div>
                <p className="text-xs text-muted-foreground">Replacing video… {editProgress}%</p>
              </div>
            ) : null}
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setEditTarget(null)}>Cancel</Button>
              <Button
                type="submit"
                disabled={update.isPending || editProgress !== null}
                data-testid="admin-episode-edit-save-btn"
                className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
              >
                {update.isPending || editProgress !== null ? (
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden />
                ) : null}
                Save changes
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      {/* delete confirm */}
      <Dialog open={deleteTarget !== null} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <DialogContent className="border-slate-800 bg-[#121622]">
          <DialogHeader>
            <DialogTitle className="text-white">Delete episode {deleteTarget?.number}?</DialogTitle>
            <DialogDescription>The video file is removed from the media store too.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button type="button" variant="ghost" onClick={() => setDeleteTarget(null)}>Cancel</Button>
            <Button variant="destructive" onClick={() => deleteTarget && remove.mutate(deleteTarget.id)} data-testid="admin-episode-delete-confirm-btn">
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* convert dialog — one upload, many resolutions + audio */}
      <Dialog open={!!convertTarget} onOpenChange={(open) => !open && setConvertTarget(null)}>
        <DialogContent className="max-w-md border-slate-800 bg-[#121622]">
          <DialogHeader>
            <DialogTitle className="font-heading text-white">Convert — Ep {convertTarget?.number}</DialogTitle>
            <DialogDescription data-testid="convert-dialog-desc">
              The uploaded file stays untouched — ffmpeg derives the variants in the background. Lower→higher and higher→lower both work.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2" data-testid="convert-dialog">
            {["720p", "480p", "360p"].map((res) => (
              <label key={res} className="flex items-center gap-2 rounded-lg border border-slate-700/70 px-3 py-2 text-sm text-zinc-200">
                <input
                  type="checkbox"
                  checked={convertRes.includes(res)}
                  onChange={(e) => setConvertRes(e.target.checked ? [...convertRes, res] : convertRes.filter((r) => r !== res))}
                  data-testid={`convert-res-${res}`}
                />
                {res}
              </label>
            ))}
            <label className="flex items-center gap-2 rounded-lg border border-slate-700/70 px-3 py-2 text-sm text-zinc-200">
              <input type="checkbox" checked={convertAudio} onChange={(e) => setConvertAudio(e.target.checked)} data-testid="convert-audio" />
              Audio-only track (m4a download)
            </label>
            <Button
              disabled={convertVideo.isPending || (!convertRes.length && !convertAudio)}
              onClick={() => convertTarget && convertVideo.mutate({ episodeId: convertTarget.id, resolutions: convertRes, extract_audio: convertAudio }, { onSuccess: () => setConvertTarget(null) })}
              className="w-full bg-sky-400 font-bold text-slate-950 hover:bg-sky-300"
              data-testid="convert-submit-btn"
            >
              {convertVideo.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <Wand2 className="mr-2 h-4 w-4" aria-hidden />}
              Queue conversion
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* attach dialog — the no-re-upload rule */}
      <Dialog open={!!attachTarget} onOpenChange={(open) => !open && setAttachTarget(null)}>
        <DialogContent className="max-h-[80svh] max-w-lg overflow-y-auto border-slate-800 bg-[#121622]">
          <DialogHeader>
            <DialogTitle className="font-heading text-white">Attach existing video — Ep {attachTarget?.number}</DialogTitle>
            <DialogDescription data-testid="attach-dialog-desc">
              Every upload lives in the library once. Point this episode at one — nobody re-uploads.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-2" data-testid="attach-dialog">
            {(videoLibrary.data ?? []).length === 0 ? (
              <p className="py-6 text-center text-sm text-muted-foreground">Library is empty — upload a video first.</p>
            ) : (
              (videoLibrary.data ?? []).map((item) => (
                <div key={item.key} className="flex items-center gap-2 rounded-lg border border-slate-700/70 px-3 py-2" data-testid={`library-item-${item.key}`}>
                  <UploadCloud className="h-4 w-4 flex-shrink-0 text-zinc-500" aria-hidden />
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-xs font-bold text-white">{item.key}</p>
                    <p className="text-[10px] text-zinc-500">{formatBytes(item.size_bytes)}{item.attached_episode ? " · attached" : ""}{item.uploaded_by ? ` · ${item.uploaded_by}` : ""}</p>
                  </div>
                  <Button
                    size="sm"
                    disabled={attachVideo.isPending || !!item.attached_episode}
                    onClick={() => attachTarget && attachVideo.mutate({ video_key: item.key, episode_id: attachTarget.id }, { onSuccess: () => setAttachTarget(null) })}
                    className="bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300"
                    data-testid={`library-attach-btn-${item.key}`}
                  >
                    Attach
                  </Button>
                </div>
              ))
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* move-to-another-playlist dialog */}
      <Dialog open={moveTarget !== null} onOpenChange={(open) => !open && setMoveTarget(null)}>
        <DialogContent className="max-w-md border-slate-800 bg-[#0D111A] text-zinc-100" data-testid="move-playlist-dialog">
          <DialogHeader>
            <DialogTitle>Move to another playlist</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            <p className="text-xs text-zinc-400">
              Move <b>{moveTarget?.name}</b> into a different series/movie. The uploaded video travels with it — <b>no re-upload, no re-download</b>.
            </p>
            <Select value={moveToId} onValueChange={setMoveToId}>
              <SelectTrigger data-testid="move-playlist-select">
                <SelectValue placeholder="Pick the target playlist" />
              </SelectTrigger>
              <SelectContent>
                {(allTitles.data ?? [])
                  .filter((t) => t.id !== selected?.id)
                  .map((t) => (
                    <SelectItem key={t.id} value={t.id}>
                      {t.name} {t.status === "draft" ? "(draft)" : ""}
                    </SelectItem>
                  ))}
              </SelectContent>
            </Select>
            <Button
              className="w-full bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
              disabled={!moveToId || moveTo.isPending}
              onClick={() => moveTarget && moveTo.mutate({ id: moveTarget.id, titleId: moveToId })}
              data-testid="move-playlist-confirm-btn"
            >
              {moveTo.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : null}
              Move episode
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
