import { useDecideApplication, useDecideSubmission, useSupplierApplications, useSupplierSubmissions, useVerifyApplication } from "@/hooks/useStudio";
import { formatDate } from "@/lib/badges";
import type { SupplierApplication } from "@/lib/types";
import { CheckCircle2, XCircle } from "lucide-react";
import { useState } from "react";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const STATUS_STYLES: Record<string, string> = {
  pending: "bg-amber-400/15 text-amber-300",
  approved: "bg-emerald-500/15 text-emerald-300",
  converted: "bg-emerald-500/15 text-emerald-300",
  rejected: "bg-rose-500/15 text-rose-300",
};

// Studio > Suppliers — the notes' "distribution" review desk: approve applications into
// worker accounts; approve link submissions into draft titles. House rules are enforced
// by the owner here (no illegal / toxic / copied content).
export default function StudioSuppliers() {
  const applications = useSupplierApplications();
  const submissions = useSupplierSubmissions();
  const decideApp = useDecideApplication();
  const decideSub = useDecideSubmission();

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="studio-suppliers-heading">
        Creators
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Approve creators into the Creator Desk, review their link submissions, purge stale titles.
      </p>

      <Tabs defaultValue="applications" className="mt-6">
        <TabsList className="bg-slate-900/80" data-testid="suppliers-tabs">
          <TabsTrigger value="applications" data-testid="suppliers-tab-applications">
            Applications ({applications.data?.length ?? 0})
          </TabsTrigger>
          <TabsTrigger value="submissions" data-testid="suppliers-tab-submissions">
            Submissions ({submissions.data?.length ?? 0})
          </TabsTrigger>
        </TabsList>

        {/* applications */}
        <TabsContent value="applications" className="mt-4 space-y-3" data-testid="supplier-applications-list">
          {(applications.data ?? []).length === 0 ? (
            <Card className="border-slate-800 bg-card/70">
              <CardContent className="px-5 py-10 text-center text-sm text-muted-foreground">
                No creator applications yet.
              </CardContent>
            </Card>
          ) : (
            (applications.data ?? []).map((app) => (
              <Card key={app.id} className="border-slate-800 bg-card/70" data-testid={`supplier-application-${app.id}`}>
                <CardContent className="flex flex-wrap items-start gap-3 px-5 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-white">
                      {app.channel_name} <span className="font-normal text-muted-foreground">· {app.email}</span>
                    </p>
                    <p className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                      <a href={app.channel_url} target="_blank" rel="noreferrer" className="font-bold text-sky-400 hover:text-sky-300">
                        {app.channel_url}
                      </a>
                      <span>· {app.content_type}</span>
                      <span>· {formatDate(app.created_at)}</span>
                    </p>
                    <p className="mt-1.5 text-xs leading-relaxed text-zinc-400">{app.note}</p>
                    {app.admin_note ? <p className="mt-1 text-xs text-zinc-500">Note: {app.admin_note}</p> : null}
                  </div>
                  <div className="flex items-center gap-2">
                    {app.status === "pending" ? (
                      <VerifyControls app={app} />
                    ) : (
                      <Badge className={STATUS_STYLES[app.status]}>{app.status}</Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>

        {/* submissions */}
        <TabsContent value="submissions" className="mt-4 space-y-3" data-testid="supplier-submissions-list">
          {(submissions.data ?? []).length === 0 ? (
            <Card className="border-slate-800 bg-card/70">
              <CardContent className="px-5 py-10 text-center text-sm text-muted-foreground">
                No content submissions yet — approved creators send them from the Creator Desk.
              </CardContent>
            </Card>
          ) : (
            (submissions.data ?? []).map((sub) => (
              <Card key={sub.id} className="border-slate-800 bg-card/70" data-testid={`supplier-submission-${sub.id}`}>
                <CardContent className="flex flex-wrap items-start gap-3 px-5 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-white">
                      {sub.title} <span className="font-normal capitalize text-muted-foreground">· {sub.kind}</span>
                    </p>
                    <p className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                      <span>{sub.email}</span>
                      {sub.language ? <span>· {sub.language}</span> : null}
                      <span>· {formatDate(sub.created_at)}</span>
                    </p>
                    {sub.description ? (
                      <p className="mt-1 line-clamp-2 text-xs leading-relaxed text-zinc-400">{sub.description}</p>
                    ) : null}
                    <a
                      href={sub.source_url}
                      target="_blank"
                      rel="noreferrer"
                      className="mt-1.5 inline-block text-xs font-bold text-sky-400 hover:text-sky-300"
                      data-testid={`supplier-submission-link-${sub.id}`}
                    >
                      Open supplied link ↗
                    </a>
                  </div>
                  <div className="flex items-center gap-2">
                    {sub.status === "pending" ? (
                      <>
                        <Button
                          size="sm"
                          disabled={decideSub.isPending}
                          onClick={() => decideSub.mutate({ id: sub.id, status: "approved" })}
                          className="bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300"
                          data-testid={`submission-approve-btn-${sub.id}`}
                        >
                          Approve → draft
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          disabled={decideSub.isPending}
                          onClick={() => decideSub.mutate({ id: sub.id, status: "rejected", admin_note: "Doesn't meet the house rules" })}
                          className="border-slate-700"
                          data-testid={`submission-reject-btn-${sub.id}`}
                        >
                          Reject
                        </Button>
                      </>
                    ) : (
                      <Badge className={STATUS_STYLES[sub.status]}>{sub.status}</Badge>
                    )}
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Channel verification controls (the notebook's Test 1 → 2 → 3 ladder): pass
// advances + emails the creator; fail rejects + emails the owner's reason.
function VerifyControls({ app }: { app: SupplierApplication }) {
  const verify = useVerifyApplication();
  const decideApp = useDecideApplication();
  const [note, setNote] = useState("");
  const current = app.current_test ?? 1;

  return (
    <div className="w-full space-y-2" data-testid={`verify-controls-${app.id}`}>
      <div className="flex flex-wrap items-center gap-2">
        {[1, 2, 3].map((n) => (
          <span key={n} className="flex items-center gap-1" data-testid={`verify-chip-${n}-${app.id}`}>
            {app.tests?.[String(n)] === "passed" ? (
              <CheckCircle2 className="h-4 w-4 text-emerald-400" aria-hidden />
            ) : app.tests?.[String(n)] === "failed" ? (
              <XCircle className="h-4 w-4 text-rose-400" aria-hidden />
            ) : (
              <span className={`text-xs font-bold ${n === current ? "text-amber-300" : "text-zinc-600"}`}>T{n}</span>
            )}
          </span>
        ))}
        <span className="text-xs text-zinc-400">Reviewing test {current} of 3</span>
      </div>
      <Input
        value={note}
        onChange={(event) => setNote(event.target.value)}
        placeholder="Note to the creator (emailed on fail)…"
        className="border-slate-700 bg-slate-900/70 text-sm"
        data-testid={`verify-note-input-${app.id}`}
      />
      <div className="flex flex-wrap items-center gap-2">
        <Button
          size="sm"
          disabled={verify.isPending}
          onClick={() => verify.mutate({ id: app.id, test: current, passed: true, note })}
          className="bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300"
          data-testid={`verify-pass-btn-${app.id}`}
        >
          Pass test {current}
        </Button>
        <Button
          size="sm"
          variant="outline"
          disabled={verify.isPending}
          onClick={() => verify.mutate({ id: app.id, test: current, passed: false, note })}
          className="border-rose-500/50 text-rose-300 hover:bg-rose-500/10"
          data-testid={`verify-fail-btn-${app.id}`}
        >
          Fail + email reason
        </Button>
        <Button
          size="sm"
          variant="ghost"
          disabled={decideApp.isPending}
          onClick={() => decideApp.mutate({ id: app.id, status: "rejected", admin_note: note || "Doesn't meet the house rules" })}
          className="text-xs text-zinc-500"
          data-testid={`supplier-reject-btn-${app.id}`}
        >
          Reject outright
        </Button>
      </div>
    </div>
  );
}
