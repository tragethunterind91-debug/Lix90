import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Clapperboard,
  Clock,
  Crown,
  Eye,
  Film,
  Inbox,
  MessageSquare,
  Send,
  TrendingUp,
  Users,
  Video,
  Wallet,
} from "lucide-react";
import { toast } from "sonner";
import { apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { OwnerOverview } from "@/lib/types";
import { useMe } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

// SUPER ADMIN (owner-only) — the notes' "super admin website": global views, profit,
// videos and visits, the team breakdown, and the 3-month stale-supplier purge.
export default function StudioOwner() {
  const { data: me, isLoading } = useMe();
  const queryClient = useQueryClient();
  const overview = useQuery({
    queryKey: ["studio", "owner"],
    queryFn: () => apiGet<OwnerOverview>("/admin/owner/overview"),
    enabled: !!me?.is_owner,
  });
  const purgeStale = useMutation({
    mutationFn: () => apiPost<{ removed: number; names: string[] }>("/admin/supplier/purge-stale"),
    onSuccess: (res) => {
      toast.success(`${res.removed} stale supplier title${res.removed === 1 ? "" : "s"} removed`);
      void queryClient.invalidateQueries({ queryKey: ["studio", "owner"] });
      void queryClient.invalidateQueries({ queryKey: ["titles"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });

  if (isLoading) {
    return <div className="h-40 animate-pulse rounded-xl bg-slate-800/70" data-testid="owner-skeleton" />;
  }
  if (!me?.is_owner) {
    return (
      <Card className="mx-auto max-w-md border-slate-800 bg-card/80">
        <CardContent className="flex flex-col items-center gap-3 px-8 py-12 text-center">
          <Crown className="h-8 w-8 text-[#FBBF24]" aria-hidden />
          <p className="font-heading text-base font-bold text-white" data-testid="owner-denied-title">
            Super Admin only
          </p>
          <p className="text-sm text-muted-foreground">
            This screen shows global platform numbers — the owner's seat only.
          </p>
        </CardContent>
      </Card>
    );
  }

  const cards = [
    { label: "Total views", value: overview.data?.total_views, icon: Eye, testid: "owner-stat-views" },
    {
      label: "Total profit",
      value: overview.data ? `₹${overview.data.total_profit.toLocaleString("en-IN")}` : "—",
      icon: Wallet,
      testid: "owner-stat-profit",
    },
    { label: "Total videos", value: overview.data?.titles, icon: Film, testid: "owner-stat-titles" },
    { label: "Episodes", value: overview.data?.episodes, icon: Video, testid: "owner-stat-episodes" },
    { label: "Site visits", value: overview.data?.total_visits, icon: TrendingUp, testid: "owner-stat-visits" },
    { label: "VIP active", value: overview.data?.vip_active, icon: Crown, testid: "owner-stat-vip" },
    { label: "Admins", value: overview.data?.admins, icon: Users, testid: "owner-stat-admins" },
    { label: "Workers", value: overview.data?.workers, icon: Clapperboard, testid: "owner-stat-workers" },
    { label: "Viewers", value: overview.data?.viewers, icon: Users, testid: "owner-stat-viewers" },
    { label: "Open feedback", value: overview.data?.feedback_open, icon: MessageSquare, testid: "owner-stat-feedback" },
    { label: "Pending applications", value: overview.data?.pending_applications, icon: Inbox, testid: "owner-stat-apps" },
    { label: "Pending submissions", value: overview.data?.pending_submissions, icon: Send, testid: "owner-stat-subs" },
  ];

  return (
    <div className="mx-auto max-w-5xl">
      <div className="flex items-center gap-2">
        <Crown className="h-6 w-6 text-[#FBBF24]" aria-hidden />
        <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="owner-heading">
          Super Admin
        </h1>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">
        The whole platform at a glance — every view, rupee, video and account.
      </p>

      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4" data-testid="owner-stats-grid">
        {cards.map(({ label, value, icon: Icon, testid }) => (
          <Card key={testid} className="border-slate-800 bg-card/70">
            <CardContent className="flex items-center gap-3 px-4 py-4">
              <span className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-[#FBBF24]/10">
                <Icon className="h-5 w-5 text-[#FBBF24]" aria-hidden />
              </span>
              <div>
                <p className="font-heading text-xl font-bold text-white" data-testid={testid}>
                  {value ?? "—"}
                </p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* 3-month rule purge */}
      <Card className="mt-6 border-rose-500/30 bg-rose-500/5" data-testid="owner-purge-card">
        <CardContent className="flex flex-wrap items-center gap-4 px-5 py-5">
          <Clock className="h-8 w-8 flex-shrink-0 text-rose-400" aria-hidden />
          <div className="min-w-0 flex-1">
            <p className="font-heading text-sm font-bold text-white">The 3-month rule</p>
            <p className="mt-0.5 text-xs text-zinc-400">
              {overview.data
                ? `${overview.data.stale_supplier_titles} supplier title${overview.data.stale_supplier_titles === 1 ? "" : "s"} with 0 views for 90+ days.`
                : "Supplier titles with 0 views for 90+ days."}{" "}
              Purging removes the title, its episodes and all references.
            </p>
          </div>
          <Button
            variant="destructive"
            disabled={purgeStale.isPending || !overview.data?.stale_supplier_titles}
            onClick={() => purgeStale.mutate()}
            data-testid="owner-purge-btn"
          >
            Purge stale titles
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
