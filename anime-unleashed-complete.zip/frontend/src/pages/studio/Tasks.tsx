import { useState, type FormEvent } from "react";
import { useAdminTasks, useCreateTask, useDeleteTask } from "@/hooks/useSocial";
import { formatBalance } from "@/hooks/useQuota";
import { ListChecks, Loader2, Trash2, ExternalLink } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";

// Studio > Tasks — admin creates reward tasks: title / distribution / duration
// (countdown or permanent) / reward (extra watch-duration for viewers).
export default function StudioTasks() {
  const tasks = useAdminTasks();
  const create = useCreateTask();
  const del = useDeleteTask();
  const [form, setForm] = useState({ title: "", description: "", reward_minutes: 30, expires: "", link_url: "", link_label: "" });

  function onSubmit(event: FormEvent) {
    event.preventDefault();
    create.mutate({
      title: form.title,
      description: form.description,
      reward_seconds: Math.round(Number(form.reward_minutes) * 60),
      expires_at: form.expires ? new Date(form.expires).toISOString() : null,
      link_url: form.link_url.trim() || null,
      link_label: form.link_label.trim(),
    });
    setForm({ title: "", description: "", reward_minutes: 30, expires: "", link_url: "", link_label: "" });
  }

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="studio-tasks-heading">
        Tasks
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Create reward tasks — viewers apply BY EMAIL; you approve and the reward lands on their account.
      </p>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        <Card className="h-fit border-slate-800 bg-card/70">
          <CardContent className="px-6 py-6">
            <form className="space-y-3" onSubmit={onSubmit} data-testid="studio-task-form">
              <div className="space-y-1.5">
                <Label htmlFor="tk-title">Title</Label>
                <Input id="tk-title" required minLength={3} value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="studio-task-title-input" />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="tk-desc">Distribution / instructions</Label>
                <Textarea id="tk-desc" rows={2} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="studio-task-desc-input" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="tk-reward">Reward (minutes)</Label>
                  <Input id="tk-reward" type="number" min={1} max={120} required value={form.reward_minutes} onChange={(e) => setForm({ ...form, reward_minutes: Number(e.target.value) })} className="border-slate-700 bg-slate-900/70" data-testid="studio-task-reward-input" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="tk-exp">Ends at (blank = permanent)</Label>
                  <Input id="tk-exp" type="datetime-local" value={form.expires} onChange={(e) => setForm({ ...form, expires: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="studio-task-expiry-input" />
                </div>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="tk-link">Link (optional — visit-to-earn task)</Label>
                <Input id="tk-link" type="url" value={form.link_url} onChange={(e) => setForm({ ...form, link_url: e.target.value })} placeholder="https://youtube.com/@yourchannel" className="border-slate-700 bg-slate-900/70" data-testid="studio-task-link-input" />
                <p className="text-xs text-zinc-500">
                  Users open this link, stay on it ~15s (a 10s countdown runs after 5s away — pauses if they return, never restarts), then claim the reward once.
                </p>
              </div>
              {form.link_url ? (
                <div className="space-y-1.5">
                  <Label htmlFor="tk-linklabel">Link button label</Label>
                  <Input id="tk-linklabel" value={form.link_label} onChange={(e) => setForm({ ...form, link_label: e.target.value })} placeholder="Open & subscribe" className="border-slate-700 bg-slate-900/70" data-testid="studio-task-link-label-input" />
                </div>
              ) : null}
              <Button type="submit" disabled={create.isPending} className="w-full bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" data-testid="studio-task-create-btn">
                {create.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <ListChecks className="mr-2 h-4 w-4" aria-hidden />}
                Publish task
              </Button>
            </form>
          </CardContent>
        </Card>

        <div className="space-y-3" data-testid="studio-tasks-list">
          {(tasks.data ?? []).length === 0 ? (
            <Card className="border-slate-800 bg-card/70">
              <CardContent className="px-5 py-10 text-center text-sm text-muted-foreground">No tasks created yet.</CardContent>
            </Card>
          ) : (
            (tasks.data ?? []).map((t) => (
              <Card key={t.id} className="border-slate-800 bg-card/70" data-testid={`studio-task-${t.id}`}>
                <CardContent className="flex items-center gap-3 px-5 py-4">
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-bold text-white">{t.title}</p>
                    <p className="mt-0.5 text-xs text-muted-foreground">
                      +{formatBalance(t.reward_seconds)} · {t.permanent ? "permanent" : `ends ${t.expires_at?.slice(0, 16).replace("T", " ")}`}
                    </p>
                    {t.link_url ? (
                      <Badge className="mt-1.5 bg-sky-500/15 text-sky-300" data-testid={`studio-task-link-${t.id}`}>
                        <ExternalLink className="mr-1 h-3 w-3" aria-hidden /> visit-link task
                      </Badge>
                    ) : null}
                  </div>
                  <Button size="sm" variant="ghost" className="text-rose-400" onClick={() => del.mutate(t.id)} data-testid={`studio-task-delete-${t.id}`}>
                    <Trash2 className="h-4 w-4" aria-hidden />
                  </Button>
                </CardContent>
              </Card>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
