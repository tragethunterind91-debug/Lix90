import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Eye, Film, Plus, TrendingUp, UploadCloud, Users, Video, Wallet, MessageSquare, Trash2, AlertTriangle } from "lucide-react";
import { Link } from "react-router-dom";
import { apiGet, apiPost, apiErrorMessage } from "@/lib/api";
import type { AdminStats } from "@/lib/types";
import { useMe } from "@/hooks/useAuth";
import { useVideoLibrary } from "@/hooks/useVideo";
import { Card, CardContent } from "@/components/ui/card";
import { Button, buttonVariants } from "@/components/ui/button";
import { toast } from "sonner";
import { useState } from "react";

// Studio dashboard: the owner's totals — views, uploads, users — at a glance.
export default function StudioDashboard() {
  const { data: me } = useMe();
  const isAdmin = me?.role === "admin";
  const qc = useQueryClient();
  const [purging, setPurging] = useState(false);

  // workers get a friendly upload desk — the admin stats API is admin-only
  const stats = useQuery({
    queryKey: ["admin", "stats"],
    queryFn: () => apiGet<AdminStats>("/admin/stats"),
    enabled: isAdmin,
  });
  const uploads = useVideoLibrary(isAdmin);

  const resetContentMutation = useMutation({
    mutationFn: () => apiPost("/admin/reset-content-data", {}),
    onSuccess: (data: any) => {
      toast.success(data?.message || "Content cleared successfully!");
      setPurging(false);
      void qc.invalidateQueries();
    },
    onError: (err) => {
      toast.error(apiErrorMessage(err));
      setPurging(false);
    },
  });

  const handleResetAll = () => {
    if (window.confirm("ARE YOU SURE? This will delete all demo playlists, titles, episodes, videos, NFTs, info stats, and trailers so you can start clean and upload manually.")) {
      setPurging(true);
      resetContentMutation.mutate();
    }
  };

  const fmtBytes = (n: number) =>
    n >= 1e9 ? `${(n / 1e9).toFixed(1)} GB` : n >= 1e6 ? `${(n / 1e6).toFixed(0)} MB` : `${Math.max(1, Math.round(n / 1e3))} KB`;

  const cards = [
    { label: "Titles", value: stats.data?.titles, icon: Film, testid: "admin-stat-titles" },
    { label: "Episodes", value: stats.data?.episodes, icon: Video, testid: "admin-stat-episodes" },
    { label: "Users", value: stats.data?.users, icon: Users, testid: "admin-stat-users" },
    { label: "Total views", value: stats.data?.total_views, icon: Eye, testid: "admin-stat-views" },
    {
      label: "Total profit",
      value: stats.data ? `₹${stats.data.total_profit.toLocaleString("en-IN")}` : "—",
      icon: Wallet,
      testid: "admin-stat-profit",
    },
    { label: "Site visits", value: stats.data?.total_visits, icon: TrendingUp, testid: "admin-stat-visits" },
    { label: "Open feedback", value: stats.data?.feedback_open, icon: MessageSquare, testid: "admin-stat-feedback" },
  ];

  return (
    <div className="mx-auto max-w-5xl">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="studio-heading">
        Dashboard
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Everything on Anime-Unleashed Entertainment — uploads go through the secure backend; cloud
        credentials never touch this browser.
      </p>

      {isAdmin ? (
        <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4" data-testid="admin-stats-row">
          {cards.map(({ label, value, icon: Icon, testid }) => (
          <Card key={testid} className="border-slate-800 bg-card/70">
            <CardContent className="flex items-center gap-3 px-4 py-4">
              <span className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-amber-400/10">
                <Icon className="h-5 w-5 text-amber-400" aria-hidden />
              </span>
              <div>
                <p className="font-heading text-xl font-bold text-white" data-testid={testid}>
                  {value ?? "—"}
                </p>
                <p className="text-xs text-muted-foreground">{label}</p>
              </div>
            </CardContent>
          </Card>
        ))}
        </div>
      ) : (
        <div className="mt-6 rounded-xl border border-sky-500/30 bg-sky-500/5 px-4 py-3 text-sm text-sky-300" data-testid="worker-dash-note">
          Worker mode — upload titles, episodes and videos as drafts. The owner reviews, adds
          details and launches them (Upcoming countdown or Home listing).
        </div>
      )}

      {isAdmin && (uploads.data?.length ?? 0) > 0 && (
        <div className="mt-6 rounded-2xl border border-slate-800 bg-card/70 p-5" data-testid="admin-uploads-card">
          <div className="flex flex-wrap items-center justify-between gap-3">
            <div>
              <p className="font-heading text-base font-bold text-white">Worker uploads</p>
              <p className="text-xs text-muted-foreground">
                Videos stored in the secure cloud library. Attach one to an episode and publish —
                nothing is ever uploaded twice. Viewer-visible only after you publish.
              </p>
            </div>
            <Link
              to="/studio/episodes"
              className={buttonVariants({ variant: "outline", size: "sm" })}
              data-testid="admin-uploads-review-link"
            >
              Review &amp; publish
            </Link>
          </div>
          <ul className="mt-4 divide-y divide-slate-800/70">
            {uploads.data!.slice(0, 4).map((u) => (
              <li key={u.key} className="flex items-center justify-between gap-3 py-2 text-sm" data-testid="admin-upload-row">
                <span className="min-w-0 truncate text-slate-300">
                  {u.key.slice(0, 18)}… · {fmtBytes(u.size_bytes)} · {u.uploaded_by || "worker"}
                </span>
                {u.attached_episode ? (
                  <span className="flex-shrink-0 rounded-full bg-emerald-500/15 px-2 py-0.5 text-xs text-emerald-400" data-testid="upload-chip-attached">
                    In an episode
                  </span>
                ) : (
                  <span className="flex-shrink-0 rounded-full bg-amber-400/15 px-2 py-0.5 text-xs text-amber-400" data-testid="upload-chip-waiting">
                    Waiting for review
                  </span>
                )}
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="mt-8 grid gap-3 sm:grid-cols-2">
        <Link
          to="/studio/catalog"
          data-testid="studio-quick-catalog"
          className="group rounded-2xl border border-slate-800 bg-card/70 p-5 transition-colors hover:border-amber-400/40"
        >
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-400/10">
            <Plus className="h-5 w-5 text-amber-400" aria-hidden />
          </span>
          <p className="mt-3 font-heading text-base font-bold text-white">Add a new anime</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Create the title, poster and metadata — it appears in the catalog the moment you publish.
          </p>
        </Link>
        <Link
          to="/studio/episodes"
          data-testid="studio-quick-episodes"
          className="group rounded-2xl border border-slate-800 bg-card/70 p-5 transition-colors hover:border-amber-400/40"
        >
          <span className="flex h-10 w-10 items-center justify-center rounded-lg bg-amber-400/10">
            <UploadCloud className="h-5 w-5 text-amber-400" aria-hidden />
          </span>
          <p className="mt-3 font-heading text-base font-bold text-white">Upload an episode</p>
          <p className="mt-1 text-sm text-muted-foreground">
            Attach a video file, set resolution and D/C tag, then publish it for streaming.
          </p>
        </Link>
      </div>

      {isAdmin && (
        <div className="mt-6 rounded-2xl border border-rose-500/30 bg-rose-950/20 p-5">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <div className="flex items-center gap-2 text-rose-400 font-bold text-sm">
                <AlertTriangle className="h-4 w-4" />
                Reset &amp; Clear Demo Content
              </div>
              <p className="mt-1 text-xs text-zinc-400 max-w-xl">
                One-click clean slate: purge all pre-loaded demo playlists, episodes, videos, NFTs, info statistics, and trailers so you can upload and organize everything manually from scratch.
              </p>
            </div>
            <Button
              variant="destructive"
              size="sm"
              onClick={handleResetAll}
              disabled={purging || resetContentMutation.isPending}
              data-testid="admin-reset-content-btn"
              className="flex-shrink-0 h-10 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold"
            >
              <Trash2 className="mr-2 h-4 w-4" />
              {purging ? "Purging Content…" : "Clear All Playlists & Videos"}
            </Button>
          </div>
        </div>
      )}

      <p className="mt-8 flex items-center gap-2 text-xs text-muted-foreground">
        <TrendingUp className="h-3.5 w-3.5 text-emerald-400" aria-hidden />
        Counters update live as viewers watch — log every rupee you earn under Revenue.
      </p>
    </div>
  );
}
