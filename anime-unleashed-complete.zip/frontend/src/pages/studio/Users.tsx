import { useState, type FormEvent } from "react";
import { Gift, Loader2, Search, ShieldBan, ShieldCheck, SlidersHorizontal, Trash2, UserPlus } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useCreateStudioUser, useDeleteStudioUser, useStudioUsers, useUpdateUserRole } from "@/hooks/useStudio";
import { useBanUser, useGrantUser, useToggleUserFeature, useUserDetail } from "@/hooks/useAdminControls";
import { formatBalance } from "@/hooks/useQuota";
import type { AdminUser } from "@/lib/types";

const FEATURE_KEYS = ["downloads", "global_chat", "refill_ads"] as const;
const FEATURE_LABELS: Record<string, string> = {
  downloads: "Downloads (video / audio / subtitles)",
  global_chat: "Global chat",
  refill_ads: "Rewarded ads",
};

function isVipActive(u: AdminUser): boolean {
  return !!u.vip_until && new Date(u.vip_until) > new Date();
}

// STUDIO > Accounts — full user management: complete account details (location,
// name, joined date, VIP, wallet), grant VD/VIP/CF by user id, per-user feature
// switches, ban/unban, history check, role change, delete.
export default function StudioUsers() {
  const users = useStudioUsers();
  const create = useCreateStudioUser();
  const roleChange = useUpdateUserRole();
  const del = useDeleteStudioUser();
  const ban = useBanUser();
  const grant = useGrantUser();
  const toggleFeature = useToggleUserFeature();
  const [search, setSearch] = useState("");
  const [mint, setMint] = useState({ email: "", password: "", display_name: "", role: "admin" });
  const [grantFor, setGrantFor] = useState<AdminUser | null>(null);
  const [grantForm, setGrantForm] = useState({ watch_minutes: 60, vip_days: 0, cf: 0, lc: 0 });
  const [featuresFor, setFeaturesFor] = useState<AdminUser | null>(null);
  const [detailFor, setDetailFor] = useState<string | null>(null);
  const detail = useUserDetail(detailFor);

  const rows = (users.data ?? []).filter(
    (u) =>
      !search ||
      `${u.email} ${u.display_name} ${u.account_id ?? ""}`.toLowerCase().includes(search.toLowerCase()),
  );

  function mintSubmit(event: FormEvent) {
    event.preventDefault();
    create.mutate(mint, {
      onSuccess: () => setMint({ email: "", password: "", display_name: "", role: "admin" }),
    });
  }

  function grantSubmit(event: FormEvent) {
    event.preventDefault();
    if (!grantFor) return;
    grant.mutate(
      {
        id: grantFor.id,
        watch_minutes: Number(grantForm.watch_minutes) || 0,
        vip_days: Number(grantForm.vip_days) || 0,
        cf: Number(grantForm.cf) || 0,
        lc: Number(grantForm.lc) || 0,
      },
      { onSuccess: () => setGrantFor(null) },
    );
  }

  return (
    <div className="mx-auto max-w-6xl">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="studio-users-heading">
        Accounts
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Every account with full details — grant value, control features, ban, inspect history.
      </p>

      {/* mint a staff account */}
      <Card className="mt-6 border-slate-800 bg-card/70">
        <CardContent className="px-6 py-5">
          <form className="grid items-end gap-3 sm:grid-cols-5" onSubmit={mintSubmit} data-testid="studio-user-mint-form">
            <div className="space-y-1.5">
              <Label htmlFor="mu-email">Email</Label>
              <Input id="mu-email" type="email" required value={mint.email} onChange={(e) => setMint({ ...mint, email: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="studio-user-mint-email" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="mu-pass">Password</Label>
              <Input id="mu-pass" type="text" required minLength={6} value={mint.password} onChange={(e) => setMint({ ...mint, password: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="studio-user-mint-password" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="mu-name">Name</Label>
              <Input id="mu-name" required minLength={2} value={mint.display_name} onChange={(e) => setMint({ ...mint, display_name: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="studio-user-mint-name" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="mu-role">Role</Label>
              <select
                id="mu-role"
                value={mint.role}
                onChange={(e) => setMint({ ...mint, role: e.target.value })}
                className="h-9 w-full rounded-md border border-slate-700 bg-slate-900/70 px-2 text-sm"
                data-testid="studio-user-mint-role"
              >
                {["admin", "worker", "creator", "user"].map((r) => (
                  <option key={r} value={r}>{r}</option>
                ))}
              </select>
            </div>
            <Button type="submit" className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" disabled={create.isPending} data-testid="studio-user-mint-submit">
              <UserPlus className="h-4 w-4" aria-hidden /> Mint account
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* search */}
      <div className="relative mt-6 max-w-sm">
        <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" aria-hidden />
        <Input placeholder="Search name / email / account no." value={search} onChange={(e) => setSearch(e.target.value)} className="border-slate-700 bg-slate-900/70 pl-9" data-testid="studio-users-search" />
      </div>

      {/* user rows */}
      <div className="mt-4 space-y-3" data-testid="studio-users-list">
        {rows.map((u) => (
          <Card key={u.id} className="border-slate-800 bg-card/70">
            <CardContent className="flex flex-wrap items-center gap-3 px-5 py-4">
              <div className="min-w-0 flex-1">
                <div className="flex flex-wrap items-center gap-2">
                  <p className="truncate font-bold text-white" data-testid={`user-name-${u.email}`}>{u.display_name}</p>
                  <Badge variant="outline" className="border-slate-600 text-[10px] uppercase">{u.role}</Badge>
                  {isVipActive(u) ? <Badge className="bg-[#F59E0B] text-[10px] font-bold text-slate-950">VIP</Badge> : null}
                  {u.banned ? <Badge variant="destructive" className="text-[10px]" data-testid={`user-banned-${u.email}`}>BANNED</Badge> : null}
                  {u.is_owner ? <Badge className="bg-amber-400/20 text-[10px] text-amber-300">OWNER</Badge> : null}
                </div>
                <p className="truncate text-xs text-zinc-400" data-testid={`user-meta-${u.email}`}>
                  {u.email} · #{u.account_id ?? "—"} · joined {new Date(u.created_at).toLocaleDateString()}
                  {u.country ? ` · ${u.country}` : ""}
                  {u.watch_balance_seconds != null ? ` · VD ${formatBalance(u.watch_balance_seconds)}` : ""}
                  {u.cf_balance != null ? ` · ${u.cf_balance} CF` : ""}
                </p>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Button size="sm" variant="outline" className="border-slate-700" onClick={() => { setGrantFor(u); setGrantForm({ watch_minutes: 60, vip_days: 0, cf: 0, lc: 0 }); }} data-testid={`user-grant-${u.email}`}>
                  <Gift className="h-4 w-4" aria-hidden /> Send
                </Button>
                <Button size="sm" variant="outline" className="border-slate-700" onClick={() => setFeaturesFor(u)} data-testid={`user-features-${u.email}`}>
                  <SlidersHorizontal className="h-4 w-4" aria-hidden /> Features
                </Button>
                <Button size="sm" variant="outline" className="border-slate-700" onClick={() => setDetailFor(u.id)} data-testid={`user-detail-${u.email}`}>
                  Details
                </Button>
                {u.role !== "admin" ? (
                  u.banned ? (
                    <Button size="sm" variant="outline" className="border-emerald-500/50 text-emerald-300" onClick={() => ban.mutate({ id: u.id, ban: false })} data-testid={`user-unban-${u.email}`}>
                      <ShieldCheck className="h-4 w-4" aria-hidden /> Unban
                    </Button>
                  ) : (
                    <Button size="sm" variant="outline" className="border-rose-500/50 text-rose-300" onClick={() => ban.mutate({ id: u.id, ban: true })} data-testid={`user-ban-${u.email}`}>
                      <ShieldBan className="h-4 w-4" aria-hidden /> Ban
                    </Button>
                  )
                ) : null}
                <Button size="icon" variant="ghost" onClick={() => del.mutate(u.id)} aria-label={`Delete ${u.email}`} data-testid={`user-delete-${u.email}`}>
                  <Trash2 className="h-4 w-4 text-rose-400" aria-hidden />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
        {rows.length === 0 ? <p className="text-sm text-zinc-500">No accounts match.</p> : null}
      </div>

      {/* grant dialog */}
      <Dialog open={!!grantFor} onOpenChange={(open) => !open && setGrantFor(null)}>
        <DialogContent className="border-slate-800 bg-[#0D111A] text-zinc-100" data-testid="user-grant-dialog">
          <DialogHeader>
            <DialogTitle>Send value to {grantFor?.display_name}</DialogTitle>
          </DialogHeader>
          <form className="space-y-3" onSubmit={grantSubmit}>
            <div className="space-y-1.5">
              <Label htmlFor="gr-vd">View duration (minutes, positive to send, negative to remove)</Label>
              <Input id="gr-vd" type="number" min={-10080} max={10080} value={grantForm.watch_minutes} onChange={(e) => setGrantForm({ ...grantForm, watch_minutes: Number(e.target.value) })} className="border-slate-700 bg-slate-900/70" data-testid="user-grant-vd-input" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="gr-vip">VIP days (positive to send, negative to remove)</Label>
              <Input id="gr-vip" type="number" min={-3650} max={3650} value={grantForm.vip_days} onChange={(e) => setGrantForm({ ...grantForm, vip_days: Number(e.target.value) })} className="border-slate-700 bg-slate-900/70" data-testid="user-grant-vip-input" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="gr-cf">CF (Conversation Fees) — positive to send, negative to remove</Label>
              <Input id="gr-cf" type="number" min={-100000} max={100000} value={grantForm.cf} onChange={(e) => setGrantForm({ ...grantForm, cf: Number(e.target.value) })} className="border-slate-700 bg-slate-900/70" data-testid="user-grant-cf-input" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="gr-lc">LC / ZC (Market &amp; NFT Coins) — positive to send, negative to remove</Label>
              <Input id="gr-lc" type="number" min={-100000} max={100000} value={grantForm.lc} onChange={(e) => setGrantForm({ ...grantForm, lc: Number(e.target.value) })} className="border-slate-700 bg-slate-900/70" data-testid="user-grant-lc-input" />
            </div>
            <Button type="submit" className="w-full bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" disabled={grant.isPending} data-testid="user-grant-submit">
              Apply Credits Change
            </Button>
          </form>
        </DialogContent>
      </Dialog>

      {/* features dialog */}
      <Dialog open={!!featuresFor} onOpenChange={(open) => !open && setFeaturesFor(null)}>
        <DialogContent className="border-slate-800 bg-[#0D111A] text-zinc-100" data-testid="user-feature-dialog">
          <DialogHeader>
            <DialogTitle>Features for {featuresFor?.display_name}</DialogTitle>
          </DialogHeader>
          <div className="space-y-3">
            {FEATURE_KEYS.map((key) => {
              const enabled = featuresFor?.features?.[key] ?? true;
              return (
                <div key={key} className="flex items-center justify-between rounded-lg border border-slate-800 bg-slate-900/60 px-4 py-3">
                  <span className="text-sm">{FEATURE_LABELS[key]}</span>
                  <Button
                    size="sm"
                    variant={enabled ? "default" : "destructive"}
                    disabled={toggleFeature.isPending}
                    onClick={() => toggleFeature.mutate({ id: featuresFor!.id, key, enabled: !enabled })}
                    data-testid={`feature-toggle-${key}`}
                  >
                    {enabled ? "ON" : "OFF"}
                  </Button>
                </div>
              );
            })}
          </div>
        </DialogContent>
      </Dialog>

      {/* detail dialog */}
      <Dialog open={!!detailFor} onOpenChange={(open) => !open && setDetailFor(null)}>
        <DialogContent className="max-h-[80svh] overflow-y-auto border-slate-800 bg-[#0D111A] text-zinc-100" data-testid="user-detail-dialog">
          <DialogHeader>
            <DialogTitle>Account details</DialogTitle>
          </DialogHeader>
          {detail.isLoading || !detail.data ? (
            <div className="flex justify-center py-8"><Loader2 className="h-6 w-6 animate-spin text-zinc-500" aria-hidden /></div>
          ) : (
            <div className="space-y-4 text-sm">
              <div className="grid grid-cols-2 gap-2" data-testid="user-detail-grid">
                {[
                  ["Name", detail.data.display_name],
                  ["Email", detail.data.email],
                  ["Account no.", `#${detail.data.account_id ?? "—"}`],
                  ["Role", detail.data.role],
                  ["Location", detail.data.country || "unknown"],
                  ["Joined", new Date(detail.data.created_at).toLocaleDateString()],
                  ["VIP until", detail.data.vip_until ? new Date(detail.data.vip_until).toLocaleDateString() : "—"],
                  ["Watch-time left", formatBalance(detail.data.watch_balance_seconds ?? 0)],
                  ["CF balance", `${detail.data.cf_balance ?? 0} CF`],
                  ["Status", detail.data.banned ? "BANNED" : "Active"],
                ].map(([k, v]) => (
                  <div key={k} className="rounded-lg border border-slate-800 bg-slate-900/60 px-3 py-2">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">{k}</p>
                    <p className="truncate font-medium text-white">{v}</p>
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-3 gap-2" data-testid="user-detail-stats">
                <div className="rounded-lg bg-sky-500/10 px-3 py-2 text-center">
                  <p className="text-[10px] uppercase text-zinc-400">Views</p>
                  <p className="font-bold text-sky-300">{detail.data.views}</p>
                </div>
                <div className="rounded-lg bg-emerald-500/10 px-3 py-2 text-center">
                  <p className="text-[10px] uppercase text-zinc-400">Watch min</p>
                  <p className="font-bold text-emerald-300">{detail.data.watch_minutes}</p>
                </div>
                <div className="rounded-lg bg-amber-500/10 px-3 py-2 text-center">
                  <p className="text-[10px] uppercase text-zinc-400">Downloads</p>
                  <p className="font-bold text-amber-300">{detail.data.downloads}</p>
                </div>
              </div>
              <div>
                <p className="mb-2 flex items-center gap-2 font-bold text-white">
                  Watch history (latest 30)
                </p>
                <div className="space-y-1" data-testid="user-detail-history">
                  {detail.data.history.length === 0 ? (
                    <p className="text-xs text-zinc-500">No watch history.</p>
                  ) : (
                    detail.data.history.map((h) => (
                      <div key={h.id} className="flex items-center justify-between rounded border border-slate-800 px-3 py-1.5 text-xs">
                        <span className="text-zinc-300">episode #{h.episode_number ?? h.episode_id.slice(0, 8)}</span>
                        <span className="text-zinc-500">{new Date(h.updated_at).toLocaleString()}</span>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
