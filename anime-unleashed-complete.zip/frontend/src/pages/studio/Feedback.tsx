import { Check, Loader2, MessageSquare, Trash2 } from "lucide-react";
import { useDeleteFeedback, useResolveFeedback, useStudioFeedback } from "@/hooks/useStudio";
import { formatDate } from "@/lib/badges";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

// Feedback inbox: what visitors send from the user site, with resolve/delete.
export default function StudioFeedback() {
  const feedback = useStudioFeedback();
  const resolve = useResolveFeedback();
  const remove = useDeleteFeedback();

  return (
    <div className="mx-auto max-w-3xl">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="studio-feedback-heading">
        Feedback
      </h1>
      <p className="mt-1 text-sm text-muted-foreground">
        Messages visitors send from the site. Mark them resolved once handled.
      </p>

      <div className="mt-6 space-y-3" data-testid="admin-feedback-list">
        {feedback.isLoading ? (
          <div className="h-24 animate-pulse rounded-2xl bg-slate-800/60" />
        ) : feedback.data && feedback.data.length > 0 ? (
          feedback.data.map((item) => (
            <Card key={item.id} className="border-slate-800 bg-card/70" data-testid={`admin-feedback-item-${item.id}`}>
              <CardContent className="px-5 py-4">
                <div className="flex items-start gap-3">
                  <span className="flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-lg bg-slate-800">
                    <MessageSquare className="h-4 w-4 text-amber-400" aria-hidden />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <p className="text-sm font-semibold text-white">{item.name}</p>
                      {item.resolved ? (
                        <Badge className="bg-emerald-500/15 text-emerald-400">resolved</Badge>
                      ) : (
                        <Badge className="bg-amber-400/15 text-amber-400">open</Badge>
                      )}
                    </div>
                    {item.email ? <p className="text-xs text-muted-foreground">{item.email}</p> : null}
                    <p className="mt-2 text-sm leading-relaxed text-zinc-300">{item.message}</p>
                    <p className="mt-2 text-[11px] uppercase tracking-widest text-muted-foreground">
                      {formatDate(item.created_at)}
                    </p>
                  </div>
                  <div className="flex flex-shrink-0 gap-1.5">
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      onClick={() => resolve.mutate({ id: item.id, resolved: !item.resolved })}
                      data-testid={`admin-feedback-resolve-${item.id}`}
                      aria-label={item.resolved ? "Mark as open" : "Mark as resolved"}
                    >
                      {resolve.isPending ? (
                        <Loader2 className="h-4 w-4 animate-spin" aria-hidden />
                      ) : (
                        <Check className={`h-4 w-4 ${item.resolved ? "text-emerald-400" : "text-zinc-400"}`} aria-hidden />
                      )}
                    </Button>
                    <Button variant="ghost" size="icon-sm" onClick={() => remove.mutate(item.id)} data-testid={`admin-feedback-delete-${item.id}`} aria-label="Delete feedback">
                      <Trash2 className="h-4 w-4 text-rose-400" aria-hidden />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        ) : (
          <p className="rounded-2xl border border-slate-800 bg-card/70 px-4 py-10 text-center text-sm text-muted-foreground" data-testid="admin-feedback-empty">
            No feedback yet — it appears here the moment a visitor sends one.
          </p>
        )}
      </div>
    </div>
  );
}
