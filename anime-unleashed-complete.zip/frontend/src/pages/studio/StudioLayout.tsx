import { NavLink, Outlet, Link } from "react-router-dom";
import { Activity, Crown, ExternalLink, Film, Inbox, LayoutDashboard, ListChecks, LogOut, MessageSquare, Settings2, UploadCloud, UserCog, Wallet, Bot, Clapperboard, BarChart3 } from "lucide-react";
import { Sparkles as SparklesIcon } from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import { useLogout, useMe } from "@/hooks/useAuth";
import { buttonVariants } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";

// STUDIO CONSOLE — a fully separate web app for admins: own shell, own navigation,
// no user-site chrome. Lives under /studio (on Firebase deploys it ships as its own site).
export default function StudioLayout() {
  const { data: me, isLoading } = useMe();
  const logout = useLogout();

  if (isLoading) {
    return (
      <div className="flex min-h-svh items-center justify-center bg-[#07090E]">
        <div className="w-full max-w-md space-y-4 px-6" data-testid="studio-skeleton">
          <div className="h-10 w-52 animate-pulse rounded-lg bg-slate-800/70" />
          <div className="h-24 w-full animate-pulse rounded-xl bg-slate-800/70" />
          <div className="h-64 w-full animate-pulse rounded-xl bg-slate-800/70" />
        </div>
      </div>
    );
  }

  // OWNER RULE: the studio never mixes with the worker desk — workers opening the
  // studio see the SAME neutral admin gate as anyone else (no desk links, no
  // worker branding). The worker desk lives only at /worker and on worker.* hosts.

  if (!me || me.role !== "admin") {
    return (
      <div className="flex min-h-svh items-center justify-center bg-[#07090E] px-4">
        <Card className="w-full max-w-md border-slate-800 bg-card/80">
          <CardContent className="flex flex-col items-center gap-4 px-8 py-14 text-center">
            <span className="font-heading text-lg font-black tracking-tight text-white">
              Anime-Unleashed <span className="text-amber-400">Studio Console</span>
            </span>
            <h1 className="text-sm text-muted-foreground" data-testid="studio-denied-title">
              {me ? "This account doesn't have studio privileges." : "Sign in with the owner account to manage content."}
            </h1>
            <Link
              to="/login"
              data-testid="studio-login-link"
              className={buttonVariants({ className: "bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" })}
            >
              Owner sign in
            </Link>
          </CardContent>
        </Card>
      </div>
    );
  }

  const navItems = [
    { to: "/studio", label: "Dashboard", icon: LayoutDashboard, end: true, testid: "studio-nav-dashboard", adminOnly: false, ownerOnly: false },
    { to: "/explore", label: "Explore & Webviews", icon: Clapperboard, end: false, testid: "studio-nav-explore", adminOnly: false, ownerOnly: false },
    { to: "/studio/catalog", label: "Catalog", icon: Film, end: false, testid: "studio-nav-catalog", adminOnly: false, ownerOnly: false },
    { to: "/studio/episodes", label: "Episodes & Uploads", icon: UploadCloud, end: false, testid: "studio-nav-episodes", adminOnly: false, ownerOnly: false },
    { to: "/studio/nfts", label: "NFT System", icon: SparklesIcon, end: false, testid: "studio-nav-nfts", adminOnly: true, ownerOnly: false },
    { to: "/studio/suppliers", label: "Creators", icon: Inbox, end: false, testid: "studio-nav-suppliers", adminOnly: true, ownerOnly: false },
    { to: "/studio/tasks", label: "Tasks", icon: ListChecks, end: false, testid: "studio-nav-tasks", adminOnly: true, ownerOnly: false },
    { to: "/studio/platform", label: "Platform", icon: Settings2, end: false, testid: "studio-nav-platform", adminOnly: true, ownerOnly: false },
    { to: "/studio/users", label: "Accounts", icon: UserCog, end: false, testid: "studio-nav-users", adminOnly: true, ownerOnly: false },
    { to: "/studio/revenue", label: "Revenue", icon: Wallet, end: false, testid: "studio-nav-revenue", adminOnly: true, ownerOnly: false },
    { to: "/studio/monitoring", label: "Video Analytics", icon: BarChart3, end: false, testid: "studio-nav-monitoring", adminOnly: true, ownerOnly: false },
    { to: "/studio/feedback", label: "Feedback", icon: MessageSquare, end: false, testid: "studio-nav-feedback", adminOnly: true, ownerOnly: false },
    { to: "/studio/audit", label: "Audit log", icon: Activity, end: false, testid: "studio-nav-audit", adminOnly: true, ownerOnly: false },
    { to: "/studio/ai-audit", label: "AI auditor", icon: Bot, end: false, testid: "studio-nav-ai-audit", adminOnly: true, ownerOnly: false },
    { to: "/studio/owner", label: "Super Admin", icon: Crown, end: false, testid: "studio-nav-owner", adminOnly: true, ownerOnly: true },
  ]
    .filter((item) => me.role === "admin" || !item.adminOnly)
    .filter((item) => !item.ownerOnly || me.is_owner);

  return (
    <div className="flex min-h-svh bg-[#07090E] text-zinc-100" data-testid="studio-layout">
      {/* sidebar (desktop) */}
      <aside className="fixed inset-y-0 left-0 z-40 hidden w-64 flex-col border-r border-slate-800/80 bg-[#0D101A] p-5 md:flex">
        <div className="flex items-center gap-2.5">
          <img
            src="/logo-app-icon.png"
            alt="Anime-Unleashed"
            className="h-9 w-9 rounded-xl object-contain shadow-[0_0_20px_rgba(168,85,247,0.35)]"
          />
          <div>
            <p className="font-heading text-sm font-bold leading-tight text-white">Anime-Unleashed</p>
            <p className="text-[10px] font-bold uppercase tracking-[0.2em] text-amber-400">Studio Console</p>
          </div>
        </div>

        <nav className="mt-8 space-y-1">
          {navItems.map(({ to, label, icon: Icon, end, testid }) => (
            <NavLink
              key={to}
              to={to}
              end={end}
              className={({ isActive }) =>
                `flex items-center gap-2.5 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                  isActive
                    ? "bg-amber-400/10 text-amber-400"
                    : "text-zinc-400 hover:bg-white/5 hover:text-white"
                }`
              }
              data-testid={testid}
            >
              <Icon className="h-4.5 w-4.5" aria-hidden /> {label}
            </NavLink>
          ))}
        </nav>

        <div className="mt-auto space-y-3 border-t border-slate-800/80 pt-4">
          <Link
            to="/"
            className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-zinc-400 transition-colors hover:bg-white/5 hover:text-white"
            data-testid="studio-view-site-link"
          >
            <ExternalLink className="h-4 w-4" aria-hidden /> View live site
          </Link>
          <div className="flex items-center gap-2 rounded-lg bg-slate-900/70 px-3 py-2">
            <span className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-rose-500 text-xs font-bold text-slate-950">
              {me.display_name.slice(0, 1).toUpperCase()}
            </span>
            <div className="min-w-0 flex-1">
              <p className="truncate text-xs font-semibold text-white">{me.display_name}</p>
              <p className="truncate text-[10px] text-muted-foreground">{me.email}</p>
            </div>
            <button
              onClick={() => logout.mutate()}
              aria-label="Sign out"
              data-testid="studio-signout-btn"
              className="rounded-md p-1.5 text-zinc-400 transition-colors hover:bg-white/5 hover:text-rose-400"
            >
              <LogOut className="h-4 w-4" aria-hidden />
            </button>
          </div>
        </div>
      </aside>

      {/* content column */}
      <div className="flex min-h-svh flex-1 flex-col md:ml-64">
        {/* mobile top bar */}
        <div className="border-b border-slate-800/80 bg-[#0D101A] px-4 py-3 md:hidden">
          <div className="flex items-center justify-between">
            <p className="font-heading text-sm font-bold text-white">
              Anime-Unleashed <span className="text-amber-400">Studio</span>
            </p>
            <div className="flex items-center gap-2">
              <Link to="/" data-testid="studio-mobile-site-link" className="text-xs text-zinc-400">
                View site
              </Link>
              <button onClick={() => logout.mutate()} data-testid="studio-mobile-signout-btn" className="text-xs text-rose-400">
                Sign out
              </button>
            </div>
          </div>
          <nav className="mt-3 flex gap-2 overflow-x-auto [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {navItems.map(({ to, label, end, testid }) => (
              <NavLink
                key={to}
                to={to}
                end={end}
                className={({ isActive }) =>
                  `flex-shrink-0 rounded-full border px-3.5 py-1.5 text-xs font-semibold ${
                    isActive
                      ? "border-amber-400/60 bg-amber-400/10 text-amber-400"
                      : "border-slate-700 text-zinc-300"
                  }`
                }
                data-testid={testid.replace("studio-nav-", "studio-mobile-nav-")}
              >
                {label}
              </NavLink>
            ))}
          </nav>
        </div>

        <main className="flex-1 px-4 py-6 sm:px-6 md:px-8" data-testid="studio-main">
          <Outlet />
        </main>
      </div>

      <Toaster position="bottom-right" richColors />
    </div>
  );
}
