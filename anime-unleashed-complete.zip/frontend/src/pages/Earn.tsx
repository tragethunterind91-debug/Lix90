import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { Clock, Coins, Crown, History, Info, Loader2, MonitorPlay, PartyPopper, Timer } from "lucide-react";
import { buttonVariants, Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader,DialogTitle } from "@/components/ui/dialog";
import { useMe } from "@/hooks/useAuth";
import { formatBalance, useQuota, useRewardHistory } from "@/hooks/useQuota";
import { apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { QuotaInfo } from "@/lib/types";

const AD_SECONDS = 10; // mock ad length until AdSense/GAM rewarded slots go live
const GRANTED_PER_AD = 1800; // +30 min per rewarded ad
const STORE_CAP_SECONDS = 12600; // 3h 30m — the max an account can store

// EARN CENTER — the full "see ads → get view duration" system: mock rewarded ad
// player, live cooldown, today/lifetime stats, reward history and the rules.
export default function Earn() {
  const { data: me, isLoading } = useMe();
  const quota = useQuota(!!me);
  const rewards = useRewardHistory(!!me);
  const queryClient = useQueryClient();
  const [adOpen, setAdOpen] = useState(false);
  const [playing, setPlaying] = useState(false);
  const [count, setCount] = useState(AD_SECONDS);
  const [claimed, setClaimed] = useState<QuotaInfo | null>(null);
  const [cooldown, setCooldown] = useState(quota.data?.ad_cooldown_seconds ?? 0);

  useEffect(() => {
    setCooldown(quota.data?.ad_cooldown_seconds ?? 0);
  }, [quota.data?.ad_cooldown_seconds]);

  useEffect(() => {
    if (cooldown <= 0) return;
    const t = setTimeout(() => setCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [cooldown]);

  const watch = useMutation<QuotaInfo, Error, void>({
    mutationFn: () => apiPost<QuotaInfo>("/quota/rewarded-ad"),
    onSuccess: async (res) => {
      toast.success(`+${formatBalance(GRANTED_PER_AD)} unlocked — ${formatBalance(res.balance_seconds)} in your wallet`);
      setClaimed(res);
      setCooldown(res.ad_cooldown_seconds);
      await queryClient.invalidateQueries({ queryKey: ["quota"] });
      await queryClient.invalidateQueries({ queryKey: ["quota", "rewards"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });

  async function runAd() {
    setClaimed(null);
    setCount(AD_SECONDS);
    setPlaying(true);
    for (let left = AD_SECONDS; left > 0; left--) {
      setCount(left);
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    setPlaying(false);
  }

  if (isLoading) {
    return <div className="mx-auto max-w-3xl px-4 py-10"><div className="h-40 animate-pulse rounded-xl bg-slate-800/60" /></div>;
  }

  if (!me) {
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center" data-testid="earn-guest-gate">
        <Timer className="mx-auto h-10 w-10 text-emerald-400" aria-hidden />
        <h1 className="mt-4 font-heading text-3xl font-bold text-white">Earn watch-time free</h1>
        <p className="mt-2 text-sm text-zinc-400">Sign in, watch a short ad, get 30 minutes of view duration each time.</p>
        <Link
          to="/login"
          data-testid="earn-login-link"
          className={`${buttonVariants({ className: "mt-6 bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300" })} mt-6 inline-flex`}
        >
          Sign in to earn
        </Link>
      </div>
    );
  }

  const limited = quota.data?.mode === "limited";
  const balance = quota.data?.balance_seconds ?? 0;
  const capPct = Math.min(100, Math.round((balance / STORE_CAP_SECONDS) * 100));

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6" data-testid="earn-page">
      <div className="text-center">
        <h1 className="font-heading text-3xl font-bold tracking-tight text-white sm:text-4xl" data-testid="earn-heading">
          Earn <span className="text-emerald-400">view duration</span>
        </h1>
        <p className="mt-2 text-sm text-zinc-400">Watch a short ad, get 30 minutes. Free forever, on every account.</p>
      </div>

      {!limited ? (
        <Card className="mt-8 border-emerald-500/40 bg-emerald-500/5" data-testid="earn-vip-card">
          <CardContent className="flex items-center gap-4 p-6">
            <Crown className="h-10 w-10 text-[#FBBF24]" aria-hidden />
            <div>
              <p className="font-heading text-lg font-bold text-white">You watch unlimited</p>
              <p className="text-sm text-zinc-400">VIP and staff accounts never run out of view duration — no ads needed.</p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* wallet + cap */}
          <Card className="mt-8 border-slate-800 bg-card/70" data-testid="earn-wallet-card">
            <CardContent className="px-6 py-6">
              <div className="flex items-end justify-between">
                <div>
                  <p className="text-[11px] font-bold uppercase tracking-wider text-zinc-500">Your wallet</p>
                  <p className="font-heading text-4xl font-black text-emerald-300" data-testid="earn-balance">
                    {formatBalance(balance)}
                  </p>
                </div>
                <p className="text-xs text-zinc-500" data-testid="earn-cap">store max 3h 30m</p>
              </div>
              <div className="mt-3 h-2.5 overflow-hidden rounded-full bg-slate-800">
                <span className="block h-full rounded-full bg-gradient-to-r from-emerald-400 to-teal-400" style={{ width: `${capPct}%` }} data-testid="earn-cap-bar" />
              </div>
              <Button
                size="lg"
                className="mt-5 w-full bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300"
                disabled={playing || cooldown > 0 || watch.isPending}
                onClick={() => { setAdOpen(true); void runAd(); }}
                data-testid="earn-watch-button"
              >
                {watch.isPending ? <Loader2 className="mr-2 h-5 w-5 animate-spin" aria-hidden /> : <MonitorPlay className="mr-2 h-5 w-5" aria-hidden />}
                {cooldown > 0 ? `Next ad in ${cooldown}s` : `Watch ad — get +${formatBalance(GRANTED_PER_AD)}`}
              </Button>
            </CardContent>
          </Card>

          {/* stats */}
          <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4" data-testid="earn-stats">
            {[
              { label: "Ads today", value: String(rewards.data?.ads_today ?? 0), testid: "earn-ads-today" },
              { label: "Min today", value: String(rewards.data?.minutes_today ?? 0), testid: "earn-min-today" },
              { label: "Total ads", value: String(rewards.data?.total_ads ?? 0), testid: "earn-ads-total" },
              { label: "Total min", value: String(rewards.data?.minutes_total ?? 0), testid: "earn-min-total" },
            ].map((s) => (
              <Card key={s.label} className="border-slate-800 bg-card/70">
                <CardContent className="px-4 py-3 text-center">
                  <p className="text-[10px] font-bold uppercase tracking-wider text-zinc-500">{s.label}</p>
                  <p className="font-heading text-lg font-bold text-white" data-testid={s.testid}>{s.value}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          {/* Advertisement / Reward Conversion (1 Ad = 1 VD = 30 min, 3 VD = 1 CF, 1 VD = 1 LC) */}
          <Card className="mt-4 border-amber-500/30 bg-amber-950/15" data-testid="earn-conversion-card">
            <CardContent className="p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <Coins className="h-5 w-5 text-amber-400" />
                  <h3 className="font-heading text-sm font-bold text-white">
                    Convert Ad Rewards to Marketplace Coins
                  </h3>
                </div>
                <span className="rounded-full bg-amber-400/20 px-2.5 py-0.5 text-[10px] font-mono font-bold text-amber-300">
                  {rewards.data?.total_ads ?? 0} VD Available
                </span>
              </div>

              <div className="rounded-xl border border-slate-800 bg-slate-900/70 p-3 text-xs space-y-1">
                <div className="flex flex-wrap items-center justify-between text-zinc-300">
                  <span><strong>1 Ad</strong> = <strong>1 VD</strong> (30 min View Duration)</span>
                  <span><strong>3 VD</strong> = <strong>1 CF</strong> (Conversation Fees)</span>
                  <span><strong>1 VD</strong> = <strong>1 LC</strong> (Leashed Coins)</span>
                </div>
                <p className="text-[11px] font-bold text-rose-400 pt-1">
                  ⚠️ Rule: LC (Leashed Coins) cannot be converted to CF or VD.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3 space-y-2">
                  <div className="flex justify-between items-center font-bold text-purple-300">
                    <span>Convert to CF (3 VD = 1 CF)</span>
                    <span className="text-[10px] bg-purple-500/20 px-2 py-0.5 rounded">Conversation Fees</span>
                  </div>
                  <p className="text-[11px] text-zinc-400">Exchange 3 VD (View Duration tokens) for 1 CF.</p>
                  <Button
                    size="sm"
                    onClick={async () => {
                      try {
                        const totalVd = rewards.data?.total_ads ?? 0;
                        if (totalVd < 3) {
                          toast.error("You need at least 3 VD (watched ads) to convert to CF");
                          return;
                        }
                        const res = await apiPost<any>("/nft/convert-rewards", {
                          ad_tokens_to_convert: totalVd,
                          target_currency: "CF",
                        });
                        toast.success(res.formula_used || "Converted to CF!");
                        await queryClient.invalidateQueries({ queryKey: ["me"] });
                      } catch (err) {
                        toast.error(apiErrorMessage(err));
                      }
                    }}
                    className="w-full bg-purple-600 text-xs font-bold text-white hover:bg-purple-500"
                    data-testid="convert-vd-to-cf-btn"
                  >
                    Convert All to CF (3 VD = 1 CF)
                  </Button>
                </div>

                <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-3 space-y-2">
                  <div className="flex justify-between items-center font-bold text-amber-300">
                    <span>Convert to LC (1 VD = 1 LC)</span>
                    <span className="text-[10px] bg-amber-400/20 px-2 py-0.5 rounded">Leashed Coins</span>
                  </div>
                  <p className="text-[11px] text-zinc-400">Exchange 1 VD (View Duration token) for 1 LC.</p>
                  <Button
                    size="sm"
                    onClick={async () => {
                      try {
                        const totalVd = rewards.data?.total_ads ?? 0;
                        if (totalVd < 1) {
                          toast.error("You need at least 1 VD (watched ad) to convert to LC");
                          return;
                        }
                        const res = await apiPost<any>("/nft/convert-rewards", {
                          ad_tokens_to_convert: totalVd,
                          target_currency: "LC",
                        });
                        toast.success(res.formula_used || "Converted to LC!");
                        await queryClient.invalidateQueries({ queryKey: ["me"] });
                      } catch (err) {
                        toast.error(apiErrorMessage(err));
                      }
                    }}
                    className="w-full bg-amber-400 text-xs font-bold text-slate-950 hover:bg-amber-300"
                    data-testid="convert-vd-to-lc-btn"
                  >
                    Convert All to LC (1 VD = 1 LC)
                  </Button>
                </div>
              </div>

              {/* Explicit prohibited warning for LC reverse conversion */}
              <div className="rounded-xl border border-rose-500/20 bg-rose-950/20 p-2.5 text-[11px] text-rose-300 flex items-center justify-between">
                <span>LC cannot be converted to CF or VD</span>
                <span className="font-bold uppercase tracking-wider text-[10px] bg-rose-500/20 px-2 py-0.5 rounded text-rose-200">
                  Non-Convertible
                </span>
              </div>
            </CardContent>
          </Card>


          {/* history */}
          <Card className="mt-4 border-slate-800 bg-card/70">
            <CardContent className="px-5 py-5">
              <p className="mb-3 flex items-center gap-2 text-sm font-bold text-white">
                <History className="h-4 w-4 text-emerald-400" aria-hidden /> Reward history
              </p>
              <div className="space-y-1.5" data-testid="earn-history">
                {(rewards.data?.items ?? []).length === 0 ? (
                  <p className="text-sm text-zinc-500">No ads watched yet — your rewards will appear here.</p>
                ) : (
                  rewards.data!.items.map((it, i) => (
                    <div key={`${it.created_at}-${i}`} className="flex items-center justify-between rounded border border-slate-800 px-3 py-2 text-xs">
                      <span className="flex items-center gap-2 text-zinc-300">
                        <PartyPopper className="h-3.5 w-3.5 text-emerald-400" aria-hidden /> +{it.minutes} min view duration
                      </span>
                      <span className="text-zinc-500">{new Date(it.created_at).toLocaleString()}</span>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </>
      )}

      {/* rules */}
      <Card className="mt-4 border-slate-800 bg-card/70">
        <CardContent className="px-5 py-5">
          <p className="mb-2 flex items-center gap-2 text-sm font-bold text-white">
            <Info className="h-4 w-4 text-amber-400" aria-hidden /> How it works
          </p>
          <ul className="space-y-1.5 text-xs text-zinc-400" data-testid="earn-rules">
            <li>· Every rewarded ad adds <b className="text-emerald-300">+30 minutes</b> of view duration.</li>
            <li>· One ad every <b className="text-zinc-200">45 seconds</b> (cooldown between ads).</li>
            <li>· Your account stores at most <b className="text-zinc-200">3h 30m</b> — convert VD to CF to make room.</li>
            <li>· Downloading an episode charges its full length upfront.</li>
            <li>· VIP accounts skip the economy entirely — unlimited watching, zero ads.</li>
          </ul>
        </CardContent>
      </Card>

      {/* mock rewarded-ad player */}
      <Dialog open={adOpen} onOpenChange={(next) => !playing && setAdOpen(next)}>
        <DialogContent className="max-w-md border-slate-800 bg-[#0F1420]" data-testid="earn-ad-dialog">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 font-heading text-white">
              <MonitorPlay className="h-5 w-5 text-emerald-400" aria-hidden /> Rewarded ad
            </DialogTitle>
          </DialogHeader>
          {claimed ? (
            <div className="py-4 text-center" data-testid="earn-claimed-panel">
              <PartyPopper className="mx-auto h-10 w-10 text-emerald-400" aria-hidden />
              <p className="mt-3 font-heading text-xl font-bold text-white">+{formatBalance(GRANTED_PER_AD)} added!</p>
              <p className="mt-1 text-sm text-zinc-400">Wallet now: <b className="text-emerald-300" data-testid="earn-claimed-balance">{formatBalance(claimed.balance_seconds)}</b></p>
              <Button className="mt-5 w-full bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300" onClick={() => setAdOpen(false)} data-testid="earn-claimed-close">
                Keep watching
              </Button>
            </div>
          ) : (
            <div className="py-2">
              <div className="flex aspect-video w-full flex-col items-center justify-center rounded-xl bg-gradient-to-br from-[#1c2a3a] via-[#132030] to-[#0d1520] text-center" data-testid="earn-ad-frame">
                {playing ? (
                  <>
                    <Clock className="h-8 w-8 animate-pulse text-sky-300" aria-hidden />
                    <p className="mt-2 font-heading text-5xl font-black text-white" data-testid="earn-ad-countdown">{count}</p>
                    <p className="mt-1 text-xs uppercase tracking-[0.3em] text-zinc-500">Your reward unlocks next…</p>
                  </>
                ) : (
                  <>
                    <MonitorPlay className="h-8 w-8 text-zinc-500" aria-hidden />
                    <p className="mt-2 text-sm text-zinc-400">Watch {AD_SECONDS}s → earn +{formatBalance(GRANTED_PER_AD)}</p>
                  </>
                )}
              </div>
              {!playing ? (
                <Button
                  className="mt-4 w-full bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300"
                  disabled={watch.isPending}
                  onClick={() => watch.mutate()}
                  data-testid="earn-claim-button"
                >
                  {watch.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <Coins />}
                  Claim +{formatBalance(GRANTED_PER_AD)}
                </Button>
              ) : (
                <p className="mt-3 text-center text-xs text-zinc-500">Ad playing — keep this open until the countdown ends.</p>
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
