import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Globe2, Send, Timer } from "lucide-react";
import { ApiError } from "@/lib/api";
import { useGlobalChat, useSendGlobal, useAccount } from "@/hooks/useSocial";
import { useMe } from "@/hooks/useAuth";
import { useQuota, formatBalance } from "@/hooks/useQuota";
import RefillModal from "@/components/RefillModal";
import ConvertModal from "@/components/ConvertModal";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { timeAgo } from "@/lib/badges";
import type { Region } from "@/lib/types";

const REGIONS: { value: Region; label: string }[] = [
  { value: "asia", label: "🌏 Asia" },
  { value: "americas", label: "🌎 Americas" },
  { value: "europe", label: "🌍 Europe" },
];
const CHAT_COST = 180; // ICF: one message = 3 minutes of watch-time

// Global chat — region rooms. No links, anti-spam, and messages spend CF (1 CF = 3 min
// watch-time via the convert system); VIP gets 300 free/day and can chat cross-region.
// Rooms are ephemeral: messages auto-delete after 5 minutes.
export default function GlobalChat() {
  const { data: me } = useMe();
  const account = useAccount();
  const quota = useQuota(true);
  const [region, setRegion] = useState<Region>("asia");
  const [text, setText] = useState("");
  const [refillOpen, setRefillOpen] = useState(false);
  const [convertOpen, setConvertOpen] = useState(false);
  const chat = useGlobalChat(region, !!me);
  const send = useSendGlobal(region);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [chat.data?.length]);

  const acc = account.data;
  const isVip = !!acc?.vip_active || (acc?.role ?? "user") !== "user";
  const limited = !!me && !isVip;
  const noCf = limited && (acc?.cf_balance ?? 0) < 1;

  function onSend(e: React.FormEvent) {
    e.preventDefault();
    if (!text.trim()) return;
    send.mutate(text.trim(), {
      onError: (error) => {
        const code = error instanceof ApiError ? (error.body as { detail?: { code?: string } } | null)?.detail?.code : undefined;
        if (code === "insufficient_cf") setConvertOpen(true);
      },
    });
    setText("");
  }

  return (
    <div className="mx-auto max-w-3xl px-0 py-10 sm:px-6" data-testid="global-chat-page">
      <div className="flex items-center gap-2">
        <Globe2 className="h-6 w-6 text-sky-400" aria-hidden />
        <h1 className="font-heading text-3xl font-bold tracking-tight text-white" data-testid="global-chat-heading">
          Global chat
        </h1>
      </div>
      <p className="mt-1 text-sm text-muted-foreground">
        {limited
          ? `Each message costs 1 CF (${formatBalance(CHAT_COST)} of watch-time — convert on the CF chip).`
          : isVip && acc?.vip_active
            ? "VIP — 300 free messages a day, every continent open."
            : "Staff chat free."}{" "}
        No links. Be nice. <span className="text-sky-300">Messages vanish after 5 minutes.</span>
      </p>

      {/* region tabs */}
      <div className="mt-4 flex gap-2" data-testid="region-tabs">
        {REGIONS.map((r) => (
          <button
            key={r.value}
            onClick={() => setRegion(r.value)}
            className={`rounded-full border px-4 py-1.5 text-sm font-semibold transition-colors ${
              region === r.value ? "border-sky-400/60 bg-sky-400/10 text-sky-300" : "border-slate-700 text-zinc-400 hover:text-white"
            }`}
            data-testid={`region-tab-${r.value}`}
          >
            {r.label}
            {acc && acc.country === r.value ? <span className="ml-1 text-[10px] text-zinc-500">(yours)</span> : null}
          </button>
        ))}
      </div>

      {/* messages — the room only keeps the last 5 minutes */}
      <div className="mt-3 flex items-center gap-2 text-[11px] text-sky-300/80" data-testid="global-chat-ephemeral-note">
        <Timer className="h-3.5 w-3.5" aria-hidden /> Live room — messages auto-delete after 5 minutes.
      </div>

      <Card className="mt-2 border-slate-800 bg-card/70">
        <CardContent className="px-0 py-0">
          <div className="h-[440px] space-y-2 overflow-y-auto px-4 py-4" data-testid="global-messages">
            {(chat.data ?? [])
              .filter((m) => Date.now() - new Date(m.created_at).getTime() < 300_000)
              .length === 0 ? (
              <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
                The room is quiet — say hi first.
              </div>
            ) : (
              (chat.data ?? [])
                .filter((m) => Date.now() - new Date(m.created_at).getTime() < 300_000)
                .map((m) => (
                <div key={m.id} className="flex gap-2.5" data-testid={`global-msg-${m.id}`}>
                  <span className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-sky-400 to-blue-500 text-xs font-bold text-slate-950">
                    {m.from_name.slice(0, 1).toUpperCase()}
                  </span>
                  <div>
                    <p className="text-xs font-bold text-sky-300">
                      {m.from_name} <span className="ml-1 font-normal text-zinc-500">{timeAgo(m.created_at)}</span>
                    </p>
                    <p className="text-sm text-zinc-100">{m.text}</p>
                  </div>
                </div>
              ))
            )}
            <div ref={bottomRef} />
          </div>

          <div className="border-t border-slate-800 px-4 py-3">
            {!me ? (
              <p className="text-center text-sm text-muted-foreground">
                <Link to="/login" className="font-bold text-sky-400">Sign in</Link> to join the chat.
              </p>
            ) : (
              <form className="flex gap-2" onSubmit={onSend} data-testid="global-chat-form">
                <Input
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  maxLength={300}
                  placeholder={noCf ? "No CF left — tap the CF chip to convert watch-time" : "Say something… (no links)"}
                  className="border-slate-700 bg-slate-900/70"
                  data-testid="global-chat-input"
                />
                <Button
                  type="submit"
                  disabled={send.isPending || noCf}
                  className="bg-sky-400 font-bold text-slate-950 hover:bg-sky-300"
                  data-testid="global-chat-send-btn"
                >
                  <Send className="mr-1.5 h-4 w-4" aria-hidden />
                  {limited ? "−1 CF" : "Send"}
                </Button>
              </form>
            )}
            {noCf ? (
              <div className="mt-2 flex items-center justify-between rounded-lg border border-rose-500/30 bg-rose-500/5 px-3 py-2 text-xs text-rose-300" data-testid="global-chat-no-cf">
                Out of CF — convert watch-time into CF to keep chatting.
                <button onClick={() => setConvertOpen(true)} className="font-bold text-emerald-400" data-testid="global-chat-open-convert">
                  Open converter →
                </button>
              </div>
            ) : null}
          </div>
        </CardContent>
      </Card>

      <RefillModal open={refillOpen} onOpenChange={setRefillOpen} requiredSeconds={CHAT_COST} />
      <ConvertModal open={convertOpen} onOpenChange={setConvertOpen} />
    </div>
  );
}
