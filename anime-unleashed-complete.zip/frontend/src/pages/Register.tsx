import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Eye, EyeOff, Loader2, Lock, Mail, Sparkles, Tv, User } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useGoogleLogin, useRegister } from "@/hooks/useAuth";
import { apiErrorMessage } from "@/lib/errors";

export default function Register() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [displayName, setDisplayName] = useState("");
  const [error, setError] = useState("");

  const registerMutation = useRegister();
  const googleLoginMutation = useGoogleLogin();

  const busy = registerMutation.isPending || googleLoginMutation.isPending;

  function onSubmit(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    registerMutation.mutate(
      { email, password, display_name: displayName },
      {
        onSuccess: () => {
          toast.success("Welcome to Anime-Unleashed!");
          navigate("/");
        },
        onError: (err) => {
          setError(apiErrorMessage(err));
        },
      },
    );
  }

  function onGoogleSignUp() {
    setError("");
    googleLoginMutation.mutate(
      {},
      {
        onSuccess: () => {
          toast.success("Welcome to Anime-Unleashed!");
          navigate("/");
        },
        onError: (err) => {
          setError(apiErrorMessage(err));
        },
      },
    );
  }

  return (
    <div className="flex min-h-[calc(100svh-4rem)] items-center justify-center px-4 py-4 md:py-6">
      <Card className="w-full max-w-md border-slate-800 bg-card/90 shadow-2xl backdrop-blur-md">
        <CardHeader className="text-center pt-5 pb-3">
          <div className="mx-auto mb-2 flex items-center justify-center">
            <img
              src="/logo-app-icon.png"
              alt="Anime-Unleashed"
              className="h-12 w-12 sm:h-14 sm:w-14 rounded-2xl object-contain shadow-xl shadow-purple-500/20"
            />
          </div>
          <CardTitle className="font-heading text-xl sm:text-2xl font-black tracking-tight text-white" data-testid="register-heading">
            Create an Account
          </CardTitle>
          <CardDescription className="text-xs sm:text-sm text-zinc-400">
            Welcome to Anime-Unleashed! Fans from across the universe are welcomed.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4 pt-0">
          {/* Google Signup Button */}
          <Button
            type="button"
            variant="outline"
            disabled={busy}
            onClick={onGoogleSignUp}
            className="w-full h-11 border-slate-700 bg-slate-900/80 font-semibold text-white hover:bg-slate-800 hover:border-slate-600 transition-all"
            data-testid="google-signup-btn"
          >
            <svg className="mr-2 h-4 w-4" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z" />
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z" />
            </svg>
            Continue with Google
          </Button>

          <div className="relative my-4 text-center text-xs text-muted-foreground after:absolute after:inset-0 after:top-1/2 after:z-0 after:flex after:items-center after:border-t after:border-slate-800">
            <span className="relative z-10 bg-slate-900 px-3 text-zinc-500 uppercase tracking-widest text-[10px] font-bold">Or with email</span>
          </div>

          <form onSubmit={onSubmit} className="space-y-4" data-testid="register-form">
            <div className="space-y-1.5">
              <Label htmlFor="register-email" className="text-xs font-semibold text-zinc-300">Email Address</Label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                <Input
                  id="register-email"
                  type="email"
                  required
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  placeholder="name@example.com"
                  className="pl-9 border-slate-700 bg-slate-900/80 text-white placeholder:text-zinc-600 focus:border-amber-400"
                  data-testid="register-email-input"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="register-display-name" className="text-xs font-semibold text-zinc-300">Display Name</Label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                <Input
                  id="register-display-name"
                  required
                  minLength={2}
                  maxLength={40}
                  value={displayName}
                  onChange={(event) => setDisplayName(event.target.value)}
                  placeholder="Your anime username"
                  className="pl-9 border-slate-700 bg-slate-900/80 text-white placeholder:text-zinc-600 focus:border-amber-400"
                  data-testid="register-name-input"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="register-password" className="text-xs font-semibold text-zinc-300">Password</Label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
                <Input
                  id="register-password"
                  type={showPassword ? "text" : "password"}
                  required
                  minLength={8}
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  placeholder="At least 8 characters (letters & numbers)"
                  className="pl-9 pr-10 border-slate-700 bg-slate-900/80 text-white placeholder:text-zinc-600 focus:border-amber-400"
                  data-testid="register-password-input"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  data-testid="register-password-toggle"
                  aria-label={showPassword ? "Hide password" : "Show password"}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300"
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
            </div>

            {error ? (
              <div className="rounded-xl border border-rose-500/40 bg-rose-500/10 px-3.5 py-2.5 text-xs text-rose-300 font-medium leading-relaxed" data-testid="register-error" role="alert">
                {error}
              </div>
            ) : null}

            <Button
              type="submit"
              disabled={busy}
              data-testid="register-submit-btn"
              className="w-full h-11 bg-amber-400 font-black text-slate-950 hover:bg-amber-300 active:scale-95 transition-all shadow-lg shadow-amber-400/10"
            >
              {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <Sparkles className="mr-2 h-4 w-4" aria-hidden />}
              Create Account
            </Button>
          </form>

          <p className="text-center text-xs text-zinc-400">
            Already have an account?{" "}
            <Link to="/login" className="font-bold text-amber-400 hover:underline" data-testid="register-login-link">
              Sign in
            </Link>
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
