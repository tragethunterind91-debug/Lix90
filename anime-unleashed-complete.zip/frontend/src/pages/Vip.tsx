import { useEffect, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { BadgeCheck, Crown, Loader2, ShieldCheck, Timer, Zap } from "lucide-react";
import { toast } from "sonner";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useMe } from "@/hooks/useAuth";
import { useCryptoInvoice, useCryptoStatus } from "@/hooks/usePayments";
import { usePlatform } from "@/hooks/usePlatform";
import { useVipOrder, useVipStatus, useVipVerify } from "@/hooks/useVip";

const BENEFITS = [
  { icon: Zap, title: "Zero ads", text: "Every ad slot across the site disappears for the full 2 months." },
  { icon: Timer, title: "Unlimited watch time", text: "Free accounts run on a watch-time balance — VIP never does." },
  { icon: BadgeCheck, title: "VIP audio & subtitles", text: "Hindi dub tracks + EN/हिं subtitles on every VIP episode." },
];

// ₹66/year VIP pass with a FAKE Razorpay checkout (per owner: "api keep fake").
// The order/verify calls hit our backend, which mirrors Razorpay's contract —
// swapping the real SDK in later touches only backend/routers/payments.py.
export default function Vip() {
  const { data: me } = useMe();
  const navigate = useNavigate();
  const status = useVipStatus(!!me);
  const order = useVipOrder();
  const verify = useVipVerify();
  const platform = usePlatform();
  const plan = platform.data?.vip_plan;
  const monthsLabel = (days: number) => (days >= 30 ? `${Math.round(days / 30)} months` : `${days} days`);
  const priceLabel = plan ? `₹${plan.price_inr} / ${monthsLabel(plan.duration_days)}` : "₹66 / 2 months";
  const [sheetOpen, setSheetOpen] = useState(false);
  const [paying, setPaying] = useState(false);

  async function startPurchase() {
    if (!me) return;
    try {
      await order.mutateAsync();
      setSheetOpen(true);
    } catch {
      /* toast already shown by the mutation */
    }
  }

  async function pay() {
    const current = order.data;
    if (!current) return;
    setPaying(true);
    await new Promise((r) => setTimeout(r, 1200)); // fake gateway roundtrip
    await verify.mutateAsync(current.order_id);
    setPaying(false);
    setSheetOpen(false);
  }

  if (!me) {
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center" data-testid="vip-guest-gate">
        <Crown className="mx-auto h-10 w-10 text-[#FBBF24]" aria-hidden />
        <h1 className="mt-4 font-heading text-3xl font-bold text-white">Go VIP — {priceLabel}</h1>
        <p className="mt-2 text-sm text-zinc-400">Sign in first, then grab the ad-free pass.</p>
        <Button
          className="mt-6 bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
          onClick={() => navigate("/login")}
          data-testid="vip-login-link"
        >
          Sign in to continue
        </Button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6" data-testid="vip-page">
      <div className="text-center">
        <Badge className="border border-[#FBBF24]/40 bg-[#F59E0B]/10 text-[#FDE047]" data-testid="vip-tier-badge">
          <Crown className="mr-1 h-3 w-3" aria-hidden /> VIP PASS
        </Badge>
        <h1 className="mt-3 font-heading text-3xl font-bold tracking-tight text-white sm:text-4xl">
          Anime-Unleashed <span className="text-[#FBBF24]">VIP</span>
        </h1>
        <p className="mt-2 text-sm text-zinc-400">{priceLabel} — less than a movie ticket. Cancel by simply not renewing.</p>
      </div>

      {status.data?.active ? (
        <Card className="mt-8 border-emerald-500/40 bg-emerald-500/5" data-testid="vip-active-card">
          <CardContent className="flex items-center gap-4 p-6">
            <ShieldCheck className="h-10 w-10 text-emerald-400" aria-hidden />
            <div>
              <p className="font-heading text-lg font-bold text-white">You're a VIP</p>
              <p className="text-sm text-zinc-400">
                Active until {status.data.until ? new Date(status.data.until).toLocaleDateString("en-IN", { day: "numeric", month: "long", year: "numeric" }) : "—"}
              </p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="mt-8 grid gap-3 sm:grid-cols-3" data-testid="vip-benefits">
            {(plan?.features?.length
              ? plan.features.map((f) => ({ icon: Crown, title: f, text: "" }))
              : BENEFITS
            ).map((b) => (
              <Card key={b.title} className="border-slate-800 bg-card/70">
                <CardContent className="p-5">
                  <b.icon className="h-6 w-6 text-[#FBBF24]" aria-hidden />
                  <p className="mt-3 font-heading text-sm font-bold text-white">{b.title}</p>
                  <p className="mt-1 text-xs text-zinc-400">{b.text}</p>
                </CardContent>
              </Card>
            ))}
          </div>
          <div className="mt-8 text-center">
            <Button
              size="lg"
              onClick={() => void startPurchase()}
              disabled={order.isPending}
              className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
              data-testid="vip-buy-button"
            >
              {order.isPending ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <Crown className="mr-2 h-4 w-4" aria-hidden />}
              Pay {plan ? `₹${plan.price_inr}` : "₹66"} — become VIP
            </Button>
            <p className="mt-3 text-xs text-zinc-500" data-testid="vip-test-mode-note">
              Test mode — payments are simulated, no real money moves.
            </p>
          </div>
          <CryptoCheckout />
        </>
      )}

      {/* fake Razorpay checkout sheet */}
      <Dialog open={sheetOpen} onOpenChange={(open) => !paying && setSheetOpen(open)}>
        <DialogContent className="max-w-sm border-slate-700 bg-[#0F1420]" data-testid="vip-checkout-modal">
          <DialogHeader>
            <DialogTitle className="flex items-center justify-between font-heading text-white">
              <span>razorpay<span className="text-sky-400">.</span></span>
              <span className="rounded bg-amber-400/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-[#FBBF24]">Test mode</span>
            </DialogTitle>
          </DialogHeader>
          <div className="rounded-xl bg-slate-900/80 p-4" data-testid="vip-order-summary">
            <p className="text-xs uppercase tracking-widest text-zinc-500">
              VIP Pass · {plan ? monthsLabel(plan.duration_days) : "2 months"}
            </p>
            <p className="mt-1 font-heading text-3xl font-black text-white">
              {plan ? `₹${plan.price_inr}.00` : "₹66.00"}
            </p>
            <p className="mt-1 break-all text-[11px] text-zinc-500">Order {order.data?.order_id}</p>
          </div>
          <Button
            onClick={() => void pay()}
            disabled={paying || verify.isPending}
            className="w-full bg-sky-500 font-bold text-white hover:bg-sky-400"
            data-testid="vip-pay-button"
          >
            {paying ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : null}
            {paying ? "Processing payment…" : `Pay ₹${plan?.price_inr ?? 66}`}
          </Button>
          <p className="text-center text-[11px] text-zinc-500">Simulated UPI / card — nothing is charged.</p>
        </DialogContent>
      </Dialog>
    </div>
  );
}

// Real crypto checkout (Cryptomus): server-side prices, signed webhook activates
// VIP — the browser is redirected to the hosted payment page and polls on return.
function CryptoCheckout() {
  const queryClient = useQueryClient();
  const invoice = useCryptoInvoice();
  const [isReturn] = useState(() => window.location.search.includes("payment=return"));
  const lastOrder = isReturn ? localStorage.getItem("ah-vip-order") : null;
  const status = useCryptoStatus(lastOrder, isReturn);
  const confirmed = status.data?.status === "paid" || status.data?.status === "paid_over";

  useEffect(() => {
    if (confirmed) {
      localStorage.removeItem("ah-vip-order");
      toast.success("Payment confirmed — VIP is active!");
      void queryClient.invalidateQueries({ queryKey: ["vip"] });
      void queryClient.invalidateQueries({ queryKey: ["me"] });
    }
  }, [confirmed, queryClient]);

  async function buy(planId: string) {
    try {
      const inv = await invoice.mutateAsync({ planId });
      localStorage.setItem("ah-vip-order", inv.order_id);
      window.location.assign(inv.payment_url);
    } catch {
      /* toast already shown by the mutation */
    }
  }

  return (
    <Card className="mt-6 border-slate-800 bg-card/70" data-testid="vip-crypto-card">
      <CardContent className="p-6">
        <p className="font-heading text-base font-bold text-white">Pay with crypto — USDT, BTC and more</p>
        <p className="mt-1 text-xs text-zinc-500">
          Secure checkout by Cryptomus. VIP activates automatically once the payment confirms on-chain.
        </p>
        {isReturn && lastOrder && !confirmed ? (
          <p className="mt-3 rounded-lg border border-sky-500/40 bg-sky-500/10 px-3 py-2 text-sm text-sky-300" data-testid="vip-crypto-pending">
            Payment received? Confirming on-chain — this page updates automatically.
          </p>
        ) : null}
        {confirmed ? (
          <p className="mt-3 rounded-lg border border-emerald-500/40 bg-emerald-500/10 px-3 py-2 text-sm text-emerald-300" data-testid="vip-crypto-confirmed">
            Payment confirmed — welcome to VIP!
          </p>
        ) : null}
        <div className="mt-4 grid gap-3 sm:grid-cols-2">
          <button
            type="button"
            onClick={() => void buy("vip_monthly")}
            disabled={invoice.isPending}
            className="rounded-xl border border-slate-700 bg-slate-900/70 p-4 text-left transition-colors hover:border-amber-400/50"
            data-testid="vip-crypto-monthly-btn"
          >
            <p className="font-heading text-lg font-bold text-white">
              ₹66 <span className="text-xs font-normal text-zinc-500">/ month</span>
            </p>
            <p className="text-xs text-zinc-500">30 days of VIP — paid in USDT, BTC and more</p>
          </button>
          <button
            type="button"
            onClick={() => void buy("vip_yearly")}
            disabled={invoice.isPending}
            className="rounded-xl border border-slate-700 bg-slate-900/70 p-4 text-left transition-colors hover:border-amber-400/50"
            data-testid="vip-crypto-yearly-btn"
          >
            <p className="font-heading text-lg font-bold text-white">
              ₹660 <span className="text-xs font-normal text-zinc-500">/ year</span>
            </p>
            <p className="text-xs text-zinc-500">365 days — 2 months free</p>
          </button>
        </div>
        {invoice.isPending ? (
          <p className="mt-2 flex items-center gap-2 text-xs text-zinc-500">
            <Loader2 className="h-3 w-3 animate-spin" aria-hidden /> Opening secure checkout…
          </p>
        ) : null}
      </CardContent>
    </Card>
  );
}
