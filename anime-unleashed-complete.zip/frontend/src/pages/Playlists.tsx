import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Globe, ListVideo, Loader2, Lock, LogIn, Plus, Trash2 } from "lucide-react";
import { useMe } from "@/hooks/useAuth";
import { useCreatePlaylist, useDeletePlaylist, usePlaylists } from "@/hooks/useSocial";
import EmptyState from "@/components/EmptyState";
import { CardGridSkeleton } from "@/components/Skeletons";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

// User playlists: named collections of titles. Private by default, shareable when public.
export default function Playlists() {
  const { data: me, isLoading } = useMe();
  const playlists = usePlaylists(Boolean(me));
  const create = useCreatePlaylist();
  const remove = useDeletePlaylist();
  const navigate = useNavigate();
  const [name, setName] = useState("");

  if (isLoading) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6 lg:px-8">
        <CardGridSkeleton count={3} />
      </div>
    );
  }

  if (!me) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <EmptyState
          icon={LogIn}
          title="Sign in to use playlists"
          message="Group anime into your own lists — binge orders, recommendations for friends — and share them with a link."
          actionLabel="Sign in"
          onAction={() => navigate("/login")}
          testId="playlists-signin-prompt"
        />
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-3xl px-4 py-6 sm:px-6 lg:px-8">
      <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="playlists-heading">
        Playlists
      </h1>

      <form
        className="mt-4 flex gap-2"
        onSubmit={(event) => {
          event.preventDefault();
          if (!name.trim()) return;
          create.mutate(name.trim(), { onSuccess: () => setName("") });
        }}
        data-testid="playlist-create-form"
      >
        <Input
          value={name}
          onChange={(event) => setName(event.target.value)}
          placeholder="New playlist name — e.g. Weekend binge"
          className="border-slate-700 bg-slate-900/70"
          maxLength={80}
          data-testid="playlist-create-input"
          aria-label="New playlist name"
        />
        <Button
          type="submit"
          disabled={!name.trim() || create.isPending}
          data-testid="playlist-create-btn"
          className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
        >
          {create.isPending ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" aria-hidden /> : <Plus className="mr-1.5 h-4 w-4" aria-hidden />}
          Create
        </Button>
      </form>

      <div className="mt-6">
        {playlists.isLoading ? (
          <CardGridSkeleton count={3} />
        ) : playlists.data && playlists.data.length > 0 ? (
          <ul className="space-y-2" data-testid="playlists-list">
            {playlists.data.map((playlist) => (
              <li
                key={playlist.id}
                className="flex items-center gap-3 rounded-xl border border-slate-800 bg-card/70 px-4 py-3"
                data-testid={`playlist-item-${playlist.id}`}
              >
                <span className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg bg-slate-800">
                  <ListVideo className="h-5 w-5 text-amber-400" aria-hidden />
                </span>
                <div className="min-w-0 flex-1">
                  <Link to={`/playlist/${playlist.id}`} className="truncate text-sm font-semibold text-white hover:text-amber-400">
                    {playlist.name}
                  </Link>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    {playlist.titles.length} title{playlist.titles.length === 1 ? "" : "s"} ·{" "}
                    {playlist.is_public ? "shared" : "private"}
                  </p>
                </div>
                {playlist.is_public ? (
                  <Badge className="bg-emerald-500/15 text-emerald-400">
                    <Globe className="mr-1 h-3 w-3" aria-hidden /> Public
                  </Badge>
                ) : (
                  <Badge variant="outline" className="border-slate-700 text-zinc-400">
                    <Lock className="mr-1 h-3 w-3" aria-hidden /> Private
                  </Badge>
                )}
                <Button
                  variant="ghost"
                  size="icon-sm"
                  onClick={() => remove.mutate(playlist.id)}
                  data-testid={`playlist-delete-btn-${playlist.id}`}
                  aria-label={`Delete ${playlist.name}`}
                >
                  <Trash2 className="h-4 w-4 text-rose-400" aria-hidden />
                </Button>
              </li>
            ))}
          </ul>
        ) : (
          <EmptyState
            icon={ListVideo}
            title="No videos, Coming Soon"
            message="No video titles found. Coming soon to this playlist!"
            testId="playlists-empty"
          />
        )}
      </div>
    </div>
  );
}
