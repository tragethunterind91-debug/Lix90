import { useEffect, useRef, useState, type FormEvent } from "react";
import { useFriends, useFriendRequest, useFriendRespond, useUnfriend, useDm, useSendDm } from "@/hooks/useSocial";
import { useMe } from "@/hooks/useAuth";
import { formatDate, timeAgo } from "@/lib/badges";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

const STICKERS = ["😂", "❤️", "🔥", "👍", "😮", "😢", "🎉", "👀"];
const EMPTY = (msg: string) => (
  <div className="rounded-xl border border-slate-800 bg-card/60 px-5 py-8 text-center text-sm text-muted-foreground">{msg}</div>
);

// Personal chat — friends + DMs. Free users: 15 friends, VIP: 30. Text + links + stickers
// only (no video/image attachments), requests can't be re-sent after decline/block.
export default function Friends() {
  const { data: me } = useMe();
  const friends = useFriends();
  const request = useFriendRequest();
  const respond = useFriendRespond();
  const unfriend = useUnfriend();
  const [addId, setAddId] = useState("");
  const [peer, setPeer] = useState<{ id: string; name: string } | null>(null);
  const dm = useDm(peer?.id ?? null);
  const sendDm = useSendDm(peer?.id ?? null);
  const [text, setText] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [dm.data?.length]);

  const list = friends.data;
  const count = list?.friends.length ?? 0;
  const limit = me?.vip_until && new Date(me.vip_until) > new Date() ? 30 : 15;

  function onSend(e: FormEvent) {
    e.preventDefault();
    if (!text.trim()) return;
    sendDm.mutate(text.trim());
    setText("");
  }

  return (
    <div className="mx-auto max-w-5xl px-0 py-10 sm:px-6" data-testid="friends-page">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <div>
          <h1 className="font-heading text-3xl font-bold tracking-tight text-white" data-testid="friends-heading">
            Friends
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            Personal chat — text, links & stickers. No videos or images in chat.
          </p>
        </div>
        <Badge className="border border-emerald-500/40 bg-emerald-500/10 text-emerald-300" data-testid="friends-counter">
          {count} / {limit} friends
        </Badge>
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-2">
        {/* left: friends + requests */}
        <div className="space-y-4">
          {/* add by ID */}
          <Card className="border-slate-800 bg-card/70">
            <CardContent className="px-5 py-4">
              <p className="font-heading text-sm font-bold text-white">Add a friend</p>
              <form
                className="mt-2 flex gap-2"
                onSubmit={(e) => {
                  e.preventDefault();
                  request.mutate(addId.trim());
                  setAddId("");
                }}
                data-testid="friend-add-form"
              >
                <Input
                  value={addId}
                  onChange={(e) => setAddId(e.target.value.replace(/[^0-9]/g, ""))}
                  placeholder="Friend's ID no. (e.g. 482913)"
                  maxLength={10}
                  className="border-slate-700 bg-slate-900/70"
                  data-testid="friend-add-input"
                />
                <Button type="submit" disabled={request.isPending || addId.length < 6} className="bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300" data-testid="friend-add-btn">
                  Add
                </Button>
              </form>
              <p className="mt-2 text-[11px] text-zinc-500">Your own ID lives on the Account page.</p>
            </CardContent>
          </Card>

          <Tabs defaultValue="friends">
            <TabsList className="bg-slate-900/80" data-testid="friends-tabs">
              <TabsTrigger value="friends" data-testid="friends-tab-friends">Friends ({count})</TabsTrigger>
              <TabsTrigger value="incoming" data-testid="friends-tab-incoming">Requests ({list?.incoming.length ?? 0})</TabsTrigger>
            </TabsList>

            <TabsContent value="friends" className="mt-3 space-y-2" data-testid="friends-list">
              {!list || list.friends.length === 0
                ? EMPTY("No friends yet — add someone with their ID no.")
                : list.friends.map((f) => (
                    <div key={f.request_id} className="flex items-center gap-3 rounded-xl border border-slate-800 bg-card/70 px-4 py-3" data-testid={`friend-row-${f.account_id}`}>
                      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 text-sm">{f.avatar_url || "🐱"}</span>
                      <button onClick={() => setPeer({ id: f.user_id, name: f.display_name })} className="min-w-0 flex-1 text-left" data-testid={`friend-open-chat-${f.account_id}`}>
                        <p className="truncate text-sm font-bold text-white">{f.display_name}</p>
                        <p className="text-xs text-muted-foreground">ID {f.account_id} · since {formatDate(f.created_at)}</p>
                      </button>
                      <Button size="sm" variant="outline" className="border-slate-700" onClick={() => setPeer({ id: f.user_id, name: f.display_name })} data-testid={`friend-chat-btn-${f.account_id}`}>
                        Chat
                      </Button>
                      <Button size="sm" variant="ghost" className="text-rose-400" onClick={() => unfriend.mutate(f.request_id)} data-testid={`friend-remove-btn-${f.account_id}`}>
                        Remove
                      </Button>
                    </div>
                  ))}
            </TabsContent>

            <TabsContent value="incoming" className="mt-3 space-y-2" data-testid="friend-requests-list">
              {!list || list.incoming.length === 0
                ? EMPTY("No pending requests.")
                : list.incoming.map((f) => (
                    <div key={f.request_id} className="flex items-center gap-3 rounded-xl border border-amber-500/30 bg-amber-500/5 px-4 py-3" data-testid={`friend-request-${f.account_id}`}>
                      <span className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-amber-400 to-orange-500 text-sm">{f.avatar_url || "🐱"}</span>
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-bold text-white">{f.display_name}</p>
                        <p className="text-xs text-muted-foreground">ID {f.account_id} · {timeAgo(f.created_at)}</p>
                      </div>
                      <Button size="sm" className="bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300" onClick={() => respond.mutate({ request_id: f.request_id, action: "accept" })} data-testid={`friend-accept-btn-${f.account_id}`}>
                        Accept
                      </Button>
                      <Button size="sm" variant="outline" className="border-slate-700" onClick={() => respond.mutate({ request_id: f.request_id, action: "decline" })} data-testid={`friend-decline-btn-${f.account_id}`}>
                        Decline
                      </Button>
                      <Button size="sm" variant="ghost" className="text-rose-400" onClick={() => respond.mutate({ request_id: f.request_id, action: "block" })} data-testid={`friend-block-btn-${f.account_id}`}>
                        Block
                      </Button>
                    </div>
                  ))}
            </TabsContent>
          </Tabs>
        </div>

        {/* right: DM thread */}
        <Card className="border-slate-800 bg-card/70" data-testid="dm-panel">
          <CardContent className="flex h-[480px] flex-col px-0 py-0">
            {!peer ? (
              <div className="flex flex-1 items-center justify-center text-sm text-muted-foreground">Pick a friend to start chatting</div>
            ) : (
              <>
                <div className="flex items-center gap-2 border-b border-slate-800 px-4 py-3">
                  <span className="flex h-8 w-8 items-center justify-center rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 text-xs">{me?.role}</span>
                  <p className="font-heading text-sm font-bold text-white" data-testid="dm-peer-name">{peer.name}</p>
                  <span className="ml-auto text-[10px] text-zinc-500">live · polls every 4s</span>
                </div>
                <div className="flex-1 space-y-2 overflow-y-auto px-4 py-3" data-testid="dm-messages">
                  {(dm.data ?? []).map((m) => (
                    <div key={m.id} className={`flex ${m.from_id === peer.id ? "justify-start" : "justify-end"}`} data-testid={`dm-msg-${m.id}`}>
                      <div className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-sm ${m.from_id === peer.id ? "bg-slate-800/80 text-zinc-100" : "bg-emerald-500/20 text-emerald-100"}`}>
                        <p className="whitespace-pre-wrap break-words">{m.text}</p>
                        <p className="mt-1 text-[10px] text-zinc-500">{timeAgo(m.created_at)}</p>
                      </div>
                    </div>
                  ))}
                  <div ref={bottomRef} />
                </div>
                <div className="border-t border-slate-800 px-4 py-3">
                  <div className="mb-2 flex gap-1">
                    {STICKERS.map((s) => (
                      <button key={s} onClick={() => setText((t) => t + s)} className="rounded-lg px-1.5 py-1 text-base hover:bg-white/10" data-testid={`dm-sticker-${s}`}>
                        {s}
                      </button>
                    ))}
                  </div>
                  <form className="flex gap-2" onSubmit={onSend} data-testid="dm-form">
                    <Input value={text} onChange={(e) => setText(e.target.value)} maxLength={500} placeholder="Message… (links ok — no videos/images)" className="border-slate-700 bg-slate-900/70" data-testid="dm-input" />
                    <Button type="submit" disabled={sendDm.isPending} className="bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300" data-testid="dm-send-btn">
                      Send
                    </Button>
                  </form>
                </div>
              </>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
