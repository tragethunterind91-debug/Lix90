import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { CalendarClock, History as HistoryIcon, Eye, Info, Play, Search, Sparkles, Star, Tv } from "lucide-react";
import { apiGet } from "@/lib/api";
import type { ChannelInfo, Title } from "@/lib/types";
import { audioBadgeClass, formatCount, formatDate, formatDuration } from "@/lib/badges";
import AnimeCard from "@/components/AnimeCard";
import { CardGridSkeleton, HeroSkeleton } from "@/components/Skeletons";
import { mediaUrl } from "@/lib/api";
import EmptyState from "@/components/EmptyState";
import AdSlot from "@/components/AdSlot";
import Countdown from "@/components/Countdown";
import { buttonVariants } from "@/components/ui/button";
import { useToggleListGuard } from "@/hooks/useWatchlist";
import { useMe } from "@/hooks/useAuth";
import { useHistory } from "@/hooks/useSocial";

const fetchFeatured = () => apiGet<Title[]>("/titles/featured?limit=4");
const fetchLatest = () => apiGet<Title[]>("/titles?sort=latest");
const fetchGenres = () => apiGet<string[]>("/titles/genres");
const fetchUpcoming = () => apiGet<Title[]>("/titles/upcoming");
const fetchSocialFeatured = () => apiGet<any[]>("/social-embeds/featured");

export default function Home() {
  const { inList, handle: handleToggle } = useToggleListGuard();
  const { data: me } = useMe();
  const history = useHistory(Boolean(me));

  const featured = useQuery({ queryKey: ["titles", "featured"], queryFn: fetchFeatured });
  const latest = useQuery({ queryKey: ["titles", "latest"], queryFn: fetchLatest });
  const genres = useQuery({ queryKey: ["genres"], queryFn: fetchGenres });
  const upcoming = useQuery({ queryKey: ["titles", "upcoming"], queryFn: fetchUpcoming, refetchInterval: 60_000 });
  const socialFeatured = useQuery({ queryKey: ["social-embeds-featured"], queryFn: fetchSocialFeatured });
  const hero = featured.data?.[0] ?? latest.data?.find((t) => t.poster_url) ?? latest.data?.[0];

  return (
    <div className="mx-auto max-w-7xl px-4 py-4 sm:px-6 md:py-6 lg:px-8">
      {/* ---- Search (owner ask: search on Home) ---- */}
      <form
        className="mb-4 sm:mb-6 flex gap-2"
        onSubmit={(e) => {
          e.preventDefault();
          const q = (document.getElementById("home-search-input") as HTMLInputElement | null)?.value ?? "";
          window.location.href = `/browse?q=${encodeURIComponent(q)}`;
        }}
        data-testid="home-search-form"
      >
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" aria-hidden />
          <input
            id="home-search-input"
            placeholder="Search anime, movies, channels…"
            className="w-full rounded-xl border border-slate-800 bg-slate-900/70 py-2.5 pl-10 pr-3 text-sm text-white placeholder:text-zinc-600"
            data-testid="home-search-input"
          />
        </div>
        <button type="submit" className="rounded-xl bg-amber-400 px-5 font-bold text-slate-950 hover:bg-amber-300" data-testid="home-search-btn">
          Search
        </button>
      </form>

      {/* ---- From your channels (follow-gated publisher videos) ---- */}
      {me ? <ChannelsSection titles={latest.data ?? []} /> : null}

      {/* ---- Hero spotlight ---- */}
      {hero ? (
        <section
          className="relative overflow-hidden rounded-2xl border border-slate-800"
          data-testid="home-hero"
        >
          {hero.poster_url ? (
            <img
              src={mediaUrl(hero.poster_url)}
              alt=""
              aria-hidden
              className="ken-burns absolute inset-0 h-full w-full object-cover blur-[2px]"
            />
          ) : null}
          <div className="absolute inset-0 bg-gradient-to-t from-[#07090E] via-[#07090E]/70 to-transparent" />
          <div className="absolute inset-0 bg-gradient-to-r from-[#07090E] via-[#07090E]/80 to-transparent" />
          <div className="relative flex min-h-[360px] flex-col justify-end gap-3 p-5 md:min-h-[460px] md:p-10">
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-md bg-amber-400/20 px-2 py-0.5 text-xs font-bold uppercase tracking-widest text-amber-400">
                Featured
              </span>
              {hero.rating ? (
                <span className="flex items-center gap-1 rounded-md bg-black/50 px-2 py-0.5 text-xs font-bold text-amber-400">
                  <Star className="h-3.5 w-3.5 fill-amber-400" aria-hidden /> {hero.rating.toFixed(1)}
                </span>
              ) : null}
              {hero.views ? (
                <span className="flex items-center gap-1 rounded-md bg-black/50 px-2 py-0.5 text-xs text-zinc-300">
                  <Eye className="h-3.5 w-3.5" aria-hidden /> {formatCount(hero.views)} views
                </span>
              ) : null}
              <span className="rounded-md bg-black/50 px-2 py-0.5 text-xs text-zinc-300">
                Added {formatDate(hero.created_at)}
              </span>
              {hero.audio.map((a) => (
                <span key={a} className={`rounded-md px-2 py-0.5 text-[10px] font-bold uppercase tracking-wide ${audioBadgeClass(a)}`}>
                  {a}
                </span>
              ))}
            </div>
            <h1 className="max-w-2xl font-heading text-3xl font-black uppercase leading-[1.05] tracking-tight text-white drop-shadow-[0_4px_24px_rgba(0,0,0,0.8)] sm:text-5xl lg:text-6xl" data-testid="home-hero-title">
              {hero.name}
            </h1>
            <p className="max-w-prose text-base leading-relaxed text-zinc-300 line-clamp-3 md:line-clamp-none">
              {hero.synopsis}
            </p>
            <div className="flex flex-wrap gap-3">
              <Link
                to={`/watch/${hero.slug}/1`}
                data-testid="home-hero-play-btn"
                className={buttonVariants({
                  className: "h-11 gap-2 bg-[#FF4655] px-6 text-sm font-bold text-white shadow-[0_0_28px_rgba(255,70,85,0.4)] hover:bg-[#E03241]",
                })}
              >
                <Play className="h-4 w-4 fill-current" aria-hidden /> Watch Episode 1
              </Link>
              <Link
                to={`/title/${hero.slug}`}
                data-testid="home-hero-info-btn"
                className={buttonVariants({
                  variant: "outline",
                  className: "h-11 gap-2 border-white/20 bg-black/40 px-6 text-sm font-semibold text-white hover:bg-white/10",
                })}
              >
                <Info className="h-4 w-4" aria-hidden /> More Info
              </Link>
            </div>
          </div>
        </section>
      ) : null}

      {/* ---- kind shortcuts: anime / movies / cartoons ---- */}
      <div className="stagger mt-2 flex flex-wrap gap-2" data-testid="home-kind-chips">
        {[
          { to: "/browse?kind=anime", label: "Anime", cls: "from-rose-500/80 to-amber-500/80" },
          { to: "/browse?kind=movie", label: "Movies", cls: "from-blue-500/80 to-emerald-500/80" },
          { to: "/browse?kind=cartoon", label: "Cartoons", cls: "from-fuchsia-500/80 to-orange-400/80" },
          { to: "/browse?kind=kdrama", label: "K-Dramas", cls: "from-rose-400/80 to-purple-400/80" },
          { to: "/browse?kind=webseries", label: "Web Series", cls: "from-emerald-400/80 to-lime-400/80" },
        ].map((c) => (
          <Link
            key={c.to}
            to={c.to}
            className={`pop-in rounded-full bg-gradient-to-r ${c.cls} px-5 py-2 font-heading text-sm font-bold text-white shadow-lg transition-transform duration-200 hover:scale-105`}
          >
            {c.label}
          </Link>
        ))}
      </div>

      {/* ---- ad: home feed ---- */}
      {/* compact ad slot */}
      <AdSlot slot="home" className="mt-2" />

      {/* ---- Coming soon — upcoming titles with live countdowns ---- */}
      {upcoming.data && upcoming.data.length > 0 ? (
        <section className="mt-8 md:mt-12" data-testid="upcoming-strip">
          <h2 className="flex items-center gap-2.5 font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl">
            <CalendarClock className="h-6 w-6 text-amber-400" aria-hidden /> Coming Soon
          </h2>
          <div className="mt-4 flex gap-4 overflow-x-auto pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {upcoming.data.map((t) => (
              <Link
                key={t.id}
                to={`/title/${t.slug}`}
                className="group w-44 flex-shrink-0 snap-start"
                data-testid={`upcoming-card-${t.slug}`}
              >
                {t.poster_url ? (
                  <img
                    src={mediaUrl(t.poster_url)}
                    alt={t.name}
                    loading="lazy"
                    className="h-60 w-44 rounded-xl border border-slate-800 object-cover transition-transform duration-300 group-hover:-translate-y-1"
                  />
                ) : (
                  <div className="flex h-60 w-44 items-center justify-center rounded-xl border border-slate-800 bg-card skeleton-shimmer">
                    <span className="px-3 text-center text-sm font-bold text-zinc-400">{t.name}</span>
                  </div>
                )}
                <p className="mt-2 truncate text-sm font-semibold text-white group-hover:text-amber-400">{t.name}</p>
                <p className="flex items-center gap-1.5 text-xs font-bold text-amber-400" data-testid={`upcoming-countdown-${t.slug}`}>
                  <CalendarClock className="h-3.5 w-3.5" aria-hidden />
                  <Countdown to={t.release_at} testId={`upcoming-timer-${t.slug}`} />
                </p>
              </Link>
            ))}
          </div>
        </section>
      ) : null}

      {/* ---- Continue watching (signed-in users with history) ---- */}
      {me && history.data && history.data.items.length > 0 ? (
        <section className="mt-8 md:mt-12" data-testid="continue-watching">
          <h2 className="flex items-center gap-2.5 font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl">
            <HistoryIcon className="h-6 w-6 text-amber-400" aria-hidden /> Continue Watching
          </h2>
          <div className="mt-4 flex gap-4 overflow-x-auto pb-2 [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {history.data.items.slice(0, 8).map((item) => (
              <Link
                key={item.episode_id}
                to={`/watch/${item.title.slug}/${item.episode_id}`}
                className="group w-40 flex-shrink-0 snap-start"
                data-testid={`continue-watching-card-${item.episode_id}`}
              >
                {item.title.poster_url ? (
                  <img
                    src={mediaUrl(item.title.poster_url)}
                    alt={item.title.name}
                    className="h-52 w-40 rounded-xl border border-slate-800 object-cover transition-transform duration-300 group-hover:-translate-y-1"
                  />
                ) : (
                  <div className="h-52 w-40 rounded-xl border border-slate-800 skeleton-shimmer" />
                )}
                <p className="mt-2 truncate text-sm font-semibold text-white group-hover:text-amber-400">{item.title.name}</p>
                <p className="text-xs text-muted-foreground">
                  EP {item.episode_number} · stopped at {formatDuration(item.position_seconds) || "start"}
                </p>
              </Link>
            ))}
          </div>
        </section>
      ) : null}

      {/* ---- Genre chips ---- */}
      {genres.data && genres.data.length > 0 ? (
        <section className="mt-4 md:mt-6">
          <div className="flex flex-wrap gap-2" data-testid="home-genre-chips">
            {genres.data.slice(0, 10).map((genre) => (
              <Link
                key={genre}
                to={`/browse?genre=${encodeURIComponent(genre)}`}
                className="rounded-full border border-slate-700 bg-card px-4 py-1.5 text-xs font-semibold text-zinc-300 transition-colors hover:border-amber-400/60 hover:text-amber-400"
              >
                {genre}
              </Link>
            ))}
          </div>
        </section>
      ) : null}

      {/* ---- Featured carousel ---- */}
      {featured.data && featured.data.length > 0 ? (
        <section className="mt-8 md:mt-14">
          <h2 className="flex items-center gap-2.5 font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl">
            <Sparkles className="h-6 w-6 text-amber-400" aria-hidden /> Featured Spotlight
          </h2>
          <div className="mt-4 flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden">
            {featured.data.map((title) => (
              <div key={title.id} className="w-36 flex-shrink-0 snap-start sm:w-48">
                <AnimeCard title={title} inList={inList(title.id)} onToggleList={handleToggle} />
              </div>
            ))}
          </div>
        </section>
      ) : null}

      {/* ---- Featured Social & Creator Webviews ---- */}
      {socialFeatured.data && socialFeatured.data.length > 0 ? (
        <section className="mt-3 md:mt-4" data-testid="home-social-featured-section">
          <div className="flex items-center justify-between gap-2">
            <div>
              <h2 className="flex items-center gap-2 font-heading text-xl font-bold text-white sm:text-2xl">
                <Sparkles className="h-5 w-5 text-amber-400" /> Featured Creator &amp; Social Webviews
              </h2>
              <p className="text-xs text-zinc-400">Curated community streams, official trailers &amp; social highlights</p>
            </div>
            <Link to="/explore" className="text-xs font-bold text-sky-400 hover:underline" data-testid="home-explore-all-link">
              Explore all &rarr;
            </Link>
          </div>
          <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3" data-testid="home-social-featured-grid">
            {socialFeatured.data.map((emb) => (
              <div key={emb.id} className="overflow-hidden rounded-2xl border border-slate-800 bg-[#07090E]/80 shadow-lg">
                <div className="relative aspect-video w-full bg-black">
                  <iframe
                    src={emb.embed_url}
                    title={emb.title}
                    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                    allowFullScreen
                    className="absolute inset-0 h-full w-full border-0"
                  />
                </div>
                <div className="p-3.5">
                  <div className="flex items-center justify-between gap-2">
                    <span className="rounded bg-sky-500/20 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-sky-300">
                      {emb.platform}
                    </span>
                    <span className="text-[11px] font-medium text-zinc-400">{emb.creator_name}</span>
                  </div>
                  <p className="mt-1.5 font-bold text-sm text-white line-clamp-1">{emb.title}</p>
                  {emb.bio ? <p className="mt-1 text-xs text-zinc-400 line-clamp-2">{emb.bio}</p> : null}
                </div>
              </div>
            ))}
          </div>
        </section>
      ) : null}

      {/* ---- Latest additions ---- */}
      <section className="mt-3 md:mt-4">
        <h2 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl">
          Latest on Anime-Unleashed
        </h2>
        <div className="mt-4">
          {latest.isLoading ? (
            null
          ) : latest.data && latest.data.length > 0 ? (
            <div className="stagger grid grid-cols-2 gap-3.5 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 md:gap-5 xl:grid-cols-6">
              {latest.data.map((title) => (
                <AnimeCard
                  key={title.id}
                  title={title}
                  inList={inList(title.id)}
                  onToggleList={handleToggle}
                />
              ))}
            </div>
          ) : (
            <EmptyState
              icon={Tv}
              title="No anime titles yet"
              message="The catalog is ready for manual uploads. Sign in to Studio to add your anime and episodes."
              actionLabel="Add Anime in Studio"
              onAction={() => window.location.assign("/studio/catalog")}
            />
          )}
        </div>
      </section>
    </div>
  );
}


// ---- From your channels: publisher videos appear on Home ONLY if followed ----
function ChannelsSection({ titles }: { titles: Title[] }) {
  const follows = useQuery({
    queryKey: ["engagement", "my-follows"],
    queryFn: () => apiGet<string[]>("/engagement/my-follows"),
  });
  const channels = useQuery({
    queryKey: ["channels"],
    queryFn: () => apiGet<ChannelInfo[]>("/channels"),
  });
  const followed = (channels.data ?? []).filter((c) => (follows.data ?? []).includes(c.user_id));
  if (!followed.length) return null;
  const emails = followed.map((c) => c.email ?? "");
  const vids = titles.filter((t) => t.supplier_email && emails.includes(t.supplier_email));
  return (
    <section className="mt-8 md:mt-12" data-testid="home-channels-section">
      <div className="flex flex-wrap items-center justify-between gap-2">
        <h2 className="font-heading text-xl font-bold text-white">From your channels</h2>
        <Link to="/channels" className="text-xs font-bold text-amber-400 hover:underline" data-testid="home-channels-discover">
          Discover channels
        </Link>
      </div>
      <div className="mt-3 flex flex-wrap gap-2" data-testid="home-channels-chips">
        {followed.map((c) => (
          <Link key={c.user_id} to={`/channel/${c.user_id}`} className="flex items-center gap-2 rounded-full border border-slate-800 bg-slate-900/70 py-1 pl-1 pr-3 text-xs font-bold text-zinc-300 hover:border-amber-400/40" data-testid="home-channel-chip">
            {c.logo ? <img src={c.logo} alt="" className="h-6 w-6 rounded-full object-cover" /> : <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-400/20 text-amber-400">{(c.name || "?").slice(0, 1)}</span>}
            {c.name}
          </Link>
        ))}
      </div>
      {vids.length ? (
        <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-5" data-testid="home-channel-videos">
          {vids.map((t) => <AnimeCard key={t.id} title={t} />)}
        </div>
      ) : (
        <p className="mt-3 text-xs text-zinc-600" data-testid="home-channels-empty">Your followed channels haven't posted yet.</p>
      )}
    </section>
  );
}
