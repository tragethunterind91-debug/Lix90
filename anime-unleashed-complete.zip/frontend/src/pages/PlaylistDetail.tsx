import { useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Globe, ListVideo, Lock, Share2, Trash2, X } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { useMe } from "@/hooks/useAuth";
import { useDeletePlaylist, usePlaylist, useUpdatePlaylist } from "@/hooks/useSocial";
import { shareLink } from "@/lib/share";
import AnimeCard from "@/components/AnimeCard";
import EmptyState from "@/components/EmptyState";
import { CardGridSkeleton } from "@/components/Skeletons";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

// Playlist detail: public share-link view for guests, full management for the owner.
export default function PlaylistDetail() {
  const { id } = useParams<{ id: string }>();
  const { data: me } = useMe();
  const playlist = usePlaylist(id);
  const update = useUpdatePlaylist();
  const remove = useDeletePlaylist();
  const navigate = useNavigate();
  const [confirmOpen, setConfirmOpen] = useState(false);

  if (playlist.isLoading) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <CardGridSkeleton count={6} />
      </div>
    );
  }
  if (playlist.isError || !playlist.data) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8">
        <EmptyState
          icon={Lock}
          title="Playlist unavailable"
          message="This playlist is private or no longer exists. Ask the owner to share it publicly."
          actionLabel="Back to home"
          onAction={() => navigate("/")}
          testId="playlist-unavailable"
        />
      </div>
    );
  }

  const data = playlist.data;
  const isOwner = me?.id === data.owner_id;

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
      <div className="flex flex-wrap items-center gap-3">
        <span className="flex h-12 w-12 items-center justify-center rounded-xl bg-slate-800">
          <ListVideo className="h-6 w-6 text-amber-400" aria-hidden />
        </span>
        <div className="min-w-0">
          <h1 className="font-heading text-2xl font-bold tracking-tight text-white sm:text-3xl" data-testid="playlist-detail-name">
            {data.name}
          </h1>
          <p className="mt-0.5 text-sm text-muted-foreground">
            {data.titles.length} title{data.titles.length === 1 ? "" : "s"}
          </p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => shareLink(window.location.href, data.name)}
            data-testid="playlist-share-btn"
            className="border-slate-700"
          >
            <Share2 className="mr-1.5 h-4 w-4" aria-hidden /> Share
          </Button>
          {isOwner ? (
            <>
              <Button
                variant="outline"
                size="sm"
                onClick={() => update.mutate({ id: data.id, is_public: !data.is_public })}
                disabled={update.isPending}
                data-testid="playlist-privacy-toggle"
                className="border-slate-700"
              >
                {data.is_public ? (
                  <><Globe className="mr-1.5 h-4 w-4 text-emerald-400" aria-hidden /> Public</>
                ) : (
                  <><Lock className="mr-1.5 h-4 w-4 text-zinc-400" aria-hidden /> Private</>
                )}
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setConfirmOpen(true)}
                data-testid="playlist-detail-delete-btn"
                className="text-rose-400 hover:bg-rose-500/10"
              >
                <Trash2 className="mr-1.5 h-4 w-4" aria-hidden /> Delete
              </Button>
            </>
          ) : (
            <Badge className="bg-amber-400/15 text-amber-400">
              {data.is_public ? <Globe className="mr-1 h-3 w-3" aria-hidden /> : null} Shared playlist
            </Badge>
          )}
        </div>
      </div>

      <div className="mt-6">
        {data.titles.length > 0 ? (
          <div className="grid grid-cols-2 gap-3.5 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 md:gap-5 xl:grid-cols-6" data-testid="playlist-grid">
            {data.titles.map((ref) => (
              <div key={ref.id} className="relative">
                <AnimeCard
                  title={{
                    id: ref.id,
                    slug: ref.slug,
                    name: ref.name,
                    poster_url: ref.poster_url,
                    synopsis: "",
                    genres: [],
                    release_year: 0,
                    type: "series",
                    kind: "anime",
                    studio: "",
                    age_rating: "",
                    original_language: "",
                    airing_status: "",
                    audio: [],
                    rating: null,
                    featured: false,
                    status: "published",
                    episode_count: 0,
                    views: 0,
                    created_at: "",
                  }}
                />
                {isOwner ? (
                  <button
                    onClick={() => update.mutate({ id: data.id, remove_title_id: ref.id })}
                    aria-label={`Remove ${ref.name} from playlist`}
                    data-testid={`playlist-remove-btn-${ref.id}`}
                    className="absolute -right-2 -top-2 z-10 flex h-7 w-7 items-center justify-center rounded-full border border-slate-600 bg-slate-900 text-zinc-300 transition-colors hover:border-rose-500 hover:text-rose-400"
                  >
                    <X className="h-4 w-4" aria-hidden />
                  </button>
                ) : null}
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={ListVideo}
            title="No video, Coming Soon"
            message={isOwner ? "This playlist currently has no video. Use the '+ Playlist' button from any title to add videos, or check back soon!" : "No video available here yet. Coming soon!"}
            actionLabel={isOwner ? "Browse catalog" : undefined}
            onAction={isOwner ? () => navigate("/browse") : undefined}
            testId="playlist-detail-empty"
          />
        )}
      </div>

      <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
        <DialogContent className="border-slate-800 bg-[#121622]">
          <DialogHeader>
            <DialogTitle className="text-white">Delete “{data.name}”?</DialogTitle>
            <DialogDescription>The playlist is removed for everyone; titles stay in the catalog.</DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="ghost" onClick={() => setConfirmOpen(false)}>Cancel</Button>
            <Button
              variant="destructive"
              data-testid="playlist-delete-confirm-btn"
              onClick={() => remove.mutate(data.id, { onSuccess: () => navigate("/playlists") })}
            >
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
