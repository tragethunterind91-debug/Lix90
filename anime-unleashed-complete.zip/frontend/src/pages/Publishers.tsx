import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { BadgeCheck, CheckCircle2, Circle, Loader2, Send, XCircle, Youtube } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { apiGet, apiPatch, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { SupplierMeOut } from "@/lib/types";
import { useMe } from "@/hooks/useAuth";
import { useGrowth } from "@/hooks/usePublisher";

const TESTS = [
  { n: 1, label: "Content rules", detail: "No illegal content, violence, discrimination, fake or mind-manipulating material." },
  { n: 2, label: "Quality", detail: "Interesting, clear video — 10 minutes to 1 hour per video." },
  { n: 3, label: "Originality", detail: "Not fully copied — real potential to attract viewers." },
];

// Publisher desk — apply with your channel, the owner verifies it in 3 tests
// (every result is emailed), approved publishers submit videos + track growth.
export default function Publishers() {
  const qc = useQueryClient();
  const { data: me } = useMe();
  const desk = useQuery({
    queryKey: ["supplier", "me"],
    queryFn: () => apiGet<SupplierMeOut>("/supplier/me"),
    enabled: !!me,
  });
  const growth = useGrowth(desk.data?.application?.channel_verified ?? false);

  const [form, setForm] = useState({ channel_name: "", channel_url: "", content_type: "", note: "" });
  const [submitForm, setSubmitForm] = useState({ title: "", source_url: "", description: "" });
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [bioDraft, setBioDraft] = useState("");

  async function saveBio() {
    setBusy(true);
    try {
      await apiPatch("/publisher/channel", { bio: bioDraft, logo_b64: "" });
      toast.success("Channel bio saved");
      void qc.invalidateQueries({ queryKey: ["channels"] });
    } catch (err) {
      toast.error(apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  }


  const app = desk.data?.application ?? null;

  async function apply(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      await apiPost("/supplier/apply", { ...form, content_type: form.content_type || "anime" });
      toast.success("Application sent — the owner reviews channels in order");
      void qc.invalidateQueries({ queryKey: ["supplier", "me"] });
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  async function submitVideo(event: React.FormEvent) {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      await apiPost("/supplier/submissions", { ...submitForm, kind: "anime", language: "" });
      toast.success("Video submitted — the owner reviews it next");
      setSubmitForm({ title: "", source_url: "", description: "" });
      void qc.invalidateQueries({ queryKey: ["supplier", "me"] });
    } catch (err) {
      setError(apiErrorMessage(err));
    } finally {
      setBusy(false);
    }
  }

  if (!me) {
    return (
      <div className="mx-auto max-w-md px-4 py-16 text-center" data-testid="publishers-guest-gate">
        <Youtube className="mx-auto h-10 w-10 text-amber-400" aria-hidden />
        <h1 className="mt-4 font-heading text-3xl font-bold text-white">Become a Publisher</h1>
        <p className="mt-2 text-sm text-zinc-400">
          Run a channel? Get verified in 3 quick tests and turn your videos into a branded, monetized presence here.
        </p>
        <Button className="mt-6 bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" onClick={() => (window.location.href = "/login")} data-testid="publishers-login-link">
          Sign in to apply
        </Button>
      </div>
    );
  }

  const ladder = (tests: Record<string, string>, currentTest: number) => (
    <ol className="mt-4 space-y-2" data-testid="publisher-test-ladder">
      {TESTS.map((t) => {
        const state = tests[String(t.n)];
        const isCurrent = !state && currentTest === t.n;
        return (
          <li key={t.n} className="flex items-start gap-3 rounded-xl border border-slate-800 bg-slate-900/50 px-4 py-3">
            {state === "passed" ? (
              <CheckCircle2 className="mt-0.5 h-5 w-5 flex-shrink-0 text-emerald-400" aria-hidden />
            ) : state === "failed" ? (
              <XCircle className="mt-0.5 h-5 w-5 flex-shrink-0 text-rose-400" aria-hidden />
            ) : isCurrent ? (
              <Loader2 className="mt-0.5 h-5 w-5 flex-shrink-0 animate-spin text-amber-400" aria-hidden />
            ) : (
              <Circle className="mt-0.5 h-5 w-5 flex-shrink-0 text-zinc-600" aria-hidden />
            )}
            <div>
              <p className="text-sm font-bold text-white">
                Test {t.n} — {t.label}
                {state === "passed" ? <span className="ml-2 text-xs font-normal text-emerald-400">passed — check your email</span> : null}
                {isCurrent ? <span className="ml-2 text-xs font-normal text-amber-400">under review…</span> : null}
              </p>
              <p className="text-xs text-zinc-500">{t.detail}</p>
            </div>
          </li>
        );
      })}
    </ol>
  );

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6" data-testid="publishers-page">
      <div className="text-center">
        <BadgeCheck className="mx-auto h-10 w-10 text-amber-400" aria-hidden />
        <h1 className="mt-3 font-heading text-3xl font-bold tracking-tight text-white sm:text-4xl">Publisher Desk</h1>
        <p className="mt-2 text-sm text-zinc-400">
          Like a channel of your own — get verified, share videos, and watch your growth.
        </p>
      </div>

      {error ? (
        <p className="mx-auto mt-6 max-w-xl rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-300" role="alert" data-testid="publishers-error">
          {error}
        </p>
      ) : null}

      {desk.isLoading ? (
        <p className="mt-10 flex items-center justify-center gap-2 text-sm text-zinc-500">
          <Loader2 className="h-4 w-4 animate-spin" aria-hidden /> Loading your desk…
        </p>
      ) : !app ? (
        <Card className="mx-auto mt-8 max-w-xl border-slate-800 bg-card/70">
          <CardHeader>
            <CardTitle className="font-heading text-lg font-bold text-white">Apply with your channel</CardTitle>
            <CardDescription className="text-zinc-300">
              We upload or accept almost all videos, but if something needs improvement we will tell you.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="mb-4 rounded-xl border border-purple-500/30 bg-purple-500/10 p-3.5 text-xs text-purple-200">
              <span className="font-bold text-amber-300">Creator Friendly Policy: </span>
              We upload or accept almost all videos! If any edit or improvement is needed for quality or guidelines, our team will guide and inform you directly.
              <p className="mt-1 text-zinc-300">
                All application details are sent straight to the owner's email (<span className="text-amber-300 font-mono">AnimeUnleashed@adown.com</span>) so your submission is safely reviewed and never lost in web messages.
              </p>
            </div>
            <form onSubmit={apply} className="space-y-4" data-testid="publisher-apply-form">
              <div className="space-y-2">
                <Label htmlFor="pub-channel-name">Channel name</Label>
                <Input id="pub-channel-name" required minLength={2} value={form.channel_name} onChange={(e) => setForm({ ...form, channel_name: e.target.value })} placeholder="e.g. AnimeVerse Dubs" className="border-slate-700 bg-slate-900/70" data-testid="publisher-channel-name-input" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pub-channel-url">Channel link (YouTube or elsewhere)</Label>
                <Input id="pub-channel-url" required minLength={5} value={form.channel_url} onChange={(e) => setForm({ ...form, channel_url: e.target.value })} placeholder="https://youtube.com/@yourchannel" className="border-slate-700 bg-slate-900/70" data-testid="publisher-channel-url-input" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pub-content-type">What do you make?</Label>
                <Input id="pub-content-type" required value={form.content_type} onChange={(e) => setForm({ ...form, content_type: e.target.value })} placeholder="e.g. anime edits, dubs, AMVs, documentaries" className="border-slate-700 bg-slate-900/70" data-testid="publisher-content-type-input" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pub-note">Tell the owner about your channel</Label>
                <Input id="pub-note" required minLength={10} value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} placeholder="What you upload, how often, and why it fits Anime-Unleashed" className="border-slate-700 bg-slate-900/70" data-testid="publisher-note-input" />
              </div>
              <Button type="submit" disabled={busy} className="w-full bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" data-testid="publisher-apply-submit-btn">
                {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <Send className="mr-2 h-4 w-4" aria-hidden />}
                Send application
              </Button>
            </form>
          </CardContent>
        </Card>
      ) : app.channel_verified ? (
        <>
          <Card className="mt-8 border-emerald-500/40 bg-emerald-500/5" data-testid="publisher-approved-card">
            <CardContent className="p-6">
              <p className="flex items-center gap-2 font-heading text-lg font-bold text-white">
                <CheckCircle2 className="h-5 w-5 text-emerald-400" aria-hidden /> Channel verified — welcome, publisher!
              </p>
              <p className="mt-1 text-sm text-zinc-400">{app.channel_name} · submit videos below; every result is emailed to you.</p>
            </CardContent>
          </Card>
          <Card className="mt-4 border-slate-800 bg-card/70" data-testid="publisher-channel-editor">
            <CardContent className="p-6">
              <p className="font-heading text-base font-bold text-white">Customize your channel</p>
              <p className="mt-1 text-xs text-zinc-500">Your logo and bio show on your public channel page — like YouTube.</p>
              <div className="mt-3 flex flex-wrap items-center gap-3">
                <input
                  id="pub-logo-input"
                  type="file"
                  accept="image/*"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    e.target.value = ""; // re-picking the same file must still fire change
                    if (!file) return;
                    // Phones hand us 5-12 MB HEIC/JPEGs — normalize in-browser to a
                    // 512px JPEG before upload so mobile/webview picks always save.
                    const img = new Image();
                    img.onload = async () => {
                      const max = 512;
                      const scale = Math.min(1, max / Math.max(img.width, img.height));
                      const canvas = document.createElement("canvas");
                      canvas.width = Math.max(1, Math.round(img.width * scale));
                      canvas.height = Math.max(1, Math.round(img.height * scale));
                      const ctx = canvas.getContext("2d");
                      if (!ctx) { toast.error("Could not read that image"); return; }
                      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
                      const b64 = canvas.toDataURL("image/jpeg", 0.85).split(",")[1] ?? "";
                      try {
                        await apiPatch("/publisher/channel", { bio: bioDraft, logo_b64: b64 });
                        toast.success("Channel logo saved");
                        void qc.invalidateQueries({ queryKey: ["channels"] });
                      } catch (err) { toast.error(apiErrorMessage(err)); }
                    };
                    img.onerror = () => toast.error("That file isn't a supported image");
                    img.src = URL.createObjectURL(file);
                  }}
                  className="text-xs text-zinc-400"
                  data-testid="publisher-logo-input"
                />
                <Input
                  value={bioDraft}
                  onChange={(e) => setBioDraft(e.target.value)}
                  placeholder="Channel bio — what do you make?"
                  className="min-w-0 flex-1 border-slate-700 bg-slate-900/70 text-sm"
                  data-testid="publisher-bio-input"
                />
                <Button size="sm" onClick={() => void saveBio()} disabled={busy} className="bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" data-testid="publisher-bio-save-btn">
                  Save bio
                </Button>
              </div>
            </CardContent>
          </Card>
          <Card className="mt-4 border-slate-800 bg-card/70" data-testid="publisher-growth-card">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-heading text-lg font-bold text-white">Channel Analytics &amp; Growth</p>
                  <p className="text-xs text-zinc-400">Live audience metrics and performance across your channel</p>
                </div>
                {growth.data?.trend_pct !== undefined ? (
                  <span
                    className={`rounded-full px-3 py-1 text-xs font-bold ${
                      growth.data.trend_pct >= 0 ? "bg-emerald-500/10 text-emerald-300" : "bg-rose-500/10 text-rose-300"
                    }`}
                  >
                    {growth.data.trend_pct >= 0 ? "+" : ""}{growth.data.trend_pct}% this month
                  </span>
                ) : null}
              </div>
              <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-5" data-testid="publisher-growth-totals">
                {[
                  { label: "Subscribers", value: growth.data?.subscribers ?? 0 },
                  { label: "Total Views", value: growth.data?.totals.views ?? 0 },
                  { label: "Watch Hours", value: growth.data?.totals.watch_hours ?? 0 },
                  { label: "Downloads", value: growth.data?.totals.downloads_total ?? 0 },
                  { label: "Uploads", value: growth.data?.uploads ?? 0 },
                ].map((s) => (
                  <div key={s.label} className="rounded-xl border border-slate-800 bg-slate-900/50 px-3 py-3 text-center">
                    <p className="font-heading text-lg sm:text-xl font-bold text-white" data-testid={`publisher-stat-${s.label.toLowerCase().replace(" ", "-")}`}>
                      {s.value.toLocaleString("en-IN")}
                    </p>
                    <p className="text-xs text-zinc-400">{s.label}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
          <Card className="mt-4 border-slate-800 bg-card/70">
            <CardHeader>
              <CardTitle className="font-heading text-base font-bold text-white">Submit a video</CardTitle>
              <CardDescription>Send your link — the owner reviews and publishes it.</CardDescription>
            </CardHeader>
            <CardContent>
              <form onSubmit={submitVideo} className="space-y-4" data-testid="publisher-submit-form">
                <div className="space-y-2">
                  <Label htmlFor="pub-sub-title">Video title</Label>
                  <Input id="pub-sub-title" required value={submitForm.title} onChange={(e) => setSubmitForm({ ...submitForm, title: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="publisher-submit-title-input" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pub-sub-url">Video link</Label>
                  <Input id="pub-sub-url" required type="url" value={submitForm.source_url} onChange={(e) => setSubmitForm({ ...submitForm, source_url: e.target.value })} placeholder="https://youtube.com/watch?v=…" className="border-slate-700 bg-slate-900/70" data-testid="publisher-submit-url-input" />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="pub-sub-desc">Short description</Label>
                  <Input id="pub-sub-desc" value={submitForm.description} onChange={(e) => setSubmitForm({ ...submitForm, description: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="publisher-submit-desc-input" />
                </div>
                <Button type="submit" disabled={busy} className="w-full bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" data-testid="publisher-submit-btn">
                  {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : <Send className="mr-2 h-4 w-4" aria-hidden />}
                  Submit for review
                </Button>
              </form>
            </CardContent>
          </Card>
        </>
      ) : (
        <Card className="mx-auto mt-8 max-w-xl border-slate-800 bg-card/70" data-testid="publisher-status-card">
          <CardContent className="p-6">
            <p className="font-heading text-base font-bold text-white">
              {app.channel_name} — {app.status === "rejected" ? "not passed this time" : "verification in progress"}
            </p>
            {ladder(app.tests ?? {}, app.current_test ?? 1)}
            {app.status === "rejected" && app.admin_note ? (
              <p className="mt-4 rounded-lg border border-rose-500/40 bg-rose-500/10 px-3 py-2 text-sm text-rose-300" data-testid="publisher-fail-note">
                Owner's note: {app.admin_note}
              </p>
            ) : null}
            {app.status === "rejected" ? (
              <p className="mt-3 text-xs text-zinc-500">Fix what the owner noted and apply again below.</p>
            ) : null}
          </CardContent>
        </Card>
      )}

      {app?.status === "rejected" ? (
        <Card className="mx-auto mt-4 max-w-xl border-slate-800 bg-card/70">
          <CardContent>
            <form onSubmit={apply} className="space-y-4" data-testid="publisher-reapply-form">
              <div className="space-y-2">
                <Label htmlFor="pub-rechannel-name">Channel name</Label>
                <Input id="pub-rechannel-name" required minLength={2} value={form.channel_name} onChange={(e) => setForm({ ...form, channel_name: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="publisher-reapply-name-input" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pub-rechannel-url">Channel link</Label>
                <Input id="pub-rechannel-url" required value={form.channel_url} onChange={(e) => setForm({ ...form, channel_url: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="publisher-reapply-url-input" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pub-recontent-type">What do you make?</Label>
                <Input id="pub-recontent-type" required value={form.content_type} onChange={(e) => setForm({ ...form, content_type: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="publisher-reapply-type-input" />
              </div>
              <div className="space-y-2">
                <Label htmlFor="pub-renote">What changed since last time?</Label>
                <Input id="pub-renote" required minLength={10} value={form.note} onChange={(e) => setForm({ ...form, note: e.target.value })} className="border-slate-700 bg-slate-900/70" data-testid="publisher-reapply-note-input" />
              </div>
              <Button type="submit" disabled={busy} className="w-full bg-amber-400 font-bold text-slate-950 hover:bg-amber-300" data-testid="publisher-reapply-submit-btn">
                {busy ? <Loader2 className="mr-2 h-4 w-4 animate-spin" aria-hidden /> : null}
                Apply again
              </Button>
            </form>
          </CardContent>
        </Card>
      ) : null}
    </div>
  );
}
