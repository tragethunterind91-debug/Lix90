import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  Trophy,
  DollarSign,
  Ticket,
  Languages,
  Clock,
  Star,
  ExternalLink,
  Mail,
  Award,
  Search,
  ArrowRightLeft,
  Tv,
} from "lucide-react";
import { apiGet } from "@/lib/api";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";

interface MovieInfo {
  id: string;
  rank: number;
  region: string;
  category: string;
  title: string;
  original_title?: string;
  poster_url: string;
  description: string;
  box_office_usd: string;
  total_tickets_sold: string;
  production_cost_usd: string;
  rating: number;
  release_date: string;
  original_language: string;
  total_dubbed_languages: number;
  dubbed_languages: string[];
  duration_mins: number;
  studio: string;
  genres: string[];
  awards_count: number;
  awards: string[];
  official_website: string;
  official_email: string;
}

// Fixed conversion rate: 1 USD ≈ 86.5 INR
const USD_TO_INR = 86.5;

function convertUsdStringToInr(usdStr: string): string {
  const numeric = parseFloat(usdStr.replace(/[^0-9.]/g, ""));
  if (isNaN(numeric)) return usdStr;
  const inrTotal = numeric * USD_TO_INR;
  if (inrTotal >= 10000000) {
    const crores = inrTotal / 10000000;
    return `₹${crores.toFixed(1)} Cr`;
  }
  return `₹${inrTotal.toLocaleString("en-IN")}`;
}

export default function MovieInfoPortal() {
  const [region, setRegion] = useState<string>("all");
  const [category, setCategory] = useState<string>("all");
  const [search, setSearch] = useState<string>("");
  const [currency, setCurrency] = useState<"USD" | "INR">("USD");
  const [tvMode, setTvMode] = useState<boolean>(false);

  // TV remote navigation listener (keyboard / D-pad arrow keys)
  useEffect(() => {
    function handleKeyDown(e: KeyboardEvent) {
      if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight"].includes(e.key)) {
        if (!tvMode) setTvMode(true);
      }
    }
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [tvMode]);

  const { data: movies = [] } = useQuery({
    queryKey: ["info", "movies", region, category],
    queryFn: () => {
      const params = new URLSearchParams();
      if (region !== "all") params.append("region", region);
      if (category !== "all") params.append("category", category);
      const qs = params.toString();
      return apiGet<MovieInfo[]>(`/info${qs ? `?${qs}` : ""}`);
    },
  });

  const filtered = movies.filter((m) =>
    m.title.toLowerCase().includes(search.toLowerCase()) ||
    m.studio.toLowerCase().includes(search.toLowerCase()) ||
    m.genres.some((g) => g.toLowerCase().includes(search.toLowerCase()))
  );

  return (
    <div className={`mx-auto min-h-screen max-w-7xl px-4 py-10 sm:px-6 lg:px-8 ${tvMode ? "tv-remote-active ring-2 ring-amber-400/20" : ""}`}>
      {/* Header Banner */}
      <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-800 pb-8">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-amber-400/30 bg-amber-400/10 px-3.5 py-1 text-xs font-bold text-amber-300">
            <Trophy className="h-4 w-4 text-amber-400" />
            <span>Official Box Office &amp; Anime Hall of Fame</span>
            {tvMode && (
              <span className="ml-2 rounded bg-amber-400 px-1.5 py-0.2 text-[10px] font-black text-slate-950 flex items-center gap-1">
                <Tv className="h-3 w-3" /> TV Remote D-Pad Active
              </span>
            )}
          </div>
          <h1 className="mt-3 font-heading text-3xl font-black text-white sm:text-4xl md:text-5xl">
            Anime, Movie &amp; Cartoon Database
          </h1>
          <p className="mt-2 text-sm text-zinc-400 max-w-2xl">
            Verified global box office collections, ticket counts, dubbed language statistics, production budgets, studio awards, and verified official contacts.
          </p>
        </div>

        {/* Currency Switcher & TV Mode Controls */}
        <div className="flex flex-wrap items-center gap-3">
          {/* 1-Click Currency Converter Toggle */}
          <button
            type="button"
            onClick={() => setCurrency(currency === "USD" ? "INR" : "USD")}
            className="group flex items-center gap-2 rounded-2xl border border-amber-400/40 bg-gradient-to-r from-amber-500/15 via-pink-500/10 to-purple-500/15 p-3.5 text-left transition-all hover:scale-105 hover:border-amber-400 focus:outline-none focus:ring-4 focus:ring-amber-400/50"
            tabIndex={0}
            data-testid="currency-converter-btn"
          >
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-amber-400 text-slate-950 font-black shadow-md shadow-amber-400/20">
              {currency === "USD" ? "$" : "₹"}
            </div>
            <div>
              <div className="flex items-center gap-1 text-[11px] font-bold text-amber-300">
                <span>Switch to {currency === "USD" ? "Indian Rupee (₹)" : "USD ($)"}</span>
                <ArrowRightLeft className="h-3 w-3 text-amber-400" />
              </div>
              <div className="text-xs font-black text-white">
                Viewing in: <span className="text-amber-400 font-mono">{currency}</span>
              </div>
            </div>
          </button>
        </div>
      </div>

      {/* Filter Tabs & Search */}
      <div className="mt-8 flex flex-wrap items-center justify-between gap-4">
        {/* Region Filter */}
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 mr-1">Region:</span>
          {[
            { id: "all", label: "All Rankings" },
            { id: "global", label: "🌍 Global" },
            { id: "india", label: "🇮🇳 India" },
            { id: "us", label: "🇺🇸 United States" },
            { id: "anime_unleashed", label: "🔥 Anime Unleashed" },
          ].map((r) => (
            <button
              key={r.id}
              onClick={() => setRegion(r.id)}
              tabIndex={0}
              className={`rounded-xl px-3.5 py-1.5 text-xs font-bold transition-all focus:outline-none focus:ring-4 focus:ring-amber-400 ${
                region === r.id
                  ? "bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20 font-black"
                  : "border border-slate-800 bg-slate-900/60 text-zinc-300 hover:border-slate-700"
              }`}
            >
              {r.label}
            </button>
          ))}
        </div>

        {/* Sub-Category Filter: All / Anime / Movie / Cartoons */}
        <div className="flex flex-wrap items-center gap-2" data-testid="info-subcategory-filter">
          <span className="text-xs font-bold uppercase tracking-wider text-zinc-500 mr-1">Category:</span>
          {[
            { id: "all", label: "All Categories" },
            { id: "anime", label: "⛩️ Anime" },
            { id: "movie", label: "🎬 Movies" },
            { id: "cartoon", label: "🎨 Cartoons" },
          ].map((c) => (
            <button
              key={c.id}
              onClick={() => setCategory(c.id)}
              tabIndex={0}
              data-testid={`info-cat-${c.id}`}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition-all focus:outline-none focus:ring-4 focus:ring-amber-400 ${
                category === c.id
                  ? "bg-gradient-to-r from-pink-500 to-amber-400 text-slate-950 shadow-md font-black"
                  : "border border-slate-800 bg-slate-900/60 text-zinc-300 hover:border-slate-700"
              }`}
            >
              {c.label}
            </button>
          ))}
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-zinc-500" />
          <Input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search title, studio, genre..."
            tabIndex={0}
            className="h-10 rounded-xl border-slate-800 bg-slate-900/80 pl-9 text-xs text-white placeholder:text-zinc-500 focus:ring-4 focus:ring-amber-400/50"
          />
        </div>
      </div>

      {/* Movie Cards List */}
      <div className="mt-8 space-y-6">
        {filtered.map((item) => {
          const displayedBoxOffice =
            currency === "USD"
              ? item.box_office_usd
              : convertUsdStringToInr(item.box_office_usd);

          const displayedCost =
            currency === "USD"
              ? item.production_cost_usd
              : convertUsdStringToInr(item.production_cost_usd);

          return (
            <Card
              key={item.id}
              tabIndex={0}
              className="overflow-hidden border-slate-800 bg-gradient-to-r from-[#0B0F19] via-[#0E1322] to-[#0A0D15] shadow-2xl backdrop-blur-xl transition-all duration-300 focus:scale-[1.01] focus:border-amber-400 focus:ring-4 focus:ring-amber-400/40 focus:outline-none"
            >
              <div className="grid gap-6 p-6 lg:grid-cols-12">
                {/* Poster & Rank Badge */}
                <div className="relative lg:col-span-3">
                  <div className="relative aspect-[3/4] w-full overflow-hidden rounded-2xl border border-slate-800 bg-slate-950 shadow-xl">
                    <img
                      src={item.poster_url}
                      alt={item.title}
                      className="h-full w-full object-cover"
                    />
                    <div className="absolute top-3 left-3 flex h-9 w-9 items-center justify-center rounded-xl bg-amber-400 font-heading text-lg font-black text-slate-950 shadow-lg">
                      #{item.rank}
                    </div>
                    <div className="absolute top-3 right-3 rounded-full bg-black/75 px-2.5 py-1 text-[10px] font-black uppercase text-amber-300 backdrop-blur-md border border-white/10">
                      {item.region.replace("_", " ")}
                    </div>
                  </div>
                </div>

                {/* Main Detailed Stats */}
                <div className="flex flex-col justify-between space-y-4 lg:col-span-9">
                  <div>
                    <div className="flex flex-wrap items-center justify-between gap-2">
                      <div>
                        <div className="flex items-center gap-2">
                          <h2 className="font-heading text-2xl font-black text-white sm:text-3xl">
                            {item.title}
                          </h2>
                          <span className="rounded-lg bg-pink-500/20 px-2 py-0.5 text-[10px] font-black uppercase tracking-wider text-pink-300 border border-pink-500/30">
                            {item.category}
                          </span>
                        </div>
                        {item.original_title && (
                          <p className="text-xs font-semibold text-zinc-400">
                            {item.original_title} · Studio {item.studio}
                          </p>
                        )}
                      </div>
                      {/* Rating Pill */}
                      <div className="flex items-center gap-1.5 rounded-2xl border border-amber-400/40 bg-amber-400/10 px-3 py-1.5 text-amber-300">
                        <Star className="h-5 w-5 fill-amber-400 text-amber-400" />
                        <span className="font-heading text-lg font-black">{item.rating.toFixed(1)}</span>
                        <span className="text-[10px] text-zinc-400">/ 10</span>
                      </div>
                    </div>

                    <p className="mt-3 text-xs leading-relaxed text-zinc-300">
                      {item.description}
                    </p>

                    {/* Genres */}
                    <div className="mt-3 flex flex-wrap gap-1.5">
                      {item.genres.map((g) => (
                        <span
                          key={g}
                          className="rounded-lg bg-purple-500/15 px-2.5 py-1 text-[11px] font-bold text-purple-300 border border-purple-500/20"
                        >
                          {g}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* 4-Box Key Metrics Grid with Dynamic Currency */}
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-4 border-y border-slate-800/80 py-4">
                    <div className="rounded-xl border border-slate-800/80 bg-slate-900/50 p-3">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 flex items-center gap-1">
                        <DollarSign className="h-3 w-3 text-emerald-400" /> Box Office ({currency})
                      </span>
                      <p className="mt-1 font-heading text-base font-black text-emerald-400">
                        {displayedBoxOffice}
                      </p>
                    </div>

                    <div className="rounded-xl border border-slate-800/80 bg-slate-900/50 p-3">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 flex items-center gap-1">
                        <Ticket className="h-3 w-3 text-amber-400" /> Tickets Sold
                      </span>
                      <p className="mt-1 font-heading text-base font-black text-white">
                        {item.total_tickets_sold}
                      </p>
                    </div>

                    <div className="rounded-xl border border-slate-800/80 bg-slate-900/50 p-3">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 flex items-center gap-1">
                        <Clock className="h-3 w-3 text-sky-400" /> Runtime &amp; Cost
                      </span>
                      <p className="mt-1 text-xs font-bold text-zinc-200">
                        {item.duration_mins}m · Cost {displayedCost}
                      </p>
                    </div>

                    <div className="rounded-xl border border-slate-800/80 bg-slate-900/50 p-3">
                      <span className="text-[10px] font-bold uppercase tracking-wider text-zinc-500 flex items-center gap-1">
                        <Languages className="h-3 w-3 text-pink-400" /> Dubs Available
                      </span>
                      <p className="mt-1 text-xs font-bold text-pink-300">
                        {item.total_dubbed_languages} Languages ({item.original_language})
                      </p>
                    </div>
                  </div>

                  {/* Awards & Dubbed Languages */}
                  <div className="space-y-2 text-xs">
                    <div>
                      <span className="font-bold text-amber-300 flex items-center gap-1">
                        <Award className="h-3.5 w-3.5 text-amber-400" /> Total Awards Won ({item.awards_count}):
                      </span>
                      <p className="text-zinc-400 mt-0.5">
                        {item.awards.join(" · ")}
                      </p>
                    </div>

                    <div>
                      <span className="font-bold text-zinc-300">Dubbed Audio Tracks: </span>
                      <span className="text-zinc-400">{item.dubbed_languages.join(", ")}</span>
                    </div>
                  </div>

                  {/* Footer Official Links */}
                  <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-800/60 pt-3 text-xs">
                    <div className="flex items-center gap-4 text-zinc-400">
                      <span className="flex items-center gap-1">
                        <Mail className="h-3.5 w-3.5 text-zinc-500" />
                        <a href={`mailto:${item.official_email}`} className="text-amber-400 hover:underline">
                          {item.official_email}
                        </a>
                      </span>
                      <span className="text-zinc-600">·</span>
                      <span>Release: {item.release_date}</span>
                    </div>

                    <a
                      href={item.official_website}
                      target="_blank"
                      rel="noreferrer"
                      tabIndex={0}
                      className="inline-flex items-center gap-1 font-bold text-purple-400 hover:text-purple-300 hover:underline focus:ring-2 focus:ring-purple-400 rounded-md p-1"
                    >
                      <span>Visit Official Website</span>
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  </div>
                </div>
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
