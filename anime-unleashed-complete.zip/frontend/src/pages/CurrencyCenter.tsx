import { useState } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import {
  Coins,
  ArrowRightLeft,
  Send,
  Sparkles,
  Wallet,
  ShieldCheck,
  TrendingUp,
  AlertCircle,
  HelpCircle,
  History,
  Lock,
} from "lucide-react";
import { apiGet, apiPost, apiErrorMessage } from "@/lib/api";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { useMe } from "@/hooks/useAuth";
import { toast } from "sonner";

export default function CurrencyCenter() {
  const { data: me } = useMe();
  const qc = useQueryClient();

  // Convert VD or CF to LC
  const [fromCurr, setFromCurr] = useState<"VD" | "CF">("CF");
  const [convertAmount, setConvertAmount] = useState<number>(10);

  // Transfer Currency
  const [transferRecipient, setTransferRecipient] = useState("");
  const [transferCurr, setTransferCurr] = useState<"LC" | "CF">("LC");
  const [transferAmount, setTransferAmount] = useState<number>(10);

  // User Deposit
  const [depositOpen, setDepositOpen] = useState(false);
  const [depositAmount, setDepositAmount] = useState<number>(100);

  const depositMutation = useMutation({
    mutationFn: (amount: number) => apiPost("/vip/deposit", { amount }),
    onSuccess: (data: any) => {
      toast.success(data?.message || "₹ deposited successfully!");
      setDepositOpen(false);
      void qc.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err: any) => {
      toast.error(apiErrorMessage(err));
    },
  });

  const convertMutation = useMutation({
    mutationFn: (body: { from_currency: string; amount: number }) =>
      apiPost("/nft/convert-to-lc", body),
    onSuccess: (data: any) => {
      toast.success(data?.message || "Converted to LC successfully!");
      void qc.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err: any) => {
      toast.error(apiErrorMessage(err));
    },
  });

  const transferMutation = useMutation({
    mutationFn: (body: { recipient_email: string; currency: string; amount: number }) =>
      apiPost("/nft/transfer-currency", body),
    onSuccess: (data: any) => {
      toast.success(data?.message || "Currency transferred successfully!");
      setTransferRecipient("");
      setTransferAmount(10);
      void qc.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (err: any) => {
      toast.error(apiErrorMessage(err));
    },
  });

  const vdMinutes = Math.floor((me?.watch_balance_seconds || 0) / 60);

  return (
    <div className="mx-auto max-w-5xl px-4 py-8 sm:px-6 lg:px-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full border border-amber-500/30 bg-amber-500/10 px-3 py-1 text-xs font-bold text-amber-400">
            <Coins className="h-3.5 w-3.5" />
            <span>ZC / LC Economy &amp; Conversions</span>
          </div>
          <h1 className="mt-2 font-heading text-2xl sm:text-3xl font-black text-white">
            Wallet &amp; Currency Exchange
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400">
            Manage your LC (Market &amp; NFT Currency), CF, VD watch duration, and transfer credits to friends.
          </p>
        </div>

        <Button
          onClick={() => setDepositOpen(true)}
          className="h-10 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black shadow-lg shadow-emerald-500/20"
        >
          <Wallet className="mr-1.5 h-4 w-4 fill-slate-950" /> + Deposit Money
        </Button>
      </div>

      {/* Balance Cards */}
      <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        {/* Deposit Balance */}
        <Card className="border-slate-800 bg-[#07090E]/80">
          <CardContent className="p-4">
            <span className="text-[11px] font-bold text-zinc-400">Deposit Wallet (₹)</span>
            <p className="mt-1 font-heading text-2xl font-black text-emerald-400">
              ₹{me?.deposit_balance ?? 0}
            </p>
            <p className="text-[10px] text-zinc-500">Live donations &amp; tipping</p>
          </CardContent>
        </Card>

        {/* LC (ZC) Balance */}
        <Card className="border-amber-400/40 bg-gradient-to-b from-amber-500/10 to-transparent">
          <CardContent className="p-4">
            <span className="text-[11px] font-black text-amber-400">LC (ZC) Coins</span>
            <p className="mt-1 font-heading text-2xl font-black text-amber-300">
              {me?.lc_balance ?? 0} LC
            </p>
            <p className="text-[10px] text-zinc-400">Buy NFTs &amp; transfer</p>
          </CardContent>
        </Card>

        {/* CF Balance */}
        <Card className="border-slate-800 bg-[#07090E]/80">
          <CardContent className="p-4">
            <span className="text-[11px] font-bold text-zinc-400">CF Balance</span>
            <p className="mt-1 font-heading text-2xl font-black text-white">
              {me?.cf_balance ?? 0} CF
            </p>
            <p className="text-[10px] text-zinc-500">Converts 1 CF = 3 LC</p>
          </CardContent>
        </Card>

        {/* VD Minutes */}
        <Card className="border-slate-800 bg-[#07090E]/80">
          <CardContent className="p-4">
            <span className="text-[11px] font-bold text-zinc-400">VD Watch Time</span>
            <p className="mt-1 font-heading text-2xl font-black text-sky-400">
              {vdMinutes} mins
            </p>
            <p className="text-[10px] text-zinc-500">Converts 1 VD = 1 LC</p>
          </CardContent>
        </Card>
      </div>

      {/* Rules Notice */}
      <div className="mt-6 rounded-2xl border border-slate-800 bg-slate-900/40 p-4 text-xs text-zinc-300">
        <div className="flex items-center gap-2 font-bold text-amber-400">
          <Lock className="h-4 w-4" /> Currency Exchange Rules
        </div>
        <ul className="mt-2 space-y-1 text-zinc-400 list-disc list-inside text-[11px]">
          <li><strong>1 VD = 1 LC</strong> (Convert watch time minutes into LC coins)</li>
          <li><strong>1 CF = 3 LC</strong> (Convert 1 CF coin into 3 LC coins)</li>
          <li><strong>LC / ZC cannot be converted into VD or CF</strong> (Strict one-way minting rule)</li>
          <li>Use LC coins to buy anime NFTs, place auction bids, and send transfers to fellow fans.</li>
        </ul>
      </div>

      <div className="mt-6 grid gap-6 md:grid-cols-2">
        {/* CONVERT TO LC */}
        <Card className="border-slate-800 bg-card/70">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg font-bold text-white">
              <ArrowRightLeft className="h-4 w-4 text-amber-400" />
              Convert VD or CF into LC
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-xs">
            <div>
              <label className="font-bold text-zinc-400">Select Source Currency</label>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setFromCurr("CF")}
                  className={`rounded-xl border p-3 font-bold text-left transition-all ${
                    fromCurr === "CF"
                      ? "border-amber-400 bg-amber-400/15 text-amber-300"
                      : "border-slate-800 bg-slate-900/60 text-zinc-400"
                  }`}
                >
                  <p className="text-sm font-bold">From CF</p>
                  <p className="text-[10px] text-zinc-400">1 CF &rarr; 3 LC</p>
                </button>
                <button
                  type="button"
                  onClick={() => setFromCurr("VD")}
                  className={`rounded-xl border p-3 font-bold text-left transition-all ${
                    fromCurr === "VD"
                      ? "border-amber-400 bg-amber-400/15 text-amber-300"
                      : "border-slate-800 bg-slate-900/60 text-zinc-400"
                  }`}
                >
                  <p className="text-sm font-bold">From VD</p>
                  <p className="text-[10px] text-zinc-400">1 VD &rarr; 1 LC</p>
                </button>
              </div>
            </div>

            <div>
              <label className="font-bold text-zinc-400">Amount to convert</label>
              <Input
                type="number"
                min={1}
                value={convertAmount}
                onChange={(e) => setConvertAmount(Number(e.target.value))}
                className="mt-1 border-slate-700 bg-slate-900 text-sm text-white"
              />
              <p className="mt-1 text-[11px] text-amber-400 font-semibold">
                You will receive: {fromCurr === "CF" ? convertAmount * 3 : convertAmount} LC
              </p>
            </div>

            <Button
              onClick={() =>
                convertMutation.mutate({
                  from_currency: fromCurr,
                  amount: convertAmount,
                })
              }
              disabled={convertAmount <= 0 || convertMutation.isPending}
              className="w-full h-10 rounded-xl bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
            >
              Convert Now &rarr;
            </Button>
          </CardContent>
        </Card>

        {/* TRANSFER CURRENCY */}
        <Card className="border-slate-800 bg-card/70">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg font-bold text-white">
              <Send className="h-4 w-4 text-sky-400" />
              Transfer Currency to Another User
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4 text-xs">
            <div>
              <label className="font-bold text-zinc-400">Recipient User Email</label>
              <Input
                type="email"
                value={transferRecipient}
                onChange={(e) => setTransferRecipient(e.target.value)}
                placeholder="e.g. friend@gmail.com"
                className="mt-1 border-slate-700 bg-slate-900 text-xs text-white"
              />
            </div>

            <div>
              <label className="font-bold text-zinc-400">Select Currency</label>
              <div className="mt-2 grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setTransferCurr("LC")}
                  className={`rounded-xl border p-2 text-center font-bold transition-all ${
                    transferCurr === "LC"
                      ? "border-amber-400 bg-amber-400/15 text-amber-300"
                      : "border-slate-800 bg-slate-900/60 text-zinc-400"
                  }`}
                >
                  LC Coins
                </button>
                <button
                  type="button"
                  onClick={() => setTransferCurr("CF")}
                  className={`rounded-xl border p-2 text-center font-bold transition-all ${
                    transferCurr === "CF"
                      ? "border-amber-400 bg-amber-400/15 text-amber-300"
                      : "border-slate-800 bg-slate-900/60 text-zinc-400"
                  }`}
                >
                  CF Coins
                </button>
              </div>
            </div>

            <div>
              <label className="font-bold text-zinc-400">Amount</label>
              <Input
                type="number"
                min={1}
                value={transferAmount}
                onChange={(e) => setTransferAmount(Number(e.target.value))}
                className="mt-1 border-slate-700 bg-slate-900 text-sm text-white"
              />
            </div>

            <Button
              onClick={() =>
                transferMutation.mutate({
                  recipient_email: transferRecipient,
                  currency: transferCurr,
                  amount: transferAmount,
                })
              }
              disabled={!transferRecipient.trim() || transferAmount <= 0 || transferMutation.isPending}
              className="w-full h-10 rounded-xl bg-sky-500 font-bold text-white hover:bg-sky-400"
            >
              Send Transfer
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* DEPOSIT MODAL */}
      <Dialog open={depositOpen} onOpenChange={setDepositOpen}>
        <DialogContent className="border-slate-800 bg-[#0D121F] text-white sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="font-heading text-lg font-black text-white">
              Deposit Money to Your Account
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 pt-2 text-xs">
            <p className="text-zinc-400">
              Deposit money into your account. Use this deposited money to tip your favourite creators and send live stream donations.
            </p>
            <div className="grid grid-cols-4 gap-2">
              {[50, 100, 250, 500].map((amt) => (
                <button
                  type="button"
                  key={amt}
                  onClick={() => setDepositAmount(amt)}
                  className={`rounded-xl border p-2.5 text-center font-bold transition-all ${
                    depositAmount === amt
                      ? "border-emerald-400 bg-emerald-500/20 text-emerald-300"
                      : "border-slate-800 bg-slate-900/60 text-zinc-400"
                  }`}
                >
                  ₹{amt}
                </button>
              ))}
            </div>
            <Input
              type="number"
              min={1}
              value={depositAmount}
              onChange={(e) => setDepositAmount(Number(e.target.value))}
              className="border-slate-700 bg-slate-900 text-sm text-white"
            />
            <Button
              onClick={() => depositMutation.mutate(depositAmount)}
              disabled={depositAmount <= 0 || depositMutation.isPending}
              className="w-full h-11 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black"
            >
              Confirm Deposit of ₹{depositAmount} (Instant Demo Sandbox)
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
