import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { Episode, VideoLibItem } from "@/lib/types";

// Upload-once library — every stored video; admins attach without re-uploading.
export function useVideoLibrary(enabled = true) {
  return useQuery({
    queryKey: ["video-library"],
    queryFn: () => apiGet<VideoLibItem[]>("/videos/library"),
    enabled,
  });
}

// Convert system (video): one upload → 720p/480p/360p variants + audio-only track.
export function useConvertVideo() {
  const qc = useQueryClient();
  return useMutation<{ queued: string[]; audio: boolean }, Error, { episodeId: string; resolutions: string[]; extract_audio: boolean }>({
    mutationFn: ({ episodeId, resolutions, extract_audio }) =>
      apiPost(`/videos/${episodeId}/convert`, { resolutions, extract_audio }),
    onSuccess: (res) => {
      toast.success(`Conversion queued — ${[...res.queued, ...(res.audio ? ["audio"] : [])].join(", ")}`);
      void qc.invalidateQueries({ queryKey: ["admin", "episodes"] });
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}

// THE no-re-upload rule: point an episode at an already-stored video.
export function useAttachVideo() {
  const qc = useQueryClient();
  return useMutation<Episode, Error, { video_key: string; episode_id: string }>({
    mutationFn: (body) => apiPost("/videos/attach", body),
    onSuccess: () => {
      toast.success("Video attached — no re-upload needed");
      void qc.invalidateQueries({ queryKey: ["admin", "episodes"] });
      void qc.invalidateQueries({ queryKey: ["video-library"] });
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}
