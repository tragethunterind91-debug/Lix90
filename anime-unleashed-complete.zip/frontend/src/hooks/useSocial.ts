import { useQuery, useQueryClient, useMutation } from "@tanstack/react-query";
import { toast } from "sonner";
import { ApiError, apiGet, apiPatch, apiPost, apiDelete } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import { formatBalance } from "@/hooks/useQuota";
import type { AccountInfo, ChatMessage, Friend, FriendsOut, HistoryOut, Playlist, Region, Task } from "@/lib/types";

// ---- convert system: VD ↔ CF (1 CF = 3 min of watch-time) ----
export function useConvert() {
  const qc = useQueryClient();
  return useMutation<{ cf_balance: number; balance_seconds: number }, Error, { direction: "vd_to_cf" | "cf_to_vd"; amount: number }>({
    mutationFn: (body) => apiPost("/me/convert", body),
    onSuccess: (res, vars) => {
      toast.success(
        vars.direction === "vd_to_cf"
          ? `Converted — +${vars.amount ? Math.floor((vars.amount * 60) / 180) : 0} CF`
          : `Converted — +${formatBalance(vars.amount * 180)} watch-time`,
      );
      void qc.invalidateQueries({ queryKey: ["account"] });
      void qc.invalidateQueries({ queryKey: ["quota"] });
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}

// ---- account (ID no. / avatar / region / downgrade) ----
export function useAccount(enabled = true) {
  return useQuery({ queryKey: ["account"], queryFn: () => apiGet<AccountInfo>("/me/account"), enabled });
}

export function useUpdateAccount() {
  const qc = useQueryClient();
  return useMutation<AccountInfo, Error, Partial<{ display_name: string; avatar_url: string; country: Region; phone: string; downgrade_vip: boolean }>>({
    mutationFn: (body) => apiPatch<AccountInfo>("/me/account", body),
    onSuccess: (acc, vars) => {
      if (vars.downgrade_vip) toast.success("VIP downgraded — you can re-join any time");
      else toast.success("Profile updated");
      void qc.invalidateQueries({ queryKey: ["account"] });
      void qc.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}

// ---- friends ----
export function useFriends(enabled = true) {
  return useQuery({ queryKey: ["friends"], queryFn: () => apiGet<FriendsOut>("/friends"), enabled, refetchInterval: 15_000 });
}

export function useFriendRequest() {
  const qc = useQueryClient();
  return useMutation<{ to: string }, Error, string>({
    mutationFn: (account_id) => apiPost("/friends/request", { account_id }),
    onSuccess: (res) => {
      toast.success(`Friend request sent to ${res.to}`);
      void qc.invalidateQueries({ queryKey: ["friends"] });
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}

export function useFriendRespond() {
  const qc = useQueryClient();
  return useMutation<FriendsOut, Error, { request_id: string; action: "accept" | "decline" | "block" }>({
    mutationFn: (body) => apiPost("/friends/respond", body),
    onSuccess: (res, vars) => {
      toast.success(vars.action === "accept" ? "Friend added" : vars.action === "block" ? "Blocked" : "Request declined");
      void qc.invalidateQueries({ queryKey: ["friends"] });
      void qc.invalidateQueries({ queryKey: ["account"] });
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}

export function useUnfriend() {
  const qc = useQueryClient();
  return useMutation<null, Error, string>({
    mutationFn: (id) => apiDelete(`/friends/${id}`),
    onSuccess: () => {
      toast.success("Removed");
      void qc.invalidateQueries({ queryKey: ["friends"] });
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}

// ---- DMs (poll every 4s for the live feel) ----
export function useDm(peerId: string | null, enabled = true) {
  return useQuery({
    queryKey: ["dm", peerId],
    queryFn: () => apiGet<ChatMessage[]>(`/messages/dm/${peerId}`),
    enabled: enabled && !!peerId,
    refetchInterval: 4000,
  });
}

export function useSendDm(peerId: string | null) {
  const qc = useQueryClient();
  return useMutation<ChatMessage, Error, string>({
    mutationFn: (text) => apiPost("/messages/dm", { peer_id: peerId, text }),
    onSuccess: () => void qc.invalidateQueries({ queryKey: ["dm", peerId] }),
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}

// ---- global chat (region rooms; free users pay 3 min per message) ----
export function useGlobalChat(region: Region, enabled = true) {
  return useQuery({
    queryKey: ["gchat", region],
    queryFn: () => apiGet<ChatMessage[]>(`/messages/global/${region}`),
    enabled,
    refetchInterval: 3000,
  });
}

export function useSendGlobal(region: Region) {
  const qc = useQueryClient();
  return useMutation<ChatMessage, Error, string>({
    mutationFn: (text) => apiPost("/messages/global", { text, region }),
    onSuccess: () => {
      void qc.invalidateQueries({ queryKey: ["gchat", region] });
      void qc.invalidateQueries({ queryKey: ["quota"] }); // the 3-min ICF just left the wallet
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}

// ---- tasks (posted by admin; users apply BY EMAIL — no web claiming) ----
export function useTasks(enabled = true) {
  return useQuery({ queryKey: ["tasks"], queryFn: () => apiGet<Task[]>("/tasks"), enabled });
}

// ---- studio: task management ----
export function useAdminTasks() {
  return useQuery({ queryKey: ["studio", "tasks"], queryFn: () => apiGet<Task[]>("/admin/tasks") });
}

export function useCreateTask() {
  const qc = useQueryClient();
  return useMutation<Task, Error, { title: string; description: string; reward_seconds: number; expires_at: string | null; link_url?: string | null; link_label?: string }>({
    mutationFn: (body) => apiPost("/admin/tasks", body),
    onSuccess: (t) => {
      toast.success(`Task "${t.title}" live`);
      void qc.invalidateQueries({ queryKey: ["studio", "tasks"] });
      void qc.invalidateQueries({ queryKey: ["tasks"] });
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}

export function useDeleteTask() {
  const qc = useQueryClient();
  return useMutation<null, Error, string>({
    mutationFn: (id) => apiDelete(`/admin/tasks/${id}`),
    onSuccess: () => {
      toast.success("Task removed");
      void qc.invalidateQueries({ queryKey: ["studio", "tasks"] });
      void qc.invalidateQueries({ queryKey: ["tasks"] });
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}

export function useHistory(enabled: boolean) {
  return useQuery({
    queryKey: ["history"],
    queryFn: () => apiGet<HistoryOut>("/history"),
    enabled,
  });
}

export function useClearHistory() {
  const queryClient = useQueryClient();
  return useMutation<null, Error, void>({
    mutationFn: () => apiDelete("/history"),
    onSuccess: () => {
      toast.success("Watch history cleared");
      void queryClient.invalidateQueries({ queryKey: ["history"] });
    },
    onError: () => toast.error("Could not clear history"),
  });
}

export function usePlaylists(enabled: boolean) {
  return useQuery({
    queryKey: ["playlists"],
    queryFn: () => apiGet<Playlist[]>("/playlists"),
    enabled,
  });
}

export function usePlaylist(id: string | undefined) {
  return useQuery({
    queryKey: ["playlist", id],
    queryFn: () => apiGet<Playlist>(`/playlists/${id ?? ""}`),
    enabled: Boolean(id),
    retry: false,
  });
}

export function useCreatePlaylist() {
  const queryClient = useQueryClient();
  return useMutation<Playlist, Error, string>({
    mutationFn: (name) => apiPost<Playlist>("/playlists", { name }),
    onSuccess: () => {
      toast.success("Playlist created");
      void queryClient.invalidateQueries({ queryKey: ["playlists"] });
    },
    onError: () => toast.error("Could not create playlist"),
  });
}

export interface PlaylistPatch {
  id: string;
  name?: string;
  is_public?: boolean;
  add_title_id?: string;
  remove_title_id?: string;
}

export function useUpdatePlaylist() {
  const queryClient = useQueryClient();
  return useMutation<Playlist, Error, PlaylistPatch>({
    mutationFn: ({ id, ...patch }) => apiPatch<Playlist>(`/playlists/${id}`, patch),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["playlists"] });
      void queryClient.invalidateQueries({ queryKey: ["playlist"] });
    },
    onError: () => toast.error("Could not update playlist"),
  });
}

export function useDeletePlaylist() {
  const queryClient = useQueryClient();
  return useMutation<null, Error, string>({
    mutationFn: (id) => apiDelete(`/playlists/${id}`),
    onSuccess: () => {
      toast.success("Playlist deleted");
      void queryClient.invalidateQueries({ queryKey: ["playlists"] });
    },
    onError: () => toast.error("Could not delete playlist"),
  });
}
