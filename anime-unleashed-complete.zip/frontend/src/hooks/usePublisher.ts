import { useQuery } from "@tanstack/react-query";
import { apiGet } from "@/lib/api";
import type { GrowthStats } from "@/lib/types";

// GET /publisher/growth → the creator's YT-Studio-style growth screen.
export function useGrowth(enabled = true) {
  return useQuery({
    queryKey: ["publisher", "growth"],
    queryFn: () => apiGet<GrowthStats>("/publisher/growth"),
    enabled,
  });
}
