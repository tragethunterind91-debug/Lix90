import { useQuery } from "@tanstack/react-query";
import { apiGet } from "@/lib/api";
import type { Notice, PlatformConfig } from "@/lib/types";

// PUBLIC /platform → maintenance flag + the admin-editable VIP plan.
export function usePlatform(enabled = true) {
  return useQuery({
    queryKey: ["platform"],
    queryFn: () => apiGet<PlatformConfig>("/platform"),
    enabled,
    staleTime: 60_000,
  });
}

// PUBLIC /notices → admin posts; the user site shows the latest as a banner.
export function usePublicNotices() {
  return useQuery({ queryKey: ["notices"], queryFn: () => apiGet<Notice[]>("/notices") });
}
