import { useQuery } from "@tanstack/react-query";
import { apiGet } from "@/lib/api";
import type { QuotaInfo, RewardHistory } from "@/lib/types";

// /quota/me → the signed-in viewer's watch-time wallet. Guests (401) read as null.
export async function fetchQuota(): Promise<QuotaInfo | null> {
  try {
    return await apiGet<QuotaInfo>("/quota/me");
  } catch {
    return null;
  }
}

export function useQuota(enabled = true) {
  return useQuery({ queryKey: ["quota"], queryFn: fetchQuota, enabled, staleTime: 10_000 });
}

// The earn center's ledger: per-ad rewards + today/lifetime stats.
export function useRewardHistory(enabled = true) {
  return useQuery({
    queryKey: ["quota", "rewards"],
    queryFn: async () => {
      try {
        return await apiGet<RewardHistory>("/quota/reward-history");
      } catch {
        return null;
      }
    },
    enabled,
  });
}

// 3661 → "1h 01m" · 249 → "4m 09s" · 42 → "42s"
export function formatBalance(seconds: number): string {
  const s = Math.max(0, Math.floor(seconds));
  const h = Math.floor(s / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  if (h > 0) return `${h}h ${String(m).padStart(2, "0")}m`;
  if (m > 0) return `${m}m ${String(sec).padStart(2, "0")}s`;
  return `${sec}s`;
}
