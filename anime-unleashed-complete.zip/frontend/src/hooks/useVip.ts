import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiErrorMessage } from "@/lib/errors";
import { apiGet, apiPost } from "@/lib/api";
import type { VipOrder, VipStatus } from "@/lib/types";

export function useVipStatus(enabled: boolean) {
  return useQuery<VipStatus>({
    queryKey: ["vip", "status"],
    queryFn: () => apiGet<VipStatus>("/vip/status"),
    enabled,
  });
}

export function useVipOrder() {
  return useMutation<VipOrder, Error>({
    mutationFn: () => apiPost<VipOrder>("/vip/order", {}),
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

export function useVipVerify() {
  const qc = useQueryClient();
  return useMutation<VipStatus, Error, string>({
    mutationFn: (orderId) => apiPost<VipStatus>("/vip/verify", { order_id: orderId }),
    onSuccess: () => {
      toast.success("VIP activated — ad-free for a year!");
      void qc.invalidateQueries({ queryKey: ["vip", "status"] });
      void qc.invalidateQueries({ queryKey: ["me"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}
