import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useNavigate } from "react-router-dom";
import { toast } from "sonner";
import { apiDelete, apiGet, apiPost } from "@/lib/api";
import { useMe } from "@/hooks/useAuth";
import type { Title, Watchlist } from "@/lib/types";

export function useWatchlist(enabled: boolean) {
  return useQuery({
    queryKey: ["watchlist"],
    queryFn: () => apiGet<Watchlist>("/watchlist"),
    enabled,
  });
}

export function useToggleWatchlist() {
  const queryClient = useQueryClient();
  return useMutation<Watchlist, Error, { titleId: string; add: boolean }>({
    mutationFn: ({ titleId, add }) =>
      add
        ? apiPost<Watchlist>("/watchlist", { title_id: titleId })
        : apiDelete<Watchlist>(`/watchlist/${titleId}`),
    onSuccess: (_data, variables) => {
      void queryClient.invalidateQueries({ queryKey: ["watchlist"] });
      toast.success(variables.add ? "Added to My List" : "Removed from My List");
    },
    onError: () => toast.error("Could not update your list"),
  });
}

// Shared card handler: guests are nudged to sign in; users get an optimistic toggle.
export function useToggleListGuard() {
  const { data: me } = useMe();
  const { data: watchlist } = useWatchlist(Boolean(me));
  const toggle = useToggleWatchlist();
  const navigate = useNavigate();

  const inList = (titleId: string) => (watchlist?.ids ?? []).includes(titleId);
  const handle = (title: Title) => {
    if (!me) {
      toast.info("Sign in to build your list");
      navigate("/login");
      return;
    }
    toggle.mutate({ titleId: title.id, add: !inList(title.id) });
  };
  return { inList, handle, me, watchlist };
}
