import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiDelete, apiGet, apiPatch, apiPost, apiPut } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type {
  AdminUser,
  AdminUserDetail,
  AirdropResult,
  GrowthStats,
  Notice,
  PlatformConfig,
} from "@/lib/types";

// ---- per-user controls (ban / grant / feature flags) ----
export function useBanUser() {
  const qc = useQueryClient();
  return useMutation<null, Error, { id: string; ban: boolean }>({
    mutationFn: ({ id, ban }) => apiPost(`/admin/users/${id}/${ban ? "ban" : "unban"}`),
    onSuccess: (_data, vars) => {
      toast.success(vars.ban ? "Account banned" : "Account unbanned");
      void qc.invalidateQueries({ queryKey: ["studio", "users"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

export function useGrantUser() {
  const qc = useQueryClient();
  return useMutation<AdminUser, Error, { id: string; watch_minutes: number; vip_days: number; cf: number; lc?: number }>({
    mutationFn: ({ id, ...body }) => apiPost<AdminUser>(`/admin/users/${id}/grant`, body),
    onSuccess: (user) => {
      toast.success(`Credits applied for ${user.email}`);
      void qc.invalidateQueries({ queryKey: ["studio", "users"] });
      void qc.invalidateQueries({ queryKey: ["studio", "user"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

export function useToggleUserFeature() {
  const qc = useQueryClient();
  return useMutation<AdminUser, Error, { id: string; key: string; enabled: boolean }>({
    mutationFn: ({ id, key, enabled }) => apiPatch<AdminUser>(`/admin/users/${id}/features`, { key, enabled }),
    onSuccess: (user) => {
      toast.success(`Features updated for ${user.email}`);
      void qc.invalidateQueries({ queryKey: ["studio", "users"] });
      void qc.invalidateQueries({ queryKey: ["studio", "user"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

export function useUserDetail(id: string | null) {
  return useQuery({
    queryKey: ["studio", "user", id],
    queryFn: () => apiGet<AdminUserDetail>(`/admin/users/${id}`),
    enabled: !!id,
  });
}

// ---- platform: maintenance / vip plan / airdrop / notices ----
export function useUpdatePlatform() {
  const qc = useQueryClient();
  return useMutation<
    PlatformConfig,
    Error,
    { maintenance?: boolean; vip_plan?: { price_inr: number; duration_days: number; features: string[] } }
  >({
    mutationFn: (body) => apiPut<PlatformConfig>("/admin/platform", body),
    onSuccess: (data) => {
      toast.success("Platform settings saved");
      qc.setQueryData(["platform"], data); // instant cache sync — no refetch race
      void qc.invalidateQueries({ queryKey: ["platform"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

export function useAirdrop() {
  return useMutation<AirdropResult, Error, { watch_minutes: number; cf: number }>({
    mutationFn: (body) => apiPost<AirdropResult>("/admin/airdrop", body),
    onSuccess: (result) => toast.success(`Airdropped to ${result.users} accounts`),
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

export function useAdminNotices() {
  return useQuery({ queryKey: ["studio", "notices"], queryFn: () => apiGet<Notice[]>("/admin/notices") });
}

export function useCreateNotice() {
  const qc = useQueryClient();
  return useMutation<Notice, Error, { title: string; body: string }>({
    mutationFn: (body) => apiPost<Notice>("/admin/notices", body),
    onSuccess: () => {
      toast.success("Notice posted");
      void qc.invalidateQueries({ queryKey: ["studio", "notices"] });
      void qc.invalidateQueries({ queryKey: ["notices"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

export function useDeleteNotice() {
  const qc = useQueryClient();
  return useMutation<null, Error, string>({
    mutationFn: (id) => apiDelete(`/admin/notices/${id}`),
    onSuccess: () => {
      toast.success("Notice deleted");
      void qc.invalidateQueries({ queryKey: ["studio", "notices"] });
      void qc.invalidateQueries({ queryKey: ["notices"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

// ---- global analytics for the console ----
export function useAdminAnalytics() {
  return useQuery({
    queryKey: ["studio", "analytics"],
    queryFn: () => apiGet<GrowthStats>("/admin/analytics"),
  });
}
