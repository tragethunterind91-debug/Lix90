import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiGet, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { CryptoInvoice, CryptoStatus } from "@/lib/types";

// Real crypto checkout (Cryptomus). The server owns prices and signature
// verification — the browser only ever receives the hosted payment URL.
export function useCryptoInvoice() {
  return useMutation<CryptoInvoice, Error, { planId: string }>({
    mutationFn: ({ planId }) => apiPost<CryptoInvoice>("/vip/crypto/invoice", { plan_id: planId }),
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}

export function useCryptoStatus(orderId: string | null, enabled = true) {
  return useQuery({
    queryKey: ["vip", "crypto", orderId],
    queryFn: () => apiGet<CryptoStatus>(`/vip/crypto/status/${orderId}`),
    enabled: enabled && !!orderId,
    refetchInterval: 5000,
  });
}
