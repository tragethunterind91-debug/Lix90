import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { toast } from "sonner";
import { apiDelete, apiGet, apiPatch, apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import type { AdminUser, FeedbackItem, OwnerOverview, RevenueEntries, SupplierApplication, SupplierSubmission } from "@/lib/types";

// ---- users (add admins, promote/demote, delete) ----
export function useStudioUsers() {
  return useQuery({ queryKey: ["studio", "users"], queryFn: () => apiGet<AdminUser[]>("/admin/users") });
}

export function useCreateStudioUser() {
  const queryClient = useQueryClient();
  return useMutation<AdminUser, Error, { email: string; password: string; display_name: string; role: string }>({
    mutationFn: (input) => apiPost<AdminUser>("/admin/users", input),
    onSuccess: (user) => {
      toast.success(`Account created: ${user.email} (${user.role})`);
      void queryClient.invalidateQueries({ queryKey: ["studio", "users"] });
      void queryClient.invalidateQueries({ queryKey: ["admin", "stats"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

export function useUpdateUserRole() {
  const queryClient = useQueryClient();
  return useMutation<AdminUser, Error, { id: string; role: string }>({
    mutationFn: ({ id, role }) => apiPatch<AdminUser>(`/admin/users/${id}`, { role }),
    onSuccess: (user) => {
      toast.success(`${user.email} is now ${user.role === "admin" ? "an admin" : "a viewer"}`);
      void queryClient.invalidateQueries({ queryKey: ["studio", "users"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

export function useDeleteStudioUser() {
  const queryClient = useQueryClient();
  return useMutation<null, Error, string>({
    mutationFn: (id) => apiDelete(`/admin/users/${id}`),
    onSuccess: () => {
      toast.success("Account deleted with all its data");
      void queryClient.invalidateQueries({ queryKey: ["studio", "users"] });
      void queryClient.invalidateQueries({ queryKey: ["admin", "stats"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

// ---- revenue ledger (profit) ----
export function useRevenue() {
  return useQuery({ queryKey: ["studio", "revenue"], queryFn: () => apiGet<RevenueEntries>("/admin/revenue") });
}

export function useAddRevenue() {
  const queryClient = useQueryClient();
  return useMutation<never, Error, { amount: number; note: string }>({
    mutationFn: (input) => apiPost("/admin/revenue", input),
    onSuccess: () => {
      toast.success("Revenue entry added");
      void queryClient.invalidateQueries({ queryKey: ["studio", "revenue"] });
      void queryClient.invalidateQueries({ queryKey: ["admin", "stats"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

export function useDeleteRevenue() {
  const queryClient = useQueryClient();
  return useMutation<null, Error, string>({
    mutationFn: (id) => apiDelete(`/admin/revenue/${id}`),
    onSuccess: () => {
      toast.success("Entry removed");
      void queryClient.invalidateQueries({ queryKey: ["studio", "revenue"] });
      void queryClient.invalidateQueries({ queryKey: ["admin", "stats"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

// ---- supplier program (applications + submissions review) ----
export function useSupplierApplications() {
  return useQuery({
    queryKey: ["studio", "supplier-apps"],
    queryFn: () => apiGet<SupplierApplication[]>("/admin/supplier/applications"),
  });
}

export function useDecideApplication() {
  const queryClient = useQueryClient();
  return useMutation<SupplierApplication, Error, { id: string; status: "approved" | "rejected"; admin_note?: string }>({
    mutationFn: ({ id, status, admin_note }) =>
      apiPatch<SupplierApplication>(`/admin/supplier/applications/${id}`, {
        status,
        admin_note: admin_note ?? "",
      }),
    onSuccess: (app) => {
      toast.success(app.status === "approved" ? `${app.email} approved — Creator Desk access granted` : "Application rejected");
      void queryClient.invalidateQueries({ queryKey: ["studio", "supplier-apps"] });
      void queryClient.invalidateQueries({ queryKey: ["studio", "users"] });
      void queryClient.invalidateQueries({ queryKey: ["studio", "owner"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

export function useSupplierSubmissions() {
  return useQuery({
    queryKey: ["studio", "supplier-subs"],
    queryFn: () => apiGet<SupplierSubmission[]>("/admin/supplier/submissions"),
  });
}

export function useDecideSubmission() {
  const queryClient = useQueryClient();
  return useMutation<SupplierSubmission, Error, { id: string; status: "approved" | "rejected"; admin_note?: string }>({
    mutationFn: ({ id, status, admin_note }) =>
      apiPatch<SupplierSubmission>(`/admin/supplier/submissions/${id}`, {
        status,
        admin_note: admin_note ?? "",
      }),
    onSuccess: (sub) => {
      toast.success(
        sub.status === "approved"
          ? `"${sub.title}" converted to a draft — finish it in Catalog`
          : "Submission rejected",
      );
      void queryClient.invalidateQueries({ queryKey: ["studio", "supplier-subs"] });
      void queryClient.invalidateQueries({ queryKey: ["titles"] });
      void queryClient.invalidateQueries({ queryKey: ["studio", "owner"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

// ---- super admin (owner seat) ----
export function useOwnerOverview() {
  return useQuery({
    queryKey: ["studio", "owner"],
    queryFn: () => apiGet<OwnerOverview>("/admin/owner/overview"),
  });
}

export function usePurgeStale() {
  const queryClient = useQueryClient();
  return useMutation<{ removed: number; names: string[] }, Error, void>({
    mutationFn: () => apiPost("/admin/supplier/purge-stale"),
    onSuccess: (res) => {
      toast.success(`${res.removed} stale supplier title${res.removed === 1 ? "" : "s"} removed`);
      void queryClient.invalidateQueries({ queryKey: ["studio", "owner"] });
      void queryClient.invalidateQueries({ queryKey: ["titles"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

// ---- feedback inbox ----
export function useStudioFeedback() {
  return useQuery({ queryKey: ["studio", "feedback"], queryFn: () => apiGet<FeedbackItem[]>("/admin/feedback") });
}

export function useResolveFeedback() {
  const queryClient = useQueryClient();
  return useMutation<FeedbackItem, Error, { id: string; resolved: boolean }>({
    mutationFn: ({ id, resolved }) => apiPatch<FeedbackItem>(`/admin/feedback/${id}`, { resolved }),
    onSuccess: () => {
      void queryClient.invalidateQueries({ queryKey: ["studio", "feedback"] });
      void queryClient.invalidateQueries({ queryKey: ["admin", "stats"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

export function useDeleteFeedback() {
  const queryClient = useQueryClient();
  return useMutation<null, Error, string>({
    mutationFn: (id) => apiDelete(`/admin/feedback/${id}`),
    onSuccess: () => {
      toast.success("Feedback deleted");
      void queryClient.invalidateQueries({ queryKey: ["studio", "feedback"] });
      void queryClient.invalidateQueries({ queryKey: ["admin", "stats"] });
    },
    onError: (error) => toast.error(apiErrorMessage(error)),
  });
}

// ---- publisher channel verification (Test 1 → 2 → 3; every result is emailed) ----
export function useVerifyApplication() {
  const queryClient = useQueryClient();
  return useMutation<SupplierApplication, Error, { id: string; test: number; passed: boolean; note?: string }>({
    mutationFn: ({ id, test, passed, note }) =>
      apiPost<SupplierApplication>(`/supplier/applications/${id}/verify`, { test, passed, note: note ?? "" }),
    onSuccess: (app) => {
      toast.success(
        app.status === "approved"
          ? "All 3 tests passed — publisher approved + welcome email sent"
          : "Test result saved — the creator has been emailed",
      );
      void queryClient.invalidateQueries({ queryKey: ["studio", "supplier-apps"] });
      void queryClient.invalidateQueries({ queryKey: ["studio", "users"] });
    },
    onError: (e) => toast.error(apiErrorMessage(e)),
  });
}
