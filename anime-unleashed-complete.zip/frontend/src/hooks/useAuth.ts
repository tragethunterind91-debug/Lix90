import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ApiError, apiGet, apiPost } from "@/lib/api";
import { beginSession, endSession } from "@/lib/session";
import { firebaseGoogleSignIn, firebaseSignIn, firebaseSignUp } from "@/lib/firebase";
import type { UserPublic } from "@/lib/types";

// /auth/me answers "who am I" from the httpOnly cookie; guests get null (401 swallowed).
export async function fetchMe(): Promise<UserPublic | null> {
  try {
    return await apiGet<UserPublic>("/auth/me");
  } catch (error) {
    if (error instanceof ApiError && error.status === 401) return null;
    throw error;
  }
}

export function useMe() {
  return useQuery({ queryKey: ["me"], queryFn: fetchMe, staleTime: 60_000 });
}

export interface LoginInput {
  email: string;
  password: string;
  pin?: string;
  totp_code?: string;
}

export interface RegisterInput extends Omit<LoginInput, "pin" | "totp_code"> {
  display_name: string;
}

export interface FirebaseInput extends LoginInput {
  display_name?: string | null;
}

function useSessionMutation<TInput, TOut>(fn: (input: TInput) => Promise<TOut>) {
  const queryClient = useQueryClient();
  return useMutation<TOut, ApiError, TInput>({
    mutationFn: fn,
    onSuccess: () => {
      beginSession();
      void queryClient.invalidateQueries({ queryKey: ["me"] });
    },
  });
}

export function useLogin() {
  return useSessionMutation<LoginInput, UserPublic>((input) =>
    apiPost<UserPublic>("/auth/login", input),
  );
}

export function useRegister() {
  return useSessionMutation<RegisterInput, UserPublic>((input) =>
    apiPost<UserPublic>("/auth/register", input),
  );
}

export function useFirebaseLogin() {
  return useSessionMutation<FirebaseInput, UserPublic>(async ({ email, password, pin, totp_code }) => {
    const user = await firebaseSignIn(email, password);
    const idToken = await user.getIdToken();
    return apiPost<UserPublic>("/auth/firebase-login", {
      id_token: idToken,
      display_name: user.displayName,
      pin,
      totp_code,
    });
  });
}

export function useGoogleLogin() {
  return useSessionMutation<{ pin?: string; totp_code?: string }, UserPublic>(async ({ pin, totp_code }) => {
    const user = await firebaseGoogleSignIn();
    const idToken = await user.getIdToken();
    return apiPost<UserPublic>("/auth/firebase-login", {
      id_token: idToken,
      display_name: user.displayName,
      pin,
      totp_code,
    });
  });
}

export function useFirebaseRegister() {
  return useSessionMutation<RegisterInput, UserPublic>(async ({ email, password, display_name }) => {
    const user = await firebaseSignUp(email, password, display_name);
    const idToken = await user.getIdToken();
    return apiPost<UserPublic>("/auth/firebase-login", {
      id_token: idToken,
      display_name: user.displayName ?? display_name,
    });
  });
}

export function useLogout() {
  return useMutation({ mutationFn: async () => endSession("/") });
}
