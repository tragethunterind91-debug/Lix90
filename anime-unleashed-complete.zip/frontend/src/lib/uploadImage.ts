import { apiPost } from "@/lib/api";

// Direct image upload (poster / episode thumbnail) through the backend's media
// disk — the same path videos take. Returns the API-served URL to store in forms.
export async function uploadImage(file: File): Promise<{ url: string }> {
  const form = new FormData();
  form.append("file", file);
  return apiPost<{ url: string }>("/uploads/image", form);
}
