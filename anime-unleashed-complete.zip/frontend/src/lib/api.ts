// Typed fetch layer over the FastAPI backend. Base is the relative "/api" prefix so the
// same code works in dev (Vite proxies /api → :8001). For production builds set
// VITE_API_BASE to the deployed backend origin (e.g. https://api.anime-unleashed.in).
export const API_BASE: string = import.meta.env.VITE_API_BASE ?? "";
const BASE = `${API_BASE}/api`;

// Prefix backend-relative URLs (video stream, media images) with the API base —
// external URLs (AniList posters) pass through untouched. In dev this is a no-op.
export function mediaUrl(url: string | null | undefined): string {
  if (!url) return "";
  if (url.startsWith("/api/")) return `${API_BASE}${url}`;
  return url;
}

// Fields are declared, not constructor parameter properties: tsconfig sets
// erasableSyntaxOnly, which rejects `constructor(readonly status: number)`.
export class ApiError extends Error {
  status: number;
  body: unknown;

  constructor(status: number, body: unknown) {
    super(`request failed with ${status}`);
    this.name = "ApiError";
    this.status = status;
    this.body = body;
  }
}

type JsonBody = unknown;

async function request<T>(method: string, path: string, body?: JsonBody): Promise<T> {
  // Auth rides the httpOnly session cookie automatically — never add auth headers here.
  // credentials:"include" keeps it working cross-origin (frontend on Firebase Hosting,
  // API on its own domain) once the backend's CORS_ORIGINS lists the frontend URL.
  const res = await fetch(`${BASE}${path}`, {
    method,
    credentials: "include",
    headers: body === undefined ? undefined : { "Content-Type": "application/json" },
    body: body === undefined ? undefined : JSON.stringify(body),
  });

  // FastAPI reports request-validation failures as 422 with a {detail: [...]} body.
  if (!res.ok) {
    const errBody = await res.json().catch(() => null);
    throw new ApiError(res.status, errBody);
  }

  if (res.status === 204) return undefined as T;
  return (await res.json()) as T;
}

// The response type is yours to declare: nothing infers across the Python boundary, so a
// TS interface here mirrors the endpoint's Pydantic model by hand — keep the two in sync.
export const apiGet = <T>(path: string) => request<T>("GET", path);
export const apiPost = <T>(path: string, body?: JsonBody) => request<T>("POST", path, body ?? null);

// Binary download (subtitles) — returns the raw file as a Blob for <a download>.
export async function apiGetBlob(path: string): Promise<Blob> {
  const res = await fetch(`${BASE}${path}`, { credentials: "include" });
  if (!res.ok) throw new ApiError(res.status, await res.text().catch(() => ""));
  return res.blob();
}
export const apiPut = <T>(path: string, body?: JsonBody) => request<T>("PUT", path, body ?? null);
export const apiPatch = <T>(path: string, body?: JsonBody) =>
  request<T>("PATCH", path, body ?? null);
export const apiDelete = <T>(path: string) => request<T>("DELETE", path);

export function apiErrorMessage(err: unknown): string {
  if (err instanceof ApiError) {
    if (typeof err.body === "string") return err.body;
    if (err.body && typeof err.body === "object") {
      const b = err.body as Record<string, any>;
      if (typeof b.detail === "string") return b.detail;
      if (Array.isArray(b.detail) && b.detail[0]?.msg) return b.detail[0].msg;
      if (typeof b.message === "string") return b.message;
    }
    return `Error (${err.status})`;
  }
  if (err instanceof Error) return err.message;
  return "An unexpected error occurred";
}
