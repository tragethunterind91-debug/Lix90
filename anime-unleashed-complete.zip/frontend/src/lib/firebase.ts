// Firebase (client) — configured for email+password and Google Sign-In
import { initializeApp } from "firebase/app";
import {
  createUserWithEmailAndPassword,
  getAuth,
  GoogleAuthProvider,
  signInWithEmailAndPassword,
  signInWithPopup,
  updateProfile,
  type User,
} from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyB4schfTAkTHFm8HEUZATwEcJ4nJEpZPV8",
  authDomain: "anime-unleashed.firebaseapp.com",
  projectId: "anime-unleashed",
  storageBucket: "anime-unleashed.firebasestorage.app",
  messagingSenderId: "959223857795",
  appId: "1:959223857795:web:70feb20373ae2c092e91b6",
};

const app = initializeApp(firebaseConfig);
export const firebaseAuth = getAuth(app);
const googleProvider = new GoogleAuthProvider();

export async function firebaseSignUp(
  email: string,
  password: string,
  displayName: string,
): Promise<User> {
  const cred = await createUserWithEmailAndPassword(firebaseAuth, email, password);
  if (displayName) await updateProfile(cred.user, { displayName });
  return cred.user;
}

export async function firebaseSignIn(email: string, password: string): Promise<User> {
  return (await signInWithEmailAndPassword(firebaseAuth, email, password)).user;
}

export async function firebaseGoogleSignIn(): Promise<User> {
  const result = await signInWithPopup(firebaseAuth, googleProvider);
  return result.user;
}

export function firebaseErrorMessage(error: unknown): string {
  const code = (error as { code?: string })?.code ?? "";
  switch (code) {
    case "auth/invalid-credential":
    case "auth/user-not-found":
    case "auth/wrong-password":
      return "Wrong email or password";
    case "auth/email-already-in-use":
      return "That email already has an account — sign in instead";
    case "auth/weak-password":
      return "Password too weak — use at least 6 characters";
    case "auth/popup-closed-by-user":
      return "Sign-in popup was closed before completing";
    default:
      return "Authentication failed — please try again";
  }
}
