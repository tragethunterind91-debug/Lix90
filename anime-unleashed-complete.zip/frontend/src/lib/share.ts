import { toast } from "sonner";

// Native share sheet when available (mobile), clipboard fallback on desktop.
export async function shareLink(url: string, title?: string): Promise<void> {
  const nav = window.navigator as Navigator & {
    share?: (data: { title?: string; url: string }) => Promise<void>;
  };
  try {
    if (typeof nav.share === "function") {
      await nav.share({ title, url });
      return;
    }
    await navigator.clipboard.writeText(url);
    toast.success("Link copied to clipboard");
  } catch {
    // user closed the share sheet — nothing to do
  }
}
