// Single source of truth for title-kind presentation — theme class, label, etc.
// Keep in sync with backend ContentKind (Literal in models/catalog.py).
export type TitleKind = "anime" | "movie" | "cartoon" | "kdrama" | "webseries";

export const KIND_THEME_CLASS: Record<TitleKind, string> = {
  anime: "theme-anime",
  movie: "theme-movie",
  cartoon: "theme-cartoon",
  kdrama: "theme-kdrama",
  webseries: "theme-webseries",
};

export const KIND_LABELS: Record<TitleKind, string> = {
  anime: "Anime",
  movie: "Movie",
  cartoon: "Cartoon",
  kdrama: "K-Drama",
  webseries: "Web Series",
};

export const KIND_WATERMARKS: Record<TitleKind, string> = {
  anime: "アニメ・ゾーン",
  movie: "シネマ・ワールド",
  cartoon: "トゥーン・ワールド",
  kdrama: "한국 드라마",
  webseries: "वेब सीरीज़",
};

export function themeClassFor(kind: string): string {
  return (KIND_THEME_CLASS as Record<string, string>)[kind] ?? "";
}

export function labelFor(kind: string): string {
  return (KIND_LABELS as Record<string, string>)[kind] ?? kind;
}
