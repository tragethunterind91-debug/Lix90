// Hand-written mirrors of the Pydantic models in backend/models/catalog.py and
// backend/models/auth.py — nothing infers across the HTTP boundary, keep in sync.

export interface UserPublic {
  id: string;
  email: string;
  display_name: string;
  role: string;
  vip_until: string | null;
  is_owner: boolean;
  phone?: string | null;
  phone_verified?: boolean;
  cf_balance?: number;
  lc_balance?: number;
  deposit_balance?: number;
  watch_balance_seconds?: number;
}

export type TitleType = "series" | "movie" | "short" | "documentary" | "thriller" | "ova";
export type TitleKind = "anime" | "movie" | "cartoon" | "kdrama" | "webseries";
export type PublishStatus = "published" | "draft";
export type TitleVisibility = "listed" | "upcoming";

export interface Title {
  id: string;
  slug: string;
  name: string;
  synopsis: string;
  description?: string;
  genres: string[];
  release_year: number;
  type: TitleType;
  kind: TitleKind;
  studio: string;
  age_rating: string;
  original_language: string;
  airing_status: string;
  audio: string[];
  rating: number | null;
  supplier_email?: string | null;
  featured: boolean;
  poster_url: string;
  status: PublishStatus;
  visibility?: TitleVisibility | null;
  release_at?: string | null;
  episode_count: number;
  views: number;
  created_at: string;
}

export interface Episode {
  id: string;
  title_id: string;
  number: number;
  name: string;
  description: string;
  source: string;
  video_key: string;
  size_bytes: number;
  duration_seconds: number | null;
  status: PublishStatus;
  season: number;
  resolution: string | null;
  dub_tag: string | null;
  thumbnail_url: string | null;
  audio_key: string | null;
  subtitle_key: string | null;
  subtitle_variants: Record<string, string>;
  video_variants?: Record<string, VideoVariant>;
  created_at: string;
}

export interface TitleDetail extends Title {
  episodes: Episode[];
}

export interface TitleIn {
  name: string;
  synopsis: string;
  genres: string[];
  release_year: number;
  type: TitleType;
  kind: TitleKind;
  studio: string;
  age_rating: string;
  original_language: string;
  airing_status: string;
  audio: string[];
  rating: number | null;
  featured: boolean;
  poster_url: string;
  status: PublishStatus;
  visibility?: TitleVisibility | null;
  release_at?: string | null;
}

export interface EpisodeIn {
  number: number;
  season: number;
  name: string;
  description: string;
  source: string;
  video_key: string;
  duration_seconds: number | null;
  status: PublishStatus;
  resolution: string | null;
  dub_tag: string | null;
  thumbnail_url: string | null;
}

export interface UploadOut {
  video_key: string;
  size_bytes: number;
  content_type: string;
}

export interface DownloadLink {
  url: string;
  expires_at: string;
  watermark?: string;
}

export interface AdminStats {
  titles: number;
  episodes: number;
  users: number;
  total_views: number;
  total_profit: number;
  total_visits: number;
  feedback_open: number;
}

// ---- studio admin ----
export interface AdminUser {
  id: string;
  email: string;
  display_name: string;
  role: string;
  firebase_uid: string | null;
  vip_until: string | null;
  is_owner: boolean;
  created_at: string;
  account_id?: string | null;
  country?: string | null;
  region?: string | null;
  watch_balance_seconds?: number | null;
  cf_balance?: number | null;
  banned?: boolean;
  features?: Record<string, boolean>;
}

export interface AdminHistoryRow {
  id: string;
  episode_id: string;
  title_id: string;
  episode_number?: number;
  position_seconds?: number;
  updated_at: string;
}

export interface AdminUserDetail extends AdminUser {
  views: number;
  watch_minutes: number;
  downloads: number;
  history: AdminHistoryRow[];
}

// ---- growth analytics (publisher YT-Studio screen + admin console) ----
export interface GrowthTotals {
  views: number;
  watch_minutes: number;
  watch_hours: number;
  downloads_video: number;
  downloads_audio: number;
  downloads_subtitle: number;
  downloads_total: number;
}

export interface GrowthStats {
  totals: GrowthTotals;
  uploads: number;
  subscribers?: number;
  trend_pct: number;
  daily: { date: string; views: number }[];
  monthly: { month: string; views: number }[];
  locations: { country: string; views: number }[];
}

// ---- platform config (maintenance / VIP plan / notices) ----
export interface Notice {
  id: string;
  title: string;
  body: string;
  created_at: string;
}

export interface VipPlan {
  price_inr: number;
  duration_days: number;
  features: string[];
}

export interface PlatformConfig {
  maintenance: boolean;
  vip_plan: VipPlan;
}

export interface AirdropResult {
  users: number;
}

// ---- earn center (watch rewarded ads → view duration) ----
export interface RewardHistory {
  items: { created_at: string; minutes: number }[];
  total_ads: number;
  minutes_total: number;
  ads_today: number;
  minutes_today: number;
}

export interface AuditEntry {
  id: string;
  actor: string;
  action: string;
  target: string;
  created_at: string;
}

export interface RevenueEntry {
  id: string;
  amount: number;
  note: string;
  created_at: string;
}

export interface RevenueEntries {
  entries: RevenueEntry[];
  total: number;
}

export interface FeedbackItem {
  id: string;
  name: string;
  email: string | null;
  message: string;
  resolved: boolean;
  created_at: string;
}

// ---- VIP pass (fake Razorpay flow — see backend/routers/payments.py) ----
export interface VipOrder {
  order_id: string;
  amount: number; // paise
  currency: string;
  key_id: string;
  test_mode: boolean;
}

export interface VipStatus {
  active: boolean;
  until: string | null;
}

// ---- AniList import ----
export interface AniListResult {
  anilist_id: number;
  name: string;
  name_english: string | null;
  synopsis: string;
  genres: string[];
  release_year: number | null;
  type: string;
  episodes_count: number;
  rating: number;
  poster_url: string;
  source: "anilist" | "offline";
}

export interface ImageUploadOut {
  url: string;
}

// ---- social: playlists + watch history ----
export interface TitleRef {
  id: string;
  slug: string;
  name: string;
  poster_url: string;
}

export interface Playlist {
  id: string;
  name: string;
  owner_id: string;
  is_public: boolean;
  title_ids: string[];
  titles: TitleRef[];
  created_at: string;
}

export interface HistoryItem {
  episode_id: string;
  title_id: string;
  episode_number: number;
  position_seconds: number;
  title: TitleRef;
  updated_at: string;
}

export interface HistoryOut {
  items: HistoryItem[];
}

export interface HistoryPing {
  title_id: string;
  episode_id: string;
  position_seconds: number;
}

export interface Watchlist {
  ids: string[];
  items: Title[];
}

// ---- watch-time economy (free accounts only — see backend/lib/quota.py) ----
export interface QuotaInfo {
  mode: "limited" | "unlimited";
  balance_seconds: number;
  ad_cooldown_seconds: number;
  granted_per_ad: number;
}

export interface DownloadCheckOut {
  ok: boolean;
  balance_seconds: number;
  charged_seconds: number;
}

// ---- supplier program (see backend/routers/supplier.py) ----
export interface SupplierApplication {
  id: string;
  user_id: string;
  email: string;
  channel_name: string;
  channel_url: string;
  content_type: string;
  note: string;
  status: "pending" | "approved" | "rejected";
  admin_note: string;
  created_at: string;
  tests: Record<string, string>;
  current_test: number;
  channel_verified: boolean;
}

export interface SupplierSubmission {
  id: string;
  user_id: string;
  email: string;
  title: string;
  kind: TitleKind;
  language: string;
  description: string;
  source_url: string;
  thumbnail_url: string;
  status: "pending" | "approved" | "converted" | "rejected";
  admin_note: string;
  created_at: string;
}

export interface SupplierMeOut {
  application: SupplierApplication | null;
  submissions: SupplierSubmission[];
}

export interface OwnerOverview extends AdminStats {
  admins: number;
  workers: number;
  viewers: number;
  vip_active: number;
  pending_applications: number;
  pending_submissions: number;
  stale_supplier_titles: number;
}

// ---- chat + tasks (social layer — see backend/routers/chat.py, routers/tasks.py) ----
export type Region = "asia" | "americas" | "europe";

export interface AccountInfo {
  account_id: string;
  display_name: string;
  avatar_url: string;
  country: Region;
  role: string;
  vip_active: boolean;
  friends_limit: number;
  chat_free_limit: number;
  member_since: string;
  cf_balance: number;
}

export interface Friend {
  request_id: string;
  user_id: string;
  account_id: string;
  display_name: string;
  avatar_url: string;
  status: "pending" | "accepted" | "declined" | "blocked";
  created_at: string;
}

export interface FriendsOut {
  friends: Friend[];
  incoming: Friend[];
  outgoing: Friend[];
}

export interface ChatMessage {
  id: string;
  from_id: string;
  from_name: string;
  text: string;
  created_at: string;
}

export interface Task {
  id: string;
  title: string;
  description: string;
  reward_seconds: number;
  expires_at: string | null;
  permanent: boolean;
  claimed: boolean;
  created_at: string;
  link_url?: string | null;
  link_label?: string;
  link_claimed_by_me?: boolean;
}

export interface VideoVariant {
  key: string;
  status: "processing" | "ready" | "failed";
  size_bytes: number;
}

export interface VideoLibItem {
  key: string;
  size_bytes: number;
  attached_episode: string;
  uploaded_by: string;
  created_at: string;
}

export const AUDIO_OPTIONS = ["Hindi Dub", "Tamil Dub", "Eng Sub", "Eng Dub", "Jap Audio"] as const;

// ---- Cryptomus crypto checkout (real payments) ----
export interface CryptoInvoice {
  order_id: string;
  payment_url: string;
}
export interface CryptoStatus {
  order_id: string;
  status: string;
  payment_url: string;
}

// ---- face verification (AWS Rekognition liveness + match + age) ----
export interface LivenessSession {
  session_id: string;
  region: string;
}
export interface VerificationResult {
  verified: boolean;
  reason: string;
  liveness: number;
  similarity: number;
  age_low: number | null;
  age_high: number | null;
  status: string;
}

// ---- AI auditor (owner-controlled read-only access for AI agents) ----
export interface AiAuditInfo {
  id: string;
  label: string;
  active: boolean;
  created_at: string;
  last_used: string;
}

// ---- direct video download (4 lifetime per video for free users; VIP unlimited) ----
export interface DirectDownload {
  url: string;
  remaining: number | null;
  vip: boolean;
}

// Trusted email domains (mirror of backend ALLOWED_DOMAINS, also served by /auth/allowed-domains)
export const ALLOWED_EMAIL_DOMAINS = [
  "gmail.com",
  "yahoo.com",
  "yahoo.in",
  "outlook.com",
  "hotmail.com",
  "live.com",
  "icloud.com",
  "proton.me",
  "protonmail.com",
  "rediffmail.com",
  "yandex.com",
] as const;

// ---- publisher channels (public directory + channel page) ----
export interface ChannelInfo {
  user_id: string;
  name: string;
  bio: string;
  logo: string;
  followers: number;
  email?: string;
  videos?: number;
  titles?: Title[];
}
