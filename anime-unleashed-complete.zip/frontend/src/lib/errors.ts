import { ApiError } from "@/lib/api";

// FastAPI 422s come back as {detail: [...]}; simple HTTPExceptions as {detail: string}.
export function apiErrorMessage(error: unknown): string {
  if (error instanceof ApiError) {
    const body = error.body as { detail?: unknown } | null;
    if (typeof body?.detail === "string") return body.detail;
    if (Array.isArray(body?.detail) && body.detail.length > 0) {
      const first = body.detail[0] as { msg?: string };
      if (first?.msg) return first.msg;
    }
  }
  if (error instanceof Error) return error.message;
  return "Something went wrong — please try again";
}
