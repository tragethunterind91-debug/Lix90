export interface NFTItem {
  id: string;
  name: string;
  description: string;
  media_url: string;
  media_type: "image" | "video" | "html" | "animation";
  html?: string;
  category: "anime" | "dragon" | "creature" | "character" | string;
  tier: "low" | "mid" | "high" | "limited" | string;
  edition: "common" | "limited" | string;
  price_lc: number;
  supply: number;
  minted: number;
  start_from?: string;
  end_at?: string;
  active: boolean;
  created_at: string;
  created_by: string;
}

export interface NFTOwnedItem {
  id: string;
  owner_id: string;
  owner_name: string;
  owner_email: string;
  nft_id: string;
  nft?: NFTItem;
  serial: number;
  acquired_at: string;
  acquired_via: string;
  showcase: boolean;
  in_auction: boolean;
}

export interface BidItem {
  user_id: string;
  user_name: string;
  amount: number;
  created_at: string;
}

export interface AuctionItem {
  id: string;
  owned_id: string;
  nft_id: string;
  nft_name: string;
  nft?: NFTItem;
  serial: number;
  seller_id: string;
  seller_name: string;
  start_price: number;
  current_price: number;
  start_at: string;
  ends_at: string;
  can_cancel_until: string;
  status: "active" | "sold" | "cancelled" | "expired";
  top_bidder_id?: string;
  top_bidder_name?: string;
  bid_count: number;
  top_bids: BidItem[];
  settled_at?: string;
  created_at: string;
}

export interface AdConversionOut {
  vd_deducted: number;
  cf_added: number;
  lc_added: number;
  current_cf_balance: number;
  current_lc_balance: number;
  formula_used: string;
}
