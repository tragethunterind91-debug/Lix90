// Indian-audience audio badges — colors per design guidelines (Hindi Dub = crimson, Tamil = emerald, Eng = blue).
export function audioBadgeClass(audio: string): string {
  if (audio.includes("Hindi")) return "bg-rose-600 text-white";
  if (audio.includes("Tamil")) return "bg-emerald-500 text-slate-950";
  if (audio.includes("Eng")) return "bg-blue-500 text-white";
  return "bg-violet-500 text-white";
}

export function formatDuration(seconds: number | null | undefined): string {
  if (!seconds || seconds <= 0) return "";
  if (seconds < 60) return `${Math.round(seconds)}s`;
  const mins = Math.round(seconds / 60);
  if (mins < 60) return `${mins}m`;
  return `${Math.floor(mins / 60)}h ${mins % 60}m`;
}

export function formatBytes(bytes: number | null | undefined): string {
  if (!bytes || bytes <= 0) return "";
  const units = ["B", "KB", "MB", "GB"];
  let value = bytes;
  let unit = 0;
  while (value >= 1024 && unit < units.length - 1) {
    value /= 1024;
    unit += 1;
  }
  return `${value.toFixed(value >= 10 || unit === 0 ? 0 : 1)} ${units[unit]}`;
}

// "24 Oct 2026" style display dates (ISO strings stored in DynamoDB).
export function formatDate(iso: string | null | undefined): string {
  if (!iso) return "";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "";
  return date.toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

export function formatCount(n: number | null | undefined): string {
  if (n === null || n === undefined) return "";
  if (n < 1000) return String(n);
  if (n < 100_000) return `${(n / 1000).toFixed(1)}K`;
  return `${(n / 100_000).toFixed(1)}L`;
}

// "just now" / "5m ago" / "3h ago" / "2d ago"
export function timeAgo(iso: string | null | undefined): string {
  if (!iso) return "";
  const seconds = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (seconds < 60) return "just now";
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}
