import { apiPost } from "@/lib/api";

// VIP-track uploads (admin-only on the backend): dub audio + subtitle files.
// SRT uploads are auto-converted to WebVTT server-side.
export async function uploadEpisodeAudio(episodeId: string, file: File): Promise<void> {
  const form = new FormData();
  form.append("file", file);
  await apiPost(`/episodes/${episodeId}/audio`, form);
}

export async function uploadEpisodeSubtitles(episodeId: string, file: File): Promise<void> {
  const form = new FormData();
  form.append("file", file);
  await apiPost(`/episodes/${episodeId}/subtitles`, form);
}
