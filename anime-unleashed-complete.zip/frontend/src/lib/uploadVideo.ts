// XHR-based multipart upload so we get real progress events (fetch can't report upload %).
// Posts to <API_BASE>/api/videos/upload — the SAME base the typed fetch layer uses, so the
// live site (frontend on Firebase, API on its own domain) uploads to the backend and not
// to Firebase hosting. (The hardcoded relative path once made every live upload fail.)
import { ApiError, API_BASE } from "@/lib/api";
import type { UploadOut } from "@/lib/types";

export interface UploadProgress {
  percent: number;
  loadedBytes: number;
  totalBytes: number;
}

export function uploadVideo(
  file: File,
  onProgress: (progress: UploadProgress) => void,
): Promise<UploadOut> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `${API_BASE}/api/videos/upload`);
    // SameSite=None cross-origin deploys need this or the session cookie never
    // reaches the backend and workers get 401 on upload.
    xhr.withCredentials = true;
    xhr.upload.onprogress = (event) => {
      if (event.lengthComputable) {
        onProgress({
          percent: Math.min(99, Math.round((event.loaded / event.total) * 100)),
          loadedBytes: event.loaded,
          totalBytes: event.total,
        });
      }
    };
    xhr.onload = () => {
      let body: unknown = null;
      try {
        body = JSON.parse(xhr.responseText);
      } catch {
        body = null;
      }
      if (xhr.status >= 200 && xhr.status < 300) {
        onProgress({ percent: 100, loadedBytes: file.size, totalBytes: file.size });
        resolve(body as UploadOut);
      } else {
        reject(new ApiError(xhr.status, body));
      }
    };
    xhr.onerror = () => reject(new Error("Upload failed — check your connection"));
    const form = new FormData();
    form.append("file", file);
    xhr.send(form);
  });
}
