// Skeleton loaders (guideline: skeletons, never spinners) matching the card grid.
export function CardSkeleton() {
  return (
    <div className="space-y-2" data-testid="card-skeleton">
      <div className="aspect-[2/3] w-full animate-pulse rounded-xl bg-slate-800/60" />
      <div className="h-4 w-4/5 animate-pulse rounded-md bg-slate-800/60" />
      <div className="h-3 w-2/5 animate-pulse rounded-md bg-slate-800/40" />
    </div>
  );
}

export function CardGridSkeleton({ count = 12 }: { count?: number }) {
  return (
    <div
      className="grid grid-cols-2 gap-3.5 sm:grid-cols-3 sm:gap-4 md:grid-cols-4 lg:grid-cols-5 md:gap-5 xl:grid-cols-6"
      data-testid="card-grid-skeleton"
    >
      {Array.from({ length: count }, (_, i) => (
        <CardSkeleton key={i} />
      ))}
    </div>
  );
}

export function HeroSkeleton() {
  return (
    <div className="relative h-[52vh] min-h-[380px] w-full overflow-hidden rounded-2xl bg-slate-900" data-testid="hero-skeleton">
      <div className="absolute inset-0 animate-pulse bg-slate-800/60" />
      <div className="absolute bottom-8 left-6 space-y-4 md:left-10">
        <div className="h-5 w-32 animate-pulse rounded-md bg-slate-700/60" />
        <div className="h-10 w-72 animate-pulse rounded-lg bg-slate-700/80 md:w-96" />
        <div className="h-4 w-full max-w-lg animate-pulse rounded-md bg-slate-700/50" />
        <div className="flex gap-3 pt-2">
          <div className="h-11 w-32 animate-pulse rounded-lg bg-slate-600/60" />
          <div className="h-11 w-32 animate-pulse rounded-lg bg-slate-700/60" />
        </div>
      </div>
    </div>
  );
}
