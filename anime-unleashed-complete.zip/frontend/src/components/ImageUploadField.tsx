import { useRef, useState } from "react";
import { Loader2, UploadCloud } from "lucide-react";
import { toast } from "sonner";
import { mediaUrl } from "@/lib/api";
import { Input } from "@/components/ui/input";
import { uploadImage } from "@/lib/uploadImage";

// URL input + inline "Upload" button + tiny preview. Posters and episode
// thumbnails both use it — paste a URL or pick a file (goes through the
// backend's media disk, the R2 stand-in).
interface Props {
  id: string;
  value: string;
  onChange: (url: string) => void;
  placeholder?: string;
  testid: string;
}

export default function ImageUploadField({ id, value, onChange, placeholder, testid }: Props) {
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);

  async function handleFile(file: File | undefined | null) {
    if (!file) return;
    setBusy(true);
    try {
      const { url } = await uploadImage(file);
      onChange(url);
      toast.success("Image uploaded");
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Upload failed");
    } finally {
      setBusy(false);
      if (fileRef.current) fileRef.current.value = "";
    }
  }

  return (
    <div className="flex items-center gap-2">
      <Input
        id={id}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder ?? "https://… or upload"}
        className="border-slate-700 bg-slate-900/70"
        data-testid={testid}
      />
      <input
        ref={fileRef}
        type="file"
        accept="image/png,image/jpeg,image/webp,image/avif"
        className="hidden"
        onChange={(event) => void handleFile(event.target.files?.[0])}
        data-testid={`${testid}-file`}
      />
      <button
        type="button"
        onClick={() => fileRef.current?.click()}
        disabled={busy}
        className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-md border border-slate-700 bg-slate-900/70 px-3 text-xs font-semibold text-zinc-300 hover:bg-slate-800 disabled:opacity-50"
        data-testid={`${testid}-upload-btn`}
      >
        {busy ? <Loader2 className="h-3.5 w-3.5 animate-spin" aria-hidden /> : <UploadCloud className="h-3.5 w-3.5" aria-hidden />}
        Upload
      </button>
      {value ? <img src={mediaUrl(value)} alt="" aria-hidden className="h-9 w-9 shrink-0 rounded object-cover" data-testid={`${testid}-preview`} /> : null}
    </div>
  );
}
