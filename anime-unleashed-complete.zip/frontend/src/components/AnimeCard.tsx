import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Bookmark, Play, Star } from "lucide-react";
import type { Title } from "@/lib/types";
import { mediaUrl } from "@/lib/api";
import { audioBadgeClass } from "@/lib/badges";

// Poster card (2:3, hover lift + play overlay) shared by Home / Browse / My List grids.
export default function AnimeCard({
  title,
  inList = false,
  onToggleList,
}: {
  title: Title;
  inList?: boolean;
  onToggleList?: (title: Title) => void;
}) {
  const navigate = useNavigate();
  const [imgFailed, setImgFailed] = useState(false);

  return (
    <article className="group relative" data-testid={`anime-card-${title.id}`}>
      <div className="card-shine relative aspect-[2/3] overflow-hidden rounded-xl border border-[#222D42]/60 skeleton-shimmer shadow-lg transition-all duration-300 ease-out group-hover:-translate-y-2 group-hover:shadow-[0_12px_32px_rgba(255,70,85,0.25)] group-hover:ring-1 group-hover:ring-[var(--kind-accent,#FF4655)]/60">
        <Link to={`/title/${title.slug}`} aria-label={title.name} className="block h-full w-full">
          {title.poster_url && !imgFailed ? (
            <img
              src={mediaUrl(title.poster_url)}
              alt={title.name}
              loading="lazy"
              onError={() => setImgFailed(true)}
              className="h-full w-full object-cover transition-transform duration-500 ease-out group-hover:scale-[1.08]"
            />
          ) : (
            <div className="flex h-full w-full items-center justify-center bg-gradient-to-br from-slate-800 to-slate-900 p-4 text-center">
              <span className="font-heading text-sm font-semibold text-zinc-400">{title.name}</span>
            </div>
          )}
        </Link>

        {/* top badges */}
        <div className="pointer-events-none absolute left-2 right-2 top-2 flex items-start justify-between gap-1">
          {title.rating ? (
            <span className="flex items-center gap-0.5 rounded-md bg-black/70 px-1.5 py-0.5 text-[11px] font-bold text-amber-400 backdrop-blur">
              <Star className="h-3 w-3 fill-amber-400" aria-hidden /> {title.rating.toFixed(1)}
            </span>
          ) : (
            <span />
          )}
          {title.audio[0] ? (
            <span
              className={`rounded-md px-1.5 py-0.5 text-[10px] font-bold uppercase tracking-wide ${audioBadgeClass(title.audio[0])}`}
            >
              {title.audio[0]}
            </span>
          ) : null}
        </div>

        {/* hover overlay actions */}
        <div className="absolute inset-x-0 bottom-0 flex translate-y-2 items-center justify-center gap-2 bg-gradient-to-t from-black/90 via-black/50 to-transparent p-3 pt-8 opacity-0 transition-all duration-200 group-hover:translate-y-0 group-hover:opacity-100">
          <button
            onClick={() => navigate(`/watch/${title.slug}/1`)}
            className="flex h-9 items-center gap-1.5 rounded-lg bg-amber-400 px-3.5 text-xs font-bold text-slate-950 transition-colors hover:bg-amber-300"
            data-testid={`anime-card-play-btn-${title.id}`}
            aria-label={`Play ${title.name}`}
          >
            <Play className="h-3.5 w-3.5 fill-current" aria-hidden /> Play
          </button>
          {onToggleList ? (
            <button
              onClick={() => onToggleList(title)}
              aria-label={inList ? `Remove ${title.name} from My List` : `Add ${title.name} to My List`}
              className={`flex h-9 w-9 items-center justify-center rounded-lg border backdrop-blur transition-colors ${
                inList
                  ? "border-amber-400 bg-amber-400/20 text-amber-400"
                  : "border-white/20 bg-black/50 text-white hover:bg-black/70"
              }`}
              data-testid={`anime-card-bookmark-btn-${title.id}`}
            >
              <Bookmark className={`h-4 w-4 ${inList ? "fill-amber-400" : ""}`} aria-hidden />
            </button>
          ) : null}
        </div>
      </div>

      <div className="mt-2 px-0.5">
        <Link to={`/title/${title.slug}`}>
          <h3 className="truncate font-heading text-sm font-semibold leading-snug text-white transition-colors group-hover:text-amber-400">
            {title.name}
          </h3>
        </Link>
        <p className="mt-0.5 text-xs text-muted-foreground">
          {title.release_year} · {title.type === "movie" ? "Movie" : "Series"}
          {title.episode_count > 0 && title.type === "series" ? ` · ${title.episode_count} eps` : ""}
        </p>
      </div>
    </article>
  );
}
