import { useState } from "react";
import { Coins } from "lucide-react";
import { useAccount } from "@/hooks/useSocial";
import { useMe } from "@/hooks/useAuth";
import QuotaChip from "@/components/QuotaChip";
import ConvertModal from "@/components/ConvertModal";

// Wallet chips in the navbar: watch-time (QuotaChip) + CF chat-fund chip.
// The CF chip opens the convert system (VD ↔ CF).
export default function WalletChips() {
  const { data: me } = useMe();
  const account = useAccount(!!me && me.role === "user");
  const [open, setOpen] = useState(false);

  const showCf = !!me && me.role === "user" && !!account.data;

  return (
    <>
      <QuotaChip />
      {showCf ? (
        <button
          onClick={() => setOpen(true)}
          title="Your CF chat fund — tap to convert watch-time ↔ CF"
          className="flex items-center gap-1.5 rounded-full border border-amber-500/40 bg-amber-500/10 px-3 py-1.5 text-xs font-bold text-amber-300 transition-colors hover:bg-amber-500/20"
          data-testid="cf-chip"
        >
          <Coins className="h-3.5 w-3.5" aria-hidden />
          <span data-testid="cf-chip-balance">{account.data!.cf_balance} CF</span>
        </button>
      ) : null}
      <ConvertModal open={open} onOpenChange={setOpen} />
    </>
  );
}
