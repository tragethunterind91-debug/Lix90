import { useEffect, useState } from "react";

// Ticking live countdown — "12d 04h 09m 33s"; handles undated (TBA) and passed dates.
export default function Countdown({ to, testId }: { to?: string | null; testId?: string }) {
  const [, tick] = useState(0);
  useEffect(() => {
    const timer = setInterval(() => tick((n) => n + 1), 1000);
    return () => clearInterval(timer);
  }, []);
  if (!to) return <span className="text-zinc-400">Release date TBA</span>;
  const ms = new Date(to).getTime() - Date.now();
  if (ms <= 0) return <span className="text-emerald-400">Out now — listing soon</span>;
  const d = Math.floor(ms / 86_400_000);
  const h = Math.floor((ms % 86_400_000) / 3_600_000);
  const m = Math.floor((ms % 3_600_000) / 60_000);
  const s = Math.floor((ms % 60_000) / 1000);
  return (
    <span className="font-mono tabular-nums" data-testid={testId}>
      {d}d {String(h).padStart(2, "0")}h {String(m).padStart(2, "0")}m {String(s).padStart(2, "0")}s
    </span>
  );
}
