import { useState } from "react";
import { Heart, ShieldCheck, TreePine, Sparkles, Check, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { apiPost } from "@/lib/api";

interface DonationResponse {
  id: string;
  amount: number;
  currency: string;
  donor_name: string;
  znq_network_cut: number;
  environmental_protection_cut: number;
  status: string;
  created_at: string;
}

export default function DonationModal({ trigger }: { trigger?: React.ReactElement }) {
  const [open, setOpen] = useState(false);
  const [currency, setCurrency] = useState<"INR" | "USD">("INR");
  const [amount, setAmount] = useState<string>("50");
  const [donorName, setDonorName] = useState<string>("");
  const [note, setNote] = useState<string>("");
  const [busy, setBusy] = useState(false);
  const [successData, setSuccessData] = useState<DonationResponse | null>(null);

  const minAmount = currency === "INR" ? 10 : 0.1;
  const numAmount = parseFloat(amount) || 0;
  const znqCut = (numAmount * 0.8).toFixed(2);
  const envCut = (numAmount * 0.2).toFixed(2);

  const presets = currency === "INR" ? ["10", "50", "100", "500"] : ["0.10", "1", "5", "10"];

  async function handleDonate(e: React.FormEvent) {
    e.preventDefault();
    if (numAmount < minAmount) {
      toast.error(
        currency === "INR"
          ? "Minimum donation is ₹10"
          : "Minimum donation is $0.10"
      );
      return;
    }

    setBusy(true);
    try {
      const res = await apiPost<DonationResponse>("/vip/donate", {
        amount: numAmount,
        currency,
        donor_name: donorName.trim() || "Anonymous",
        note: note.trim() || undefined,
      });
      setSuccessData(res);
      const formattedAmount = currency === "INR" ? numAmount.toString() : numAmount.toFixed(2);
      toast.success(
        `Thank you for donating ${currency === "INR" ? "₹" : "$"}${formattedAmount}! Your support means the world to us.`
      );
    } catch (err: any) {
      toast.error(err?.message || "Failed to process donation. Please try again.");
    } finally {
      setBusy(false);
    }
  }

  function handleReset() {
    setSuccessData(null);
    setOpen(false);
    setAmount("50");
    setDonorName("");
    setNote("");
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) setSuccessData(null);
      }}
    >
      <DialogTrigger
        render={
          trigger || (
            <button
              type="button"
              data-testid="footer-donate-btn"
              className="flex items-center gap-1.5 rounded-full border border-pink-500/30 bg-gradient-to-r from-pink-500/10 via-rose-500/15 to-amber-500/10 px-4 py-2 text-xs font-bold text-pink-300 transition-all hover:scale-105 hover:border-pink-500 hover:text-white"
            >
              <Heart className="h-4 w-4 fill-pink-500 text-pink-500 animate-pulse" />
              <span>Support &amp; Donate</span>
            </button>
          )
        }
      />

      <DialogContent
        className="max-w-lg border-slate-800 bg-[#0B0F19] text-zinc-100 p-6 sm:p-8"
        data-testid="donate-dialog-content"
      >
        <DialogHeader>
          <div className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-pink-500/20 text-pink-400">
              <Heart className="h-5 w-5 fill-pink-400 text-pink-400" />
            </div>
            <div>
              <DialogTitle className="font-heading text-xl font-black text-white sm:text-2xl">
                Support Anime-Unleashed
              </DialogTitle>
              <DialogDescription className="text-xs text-zinc-400">
                Minimum Donation: ₹10 or $0.10
              </DialogDescription>
            </div>
          </div>
        </DialogHeader>

        {successData ? (
          <div className="space-y-4 py-4 text-center" data-testid="donate-success-screen">
            <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full bg-emerald-500/20 text-emerald-400">
              <Check className="h-8 w-8" />
            </div>
            <h3 className="font-heading text-xl font-bold text-white">Thank You for Supporting Us!</h3>
            <p className="text-sm text-zinc-300">
              Your contribution of{" "}
              <span className="font-bold text-amber-400">
                {successData.currency === "INR" ? "₹" : "$"}
                {Number(successData.amount).toFixed(2)}
              </span>{" "}
              has been recorded.
            </p>

            <div className="rounded-xl border border-slate-800 bg-slate-900/60 p-4 text-xs space-y-2 text-left">
              <p className="font-bold text-zinc-400 uppercase tracking-wider">Donation Distribution:</p>
              <div className="flex justify-between items-center text-purple-300">
                <span>80% to ZNQ Network (Parent Infrastructure &amp; Servers):</span>
                <span className="font-mono font-bold">
                  {successData.currency === "INR" ? "₹" : "$"}
                  {successData.znq_network_cut}
                </span>
              </div>
              <div className="flex justify-between items-center text-emerald-300">
                <span>20% to Environmental Protection:</span>
                <span className="font-mono font-bold">
                  {successData.currency === "INR" ? "₹" : "$"}
                  {successData.environmental_protection_cut}
                </span>
              </div>
            </div>

            <Button
              onClick={handleReset}
              className="w-full bg-pink-500 font-bold text-white hover:bg-pink-600"
              data-testid="donate-done-btn"
            >
              Close
            </Button>
          </div>
        ) : (
          <form onSubmit={handleDonate} className="space-y-5 py-2" data-testid="donate-form">
            <p className="text-xs leading-relaxed text-zinc-300">
              If you liked our work or website, please support us. If you want, you can donate some
              money here. It is used for server/bills maintenance, future projects, development, etc.
            </p>

            {/* Currency switcher */}
            <div className="flex items-center justify-between rounded-xl border border-slate-800 bg-slate-950/70 p-1.5">
              <span className="px-3 text-xs font-bold text-zinc-400">Currency</span>
              <div className="flex gap-1">
                <button
                  type="button"
                  onClick={() => {
                    setCurrency("INR");
                    setAmount("50");
                  }}
                  data-testid="donate-currency-inr"
                  className={`rounded-lg px-3 py-1 text-xs font-bold transition-all ${
                    currency === "INR"
                      ? "bg-amber-400 text-slate-950 font-black shadow"
                      : "text-zinc-400 hover:text-white"
                  }`}
                >
                  ₹ INR (Min ₹10)
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setCurrency("USD");
                    setAmount("1");
                  }}
                  data-testid="donate-currency-usd"
                  className={`rounded-lg px-3 py-1 text-xs font-bold transition-all ${
                    currency === "USD"
                      ? "bg-amber-400 text-slate-950 font-black shadow"
                      : "text-zinc-400 hover:text-white"
                  }`}
                >
                  $ USD (Min $0.10)
                </button>
              </div>
            </div>

            {/* Amount presets */}
            <div className="space-y-2">
              <label className="text-xs font-bold uppercase tracking-wider text-zinc-400">
                Choose or Enter Amount ({currency === "INR" ? "₹" : "$"})
              </label>
              <div className="grid grid-cols-4 gap-2">
                {presets.map((preset) => (
                  <button
                    key={preset}
                    type="button"
                    onClick={() => setAmount(preset)}
                    data-testid={`donate-preset-${preset}`}
                    className={`rounded-xl border py-2 text-xs font-bold transition-all ${
                      amount === preset
                        ? "border-pink-500 bg-pink-500/20 text-pink-300 font-black"
                        : "border-slate-800 bg-slate-900/60 text-zinc-400 hover:border-slate-700 hover:text-white"
                    }`}
                  >
                    {currency === "INR" ? "₹" : "$"}
                    {preset}
                  </button>
                ))}
              </div>
              <div className="relative mt-2">
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-sm font-bold text-zinc-400">
                  {currency === "INR" ? "₹" : "$"}
                </span>
                <Input
                  type="number"
                  step="any"
                  min={minAmount}
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  placeholder={`Min ${currency === "INR" ? "10" : "0.10"}`}
                  className="border-slate-800 bg-slate-900 pl-8 text-sm font-bold text-white"
                  data-testid="donate-amount-input"
                  required
                />
              </div>
            </div>

            {/* Optional donor name & note */}
            <div className="grid grid-cols-1 gap-2.5 sm:grid-cols-2">
              <div>
                <label className="text-[11px] font-bold text-zinc-400">Your Name (Optional)</label>
                <Input
                  type="text"
                  value={donorName}
                  onChange={(e) => setDonorName(e.target.value)}
                  placeholder="Anonymous Fan"
                  className="mt-1 h-9 border-slate-800 bg-slate-900 text-xs"
                  data-testid="donate-name-input"
                />
              </div>
              <div>
                <label className="text-[11px] font-bold text-zinc-400">Message (Optional)</label>
                <Input
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Keep up the great work!"
                  className="mt-1 h-9 border-slate-800 bg-slate-900 text-xs"
                  data-testid="donate-note-input"
                />
              </div>
            </div>

            {/* Donation Distribution breakdown */}
            <Card className="border-pink-500/20 bg-pink-950/15">
              <CardContent className="p-3 space-y-2 text-xs">
                <div className="flex items-center gap-1.5 font-bold text-pink-300">
                  <Sparkles className="h-4 w-4" />
                  <span>Donation Distribution:</span>
                </div>
                <div className="flex items-center justify-between text-zinc-300">
                  <span className="flex items-center gap-1">
                    <ShieldCheck className="h-3.5 w-3.5 text-purple-400" />
                    <span>80% will go to ZNQ Network (Parent)</span>
                  </span>
                  <span className="font-mono font-bold text-purple-300">
                    {currency === "INR" ? "₹" : "$"}
                    {znqCut}
                  </span>
                </div>
                <div className="flex items-center justify-between text-zinc-300">
                  <span className="flex items-center gap-1">
                    <TreePine className="h-3.5 w-3.5 text-emerald-400" />
                    <span>20% will go to environmental protection</span>
                  </span>
                  <span className="font-mono font-bold text-emerald-300">
                    {currency === "INR" ? "₹" : "$"}
                    {envCut}
                  </span>
                </div>
              </CardContent>
            </Card>

            <Button
              type="submit"
              disabled={busy || numAmount < minAmount}
              className="w-full bg-gradient-to-r from-pink-500 via-rose-500 to-amber-500 font-heading text-sm font-black text-white hover:opacity-95"
              data-testid="donate-submit-btn"
            >
              {busy ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Processing...
                </>
              ) : (
                <>
                  <Heart className="mr-2 h-4 w-4 fill-white" /> Complete Donation (
                  {currency === "INR" ? "₹" : "$"}
                  {numAmount || 0})
                </>
              )}
            </Button>
          </form>
        )}
      </DialogContent>
    </Dialog>
  );
}
