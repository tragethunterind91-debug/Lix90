import { useState } from "react";
import { ArrowDownUp, Coins, Timer } from "lucide-react";
import { useAccount, useConvert } from "@/hooks/useSocial";
import { formatBalance, useQuota } from "@/hooks/useQuota";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

// THE convert system — View-Duration ↔ CF (chat fund). 1 CF = 3 minutes of watch-time.
// Chat spends CF; tasks/rewarded-ads earn watch-time you convert here.
export default function ConvertModal({
  open,
  onOpenChange,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const account = useAccount(open);
  const quota = useQuota(open);
  const convert = useConvert();
  const [minutes, setMinutes] = useState("30");
  const [cf, setCf] = useState("10");

  const acc = account.data;
  const cfOut = Math.floor((Number(minutes) * 60) / 180);
  const vdOut = Number(cf) * 180;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md border-slate-800 bg-[#0F1420]" data-testid="convert-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-heading text-white" data-testid="convert-title">
            <ArrowDownUp className="h-5 w-5 text-emerald-400" aria-hidden /> Convert
          </DialogTitle>
          <DialogDescription data-testid="convert-rate">
            Rate: <b className="text-white">1 CF = {formatBalance(180)}</b> of watch-time. Chatting spends CF.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center justify-around rounded-xl border border-slate-700/70 bg-slate-900/60 px-4 py-3 text-center">
          <div>
            <p className="flex items-center justify-center gap-1 font-heading text-lg font-bold text-white" data-testid="convert-vd-balance">
              <Timer className="h-4 w-4 text-emerald-400" aria-hidden /> {formatBalance(quota.data?.balance_seconds ?? 0)}
            </p>
            <p className="text-[10px] uppercase tracking-wider text-zinc-500">Watch-time</p>
          </div>
          <ArrowDownUp className="h-4 w-4 text-zinc-500" aria-hidden />
          <div>
            <p className="flex items-center justify-center gap-1 font-heading text-lg font-bold text-white" data-testid="convert-cf-balance">
              <Coins className="h-4 w-4 text-amber-400" aria-hidden /> {acc?.cf_balance ?? 0} CF
            </p>
            <p className="text-[10px] uppercase tracking-wider text-zinc-500">Chat fund</p>
          </div>
        </div>

        <Tabs defaultValue="vd2cf">
          <TabsList className="w-full bg-slate-900/80" data-testid="convert-tabs">
            <TabsTrigger value="vd2cf" className="flex-1" data-testid="convert-tab-vd2cf">Watch-time → CF</TabsTrigger>
            <TabsTrigger value="cf2vd" className="flex-1" data-testid="convert-tab-cf2vd">CF → Watch-time</TabsTrigger>
          </TabsList>

          <TabsContent value="vd2cf" className="mt-3 space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="cvd-min">Minutes to convert</Label>
              <Input id="cvd-min" type="number" min={3} value={minutes} onChange={(e) => setMinutes(e.target.value)} className="border-slate-700 bg-slate-900/70" data-testid="convert-vd-input" />
            </div>
            <div className="flex gap-1.5">
              {[3, 30, 60, 180].map((m) => (
                <button key={m} onClick={() => setMinutes(String(m))} className="flex-1 rounded-lg border border-slate-700 px-2 py-1 text-xs font-bold text-zinc-300 hover:border-emerald-400/50" data-testid={`convert-vd-quick-${m}`}>
                  {m}m
                </button>
              ))}
            </div>
            <Button
              disabled={convert.isPending || cfOut < 1}
              onClick={() => convert.mutate({ direction: "vd_to_cf", amount: Number(minutes) })}
              className="w-full bg-emerald-400 font-bold text-slate-950 hover:bg-emerald-300"
              data-testid="convert-vd-btn"
            >
              Convert → +{Math.max(0, cfOut)} CF
            </Button>
          </TabsContent>

          <TabsContent value="cf2vd" className="mt-3 space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="cvd-cf">CF to convert</Label>
              <Input id="cvd-cf" type="number" min={1} value={cf} onChange={(e) => setCf(e.target.value)} className="border-slate-700 bg-slate-900/70" data-testid="convert-cf-input" />
            </div>
            <div className="flex gap-1.5">
              {[1, 10, 50, 100].map((c) => (
                <button key={c} onClick={() => setCf(String(c))} className="flex-1 rounded-lg border border-slate-700 px-2 py-1 text-xs font-bold text-zinc-300 hover:border-amber-400/50" data-testid={`convert-cf-quick-${c}`}>
                  {c} CF
                </button>
              ))}
            </div>
            <Button
              disabled={convert.isPending || Number(cf) < 1}
              onClick={() => convert.mutate({ direction: "cf_to_vd", amount: Number(cf) })}
              className="w-full bg-amber-400 font-bold text-slate-950 hover:bg-amber-300"
              data-testid="convert-cf-btn"
            >
              Convert → +{formatBalance(Math.max(0, vdOut))}
            </Button>
          </TabsContent>
        </Tabs>
      </DialogContent>
    </Dialog>
  );
}
