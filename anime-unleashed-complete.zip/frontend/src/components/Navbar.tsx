import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Bookmark,
  Clapperboard,
  Crown,
  History as HistoryIcon,
  LayoutDashboard,
  ListChecks,
  ListVideo,
  LogOut,
  MessagesSquare,
  Search,
  Send,
  UploadCloud,
  UserCog,
  UserPlus,
  Menu,
  X,
  Heart,
  Coins,
} from "lucide-react";
import WalletChips from "@/components/WalletChips";
import { useLogout, useMe } from "@/hooks/useAuth";
import { Button, buttonVariants } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Sticky glass navbar (guideline: backdrop-blur-xl over obsidian) with inline search + auth area.
export default function Navbar() {
  const { data: me, isLoading } = useMe();
  const logout = useLogout();
  const navigate = useNavigate();
  const [query, setQuery] = useState("");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  function submitSearch() {
    const q = query.trim();
    navigate(`/browse${q ? `?q=${encodeURIComponent(q)}` : ""}`);
  }

  return (
    <header className="nav-drop sticky top-0 z-50 border-b border-slate-800/80 bg-[#07090E]/85 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 sm:px-6 lg:px-8">
        <Link to="/" className="flex items-center gap-2.5 flex-shrink-0" data-testid="nav-logo-link">
          <img
            src="/logo-app-icon.png"
            alt="Anime-Unleashed"
            className="h-8 w-8 sm:h-9 sm:w-9 rounded-xl object-contain shadow-[0_0_20px_rgba(168,85,247,0.35)]"
          />
          <div className="flex flex-col">
            <span className="whitespace-nowrap font-heading text-sm sm:text-base font-bold tracking-tight text-white">
              <span className="bg-gradient-to-r from-[#FF2A85] via-[#FF4655] to-[#FEE140] bg-clip-text font-black tracking-tighter text-transparent">
                Anime-Unleashed
              </span>
              <span className="ml-1.5 hidden rounded bg-gradient-to-r from-[#FF2A85] via-[#FF4655] to-[#FEE140] px-1.5 py-0.5 align-middle text-[10px] font-black uppercase tracking-widest text-slate-950 sm:inline-block">
                Entertainment
              </span>
            </span>
            <span className="hidden items-center gap-1.5 text-[9px] font-bold tracking-wider text-purple-400 sm:flex">
              <span>A PART OF</span>
              <img src="/znq-network-icon.png" alt="ZNQ Network" className="h-3 w-3 rounded-sm object-contain" />
              <span className="text-zinc-300 font-black">ZNQ NETWORK</span>
            </span>
          </div>
        </Link>

        <nav className="ml-3 hidden items-center gap-0.5 xl:gap-1 lg:flex flex-nowrap overflow-hidden">
          <Link
            to="/browse"
            data-testid="nav-browse-link"
            className="whitespace-nowrap rounded-md px-2 py-1 text-xs lg:text-sm font-medium text-zinc-300 transition-colors hover:bg-white/5 hover:text-white"
          >
            Browse
          </Link>
          <Link
            to="/explore"
            data-testid="nav-explore-link"
            className="whitespace-nowrap flex items-center gap-1.5 rounded-md px-2 py-1 text-xs lg:text-sm font-bold text-sky-400 transition-colors hover:bg-sky-400/10 hover:text-sky-300"
          >
            <Clapperboard className="h-3.5 w-3.5" />
            Explore
          </Link>
          {me ? (
            <>
              <Link
                to="/"
                data-testid="nav-home-link"
                className="whitespace-nowrap rounded-md px-2 py-1 text-xs lg:text-sm font-medium text-zinc-300 transition-colors hover:bg-white/5 hover:text-white"
              >
                Home
              </Link>
              <Link
                to="/live"
                data-testid="nav-live-link"
                className="whitespace-nowrap flex items-center gap-1 rounded-md px-2 py-1 text-xs lg:text-sm font-bold text-rose-400 transition-colors hover:bg-rose-500/10 hover:text-rose-300"
              >
                <span className="h-1.5 w-1.5 rounded-full bg-rose-500 animate-pulse" />
                Live
              </Link>
              <Link
                to="/info"
                data-testid="nav-info-link"
                className="whitespace-nowrap rounded-md px-2 py-1 text-xs lg:text-sm font-medium text-amber-300 transition-colors hover:bg-amber-400/10 hover:text-amber-200"
              >
                Info &amp; Stats
              </Link>
              <Link
                to="/nft"
                data-testid="nav-nft-link"
                className="whitespace-nowrap rounded-md px-2 py-1 text-xs lg:text-sm font-bold text-amber-400 transition-colors hover:bg-amber-400/10 hover:text-amber-300"
              >
                NFTs
              </Link>
              <Link
                to="/auctions"
                data-testid="nav-auctions-link"
                className="whitespace-nowrap rounded-md px-2 py-1 text-xs lg:text-sm font-bold text-purple-400 transition-colors hover:bg-purple-400/10 hover:text-purple-300"
              >
                Auctions
              </Link>
              <Link
                to="/chat"
                data-testid="nav-chat-link"
                className="whitespace-nowrap rounded-md px-2 py-1 text-xs lg:text-sm font-medium text-zinc-300 transition-colors hover:bg-white/5 hover:text-white"
              >
                Chat
              </Link>
              <Link
                to="/friends"
                data-testid="nav-friends-link"
                className="whitespace-nowrap rounded-md px-2 py-1 text-xs lg:text-sm font-medium text-zinc-300 transition-colors hover:bg-white/5 hover:text-white"
              >
                Friends
              </Link>
              <Link
                to="/tasks"
                data-testid="nav-tasks-link"
                className="whitespace-nowrap rounded-md px-2 py-1 text-xs lg:text-sm font-medium text-zinc-300 transition-colors hover:bg-white/5 hover:text-white"
              >
                Tasks
              </Link>
              <Link
                to="/subscriptions"
                data-testid="nav-subscriptions-link"
                className="whitespace-nowrap flex items-center gap-1 rounded-md px-2 py-1 text-xs lg:text-sm font-bold text-pink-400 transition-colors hover:bg-pink-500/10 hover:text-pink-300"
              >
                <Heart className="h-3.5 w-3.5 fill-pink-400" />
                Following
              </Link>
              <Link
                to="/publishers"
                data-testid="nav-publishers-link"
                className="whitespace-nowrap rounded-md px-2 py-1 text-xs lg:text-sm font-medium text-zinc-300 transition-colors hover:bg-white/5 hover:text-white"
              >
                Publishers
              </Link>
              <Link
                to="/my-list"
                data-testid="nav-mylist-link"
                className="whitespace-nowrap rounded-md px-2 py-1 text-xs lg:text-sm font-medium text-zinc-300 transition-colors hover:bg-white/5 hover:text-white"
              >
                My List
              </Link>
            </>
          ) : (
            <span className="flex items-center gap-1.5 rounded-full border border-purple-500/30 bg-purple-500/10 px-2.5 py-0.5 text-xs font-bold text-purple-300">
              <img src="/znq-network-icon.png" alt="ZNQ" className="h-3.5 w-3.5 rounded-sm object-contain" />
              <span>ZNQ NETWORK</span>
            </span>
          )}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          <div className="relative hidden lg:block">
            <Search className="absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" aria-hidden />
            <Input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") submitSearch();
              }}
              placeholder="Search anime…"
              className="w-48 xl:w-56 border-slate-700 bg-slate-900/70 pl-8 text-xs xl:text-sm"
              data-testid="nav-search-input"
              aria-label="Search anime"
            />
          </div>
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden"
            onClick={() => navigate("/browse")}
            data-testid="nav-mobile-search-btn"
            aria-label="Search anime"
          >
            <Search className="h-5 w-5" aria-hidden />
          </Button>
          {/* Mobile hamburger menu toggle */}
          <Button
            variant="ghost"
            size="icon"
            className="lg:hidden text-zinc-300"
            onClick={() => setMobileMenuOpen((o) => !o)}
            data-testid="nav-mobile-menu-toggle"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>

          <WalletChips />
          {isLoading ? (
            <div className="h-9 w-9 animate-pulse rounded-full bg-slate-800" data-testid="nav-user-skeleton" />
          ) : me ? (
            <DropdownMenu>
              <DropdownMenuTrigger
                render={
                  <button
                    className="flex h-9 w-9 items-center justify-center rounded-full bg-gradient-to-br from-[#F59E0B] to-[#D97706] font-heading text-sm font-bold text-slate-950 outline-none ring-amber-400/60 focus-visible:ring-2"
                    data-testid="nav-user-menu"
                    aria-label="Account menu"
                  >
                    {me.display_name.slice(0, 1).toUpperCase()}
                  </button>
                }
              />
              <DropdownMenuContent align="end" className="w-52">
                <div className="px-1.5 py-1" data-testid="nav-user-info">
                  <span className="flex items-center gap-1.5 text-sm font-semibold text-white">
                    {me.display_name}
                    {me.vip_until ? (
                      <span className="rounded bg-gradient-to-r from-[#F59E0B] to-[#D97706] px-1 py-0.5 text-[9px] font-black uppercase tracking-wider text-slate-950" data-testid="nav-vip-badge">
                        VIP
                      </span>
                    ) : null}
                  </span>
                  <span className="block text-xs text-muted-foreground">{me.email}</span>
                </div>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  data-testid="nav-user-wallet-item"
                  onClick={() => navigate("/wallet")}
                >
                  <Coins className="mr-2 h-4 w-4 text-amber-400" aria-hidden /> Wallet &amp; Exchange (LC)
                </DropdownMenuItem>
                <DropdownMenuItem
                  data-testid="nav-user-subscriptions-item"
                  onClick={() => navigate("/subscriptions")}
                >
                  <Heart className="mr-2 h-4 w-4 text-pink-400 fill-pink-400" aria-hidden /> Following &amp; Loved
                </DropdownMenuItem>
                <DropdownMenuItem
                  data-testid="nav-user-explore-item"
                  onClick={() => navigate("/explore")}
                >
                  <Clapperboard className="mr-2 h-4 w-4 text-sky-400" aria-hidden /> Explore
                </DropdownMenuItem>
                <DropdownMenuItem
                  data-testid="nav-user-mylist-item"
                  onClick={() => navigate("/my-list")}
                >
                  <Bookmark className="mr-2 h-4 w-4" aria-hidden /> My List
                </DropdownMenuItem>
                <DropdownMenuItem
                  data-testid="nav-user-playlists-item"
                  onClick={() => navigate("/playlists")}
                >
                  <ListVideo className="mr-2 h-4 w-4" aria-hidden /> Playlists
                </DropdownMenuItem>
                <DropdownMenuItem
                  data-testid="nav-user-history-item"
                  onClick={() => navigate("/history")}
                >
                  <HistoryIcon className="mr-2 h-4 w-4" aria-hidden /> History
                </DropdownMenuItem>
                <DropdownMenuItem
                  data-testid="nav-user-chat-item"
                  onClick={() => navigate("/chat")}
                >
                  <MessagesSquare className="mr-2 h-4 w-4" aria-hidden /> Global chat
                </DropdownMenuItem>
                <DropdownMenuItem
                  data-testid="nav-user-tasks-item"
                  onClick={() => navigate("/tasks")}
                >
                  <ListChecks className="mr-2 h-4 w-4" aria-hidden /> Tasks
                </DropdownMenuItem>
                <DropdownMenuItem
                  data-testid="nav-user-vip-item"
                  onClick={() => navigate("/vip")}
                >
                  <Crown className="mr-2 h-4 w-4 text-amber-400" aria-hidden /> {me.vip_until ? "VIP status" : "Go VIP — ₹66/2 mo"}
                </DropdownMenuItem>
                {me.role === "admin" ? (
                  <DropdownMenuItem
                    data-testid="nav-user-admin-item"
                    onClick={() => navigate("/studio")}
                  >
                    <LayoutDashboard className="mr-2 h-4 w-4" aria-hidden /> Studio Console
                  </DropdownMenuItem>
                ) : null}
                {me.role === "worker" ? (
                  <DropdownMenuItem
                    data-testid="nav-user-worker-item"
                    onClick={() => navigate("/worker")}
                  >
                    <UploadCloud className="mr-2 h-4 w-4" aria-hidden /> Worker Desk
                  </DropdownMenuItem>
                ) : null}
                {me.role === "creator" ? (
                  <DropdownMenuItem
                    data-testid="nav-user-creator-item"
                    onClick={() => navigate("/creator")}
                  >
                    <Send className="mr-2 h-4 w-4" aria-hidden /> Creator Desk
                  </DropdownMenuItem>
                ) : null}
                {me.role === "user" ? (
                  <DropdownMenuItem
                    data-testid="nav-user-supplier-item"
                    onClick={() => navigate("/supplier")}
                  >
                    <Send className="mr-2 h-4 w-4" aria-hidden /> Become a supplier
                  </DropdownMenuItem>
                ) : null}
                <DropdownMenuItem data-testid="nav-user-account-item" onClick={() => navigate("/account")}>
                  <UserCog className="mr-2 h-4 w-4" aria-hidden /> Account settings
                </DropdownMenuItem>
                <DropdownMenuItem data-testid="nav-user-friends-item" onClick={() => navigate("/friends")}>
                  <UserPlus className="mr-2 h-4 w-4" aria-hidden /> Friends
                </DropdownMenuItem>
                <DropdownMenuItem data-testid="nav-user-chat-item" onClick={() => navigate("/chat")}>
                  <MessagesSquare className="mr-2 h-4 w-4" aria-hidden /> Global chat
                </DropdownMenuItem>
                <DropdownMenuItem data-testid="nav-user-tasks-item" onClick={() => navigate("/tasks")}>
                  <ListChecks className="mr-2 h-4 w-4" aria-hidden /> Tasks
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  variant="destructive"
                  data-testid="nav-logout-btn"
                  onClick={() => logout.mutate()}
                >
                  <LogOut className="mr-2 h-4 w-4" aria-hidden /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <Link
              to="/login"
              data-testid="nav-login-btn"
              className={buttonVariants({ className: "bg-amber-400 text-slate-950 hover:bg-amber-300" })}
            >
              Sign in
            </Link>
          )}
        </div>
      </div>
      {/* Mobile expandable dropdown navigation drawer */}
      {mobileMenuOpen && (
        <div
          className="lg:hidden border-t border-slate-800 bg-[#07090E]/95 px-4 py-4 backdrop-blur-2xl transition-all"
          data-testid="nav-mobile-drawer"
        >
          <div className="mb-3">
            <div className="relative w-full">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") {
                    submitSearch();
                    setMobileMenuOpen(false);
                  }
                }}
                placeholder="Search anime..."
                className="w-full border-slate-700 bg-slate-900/80 pl-9 text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-semibold">
            <Link
              to="/"
              data-testid="nav-mobile-home-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-slate-800/80 bg-slate-900/60 p-2.5 text-zinc-300 hover:text-white hover:border-amber-400/40"
            >
              <span>🏠 Home</span>
            </Link>
            <Link
              to="/browse"
              data-testid="nav-mobile-browse-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-slate-800/80 bg-slate-900/60 p-2.5 text-zinc-300 hover:text-white hover:border-amber-400/40"
            >
              <span>🍿 Browse</span>
            </Link>
            <Link
              to="/live"
              data-testid="nav-mobile-live-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-rose-500/30 bg-rose-500/10 p-2.5 text-rose-300 hover:bg-rose-500/20"
            >
              <span className="h-2 w-2 rounded-full bg-rose-500 animate-pulse" />
              <span>Live Streams</span>
            </Link>
            <Link
              to="/info"
              data-testid="nav-mobile-info-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 p-2.5 text-amber-300 hover:bg-amber-500/20"
            >
              <span>📊 Info &amp; Stats</span>
            </Link>
            <Link
              to="/nft"
              data-testid="nav-mobile-nft-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-amber-400/40 bg-amber-400/10 p-2.5 text-amber-300 hover:bg-amber-400/20"
            >
              <span>💎 NFT Market</span>
            </Link>
            <Link
              to="/auctions"
              data-testid="nav-mobile-auctions-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-purple-500/40 bg-purple-500/10 p-2.5 text-purple-300 hover:bg-purple-500/20"
            >
              <span>🔨 Auctions</span>
            </Link>
            <Link
              to="/inventory"
              data-testid="nav-mobile-inventory-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-slate-800 bg-slate-900/60 p-2.5 text-zinc-300 hover:text-white"
            >
              <span>🎒 Inventory</span>
            </Link>
            <Link
              to="/explore"
              data-testid="nav-mobile-explore-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-sky-500/30 bg-sky-500/10 p-2.5 text-sky-300 hover:bg-sky-500/20"
            >
              <span>🎬 Explore</span>
            </Link>
            <Link
              to="/chat"
              data-testid="nav-mobile-chat-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-slate-800/80 bg-slate-900/60 p-2.5 text-zinc-300 hover:text-white"
            >
              <span>💬 Global Chat</span>
            </Link>
            <Link
              to="/friends"
              data-testid="nav-mobile-friends-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-slate-800/80 bg-slate-900/60 p-2.5 text-zinc-300 hover:text-white"
            >
              <span>👥 Friends</span>
            </Link>
            <Link
              to="/tasks"
              data-testid="nav-mobile-tasks-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-slate-800/80 bg-slate-900/60 p-2.5 text-zinc-300 hover:text-white"
            >
              <span>🎯 Tasks</span>
            </Link>
            <Link
              to="/wallet"
              data-testid="nav-mobile-wallet-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-amber-500/30 bg-amber-500/10 p-2.5 text-amber-300 hover:bg-amber-500/20"
            >
              <span>🪙 Wallet &amp; Exchange (LC)</span>
            </Link>
            <Link
              to="/subscriptions"
              data-testid="nav-mobile-subscriptions-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-pink-500/30 bg-pink-500/10 p-2.5 text-pink-300 hover:bg-pink-500/20"
            >
              <span>❤️ Following &amp; Loved</span>
            </Link>
            <Link
              to="/publishers"
              data-testid="nav-mobile-publishers-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-slate-800/80 bg-slate-900/60 p-2.5 text-zinc-300 hover:text-white"
            >
              <span>📢 Publishers</span>
            </Link>
            <Link
              to="/my-list"
              data-testid="nav-mobile-mylist-link"
              onClick={() => setMobileMenuOpen(false)}
              className="flex items-center gap-2 rounded-xl border border-slate-800/80 bg-slate-900/60 p-2.5 text-zinc-300 hover:text-white"
            >
              <span>🔖 My List</span>
            </Link>
            <Link
              to="/playlists"
              data-testid="nav-mobile-playlists-link"
              onClick={() => setMobileMenuOpen(false)}
              className="col-span-2 flex items-center justify-center gap-2 rounded-xl border border-slate-800/80 bg-slate-900/60 p-2.5 text-zinc-300 hover:text-white"
            >
              <span>📋 Playlists</span>
            </Link>
            <Link
              to="/vip"
              data-testid="nav-mobile-vip-link"
              onClick={() => setMobileMenuOpen(false)}
              className="col-span-2 flex items-center justify-center gap-2 rounded-xl border border-amber-400/40 bg-gradient-to-r from-amber-500/20 to-pink-500/20 p-2.5 font-bold text-amber-300"
            >
              <Crown className="h-4 w-4 text-amber-400" />
              <span>Go VIP Pass (₹66/2 mo)</span>
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
