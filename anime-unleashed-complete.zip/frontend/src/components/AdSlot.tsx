import { Link } from "react-router-dom";
import { Crown } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { apiGet } from "@/lib/api";
import { useMe } from "@/hooks/useAuth";
import type { VipStatus } from "@/lib/types";

// Ad placement slot. When VITE_ADSENSE_CLIENT + VITE_ADSENSE_SLOT_<NAME> are set a
// real AdSense unit renders; until then a styled placeholder stands in. VIP members
// (₹66 / 2-month pass) never see ads — that is the whole pitch.
export default function AdSlot({ slot, className = "" }: { slot: string; className?: string }) {
  const { data: me } = useMe();
  const vip = useQuery<VipStatus>({
    queryKey: ["vip", "status"],
    queryFn: () => apiGet<VipStatus>("/vip/status"),
    enabled: !!me,
  });

  if (me && vip.data?.active) return null;

  const client = import.meta.env.VITE_ADSENSE_CLIENT as string | undefined;
  const slotId = import.meta.env[`VITE_ADSENSE_SLOT_${slot.toUpperCase()}`] as string | undefined;

  if (client && slotId) {
    return (
      <div className={className} data-testid={`ad-slot-${slot}`}>
        <ins
          className="adsbygoogle"
          style={{ display: "block" }}
          data-ad-client={client}
          data-ad-slot={slotId}
          data-ad-format="auto"
          data-full-width-responsive="true"
        />
      </div>
    );
  }

  return (
    <div
      className={`flex h-12 items-center justify-center rounded-xl border border-dashed border-slate-700/60 bg-slate-900/30 ${className}`}
      data-testid={`ad-slot-${slot}`}
    >
      <span className="flex items-center gap-2 text-[10px] sm:text-[11px] font-medium uppercase tracking-[0.15em] text-zinc-500">
        Advertisement — {slot}
        <Link to="/vip" className="normal-case tracking-normal text-amber-400/80 underline-offset-2 hover:underline">
          <Crown className="inline h-3 w-3" aria-hidden /> Go ad-free ₹66/2 mo
        </Link>
      </span>
    </div>
  );
}
