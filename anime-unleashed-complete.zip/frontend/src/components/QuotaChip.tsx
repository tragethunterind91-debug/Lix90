import { Link } from "react-router-dom";
import { Timer } from "lucide-react";
import { useMe } from "@/hooks/useAuth";
import { formatBalance, useQuota } from "@/hooks/useQuota";

// Watch-time wallet chip in the navbar — only signed-in FREE viewers carry a balance
// (VIP + staff are unlimited, guests are untracked). Low balance pulses red.
export default function QuotaChip() {
  const { data: me } = useMe();
  const limited =
    !!me && me.role === "user" && (!me.vip_until || new Date(me.vip_until) <= new Date());
  const quota = useQuota(limited);

  if (!limited || !quota.data || quota.data.mode !== "limited") return null;
  const low = quota.data.balance_seconds < 600;

  return (
    <Link
      to="/earn"
      data-testid="quota-chip"
      title="Your watch-time balance — watch a rewarded ad or go VIP to refill"
      className={`flex items-center gap-1.5 rounded-full border px-3 py-1.5 text-xs font-bold transition-colors ${
        low
          ? "animate-pulse border-rose-500/50 bg-rose-500/10 text-rose-300"
          : "border-emerald-500/40 bg-emerald-500/10 text-emerald-300"
      }`}
    >
      <Timer className="h-3.5 w-3.5" aria-hidden />
      <span data-testid="quota-chip-balance">{formatBalance(quota.data.balance_seconds)}</span>
      <span className="hidden font-medium text-zinc-400 sm:inline">/ 3h 30m left</span>
    </Link>
  );
}
