import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { Link } from "react-router-dom";
import { Crown, Loader2, MonitorPlay, Timer } from "lucide-react";
import { toast } from "sonner";
import { apiPost } from "@/lib/api";
import { apiErrorMessage } from "@/lib/errors";
import { formatBalance } from "@/hooks/useQuota";
import type { QuotaInfo } from "@/lib/types";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

const AD_SECONDS = 1800; // +30 min per rewarded ad

// Out-of-time popup: the mock rewarded ad refills +30 min until real AdSense/GAM
// rewarded slots are approved; VIP converts the account to unlimited.
export default function RefillModal({
  open,
  onOpenChange,
  requiredSeconds,
}: {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  requiredSeconds?: number | null;
}) {
  const queryClient = useQueryClient();
  const [playing, setPlaying] = useState(false);
  const [count, setCount] = useState(5);

  async function watchAd() {
    setPlaying(true);
    for (let left = 5; left > 0; left--) {
      setCount(left);
      await new Promise((resolve) => setTimeout(resolve, 1000));
    }
    try {
      const res = await apiPost<QuotaInfo>("/quota/rewarded-ad");
      toast.success(`+${formatBalance(AD_SECONDS)} unlocked — you have ${formatBalance(res.balance_seconds)}`);
      await queryClient.invalidateQueries({ queryKey: ["quota"] });
      onOpenChange(false);
    } catch (error) {
      toast.error(apiErrorMessage(error));
    } finally {
      setPlaying(false);
    }
  }

  return (
    <Dialog open={open} onOpenChange={(next) => !playing && onOpenChange(next)}>
      <DialogContent className="max-w-md border-slate-800 bg-[#0F1420]" data-testid="refill-modal">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-heading text-white" data-testid="refill-title">
            <Timer className="h-5 w-5 text-rose-400" aria-hidden /> Out of watch time
          </DialogTitle>
          <DialogDescription data-testid="refill-description">
            {requiredSeconds
              ? `This download needs ${formatBalance(requiredSeconds)} — your balance is empty.`
              : "Your free watch-time balance hit zero. Refill it in seconds."}
          </DialogDescription>
        </DialogHeader>

        <div className="flex flex-col items-center gap-3 rounded-2xl border border-slate-700/70 bg-slate-900/70 px-4 py-6">
          <MonitorPlay className="h-8 w-8 text-sky-400" aria-hidden />
          <p className="text-center text-xs text-zinc-400">
            Watch a short ad — get <b className="text-white">+{formatBalance(AD_SECONDS)}</b> of watch time
          </p>
          {playing ? (
            <div className="w-full" data-testid="refill-ad-progress">
              <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
                <div
                  className="h-full rounded-full bg-sky-500 transition-all duration-1000"
                  style={{ width: `${((5 - count) / 5) * 100}%` }}
                />
              </div>
              <p className="mt-2 flex items-center justify-center gap-1.5 text-xs font-bold text-sky-300">
                <Loader2 className="h-3 w-3 animate-spin" aria-hidden /> Ad playing — {count}s
              </p>
            </div>
          ) : (
            <Button
              onClick={() => void watchAd()}
              className="w-full bg-sky-500 font-bold text-white hover:bg-sky-400"
              data-testid="refill-ad-btn"
            >
              Watch ad · +30 min
            </Button>
          )}
        </div>

        <Link
          to="/vip"
          data-testid="refill-vip-link"
          className="flex items-center justify-center gap-2 rounded-xl border border-[#FBBF24]/40 bg-[#F59E0B]/10 px-4 py-3 text-sm font-bold text-[#FDE047] transition-colors hover:bg-[#F59E0B]/20"
        >
          <Crown className="h-4 w-4" aria-hidden /> Go VIP — ₹66 / 2 months · unlimited, ad-free
        </Link>
        <p className="text-center text-[11px] text-zinc-500">
          Mock rewarded ad — real AdSense slots drop in when approved.
        </p>
      </DialogContent>
    </Dialog>
  );
}
