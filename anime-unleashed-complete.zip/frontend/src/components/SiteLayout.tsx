import { useEffect, useState } from "react";
import { Link, Outlet, useLocation } from "react-router-dom";
import { Megaphone, Wrench, X } from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import Navbar from "@/components/Navbar";
import DonationModal from "@/components/DonationModal";
import AdSlot from "@/components/AdSlot";
import { useMe } from "@/hooks/useAuth";
import { usePlatform, usePublicNotices } from "@/hooks/usePlatform";
import { apiPost } from "@/lib/api";

// App shell: sticky navbar, routed page, footer. Toaster mounted once, bottom-right.
// Also pings the studio's visit counter once per browser session. When the owner
// flips maintenance ON (Studio > Platform), viewers + guests see the maintenance
// screen instead of the site — admins keep full access.
export default function SiteLayout() {
  const { pathname } = useLocation();
  const { data: me } = useMe();
  const platform = usePlatform();
  const notices = usePublicNotices();
  const [dismissed, setDismissed] = useState<string[]>([]);
  const notice = notices.data?.[0];

  useEffect(() => {
    if (sessionStorage.getItem("ah-visit")) return;
    sessionStorage.setItem("ah-visit", "1");
    apiPost("/visits").catch(() => {});
  }, []);

  if (platform.data?.maintenance && me?.role !== "admin") {
    return (
      <div
        className="flex min-h-svh flex-col items-center justify-center bg-[#07090E] px-4 text-center text-zinc-100"
        data-testid="maintenance-screen"
      >
        <Wrench className="h-10 w-10 text-amber-400" aria-hidden />
        <h1 className="mt-4 font-heading text-3xl font-bold text-white">Under maintenance</h1>
        <p className="mt-2 max-w-md text-sm text-zinc-400">
          Anime-Unleashed is getting a quick tune-up. Please check back in a little while.
        </p>
      </div>
    );
  }

  return (
    <div className="flex min-h-svh flex-col bg-[#07090E] text-zinc-100">
      <Navbar />
      {notice && !dismissed.includes(notice.id) ? (
        <div
          className="flex items-start gap-2 border-b border-amber-500/30 bg-amber-500/10 px-4 py-2 text-sm text-amber-200"
          data-testid="notice-banner"
        >
          <Megaphone className="mt-0.5 h-4 w-4 shrink-0" aria-hidden />
          <p className="min-w-0">
            <span className="font-bold">{notice.title}</span> — {notice.body}
          </p>
          <button
            onClick={() => setDismissed((d) => [...d, notice.id])}
            aria-label="Dismiss notice"
            className="ml-auto shrink-0 rounded p-0.5 hover:bg-white/10"
            data-testid="notice-dismiss"
          >
            <X className="h-4 w-4" aria-hidden />
          </button>
        </div>
      ) : null}
      <main className="flex-1">
        <div key={pathname} className="route-fade">
          <Outlet />
        </div>
      </main>
      {/* Footer minimal without redundant ad slot box */}
      <footer className="border-t border-slate-800/60 py-4 sm:py-5 bg-[#04060A]">
        <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col items-center justify-center gap-3 text-center">
            {/* ZNQ Network Banner */}
            <div className="flex flex-wrap items-center justify-center gap-2.5 rounded-2xl border border-purple-500/20 bg-purple-950/20 px-4 py-2 backdrop-blur-md">
              <span className="text-sm font-semibold text-zinc-300">Anime-Unleashed is proudly a part of</span>
              <img
                src="/znq-network-full.webp"
                alt="ZNQ Network"
                className="h-7 w-auto object-contain brightness-110"
              />
            </div>

            {/* Donation Support Button */}
            <div className="my-1">
              <DonationModal />
            </div>

            <div className="flex justify-center gap-6 text-xs text-muted-foreground" data-testid="footer-legal-links">
              <Link to="/about" className="hover:text-amber-400">About us</Link>
              <Link to="/privacy" className="hover:text-amber-400">Privacy policy</Link>
              <Link to="/terms" className="hover:text-amber-400">Terms &amp; conditions</Link>
              <Link to="/feedback" className="hover:text-amber-400">Feedback</Link>
            </div>

            <p className="max-w-2xl text-xs text-zinc-500">
              Anime-Unleashed Entertainment — streaming only owned &amp; licensed content. Rights
              holders can request a takedown via About us.
            </p>
            <p className="text-[11px] text-zinc-600">
              © {new Date().getFullYear()} Anime-Unleashed · An Official Member of ZNQ NETWORK · All Rights Reserved
            </p>
          </div>
        </div>
      </footer>
      <Toaster position="bottom-right" richColors />
    </div>
  );
}
