import { useEffect, useRef, useState, type CSSProperties, type ReactNode } from "react";

// Google-style scroll reveal — one IntersectionObserver per element, disconnects
// after first reveal. Pure transform/opacity (GPU), honours reduced motion.
export default function Reveal({
  children,
  delay = 0,
  className = "",
  testId,
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
  testId?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    if (typeof IntersectionObserver === "undefined") {
      setShown(true);
      return;
    }
    const io = new IntersectionObserver(
      (entries) => {
        if (entries.some((e) => e.isIntersecting)) {
          setShown(true);
          io.disconnect();
        }
      },
      { rootMargin: "0px 0px -6% 0px", threshold: 0.05 },
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  return (
    <div
      ref={ref}
      data-testid={testId}
      className={`reveal ${shown ? "is-revealed" : ""} ${className}`}
      style={{ "--reveal-delay": `${delay}ms` } as CSSProperties}
    >
      {children}
    </div>
  );
}
