import type { LucideIcon } from "lucide-react";
import { Button } from "@/components/ui/button";

// Friendly empty/error state with an optional recovery action.
export default function EmptyState({
  icon: Icon,
  title,
  message,
  actionLabel,
  onAction,
  testId = "empty-state",
}: {
  icon?: LucideIcon;
  title: string;
  message: string;
  actionLabel?: string;
  onAction?: () => void;
  testId?: string;
}) {
  return (
    <div
      data-testid={testId}
      className="mx-auto flex max-w-md flex-col items-center rounded-2xl border border-border bg-card/60 px-8 py-14 text-center"
    >
      {Icon ? (
        <div className="mb-4 flex h-14 w-14 items-center justify-center rounded-full bg-amber-400/10">
          <Icon className="h-7 w-7 text-amber-400" aria-hidden />
        </div>
      ) : null}
      <h3 className="text-lg font-semibold text-white">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{message}</p>
      {actionLabel && onAction ? (
        <Button className="mt-6" onClick={onAction} data-testid={`${testId}-action-btn`}>
          {actionLabel}
        </Button>
      ) : null}
    </div>
  );
}
