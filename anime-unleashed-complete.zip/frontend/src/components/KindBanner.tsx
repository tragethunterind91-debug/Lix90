import { Clapperboard, Heart, MonitorPlay, Rocket, Sparkles } from "lucide-react";
import type { TitleKind } from "@/lib/types";

// Themed hero band per content kind. Background = a slow-panning wall of the
// REAL catalog posters for that kind (actual artwork from the database, no
// generated art). Scrim keeps text legible; vertical word-wall carries the
// Japanese/Hangul/Devanagari/marquee typography. Gradient fallback when a kind
// has fewer than 2 posters.
const THEMES: Record<
  TitleKind,
  { banner: string; icon: typeof Sparkles; title: string; sub: string; marks: string[]; kanaTag: string }
> = {
  anime: {
    banner: "banner-anime",
    icon: Sparkles,
    title: "Anime Zone",
    sub: "Subbed & dubbed series — binge the arcs",
    marks: ["アニメ・ゾーン", "無限の物語"],
    kanaTag: "サイバー・ネオ・アニメ",
  },
  movie: {
    banner: "banner-movie",
    icon: Clapperboard,
    title: "Movie Night",
    sub: "Full-length films in cinematic quality",
    marks: ["シネマ", "NOW SHOWING"],
    kanaTag: "",
  },
  cartoon: {
    banner: "banner-cartoon",
    icon: Rocket,
    title: "Cartoon Corner",
    sub: "Fun picks for every age — no homework required",
    marks: ["まんが", "TOON ZONE"],
    kanaTag: "",
  },
  kdrama: {
    banner: "banner-kdrama",
    icon: Heart,
    title: "K-Drama Lane",
    sub: "Korean dramas — romance, thrillers & sageuk",
    marks: ["한국 드라마", "K-DRAMA"],
    kanaTag: "서울에서 온 이야기",
  },
  webseries: {
    banner: "banner-webseries",
    icon: MonitorPlay,
    title: "Web Series Hub",
    sub: "Binge-worthy originals & streaming hits",
    marks: ["वेब सीरीज़", "BINGE"],
    kanaTag: "",
  },
};

export default function KindBanner({ kind, posters = [] }: { kind: TitleKind; posters?: string[] }) {
  const t = THEMES[kind];
  const Icon = t.icon;
  // fill to 12 slots (repeat small sets), duplicate once for a seamless -50% pan
  const real = posters.filter(Boolean).slice(0, 12);
  const filled =
    real.length >= 2
      ? Array.from({ length: Math.ceil(12 / real.length) * real.length }, (_, i) => real[i % real.length]).slice(0, 12)
      : [];
  const wall = filled.length > 0 ? [...filled, ...filled] : [];

  return (
    <div
      className={`pop-in relative overflow-hidden rounded-2xl border border-slate-800 px-6 py-8 sm:px-10 sm:py-12 ${t.banner}`}
      data-testid={`kind-banner-${kind}`}
    >
      {/* real-poster wall — slow cinematic pan behind the content */}
      {wall.length > 0 ? (
        <div
          className="banner-poster-wall pointer-events-none absolute inset-0 flex h-full opacity-45"
          aria-hidden
          data-testid={`kind-poster-wall-${kind}`}
        >
          {wall.map((src, i) => (
            <img
              key={`${src}-${i}`}
              src={src}
              alt=""
              loading="lazy"
              className="h-full w-auto min-w-[130px] scale-105 object-cover blur-[1.5px]"
            />
          ))}
        </div>
      ) : null}
      {/* legibility scrim */}
      <div
        className="absolute inset-0"
        style={{ background: "linear-gradient(100deg, rgba(4,4,8,.93) 0%, rgba(4,4,8,.74) 55%, rgba(4,4,8,.42) 100%)" }}
        aria-hidden
      />

      {/* vertical word-wall art (Japanese/Hangul/Devanagari typography / marquee) */}
      <div
        className="pointer-events-none absolute right-3 top-1/2 z-10 hidden -translate-y-1/2 select-none flex-col items-center gap-4 sm:flex md:right-6"
        aria-hidden
      >
        {t.marks.map((m) => (
          <span
            key={m}
            className="banner-kana text-lg font-black uppercase tracking-[0.3em] text-white/[.20] md:text-2xl"
            style={kind === "anime" ? { textShadow: "0 0 18px rgba(255,42,133,.4)" } : undefined}
          >
            {m}
          </span>
        ))}
      </div>

      <div className="relative z-10">
        <span
          className="inline-flex items-center gap-2 rounded-lg px-3 py-1 text-[11px] font-black uppercase tracking-[0.18em] text-white/90"
          style={{ backgroundColor: "var(--kind-surface)", boxShadow: "0 0 0 1px var(--kind-accent)", clipPath: kind === "anime" ? "polygon(8px 0, 100% 0, calc(100% - 8px) 100%, 0 100%)" : undefined }}
        >
          <Icon className="h-3.5 w-3.5" style={{ color: "var(--kind-accent)" }} aria-hidden /> {kind}
        </span>
        <h2 className="kind-banner-text mt-3 font-heading text-3xl font-black uppercase tracking-tight sm:text-4xl">
          {t.title}
        </h2>
        {t.kanaTag ? <p className="mt-1 font-mono text-xs tracking-[0.3em] text-[#FF71CE]">{t.kanaTag}</p> : null}
        <p className="mt-1 max-w-md text-sm text-zinc-300/85">{t.sub}</p>
      </div>
    </div>
  );
}
