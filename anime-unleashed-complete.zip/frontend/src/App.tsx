import { useEffect, type ReactNode } from "react";
import { Routes, Route, Navigate, useLocation, useNavigate } from "react-router-dom";
import { Tv } from "lucide-react";
import SiteLayout from "@/components/SiteLayout";
import EmptyState from "@/components/EmptyState";
import Landing from "@/pages/Landing";
import Home from "@/pages/Home";
import Browse from "@/pages/Browse";
import Live from "@/pages/Live";
import MovieInfoPortal from "@/pages/MovieInfoPortal";
import SocialFeeds from "@/pages/SocialFeeds";
import TitleDetail from "@/pages/TitleDetail";
import Watch from "@/pages/Watch";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import ForgotPassword from "@/pages/ForgotPassword";
import MyList from "@/pages/MyList";
import Playlists from "@/pages/Playlists";
import PlaylistDetail from "@/pages/PlaylistDetail";
import HistoryPage from "@/pages/History";
import StudioLayout from "@/pages/studio/StudioLayout";
import StudioDashboard from "@/pages/studio/Dashboard";
import StudioCatalog from "@/pages/studio/Catalog";
import StudioEpisodes from "@/pages/studio/Episodes";
import StudioUsers from "@/pages/studio/Users";
import StudioRevenue from "@/pages/studio/Revenue";
import StudioFeedback from "@/pages/studio/Feedback";
import StudioAudit from "@/pages/studio/AuditLog";
import StudioSuppliers from "@/pages/studio/Suppliers";
import StudioOwner from "@/pages/studio/Owner";
import Supplier from "@/pages/Supplier";
import UserFeedback from "@/pages/Feedback";
import Vip from "@/pages/Vip";
import Publishers from "@/pages/Publishers";
import AiAudit from "@/pages/studio/AiAudit";
import SubscriptionsFeed from "@/pages/SubscriptionsFeed";
import CurrencyCenter from "@/pages/CurrencyCenter";
import Channel from "@/pages/Channel";
import ChannelsDirectory from "@/pages/Channels";
import Admin from "@/pages/Admin";
import WorkerLayout from "@/pages/worker/WorkerLayout";
import WorkerLogin from "@/pages/worker/WorkerLogin";
import WorkerDashboard from "@/pages/worker/WorkerDashboard";
import WorkerUpload from "@/pages/worker/WorkerUpload";
import CreatorSubmit from "@/pages/worker/CreatorSubmit";
import CreatorGrowth from "@/pages/worker/CreatorGrowth";
import StudioPlatform from "@/pages/studio/Platform";
import StudioNfts from "@/pages/studio/StudioNfts";
import AdminMonitoring from "@/pages/studio/AdminMonitoring";
import NftMarketplace from "@/pages/NftMarketplace";
import AuctionHouse from "@/pages/AuctionHouse";
import NftInventory from "@/pages/NftInventory";
import Account from "@/pages/Account";
import Friends from "@/pages/Friends";
import GlobalChat from "@/pages/GlobalChat";
import Tasks from "@/pages/Tasks";
import Earn from "@/pages/Earn";
import StudioTasks from "@/pages/studio/Tasks";
import { About, Privacy, Terms } from "@/pages/Legal";
import { useMe } from "@/hooks/useAuth";

function HomeOrLanding() {
  const { data: me, isLoading } = useMe();
  if (isLoading) return null;
  return me ? <Home /> : <Landing />;
}

function RequireAuth({ children }: { children: ReactNode }) {
  const { data: me, isLoading } = useMe();
  if (isLoading) return null;
  if (!me) {
    return <Navigate to="/login" replace />;
  }
  return children;
}

function ScrollToTop() {
  const { pathname } = useLocation();
  useEffect(() => {
    window.scrollTo(0, 0);
  }, [pathname]);
  return null;
}

// TWO apps in one repo:
//  - Viewer site: everything under SiteLayout (navbar + footer) — no admin UI anywhere.
//  - Studio console: /studio/* with its own shell (SidebarLayout) — deploys as a
//    separate Firebase site for admins (see docs/DEPLOY-TERMUX.md).
// Separate sites by HOST: studio.* -> the admin console, worker.* -> the worker
// desk, everything else -> the viewer site. Admin and worker are never mixed.
function HostRedirect() {
  const host = typeof window !== "undefined" ? window.location.hostname : "";
  const { pathname } = useLocation();
  const navigate = useNavigate();
  useEffect(() => {
    if (host.startsWith("publisher")) {
      if (pathname !== "/publishers") navigate("/publishers", { replace: true });
      return;
    }
    const isWorkerHost = host.startsWith("worker.");
    if (isWorkerHost) {
      const inWorker = pathname === "/worker" || pathname.startsWith("/worker/");
      if (!inWorker) navigate("/worker", { replace: true });
      return;
    }
    const isStudioHost = host.startsWith("studio.") || host.startsWith("studio-");
    const inStudio = pathname === "/studio" || pathname.startsWith("/studio/") || pathname === "/login" || pathname.startsWith("/auth");
    if (isStudioHost && !inStudio) navigate("/studio", { replace: true });
  }, [host, pathname, navigate]);
  return null;
}

export default function App() {
  return (
    <>
      <ScrollToTop />
      <HostRedirect />
      <Routes>
        {/* viewer website */}
        <Route element={<SiteLayout />}>
          <Route path="/" element={<HomeOrLanding />} />
          <Route path="/home" element={<RequireAuth><Home /></RequireAuth>} />
          <Route path="/landing" element={<Landing />} />
          <Route path="/live" element={<Live />} />
          <Route path="/info" element={<RequireAuth><MovieInfoPortal /></RequireAuth>} />
          <Route path="/social" element={<Navigate to="/explore" replace />} />
          <Route path="/explore" element={<SocialFeeds />} />
          <Route path="/browse" element={<Browse />} />
          <Route path="/title/:slug" element={<TitleDetail />} />
          <Route path="/watch/:slug/:ep?" element={<Watch />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/forgot-password" element={<ForgotPassword />} />
          <Route path="/my-list" element={<RequireAuth><MyList /></RequireAuth>} />
          <Route path="/playlists" element={<RequireAuth><Playlists /></RequireAuth>} />
          <Route path="/playlist/:id" element={<RequireAuth><PlaylistDetail /></RequireAuth>} />
          <Route path="/history" element={<RequireAuth><HistoryPage /></RequireAuth>} />
          <Route path="/privacy" element={<Privacy />} />
          <Route path="/terms" element={<Terms />} />
          <Route path="/about" element={<About />} />
          <Route path="/feedback" element={<RequireAuth><UserFeedback /></RequireAuth>} />
          <Route path="/supplier" element={<RequireAuth><Supplier /></RequireAuth>} />
          <Route path="/account" element={<RequireAuth><Account /></RequireAuth>} />
          <Route path="/friends" element={<RequireAuth><Friends /></RequireAuth>} />
          <Route path="/chat" element={<RequireAuth><GlobalChat /></RequireAuth>} />
          <Route path="/tasks" element={<RequireAuth><Tasks /></RequireAuth>} />
          <Route path="/earn" element={<RequireAuth><Earn /></RequireAuth>} />
          <Route path="/vip" element={<RequireAuth><Vip /></RequireAuth>} />
          <Route path="/publishers" element={<RequireAuth><Publishers /></RequireAuth>} />
          <Route path="/subscriptions" element={<RequireAuth><SubscriptionsFeed /></RequireAuth>} />
          <Route path="/following" element={<RequireAuth><SubscriptionsFeed /></RequireAuth>} />
          <Route path="/wallet" element={<RequireAuth><CurrencyCenter /></RequireAuth>} />
          <Route path="/channel/:userId" element={<RequireAuth><Channel /></RequireAuth>} />
          <Route path="/channels" element={<RequireAuth><ChannelsDirectory /></RequireAuth>} />
          <Route path="/nft" element={<NftMarketplace />} />
          <Route path="/auctions" element={<AuctionHouse />} />
          <Route path="/inventory" element={<RequireAuth><NftInventory /></RequireAuth>} />
          <Route
            path="*"
            element={
              <div className="mx-auto max-w-3xl px-4 py-20">
                <EmptyState
                  icon={Tv}
                  title="Page not found"
                  message="The page you're looking for drifted into another timeline."
                  actionLabel="Back to home"
                  onAction={() => window.location.assign("/")}
                  testId="not-found"
                />
              </div>
            }
          />
        </Route>

        {/* separate admin console */}
        <Route path="/studio" element={<StudioLayout />}>
          <Route index element={<StudioDashboard />} />
          <Route path="catalog" element={<StudioCatalog />} />
          <Route path="episodes" element={<StudioEpisodes />} />
          <Route path="nfts" element={<StudioNfts />} />
          <Route path="users" element={<StudioUsers />} />
          <Route path="revenue" element={<StudioRevenue />} />
          <Route path="monitoring" element={<AdminMonitoring />} />
          <Route path="feedback" element={<StudioFeedback />} />
        <Route path="audit" element={<StudioAudit />} />
          <Route path="ai-audit" element={<AiAudit />} />
          <Route path="suppliers" element={<StudioSuppliers />} />
          <Route path="tasks" element={<StudioTasks />} />
          <Route path="platform" element={<StudioPlatform />} />
          <Route path="owner" element={<StudioOwner />} />
        </Route>
        <Route path="/admin" element={<Admin />} />

        {/* staff webs — the owner's distinction:
            worker  = upload staff (uploads the owner's videos as drafts)
            creator = YouTube-style supplier (submits their OWN content by link) */}
        <Route path="/worker/login" element={<WorkerLogin variant="worker" />} />
        <Route path="/worker" element={<WorkerLayout variant="worker" />}>
          <Route index element={<WorkerDashboard variant="worker" />} />
          <Route path="upload" element={<WorkerUpload />} />
        </Route>
        <Route path="/creator/login" element={<WorkerLogin variant="creator" />} />
        <Route path="/creator" element={<WorkerLayout variant="creator" />}>
          <Route index element={<WorkerDashboard variant="creator" />} />
          <Route path="submit" element={<CreatorSubmit />} />
          <Route path="growth" element={<CreatorGrowth />} />
        </Route>
      </Routes>
    </>
  );
}
