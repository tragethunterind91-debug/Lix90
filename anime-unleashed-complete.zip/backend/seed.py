"""Idempotent bootstrap: ensures the owner's admin account exists in DynamoDB.

No demo content is seeded — the real catalog (titles, episodes, videos) is created
from the Admin panel only. Run: cd /app/backend && python seed.py"""

import asyncio

from lib import store
from lib.security import hash_password

ADMIN_EMAIL = "admin@animehub.in"
# Owner's seat until Firebase sign-in is enabled; rotate via ADMIN_EMAILS + Firebase,
# or change this password and re-run seed with the account removed.
ADMIN_PASSWORD = "AnimeHub@2025"


async def seed() -> None:
    store.ensure_tables()
    if store.get_user_by_email(ADMIN_EMAIL):
        print(f"Admin {ADMIN_EMAIL} already exists — nothing to do.")
        return
    store.put_user({
        "id": "seed-admin",
        "email": ADMIN_EMAIL,
        "display_name": "Studio Owner",
        "role": "admin",
        "is_owner": True,  # super-admin seat — global stats + admin management
        "password_hash": hash_password(ADMIN_PASSWORD),
        "created_at": "2025-01-01T00:00:00+00:00",
    })
    print(f"Created admin {ADMIN_EMAIL} in DynamoDB")


if __name__ == "__main__":
    asyncio.run(seed())
