#!/usr/bin/env bash
# One-shot AWS EC2 bootstrap for the Anime-Unleashed backend.
# Run ON a fresh Ubuntu 24.04 EC2 instance (t2.micro is fine), as ubuntu:
#   sudo apt-get update && sudo apt-get install -y git
#   git clone <YOUR-REPO> ~/animehub && cd ~/animehub/backend/aws
#   DOMAIN=api.your-domain.com REPO=/home/ubuntu/animehub sudo -E bash ec2-setup.sh
set -euo pipefail

DOMAIN="${DOMAIN:?Set DOMAIN=api.your-domain.com with a DNS A record pointing at this instance IP}"
REPO="${REPO:-/home/ubuntu/animehub}"
APP_DIR="$REPO/backend"

echo "==> 1/6 System packages"
apt-get update -qq
apt-get install -y -qq python3-venv python3-pip debian-keyring debian-archive-keyring apt-transport-https curl ffmpeg >/dev/null
# ffmpeg powers the convert system (resolution variants + audio-only tracks)
# Caddy is not in Ubuntu's default repos — add the official one.
curl -fsSL "https://caddyserver.com/api/download?os=linux&arch=amd64" -o /usr/local/bin/caddy 2>/dev/null \
  || { add-apt-repository -y ppa:caddy-d/web 2>/dev/null || true; apt-get update -qq; apt-get install -y -qq caddy; }
chmod +x /usr/local/bin/caddy 2>/dev/null || true

echo "==> 2/6 Python venv + dependencies"
cd "$APP_DIR"
python3 -m venv venv
venv/bin/pip install -q -r aws/requirements-ec2.txt

echo "==> 3/6 Environment (.env)"
if [ ! -f "$APP_DIR/.env" ]; then
  install -o ubuntu -g ubuntu -m 600 "$APP_DIR/.env.production.example" "$APP_DIR/.env"
fi
if grep -q "REPLACE_ME" "$APP_DIR/.env"; then
  echo "    STOP: fill in $APP_DIR/.env first (AWS keys + SESSION_SECRET), then re-run this script."
  echo "    Open it with:  nano $APP_DIR/.env"
  exit 1
fi

echo "==> 4/6 systemd service"
cp "$APP_DIR/aws/animehub-api.service" /etc/systemd/system/
systemctl daemon-reload
systemctl enable --now animehub-api

echo "==> 5/6 Caddy reverse proxy (auto-HTTPS for $DOMAIN)"
sed -i "s|^api.YOUR-DOMAIN.com|$DOMAIN|" "$APP_DIR/aws/Caddyfile"
cp "$APP_DIR/aws/Caddyfile" /etc/caddy/Caddyfile
systemctl enable --now caddy
systemctl reload caddy || systemctl restart caddy

echo "==> 6/6 Smoke test"
sleep 3
curl -fsS "http://127.0.0.1:8001/api/titles" >/dev/null && echo "OK: local API responds"
curl -fsS "https://$DOMAIN/api/titles" && echo "OK: public HTTPS API live"

echo
echo "DONE. Deploy the frontend with:"
echo "  ./deploy.sh https://$DOMAIN"
