#!/usr/bin/env bash
# Nightly DynamoDB catalog backup — FREE (scan-to-JSON on the box, no AWS backup fees).
# Keeps 7 nights in ~/backups, compresses each table, logs to ~/backups/backup.log.
# Install: the updater wires a cron line (2:30 AM IST nightly).

set -uo pipefail
BACKUP_DIR="$HOME/backups"
LOG="$BACKUP_DIR/backup.log"
KEEP=7
REGION="${AWS_REGION:-ap-south-1}"
TABLES=(animehub-users animehub-titles animehub-episodes animehub-history animehub-playlists animehub-feedback animehub-audit animehub-tasks animehub-task-claims animehub-submissions animehub-videos animehub-analytics_events animehub-notices animehub-link_rewards animehub-visits animehub-status animehub-config animehub-otps animehub-watermarks)

mkdir -p "$BACKUP_DIR"
STAMP="$(date +%Y-%m-%d_%H%M)"
echo "[$(date)] backup start" >> "$LOG"

for T in "${TABLES[@]}"; do
  OUT="$BACKUP_DIR/${T}_${STAMP}.json.gz"
  if python3 - "$T" "$OUT" "$REGION" <<'PY'
import json, gzip, sys, os
import boto3
from boto3.dynamodb.types import TypeDeserializer

table, out, region = sys.argv[1], sys.argv[2], sys.argv[3]
client = boto3.client("dynamodb", region_name=region)
des = TypeDeserializer()
rows, last = [], None
try:
    while True:
        kw = {"TableName": table, "Limit": 300}
        if last:
            kw["ExclusiveStartKey"] = last
        resp = client.scan(**kw)
        rows.extend([{k: des.deserialize(v) for k, v in item.items()} for item in resp.get("Items", [])])
        last = resp.get("LastEvaluatedKey")
        if not last:
            break
    with gzip.open(out, "wt") as f:
        json.dump(rows, f)
    sys.exit(0)
except Exception:
    sys.exit(1)
PY
  then
    echo "[$(date)] OK  $T ($(du -h "$OUT" | cut -f1))" >> "$LOG"
  else
    rm -f "$OUT"
    echo "[$(date)] FAIL $T" >> "$LOG"
  fi
done

find "$BACKUP_DIR" -name "*.json.gz" -mtime +$KEEP -delete
echo "[$(date)] backup done" >> "$LOG"
