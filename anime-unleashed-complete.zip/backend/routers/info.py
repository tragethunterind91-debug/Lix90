"""Curated Anime, Cartoon & Movie Box Office, Ratings, Awards and Global Statistics.

Provides detailed box office collection, ticket sales, dub counts, awards, production budget,
genres, duration, studio, and official links across Global, India, US, and Anime Unleashed rankings.
"""

from typing import List, Optional
import uuid
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel
from lib import store
from lib.security import get_admin_user

router = APIRouter(prefix="/info", tags=["info"])


class MovieInfo(BaseModel):
    id: str
    rank: int
    region: str  # "global", "india", "us", "anime_unleashed"
    category: str  # "anime", "movie", "cartoon"
    title: str
    original_title: Optional[str] = None
    poster_url: str
    description: str
    box_office_usd: str
    total_tickets_sold: str
    production_cost_usd: str
    rating: float
    release_date: str
    original_language: str
    total_dubbed_languages: int
    dubbed_languages: List[str]
    duration_mins: int
    studio: str
    genres: List[str]  # e.g. ["#action", "#thriller", "#supernatural"]
    awards_count: int
    awards: List[str]
    official_website: str
    official_email: str


STATS_CATALOG: List[MovieInfo] = []


class MovieInfoIn(BaseModel):
    rank: int = 1
    region: str = "global"  # "global", "india", "us", "anime_unleashed"
    category: str = "anime"  # "anime", "movie", "cartoon"
    title: str
    original_title: Optional[str] = None
    poster_url: str = ""
    description: str = ""
    box_office_usd: str = "$0"
    total_tickets_sold: str = "0 tickets"
    production_cost_usd: str = "$0"
    rating: float = 8.0
    release_date: str = ""
    original_language: str = "Japanese"
    total_dubbed_languages: int = 1
    dubbed_languages: List[str] = []
    duration_mins: int = 100
    studio: str = ""
    genres: List[str] = []
    awards_count: int = 0
    awards: List[str] = []
    official_website: str = ""
    official_email: str = ""


@router.post("", response_model=MovieInfo, status_code=201)
async def create_movie_info(payload: MovieInfoIn, admin: dict = Depends(get_admin_user)):
    """ADMIN ONLY: Add a new movie/anime record to the Information database."""
    info_id = f"info-{uuid.uuid4().hex[:10]}"
    doc = {
        "id": info_id,
        **payload.model_dump(),
    }
    store.put_item("movie_info", doc)
    return MovieInfo(**doc)


@router.delete("/{movie_id}", status_code=204)
async def delete_movie_info(movie_id: str, admin: dict = Depends(get_admin_user)):
    """ADMIN ONLY: Delete a movie info record."""
    store.delete_item("movie_info", movie_id)


@router.get("", response_model=List[MovieInfo])
async def list_movies_info(
    region: Optional[str] = Query(None, description="Filter by region: global, india, us, anime_unleashed"),
    category: Optional[str] = Query(None, description="Filter by category: anime, movie, cartoon"),
    genre: Optional[str] = Query(None, description="Filter by genre tag: e.g. action, thriller"),
):
    """Retrieve top-ranked anime, cartoons, and movies with deep statistics."""
    try:
        items = [MovieInfo(**x) for x in store.scan("movie_info")]
    except Exception:
        items = []
    
    if region:
        items = [m for m in items if m.region.lower() == region.lower()]
    if category:
        items = [m for m in items if m.category.lower() == category.lower()]
    if genre:
        g = f"#{genre.lower().lstrip('#')}"
        items = [m for m in items if g in [x.lower() for x in m.genres]]
    return sorted(items, key=lambda x: x.rank)


@router.get("/{movie_id}", response_model=MovieInfo)
async def get_movie_info(movie_id: str):
    """Get full details for a specific movie or anime release."""
    item = store.get_item("movie_info", movie_id)
    if not item:
        raise HTTPException(status_code=404, detail="Movie info not found")
    return MovieInfo(**item)
