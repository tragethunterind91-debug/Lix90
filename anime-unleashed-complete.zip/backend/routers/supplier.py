"""Supplier (content-partner) program — the owner's "distribution" plan:

1. a viewer applies in-app (channel + ownership proof; no illegal/toxic/copied content);
2. the owner approves in the Studio → the account becomes a WORKER (Creator Desk access);
3. approved creators submit content BY LINK (video link + title/language/thumb/description);
4. approving a submission creates a DRAFT title — the owner finishes details and launches
   it as Upcoming (countdown) or Listed exactly like any other title;
5. stale rule: supplier-origin titles with 0 views for 90+ days can be purged.
"""

import uuid
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException

from lib import storage, store
from lib.security import get_admin_user, get_current_user, admin_emails
from models.supplier import (
    DecisionIn,
    PublisherVerifyIn,
    SubmissionIn,
    SupplierApplyIn,
    SupplierApplicationOut,
    SupplierMeOut,
    SupplierSubmissionOut,
)
from routers.titles import _unique_slug

router = APIRouter(tags=["supplier"])


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _app_out(doc: dict) -> SupplierApplicationOut:
    return SupplierApplicationOut(**doc)


def _sub_out(doc: dict) -> SupplierSubmissionOut:
    return SupplierSubmissionOut(**doc)


def _latest_application(user_id: str) -> dict | None:
    rows = store.query("supplier_apps", "user_created", "user_id", user_id, "created_at", None, False)
    return rows[0] if rows else None


# ------------------------------------------------------------- creator surface
@router.post("/supplier/apply", response_model=SupplierApplicationOut, status_code=201)
async def apply(payload: SupplierApplyIn, user: dict = Depends(get_current_user)):
    """Viewer → supplier application. Reviewed by the owner in Studio > Suppliers."""
    if user.get("role") in ("worker", "admin"):
        raise HTTPException(status_code=400, detail="You're already on the creator team")
    existing = _latest_application(user["id"])
    if existing and existing.get("status") == "pending":
        raise HTTPException(status_code=409, detail="You already applied — wait for the owner's review")
    doc = {
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "email": user["email"],
        **payload.model_dump(),
        "status": "pending",
        "created_at": _now_iso(),
    }
    store.put_item("supplier_apps", doc)

    # Send creator application details directly to owner email so it never gets lost in web chat
    try:
        from lib import otp
        import boto3
        import os

        owner_dest = admin_emails() or ["AnimeUnleashed@adown.com"]
        region = os.environ.get("SES_REGION", os.environ.get("AWS_REGION", "ap-south-1"))
        sender = os.environ.get("MAIL_FROM", "noreply@animeunleashed.in")
        subject = f"New Publisher Channel Application: {payload.channel_name}"
        body = (
            f"You received a new Publisher Channel application on Anime-Unleashed:\n\n"
            f"• Channel Name: {payload.channel_name}\n"
            f"• Applicant Email: {user['email']}\n"
            f"• Channel URL: {payload.channel_url}\n"
            f"• Content Type: {payload.content_type}\n"
            f"• Note / Content Plan: {payload.note}\n"
            f"• Date: {_now_iso()}\n\n"
            f"To review or approve, login to Studio Admin -> Creators & Suppliers.\n"
            f"Policy reminder: We accept almost all videos; if improvement is needed, inform the creator."
        )
        client = boto3.client("sesv2", region_name=region)
        client.send_email(
            FromEmailAddress=sender,
            Destination={"ToAddresses": owner_dest},
            Content={
                "Simple": {
                    "Subject": {"Data": subject, "Charset": "UTF-8"},
                    "Body": {"Text": {"Data": body, "Charset": "UTF-8"}},
                }
            },
        )
    except Exception as e:
        # Non-blocking so application still records in database even if SES sandbox rejects unverified recipient
        pass

    return _app_out(doc)


@router.get("/supplier/me", response_model=SupplierMeOut)
async def my_desk(user: dict = Depends(get_current_user)):
    app_doc = _latest_application(user["id"])
    subs = store.query(
        "supplier_submissions", "user_created", "user_id", user["id"], "created_at", None, False
    )
    return SupplierMeOut(
        application=_app_out(app_doc) if app_doc else None,
        submissions=[_sub_out(s) for s in subs],
    )


@router.post("/supplier/submissions", response_model=SupplierSubmissionOut, status_code=201)
async def submit_content(payload: SubmissionIn, user: dict = Depends(get_current_user)):
    """Approved creators hand in content by link — the owner reviews it. Workers are a
    different role (owner's upload staff) and never submit through this program."""
    if user.get("role") not in ("creator", "admin"):
        raise HTTPException(
            status_code=403,
            detail="Become an approved creator first — apply from the Creator page",
        )
    doc = {
        "id": str(uuid.uuid4()),
        "user_id": user["id"],
        "email": user["email"],
        **payload.model_dump(),
        "status": "pending",
        "created_at": _now_iso(),
    }
    store.put_item("supplier_submissions", doc)
    return _sub_out(doc)


# ---------------------------------------------------------------- admin review
@router.get("/admin/supplier/applications", response_model=list[SupplierApplicationOut])
async def list_applications(_: dict = Depends(get_admin_user)):
    rows = store.scan("supplier_apps")
    rows.sort(key=lambda a: a.get("created_at", ""), reverse=True)
    return [_app_out(a) for a in rows]


# ------------------------------------------------ channel verification (3 tests)
TEST_RULES = {
    1: "content rules — no illegal content, violence, discrimination, fake or mind-manipulating material",
    2: "quality — interesting, clear video, 10 minutes to 1 hour per video",
    3: "originality — not fully copied; must have potential to attract viewers",
}


@router.post("/admin/supplier/applications/{app_id}/verify", response_model=SupplierApplicationOut)
async def verify_application(app_id: str, payload: PublisherVerifyIn, _: dict = Depends(get_admin_user)):
    """The notebook's channel check: Test 1 → 2 → 3, auto-advance on pass; a fail
    rejects + emails the reason. Passing test 3 approves the publisher (creator role,
    so submissions + growth unlock) and mails the welcome/congratulations email."""
    from lib import mailer

    doc = store.get_item("supplier_apps", app_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Application not found")
    tests = dict(doc.get("tests") or {})
    current = int(doc.get("current_test") or 1)
    if current > 3:
        raise HTTPException(status_code=409, detail="All 3 tests are already reviewed")
    if payload.test != current:
        raise HTTPException(status_code=409, detail=f"Review test {current} first")
    if payload.passed:
        tests[str(payload.test)] = "passed"
        if payload.test == 3:
            doc.update(
                {
                    "tests": tests,
                    "status": "approved",
                    "channel_verified": True,
                    "admin_note": payload.note or "Passed all 3 channel tests",
                }
            )
            store.put_item("supplier_apps", doc)
            store.update_user(doc.get("user_id", ""), {"role": "creator"})
            mailer.send_email(
                doc.get("email", ""),
                "You passed all 3 tests — welcome, publisher!",
                f"Hi {doc.get('channel_name', 'there')},\n\nCongratulations — your channel passed all 3 "
                "Anime-Unleashed tests. Your Publisher desk is live at animeunleashed.in/publishers — "
                "submit your videos and track your growth there.\n\n"
                "One last step: add a short Anime-Unleashed welcome note or link in your channel bio.\n\n— The Anime-Unleashed team",
            )
        else:
            doc.update({"tests": tests, "current_test": payload.test + 1})
            store.put_item("supplier_apps", doc)
            mailer.send_email(
                doc.get("email", ""),
                f"Channel test {payload.test} passed",
                f"Hi {doc.get('channel_name', 'there')},\n\nYour channel passed test {payload.test} "
                f"({TEST_RULES[payload.test]}). The owner will review test {payload.test + 1} next.\n\n— The Anime-Unleashed team",
            )
    else:
        tests[str(payload.test)] = "failed"
        doc.update({"tests": tests, "status": "rejected", "admin_note": payload.note or "Did not pass the channel test"})
        store.put_item("supplier_apps", doc)
        mailer.send_email(
            doc.get("email", ""),
            f"Channel test {payload.test}: not passed",
            f"Hi {doc.get('channel_name', 'there')},\n\nYour channel did not pass test {payload.test} "
            f"({TEST_RULES[payload.test]}).\n\nOwner's note: {payload.note or 'Review the rules and apply again with improved videos.'}\n\n— The Anime-Unleashed team",
        )
    return _app_out(doc)


@router.patch("/admin/supplier/applications/{app_id}", response_model=SupplierApplicationOut)
async def decide_application(app_id: str, payload: DecisionIn, admin: dict = Depends(get_admin_user)):
    doc = store.get_item("supplier_apps", app_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Application not found")
    if doc.get("status") != "pending":
        raise HTTPException(status_code=409, detail="Already decided")
    updated = store.update_item(
        "supplier_apps",
        app_id,
        set_updates={"status": payload.status, "admin_note": payload.admin_note, "decided_at": _now_iso()},
    )
    if payload.status == "approved":
        store.update_user(doc["user_id"], {"role": "creator"})  # Creator Desk access (NOT a worker — workers are the owner's upload staff)
    store.put_audit(
        {
            "id": str(uuid.uuid4()),
            "actor": admin.get("email", "unknown"),
            "action": f"supplier.application.{payload.status}",
            "target": f"{doc.get('email')} — {doc.get('channel_name')}",
            "created_at": _now_iso(),
        }
    )
    return _app_out(updated or doc)


@router.get("/admin/supplier/submissions", response_model=list[SupplierSubmissionOut])
async def list_submissions(_: dict = Depends(get_admin_user)):
    rows = store.scan("supplier_submissions")
    rows.sort(key=lambda s: s.get("created_at", ""), reverse=True)
    return [_sub_out(s) for s in rows]


@router.patch("/admin/supplier/submissions/{sub_id}", response_model=SupplierSubmissionOut)
async def decide_submission(sub_id: str, payload: DecisionIn, admin: dict = Depends(get_admin_user)):
    doc = store.get_item("supplier_submissions", sub_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Submission not found")
    if doc.get("status") != "pending":
        raise HTTPException(status_code=409, detail="Already decided")
    updates: dict = {"status": payload.status, "admin_note": payload.admin_note, "decided_at": _now_iso()}
    if payload.status == "approved":
        # seed a DRAFT title from the submission — owner finishes details + launches it
        doc.update(updates)
        _convert_to_draft(doc)
        updates["status"] = "converted"
    updated = store.update_item("supplier_submissions", sub_id, set_updates=updates)
    store.put_audit(
        {
            "id": str(uuid.uuid4()),
            "actor": admin.get("email", "unknown"),
            "action": f"supplier.submission.{updates['status']}",
            "target": f"{doc.get('email')} — {doc.get('title')}",
            "created_at": _now_iso(),
        }
    )
    return _sub_out(updated or {**doc, **updates})


def _convert_to_draft(sub: dict) -> None:
    now = datetime.now(timezone.utc)
    store.put_title(
        {
            "id": str(uuid.uuid4()),
            "slug": _unique_slug(sub["title"]),
            "name": sub["title"],
            "synopsis": sub.get("description", ""),
            "genres": [],
            "release_year": now.year,
            "type": "movie" if sub.get("kind") == "movie" else "series",
            "kind": sub.get("kind", "anime"),
            "studio": "",
            "age_rating": "",
            "original_language": sub.get("language", ""),
            "airing_status": "",
            "audio": ["Eng Sub"],
            "rating": None,
            "featured": False,
            "poster_url": sub.get("thumbnail_url", ""),
            "status": "draft",
            "visibility": None,
            "release_at": None,
            "episode_count": 0,
            "views": 0,
            "created_at": _now_iso(),
            "created_by_role": "supplier",
            "source_url": sub.get("source_url", ""),
            "supplier_email": sub.get("email", ""),
        }
    )


# ----------------------------------------------------------- stale-title purge
@router.post("/admin/supplier/purge-stale")
async def purge_stale(admin: dict = Depends(get_admin_user)):
    """The 3-month rule: supplier titles with ZERO views for 90+ days get removed."""
    cutoff = (datetime.now(timezone.utc) - timedelta(days=90)).isoformat()
    removed: list[str] = []
    for t in store.scan("titles"):
        if not t.get("supplier_email") or t.get("views", 0) != 0:
            continue
        if (t.get("created_at") or "9999") >= cutoff:
            continue
        for ep in store.get_episodes_by_title(t["id"], published_only=False):
            storage.delete_video(ep.get("video_key"))
            store.delete_episode(ep["id"])
        store.remove_watchlist_for_title(t["id"])
        store.remove_history_for_title(t["id"])
        store.delete_title(t["id"])
        removed.append(t["name"])
    store.put_audit(
        {
            "id": str(uuid.uuid4()),
            "actor": admin.get("email", "unknown"),
            "action": "supplier.purge_stale",
            "target": ", ".join(removed)[:200],
            "created_at": _now_iso(),
        }
    )
    return {"removed": len(removed), "names": removed[:20]}
