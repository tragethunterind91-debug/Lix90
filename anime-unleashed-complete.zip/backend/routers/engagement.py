"""Engagement system — the owner's YouTube-style batch:

- FOLLOW a publisher channel (followed channels' videos appear on Home)
- LIKE / DISLIKE episodes (one vote each, toggleable)
- COMMENTS per episode (own comments deletable, admin can moderate)
- Public channel directory: name, logo, bio, followers, videos

Tables: follows (by_user), reactions (by_episode), comments (by_episode+created_at).
"""

import base64
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from lib import r2, store
from lib.security import get_admin_user, get_current_user

router = APIRouter(tags=["engagement"])


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class FollowIn(BaseModel):
    channel_user_id: str = Field(min_length=6, max_length=64)


@router.post("/engagement/follow")
async def toggle_follow(payload: FollowIn, user: dict = Depends(get_current_user)):
    """Follow/unfollow a publisher channel. Followed channels' videos appear on Home."""
    if payload.channel_user_id == user["id"]:
        raise HTTPException(status_code=422, detail="You can't follow your own channel")
    fid = f"{user['id']}:{payload.channel_user_id}"
    existing = store.get_item("follows", fid)
    channel = store.get_user(payload.channel_user_id)
    if existing:
        store.delete_item("follows", fid)
        if channel:
            store.update_user(channel["id"], {"followers_count": max(0, int(channel.get("followers_count") or 0) - 1)})
        return {"following": False}
    store.put_item(
        "follows",
        {"id": fid, "user_id": user["id"], "channel_user_id": payload.channel_user_id, "created_at": _now()},
    )
    if channel:
        store.update_user(channel["id"], {"followers_count": int(channel.get("followers_count") or 0) + 1})
    return {"following": True}


@router.get("/engagement/my-follows")
async def my_follows(user: dict = Depends(get_current_user)):
    rows = store.query("follows", "by_user", "user_id", user["id"], None, None, True)
    return [r["channel_user_id"] for r in rows]


@router.get("/engagement/subscriptions-feed")
async def subscriptions_feed(user: dict = Depends(get_current_user)):
    """YouTube-style Subscriptions Feed:
    Returns followed channels with their profile details AND all videos published by those channels.
    Also computes smart 'Loved & Suggested Videos' based on liked genres/tags and top-viewed uploads."""
    follow_rows = store.query("follows", "by_user", "user_id", user["id"], None, None, True)
    followed_ids = [r["channel_user_id"] for r in follow_rows]
    
    followed_channels = []
    followed_videos = []
    
    for cid in followed_ids:
        u = store.get_user(cid)
        if not u:
            continue
        c_view = _channel_view(u, with_email=True)
        c_titles = [t for t in store.scan("titles") if t.get("supplier_email") == u.get("email") and t.get("status") == "published"]
        c_view["videos"] = len(c_titles)
        followed_channels.append(c_view)
        for t in c_titles:
            followed_videos.append({
                **t,
                "channel_name": c_view["name"],
                "channel_logo": c_view["logo"],
                "channel_id": cid,
            })
            
    # Sort followed videos newest first
    followed_videos.sort(key=lambda x: x.get("created_at", ""), reverse=True)
    
    # YouTube-style 'Loved & Suggested for You':
    # 1. Fetch user's liked episodes/titles to deduce favorite categories/genres
    user_reactions = [r for r in store.scan("reactions") if r.get("user_id") == user["id"] and r.get("val") == 1]
    liked_episodes = {r["episode_id"] for r in user_reactions}
    
    # 2. Extract keywords/genres from liked titles or history
    history_rows = store.query("history", "by_user", "user_id", user["id"], "updated_at", None, True)
    viewed_title_slugs = {h.get("title_slug") for h in history_rows if h.get("title_slug")}
    
    all_published = [t for t in store.scan("titles") if t.get("status") == "published"]
    
    suggested_videos = []
    for t in all_published:
        # Avoid already fully watched unless catalog is small
        score = 0
        if t.get("slug") in viewed_title_slugs:
            score += 2
        if t.get("featured"):
            score += 3
        score += min(5, int(t.get("views") or 0))
        suggested_videos.append({"title": t, "score": score})
        
    suggested_videos.sort(key=lambda x: x["score"], reverse=True)
    top_suggestions = [s["title"] for s in suggested_videos[:12]]
    
    # Also fetch featured social/creator webviews from Explore
    social_suggestions = [x for x in store.scan("social_embeds") if x.get("featured_on_home")][:6]
    
    return {
        "followed_channels": followed_channels,
        "followed_videos": followed_videos,
        "suggested_videos": top_suggestions,
        "social_suggestions": social_suggestions,
        "total_following": len(followed_channels),
    }


class ReactIn(BaseModel):
    episode_id: str = Field(min_length=6, max_length=80)
    val: int  # 1 like, -1 dislike, 0 = clear my vote


def _counts(episode_id: str) -> dict:
    likes = dislikes = 0
    for r in store.query("reactions", "by_episode", "episode_id", episode_id, None, None, True):
        if r.get("val") == 1:
            likes += 1
        elif r.get("val") == -1:
            dislikes += 1
    return {"likes": likes, "dislikes": dislikes}


@router.post("/engagement/react")
async def react(payload: ReactIn, user: dict = Depends(get_current_user)):
    rid = f"{user['id']}:{payload.episode_id}"
    existing = store.get_item("reactions", rid)
    if payload.val == 0 or (existing and existing.get("val") == payload.val):
        if existing:
            store.delete_item("reactions", rid)
        val = 0
    else:
        store.put_item(
            "reactions",
            {"id": rid, "user_id": user["id"], "episode_id": payload.episode_id, "val": payload.val, "created_at": _now()},
        )
        val = payload.val
    return {"my_reaction": val, **_counts(payload.episode_id)}


class CommentIn(BaseModel):
    text: str = Field(min_length=1, max_length=600)


@router.post("/engagement/{episode_id}/comment", status_code=201)
async def add_comment(episode_id: str, payload: CommentIn, user: dict = Depends(get_current_user)):
    doc = {
        "id": str(uuid.uuid4()),
        "episode_id": episode_id,
        "user_id": user["id"],
        "name": user.get("display_name", ""),
        "text": payload.text.strip(),
        "created_at": _now(),
    }
    store.put_item("comments", doc)
    return doc


@router.delete("/engagement/comment/{comment_id}", status_code=204)
async def delete_comment(comment_id: str, user: dict = Depends(get_current_user)):
    doc = store.get_item("comments", comment_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Comment not found")
    if doc.get("user_id") != user["id"] and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Not your comment")
    store.delete_item("comments", comment_id)


@router.get("/engagement/{episode_id}")
async def engagement(episode_id: str, user: dict = Depends(get_current_user)):
    comments = store.query("comments", "by_episode", "episode_id", episode_id, "created_at", None, True)
    mine = store.get_item("reactions", f"{user['id']}:{episode_id}")
    return {
        "my_reaction": int((mine or {}).get("val", 0)),
        **_counts(episode_id),
        "comments": list(reversed(comments[-50:])),
    }


class ChannelIn(BaseModel):
    bio: str = Field(default="", max_length=1000)
    logo_b64: str = Field(default="", max_length=10_000_000)


@router.patch("/publisher/channel")
async def update_channel(payload: ChannelIn, user: dict = Depends(get_current_user)):
    """Publisher customizes the public channel: bio + logo (stored privately in R2)."""
    if user.get("role") not in ("creator", "admin"):
        raise HTTPException(status_code=403, detail="Only approved publishers can edit a channel")
    updates: dict = {"channel_bio": payload.bio[:1000]}
    if payload.logo_b64:
        try:
            data = base64.b64decode(payload.logo_b64, validate=True)
        except Exception:
            raise HTTPException(status_code=400, detail="That logo couldn't be read")
        if len(data) > 5_000_000:
            raise HTTPException(status_code=413, detail="Logo too large (max 5 MB)")
        if not r2.enabled():
            raise HTTPException(status_code=503, detail="Storage isn't available — try again shortly")
        key = f"channel-logos/{user['id']}.jpg"
        r2.upload_bytes(key, data, "image/jpeg")
        updates["channel_logo_key"] = key
    store.update_user(user["id"], updates)
    return {"ok": True}


def _channel_view(u: dict, with_email: bool = False) -> dict:
    logo = ""
    if u.get("channel_logo_key") and r2.enabled():
        try:
            logo = r2.presign_get(u["channel_logo_key"], 3600)
        except Exception:
            logo = ""
    view = {
        "user_id": u["id"],
        "name": u.get("channel_name") or u.get("display_name", ""),
        "bio": u.get("channel_bio", ""),
        "logo": logo,
        "followers": int(u.get("followers_count") or 0),
    }
    if with_email:
        view["email"] = u.get("email", "")
    return view


@router.get("/channels")
async def list_channels():
    """Public directory of verified publisher channels."""
    out = []
    for u in store.scan("users"):
        if u.get("role") != "creator":
            continue
        titles = [t for t in store.scan("titles") if t.get("supplier_email") == u.get("email") and t.get("status") == "published"]
        view = _channel_view(u, with_email=True)
        view["videos"] = len(titles)
        out.append(view)
    return sorted(out, key=lambda c: (c["followers"], c["videos"]), reverse=True)


@router.get("/channels/{user_id}")
async def channel_detail(user_id: str):
    u = store.get_user(user_id)
    if not u or u.get("role") != "creator":
        raise HTTPException(status_code=404, detail="Channel not found")
    titles = [t for t in store.scan("titles") if t.get("supplier_email") == u.get("email") and t.get("status") == "published"]
    view = _channel_view(u, with_email=True)
    view["titles"] = titles
    return view
