"""Fake Razorpay checkout for the ₹66 / 2-month VIP pass ("api keep fake").

Flow mirrors the real Razorpay browser flow so the swap is one file:
  1. POST /vip/order   → fake order (order_id, amount paise, test key_id)
  2. browser "pays" in the fake checkout sheet
  3. POST /vip/verify  → activates VIP for 2 months and AUTO-LOGS ₹66 into the
     studio revenue ledger (no manual entry needed).
Real-money integration later: replace steps 1/3 with razorpay SDK calls +
signature verification (hmac SHA256 of order_id|payment_id against key secret).
"""

import base64
import hashlib
import hmac
import json
import os
import uuid
from typing import Optional
from datetime import datetime, timedelta, timezone
from pydantic import BaseModel, Field

import httpx
from fastapi import APIRouter, Depends, HTTPException, Request

from models.payments import (
    CryptoInvoiceIn,
    CryptoInvoiceOut,
    CryptoStatusOut,
    DonateIn,
    DonateOut,
    VipOrderOut,
    VipStatusOut,
    VipVerifyIn,
)
from lib import store
from lib.security import get_current_user

router = APIRouter(prefix="/vip", tags=["vip"])

VIP_PRICE_PAISE = 6600  # ₹66.00
VIP_DAYS = 60  # ₹66 / 2 months (owner decision)


def _now() -> datetime:
    return datetime.now(timezone.utc)


@router.post("/order", response_model=VipOrderOut)
async def create_order(user: dict = Depends(get_current_user)):
    """Step 1 — create the (fake) Razorpay order."""
    return VipOrderOut(order_id=f"order_{uuid.uuid4().hex[:18]}", amount=VIP_PRICE_PAISE)


@router.post("/verify", response_model=VipStatusOut)
async def verify_payment(payload: VipVerifyIn, user: dict = Depends(get_current_user)):
    """Step 3 — (fake) signature check, then activate + auto-log the revenue entry."""
    until = (_now() + timedelta(days=VIP_DAYS)).isoformat()
    store.update_user(user["id"], {"vip_until": until})
    store.put_revenue(
        {
            "id": str(uuid.uuid4()),
            "amount": VIP_PRICE_PAISE / 100,
            "note": f"VIP pass — {user['email']} (auto)",
            "created_at": _now().isoformat(),
        }
    )
    return VipStatusOut(active=True, until=until)


@router.get("/status", response_model=VipStatusOut)
async def vip_status(user: dict = Depends(get_current_user)):
    raw = user.get("vip_until")
    if not raw:
        return VipStatusOut(active=False)
    try:
        active = datetime.fromisoformat(raw) > _now()
    except ValueError:
        active = False
    return VipStatusOut(active=active, until=raw if active else None)


class UserDepositIn(BaseModel):
    amount: float = Field(..., ge=1.0, le=100000.0, description="Deposit amount in INR (₹)")


class UserDepositOut(BaseModel):
    ok: bool
    deposit_id: str
    amount: float
    new_deposit_balance: float
    message: str


@router.post("/deposit", response_model=UserDepositOut)
async def deposit_funds(payload: UserDepositIn, user: dict = Depends(get_current_user)):
    """User Deposit: Users can deposit money into their account to tip favorite creators & send live donations."""
    dep_id = f"dep-{uuid.uuid4().hex[:12]}"
    cur_bal = float(user.get("deposit_balance") or 0.0)
    new_bal = round(cur_bal + payload.amount, 2)
    store.update_user(user["id"], {"deposit_balance": new_bal})

    # Record deposit transaction
    dep_doc = {
        "id": dep_id,
        "user_id": user["id"],
        "user_email": user.get("email"),
        "amount": payload.amount,
        "status": "completed",
        "created_at": _now().isoformat(),
    }
    try:
        store.put_item("deposits", dep_doc)
    except Exception:
        pass

    return UserDepositOut(
        ok=True,
        deposit_id=dep_id,
        amount=payload.amount,
        new_deposit_balance=new_bal,
        message=f"₹{payload.amount} successfully deposited to your wallet!",
    )


class TipCreatorIn(BaseModel):
    creator_user_id: str
    amount: float = Field(..., ge=1.0, description="Tip amount in ₹")
    message: Optional[str] = ""


@router.post("/tip-creator")
async def tip_creator(payload: TipCreatorIn, user: dict = Depends(get_current_user)):
    """Tip Creator: User uses their deposited money to tip their favorite creator directly."""
    creator = store.get_user(payload.creator_user_id)
    if not creator:
        raise HTTPException(status_code=404, detail="Creator not found")
    if creator["id"] == user["id"]:
        raise HTTPException(status_code=400, detail="Cannot tip yourself")

    user_dep = float(user.get("deposit_balance") or 0.0)
    if user_dep < payload.amount and user.get("role") != "admin":
        raise HTTPException(status_code=400, detail=f"Insufficient deposit balance (₹{user_dep}). Please deposit funds first.")

    if user.get("role") != "admin":
        store.update_user(user["id"], {"deposit_balance": round(user_dep - payload.amount, 2)})

    creator_dep = float(creator.get("deposit_balance") or 0.0)
    store.update_user(payload.creator_user_id, {"deposit_balance": round(creator_dep + payload.amount, 2)})

    tip_doc = {
        "id": f"tip-{uuid.uuid4().hex[:10]}",
        "from_user_id": user["id"],
        "from_user_name": user.get("display_name") or user.get("email"),
        "to_creator_id": creator["id"],
        "to_creator_name": creator.get("display_name") or creator.get("email"),
        "amount": payload.amount,
        "message": payload.message or "",
        "created_at": _now().isoformat(),
    }
    try:
        store.put_item("tips", tip_doc)
    except Exception:
        pass

    return {
        "ok": True,
        "message": f"Successfully tipped ₹{payload.amount} to {creator.get('display_name') or creator.get('email')}!",
        "new_balance": round(user_dep - payload.amount, 2) if user.get("role") != "admin" else user_dep,
    }
# VIP activates ONLY on a verified paid/paid_over webhook, never on redirects.
# Keys come from env: CRYPTOMUS_MERCHANT_ID + CRYPTOMUS_PAYMENT_API_KEY.
# ===================================================================
CRYPTO_API = "https://api.cryptomus.com/v1"
CRYPTO_PLANS = {  # server-side prices — INR (Cryptomus converts to the payer's crypto at live rates)
    "vip_monthly": {"amount": "66", "days": 30},   # ₹66 / month
    "vip_yearly": {"amount": "660", "days": 365},  # ₹660 / year — 2 months free
}


def _crypto_creds() -> tuple[str, str]:
    merchant = os.environ.get("CRYPTOMUS_MERCHANT_ID", "")
    key = os.environ.get("CRYPTOMUS_PAYMENT_API_KEY", "")
    if not merchant or not key:
        raise HTTPException(
            status_code=503,
            detail="Crypto payments aren't configured yet — add the Cryptomus keys on the server first",
        )
    return merchant, key


def _crypto_sign(body: bytes, key: str) -> str:
    return hashlib.md5(base64.b64encode(body) + key.encode()).hexdigest()


@router.post("/crypto/invoice", response_model=CryptoInvoiceOut)
async def crypto_invoice(payload: CryptoInvoiceIn, user: dict = Depends(get_current_user)):
    plan = CRYPTO_PLANS.get(payload.plan_id)
    if not plan:
        raise HTTPException(status_code=422, detail="Unknown plan — use vip_monthly or vip_yearly")
    merchant, key = _crypto_creds()
    order_id = f"vip-{user['id'][:8]}-{uuid.uuid4().hex[:10]}"
    store.put_item(
        "payments",
        {
            "id": order_id,
            "user_id": user["id"],
            "email": user["email"],
            "plan_id": payload.plan_id,
            "amount_fiat": float(plan["amount"]),
            "currency": "INR",
            "status": "created",
            "created_at": _now().isoformat(),
        },
    )
    api_base = os.environ.get("PUBLIC_API_ORIGIN", "https://api.animeunleashed.in")
    body = {
        "amount": plan["amount"],
        "currency": "INR",
        "order_id": order_id,
        "url_callback": f"{api_base}/api/vip/crypto/webhook",
        "url_return": "https://animeunleashed.in/vip?payment=return",
        "url_success": "https://animeunleashed.in/vip?payment=return",
        "lifetime": 3600,
    }
    raw = json.dumps(body, separators=(",", ":")).encode()
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            r = await client.post(
                f"{CRYPTO_API}/payment",
                content=raw,
                headers={"merchant": merchant, "sign": _crypto_sign(raw, key), "Content-Type": "application/json"},
            )
        r.raise_for_status()
        data = r.json()
    except httpx.HTTPStatusError as exc:
        body = exc.response.text[:300] if exc.response is not None else "no body"
        raise HTTPException(status_code=502, detail=f"Cryptomus rejected the order: {body}")
    except Exception:
        raise HTTPException(status_code=502, detail="Couldn't reach Cryptomus — try again shortly")
    result = data.get("result") or {}
    if data.get("state") != 0 or not result.get("url"):
        raise HTTPException(status_code=502, detail=str(data.get("message") or "Cryptomus rejected the order"))
    store.update_item(
        "payments",
        order_id,
        set_updates={
            "cryptomus_uuid": result.get("uuid", ""),
            "status": result.get("status", "check"),
            "payment_url": result["url"],
        },
    )
    return CryptoInvoiceOut(order_id=order_id, payment_url=result["url"])


@router.post("/crypto/webhook")
async def crypto_webhook(request: Request):
    """Cryptomus → us. Signature-checked (both PHP/other slash-escaping forms),
    idempotent — a repeated paid webhook must never double-extend VIP."""
    raw = await request.body()
    _, key = _crypto_creds()
    try:
        incoming = json.loads(raw)
        supplied = str(incoming.pop("sign", ""))
    except Exception:
        raise HTTPException(status_code=400, detail="Bad webhook body")
    compact = json.dumps(incoming, separators=(",", ":"), ensure_ascii=False).encode()
    variants = (compact, compact.replace(b"/", b"\\/"))
    if not any(hmac.compare_digest(_crypto_sign(v, key), supplied) for v in variants):
        raise HTTPException(status_code=401, detail="Invalid webhook signature")
    order_id = str(incoming.get("order_id", ""))
    order = store.get_item("payments", order_id)
    if not order:
        raise HTTPException(status_code=404, detail="Unknown order")
    status = str(incoming.get("status", ""))
    updates: dict = {"status": status}
    if incoming.get("txid"):
        updates["txid"] = str(incoming["txid"])
    store.update_item("payments", order_id, set_updates=updates)
    if status in ("paid", "paid_over") and order.get("status") not in ("paid", "paid_over"):
        plan = CRYPTO_PLANS.get(order.get("plan_id", ""), {"days": 30})
        user_doc = store.get_user(order.get("user_id", ""))
        if user_doc:
            base = user_doc.get("vip_until") or ""
            try:
                base_dt = datetime.fromisoformat(base)
            except ValueError:
                base_dt = None
            start = base_dt if base_dt and base_dt > _now() else _now()
            until = (start + timedelta(days=plan["days"])).isoformat()
            store.update_user(user_doc["id"], {"vip_until": until})
            store.put_revenue(
                {
                    "id": str(uuid.uuid4()),
                    "amount": float(order.get("amount_fiat", 0)),
                    "note": f"VIP crypto — {order.get('email', '')} (INR)",
                    "created_at": _now().isoformat(),
                }
            )
    return {"ok": True}


@router.get("/crypto/status/{order_id}", response_model=CryptoStatusOut)
async def crypto_status(order_id: str, user: dict = Depends(get_current_user)):
    order = store.get_item("payments", order_id)
    if not order or order.get("user_id") != user["id"]:
        raise HTTPException(status_code=404, detail="Order not found")
    return CryptoStatusOut(
        order_id=order_id,
        status=order.get("status", "created"),
        payment_url=order.get("payment_url", ""),
    )


# ===================================================================
# Donations system (ZNQ Network & Environmental Protection)
# ===================================================================
@router.post("/donate", response_model=DonateOut)
async def create_donation(payload: DonateIn):
    """Donate to support Anime-Unleashed.

    Minimum Donation: ₹10 or $0.10.
    Distribution:
      80% -> ZNQ Network (Parent)
      20% -> Environmental Protection
    """
    currency = payload.currency.upper()
    if currency not in ("INR", "USD"):
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported currency '{payload.currency}'. Only 'INR' (₹10 min) or 'USD' ($0.10 min) are accepted.",
        )

    if currency == "INR" and payload.amount < 10.0:
        raise HTTPException(status_code=400, detail="Minimum donation in INR is ₹10")
    elif currency == "USD" and payload.amount < 0.10:
        raise HTTPException(status_code=400, detail="Minimum donation in USD is $0.10")

    znq_cut = round(payload.amount * 0.80, 2)
    env_cut = round(payload.amount * 0.20, 2)
    donation_id = f"don_{uuid.uuid4().hex[:12]}"
    now_ts = _now().isoformat()

    doc = {
        "id": donation_id,
        "amount": payload.amount,
        "currency": currency,
        "donor_name": payload.donor_name or "Anonymous",
        "note": payload.note or "",
        "znq_network_cut": znq_cut,
        "environmental_protection_cut": env_cut,
        "status": "completed",
        "created_at": now_ts,
    }

    # Store donation in payments table
    try:
        store.put_item("payments", doc)
    except Exception:
        pass

    # Log into studio revenue ledger
    try:
        store.put_revenue(
            {
                "id": str(uuid.uuid4()),
                "amount": payload.amount if currency == "INR" else payload.amount * 86.5,
                "note": f"Donation from {doc['donor_name']} ({currency} {payload.amount}) [80% ZNQ / 20% Env]",
                "created_at": now_ts,
            }
        )
    except Exception:
        pass

    return DonateOut(**doc)
