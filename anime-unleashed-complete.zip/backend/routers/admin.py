"""Full-stack studio admin: user management, revenue ledger (profit), feedback inbox,
visit tracking. Every /admin/* route requires role=admin; feedback + visit pings are public."""

import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import PlainTextResponse

from lib import analytics, quota, store
from lib.ratelimit import allow, client_ip
from lib.security import UserPublic, get_admin_user, get_owner_user, hash_password, is_owner
from models.admin import (
    AdminUserCreateIn,
    AdminUserDetailOut,
    AdminUserOut,
    AirdropIn,
    AirdropOut,
    AuditOut,
    FeedbackIn,
    FeedbackOut,
    FeatureToggleIn,
    GrantIn,
    NoticeIn,
    NoticeOut,
    OwnerOverview,
    PlatformConfigIn,
    PlatformConfigOut,
    RevenueIn,
    RevenueOut,
    RevenueOut2,
    RoleUpdateIn,
    VipPlan,
    VisitStats,
)
from models.catalog import AdminStats

router = APIRouter(tags=["admin"])


def _audit(actor: dict, action: str, target: str) -> None:
    """Fire-and-forget audit trail for sensitive admin actions."""
    store.put_audit(
        {
            "id": str(uuid.uuid4()),
            "actor": actor.get("email", "unknown"),
            "action": action,
            "target": target,
            "created_at": _now_iso(),
        }
    )


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _day_key() -> str:
    return datetime.now(timezone.utc).strftime("%Y%m%d")


def _user_out(doc: dict) -> AdminUserOut:
    return AdminUserOut(
        id=doc["id"],
        email=doc["email"],
        display_name=doc["display_name"],
        role=doc["role"],
        firebase_uid=doc.get("firebase_uid"),
        vip_until=doc.get("vip_until"),
        is_owner=doc.get("is_owner", False),
        created_at=doc["created_at"],
        account_id=doc.get("account_id"),
        country=doc.get("country"),
        region=doc.get("region"),
        watch_balance_seconds=int(doc.get("watch_balance_seconds") or 0),
        cf_balance=int(doc.get("cf_balance") or 0),
        lc_balance=int(doc.get("lc_balance") or 0),
        banned=bool(doc.get("banned")),
        features=doc.get("features") or {},
    )


# --------------------------------------------------------------------- users
@router.get("/admin/users", response_model=list[AdminUserOut])
async def list_users(search: str = "", _: UserPublic = Depends(get_admin_user)):
    """List users in admin with search by email or user ID."""
    all_users = store.list_users()
    if not search:
        return [_user_out(u) for u in all_users]

    q = search.lower().strip()
    filtered = []
    for u in all_users:
        if (
            q in u.get("email", "").lower()
            or q in u.get("id", "").lower()
            or q in str(u.get("account_id", "")).lower()
            or q in u.get("display_name", "").lower()
        ):
            filtered.append(u)
    return [_user_out(u) for u in filtered]


@router.get("/admin/env-export", response_class=PlainTextResponse)
async def export_env(admin: dict = Depends(get_admin_user)):
    """Hand the owner their ready-made production .env over HTTPS (admin + PIN gated,
    rate-limited, audit-logged) — piped straight into the EC2 box during deploy so
    secrets never need to be typed or pasted anywhere."""
    if not allow(f"env-export:{admin['id']}", 5, 300):
        raise HTTPException(status_code=429, detail="Too many exports — wait a few minutes")
    env_path = Path(__file__).resolve().parents[1] / ".env"
    if not env_path.exists():
        raise HTTPException(status_code=404, detail="No .env found in this backend")
    _audit(admin, "env.export", "production .env downloaded")
    return PlainTextResponse(env_path.read_text())


@router.get("/admin/audit", response_model=list[AuditOut])
async def audit_log(_: UserPublic = Depends(get_admin_user)):
    """Newest-first trail of sensitive admin actions (accounts, revenue, feedback)."""
    return [AuditOut(**e) for e in store.list_audit()]


@router.post("/admin/users", response_model=AdminUserOut, status_code=201)
async def create_admin_user(payload: AdminUserCreateIn, admin: dict = Depends(get_admin_user)):
    """Notebook: 'Add new admin, create new admin pass' — super admin mints accounts."""
    if payload.role == "admin" and not is_owner(admin):
        raise HTTPException(status_code=403, detail="Only the super admin can mint admin accounts")
    if payload.role not in ("admin", "worker", "creator", "user"):
        raise HTTPException(status_code=422, detail="Role must be 'admin', 'worker', 'creator' or 'user'")
    email = payload.email.lower()
    if store.get_user_by_email(email):
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    user = {
        "id": str(uuid.uuid4()),
        "email": email,
        "display_name": payload.display_name.strip(),
        "role": payload.role if payload.role in ("admin", "worker", "creator", "user") else "user",
        "password_hash": hash_password(payload.password),
        "created_by": admin["id"],
        "created_at": _now_iso(),
    }
    store.put_user(user)
    _audit(admin, "user.create", f"{user['email']} ({user['role']})")
    return _user_out(user)


@router.patch("/admin/users/{user_id}", response_model=AdminUserOut)
async def update_user_role(
    user_id: str, payload: RoleUpdateIn, admin: dict = Depends(get_admin_user)
):
    sent = payload.model_dump(exclude_unset=True)
    if sent.get("role") is not None and sent["role"] not in ("admin", "worker", "creator", "user"):
        raise HTTPException(status_code=422, detail="Role must be 'admin', 'worker', 'creator' or 'user'")
    if user_id == admin["id"] and sent.get("role") == "user":
        raise HTTPException(status_code=403, detail="You can't demote your own account")
    user = store.get_user(user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    if user.get("role") == "admin" and not is_owner(admin):
        raise HTTPException(status_code=403, detail="Only the super admin can change admin accounts")
    updates: dict = {}
    if sent.get("role") is not None:
        updates["role"] = sent["role"]
    if "vip_until" in sent:
        updates["vip_until"] = sent["vip_until"]  # None → attribute REMOVE (clears VIP)
    updated = store.update_user(user_id, updates) if updates else user
    _audit(admin, "user.update", f"{user['email']} → {'vip-until=' + str(updates.get('vip_until')) if 'vip_until' in updates else 'role=' + str(updates.get('role', user['role']))}")
    return _user_out(updated or user)


@router.delete("/admin/users/{user_id}", status_code=204)
async def delete_user(user_id: str, admin: dict = Depends(get_admin_user)):
    if user_id == admin["id"]:
        raise HTTPException(status_code=403, detail="You can't delete your own account")
    target = store.get_user(user_id)
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.get("role") == "admin" and not is_owner(admin):
        raise HTTPException(status_code=403, detail="Only the super admin can delete admin accounts")
    store.cascade_delete_user(user_id)


# ------------------------------------------------------------------- revenue
@router.get("/admin/revenue", response_model=RevenueOut2)
async def list_revenue(_: UserPublic = Depends(get_admin_user)):
    entries = store.list_revenue()
    total = sum(e.get("amount", 0) for e in entries)
    return RevenueOut2(
        entries=[RevenueOut(**e) for e in entries],
        total=round(float(total), 2),
    )


@router.post("/admin/revenue", response_model=RevenueOut, status_code=201)
async def add_revenue(payload: RevenueIn, admin: dict = Depends(get_admin_user)):
    """Manual profit ledger — UPI/VIP income recorded by the owner until payments go live."""
    entry = {
        "id": str(uuid.uuid4()),
        "amount": payload.amount,
        "note": payload.note.strip(),
        "created_at": _now_iso(),
    }
    store.put_revenue(entry)
    _audit(admin, "revenue.add", f"₹{payload.amount} — {payload.note.strip()}")
    return RevenueOut(**entry)


@router.delete("/admin/revenue/{entry_id}", status_code=204)
async def delete_revenue(entry_id: str, admin: dict = Depends(get_admin_user)):
    if not store.get_item("revenue", entry_id):
        raise HTTPException(status_code=404, detail="Entry not found")
    store.delete_revenue(entry_id)
    _audit(admin, "revenue.delete", entry_id)


# ------------------------------------------------------------------ feedback
@router.post("/feedback", response_model=FeedbackOut, status_code=201)
async def submit_feedback(payload: FeedbackIn, request: Request):
    """Public: any visitor can send feedback from the user site (rate-limited per IP)."""
    if not allow(f"feedback:{client_ip(request)}", 3, 600):
        raise HTTPException(status_code=429, detail="Too many messages — try again in 10 minutes")
    item = {
        "id": str(uuid.uuid4()),
        "name": payload.name.strip(),
        "email": (payload.email or "").strip() or None,
        "message": payload.message.strip(),
        "resolved": False,
        "created_at": _now_iso(),
    }
    store.put_feedback(item)
    return FeedbackOut(**item)


@router.get("/admin/feedback", response_model=list[FeedbackOut])
async def list_feedback(_: UserPublic = Depends(get_admin_user)):
    return [FeedbackOut(**f) for f in store.list_feedback()]


@router.patch("/admin/feedback/{feedback_id}", response_model=FeedbackOut)
async def resolve_feedback(
    feedback_id: str, payload: dict, _: UserPublic = Depends(get_admin_user)
):
    resolved = payload.get("resolved")
    if not isinstance(resolved, bool):
        raise HTTPException(status_code=422, detail="'resolved' must be true or false")
    if not store.get_feedback(feedback_id):
        raise HTTPException(status_code=404, detail="Feedback not found")
    updated = store.update_feedback(feedback_id, {"resolved": resolved})
    return FeedbackOut(**(updated or {}))


@router.delete("/admin/feedback/{feedback_id}", status_code=204)
async def delete_feedback(feedback_id: str, admin: dict = Depends(get_admin_user)):
    if not store.get_feedback(feedback_id):
        raise HTTPException(status_code=404, detail="Feedback not found")
    store.delete_feedback(feedback_id)
    _audit(admin, "feedback.delete", feedback_id)


# -------------------------------------------------------------------- visits
@router.post("/visits", status_code=204)
async def record_visit(request: Request):
    """Public: pinged once per browser session by the user site (rate-limited per IP)."""
    if not allow(f"visits:{client_ip(request)}", 30, 60):
        raise HTTPException(status_code=429, detail="Too many requests")
    store.record_visit(_day_key())


@router.get("/admin/visits", response_model=VisitStats)
async def visit_stats(_: UserPublic = Depends(get_admin_user)):
    total, today = store.get_visit_stats(_day_key())
    return VisitStats(total=total, today=today)


# --------------------------------------------------------------------- stats
@router.get("/admin/stats", response_model=AdminStats)
async def admin_stats(_: UserPublic = Depends(get_admin_user)):
    revenue_entries = store.list_revenue()
    open_feedback = sum(1 for f in store.list_feedback() if not f.get("resolved"))
    total_visits, _ = store.get_visit_stats(_day_key())
    return AdminStats(
        titles=store.count("titles"),
        episodes=store.count("episodes"),
        users=store.count_users(),
        total_views=store.sum_views(),
        total_profit=round(float(sum(e.get("amount", 0) for e in revenue_entries)), 2),
        total_visits=total_visits,
        feedback_open=open_feedback,
    )


# ------------------------------------------------------------------- owner
@router.get("/admin/owner/overview", response_model=OwnerOverview)
async def owner_overview(_: dict = Depends(get_owner_user)):
    """Super-admin web: global views / profit / videos / visits + team + supplier queue."""
    users = store.list_users()
    now = datetime.now(timezone.utc)
    vip_active = 0
    for u in users:
        raw = u.get("vip_until")
        if raw:
            try:
                if datetime.fromisoformat(raw) > now:
                    vip_active += 1
            except ValueError:
                pass
    cutoff = (now - timedelta(days=90)).isoformat()
    stale = sum(
        1
        for t in store.scan("titles")
        if t.get("supplier_email") and not t.get("views", 0) and (t.get("created_at") or "9999") < cutoff
    )
    revenue_entries = store.list_revenue()
    total_visits, _ = store.get_visit_stats(_day_key())
    return OwnerOverview(
        titles=store.count("titles"),
        episodes=store.count("episodes"),
        users=len(users),
        total_views=store.sum_views(),
        total_profit=round(float(sum(e.get("amount", 0) for e in revenue_entries)), 2),
        total_visits=total_visits,
        feedback_open=sum(1 for f in store.list_feedback() if not f.get("resolved")),
        admins=sum(1 for u in users if u.get("role") == "admin"),
        workers=sum(1 for u in users if u.get("role") == "worker"),
        viewers=sum(1 for u in users if u.get("role") == "user"),
        vip_active=vip_active,
        pending_applications=sum(1 for a in store.scan("supplier_apps") if a.get("status") == "pending"),
        pending_submissions=sum(1 for s in store.scan("supplier_submissions") if s.get("status") == "pending"),
        stale_supplier_titles=stale,
    )


# ----------------------------------------------- user controls: ban/grant/features
@router.post("/admin/users/{user_id}/ban", status_code=204)
async def ban_user(user_id: str, admin: dict = Depends(get_admin_user)):
    target = store.get_user(user_id)
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if target.get("role") == "admin":
        raise HTTPException(status_code=403, detail="Admin accounts can't be banned")
    store.update_user(user_id, {"banned": True})
    _audit(admin, "user.ban", target["email"])


@router.post("/admin/users/{user_id}/unban", status_code=204)
async def unban_user(user_id: str, admin: dict = Depends(get_admin_user)):
    target = store.get_user(user_id)
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    store.update_user(user_id, {"banned": False})
    _audit(admin, "user.unban", target["email"])


@router.post("/admin/users/{user_id}/grant", response_model=AdminUserOut)
async def grant_user(user_id: str, payload: GrantIn, admin: dict = Depends(get_admin_user)):
    """Send or remove value to/from ONE user by id: watch-duration (VD), VIP days, CF, and LC/ZC."""
    target = store.get_user(user_id)
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    if payload.watch_minutes:
        if payload.watch_minutes > 0:
            quota.grant_seconds(user_id, payload.watch_minutes * 60)
        else:
            curr_sec = int(target.get("watch_balance_seconds") or 0)
            store.update_item("users", user_id, set_updates={"watch_balance_seconds": max(0, curr_sec + (payload.watch_minutes * 60))})
    if payload.cf:
        curr_cf = int(target.get("cf_balance") or 0)
        new_cf = max(0, curr_cf + payload.cf)
        store.update_item("users", user_id, set_updates={"cf_balance": new_cf})
    if payload.lc:
        curr_lc = int(target.get("lc_balance") or 0)
        new_lc = max(0, curr_lc + payload.lc)
        store.update_item("users", user_id, set_updates={"lc_balance": new_lc})
    if payload.vip_days:
        now = datetime.now(timezone.utc)
        base = now
        if target.get("vip_until"):
            try:
                current = datetime.fromisoformat(target["vip_until"])
                if current > now:
                    base = current
            except ValueError:
                pass
        store.update_user(user_id, {"vip_until": (base + timedelta(days=payload.vip_days)).isoformat()})
    _audit(
        admin,
        "user.grant_credits",
        f"{target['email']} ← vd={payload.watch_minutes}min vip={payload.vip_days}d cf={payload.cf} lc={payload.lc}",
    )
    return _user_out(store.get_user(user_id) or target)


FEATURE_KEYS = ("downloads", "global_chat", "refill_ads")


@router.patch("/admin/users/{user_id}/features", response_model=AdminUserOut)
async def toggle_user_feature(user_id: str, payload: FeatureToggleIn, admin: dict = Depends(get_admin_user)):
    """Admin controls ANY user's features: downloads / global_chat / refill_ads."""
    if payload.key not in FEATURE_KEYS:
        raise HTTPException(status_code=422, detail=f"key must be one of: {', '.join(FEATURE_KEYS)}")
    target = store.get_user(user_id)
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    features = dict(target.get("features") or {})
    features[payload.key] = payload.enabled
    store.update_user(user_id, {"features": features})
    _audit(admin, "user.feature", f"{target['email']} {payload.key}={'on' if payload.enabled else 'off'}")
    return _user_out(store.get_user(user_id) or target)


@router.get("/admin/users/{user_id}", response_model=AdminUserDetailOut)
async def user_detail(user_id: str, _: dict = Depends(get_admin_user)):
    """Full account card: location, name, joined, wallet, VIP, lifetime stats + history."""
    target = store.get_user(user_id)
    if not target:
        raise HTTPException(status_code=404, detail="User not found")
    events = store.query("analytics_events", "user_created", "user_id", user_id)
    agg = analytics.aggregate(events)
    return AdminUserDetailOut(
        **_user_out(target).model_dump(),
        views=agg["views"],
        watch_minutes=agg["watch_minutes"],
        downloads=agg["downloads_total"],
        history=store.list_history(user_id, limit=30),
    )


# --------------------------------------------- platform: maintenance/airdrop/vip
@router.get("/platform", response_model=PlatformConfigOut)
async def public_platform():
    """PUBLIC: the user site reads maintenance + the VIP plan from here."""
    cfg = store.get_platform_config()
    return PlatformConfigOut(
        maintenance=bool(cfg.get("maintenance")),
        vip_plan=VipPlan(**(cfg.get("vip_plan") or {})),
    )


@router.get("/notices", response_model=list[NoticeOut])
async def public_notices():
    """PUBLIC: latest site-wide notices for the user-site banner."""
    return [NoticeOut(**n) for n in store.list_notices(limit=10)]


@router.put("/admin/platform", response_model=PlatformConfigOut)
async def update_platform(payload: PlatformConfigIn, admin: dict = Depends(get_admin_user)):
    updates: dict = {}
    if payload.maintenance is not None:
        updates["maintenance"] = payload.maintenance
    if payload.vip_plan is not None:
        updates["vip_plan"] = payload.vip_plan.model_dump()
    if updates:
        store.save_platform_config(updates)
        _audit(admin, "platform.update", ", ".join(updates.keys()))
    cfg = store.get_platform_config()
    return PlatformConfigOut(
        maintenance=bool(cfg.get("maintenance")),
        vip_plan=VipPlan(**(cfg.get("vip_plan") or {})),
    )


@router.post("/admin/airdrop", response_model=AirdropOut)
async def airdrop(payload: AirdropIn, admin: dict = Depends(get_admin_user)):
    """Airdrop watch-duration / CF to EVERY account at once (VD capped at 3.5 h each)."""
    users = store.list_users()
    for u in users:
        if payload.watch_minutes:
            quota.grant_seconds(u["id"], payload.watch_minutes * 60)
        if payload.cf:
            store.update_item("users", u["id"], add_updates={"cf_balance": payload.cf})
    _audit(admin, "platform.airdrop", f"vd={payload.watch_minutes}min cf={payload.cf} → {len(users)} users")
    return AirdropOut(users=len(users))


# ------------------------------------------------------------------- notices
@router.post("/admin/notices", response_model=NoticeOut, status_code=201)
async def create_notice(payload: NoticeIn, admin: dict = Depends(get_admin_user)):
    doc = {
        "id": str(uuid.uuid4()),
        "gsipk": "n",
        "title": payload.title.strip(),
        "body": payload.body.strip(),
        "created_at": _now_iso(),
        "created_by": admin["email"],
    }
    store.put_item("notices", doc)
    _audit(admin, "notice.create", doc["title"])
    return NoticeOut(**doc)


@router.get("/admin/notices", response_model=list[NoticeOut])
async def admin_notices(_: dict = Depends(get_admin_user)):
    return [NoticeOut(**n) for n in store.list_notices()]


@router.delete("/admin/notices/{notice_id}", status_code=204)
async def delete_notice(notice_id: str, admin: dict = Depends(get_admin_user)):
    if not store.get_item("notices", notice_id):
        raise HTTPException(status_code=404, detail="Notice not found")
    store.delete_item("notices", notice_id)
    _audit(admin, "notice.delete", notice_id)
