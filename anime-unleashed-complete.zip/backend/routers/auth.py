"""Email + password auth with httpOnly-cookie sessions (per template §4), backed by
DynamoDB (lib/store).

Two ways in:
- Local accounts (the owner's admin seat until Firebase is enabled): /auth/register +
  /auth/login with password hash.
- Firebase: browser signs in with the Firebase JS SDK, posts the ID token to
  /auth/firebase-login; we verify it against Google's public certs, upsert the user,
  and issue the same session cookie. All other endpoints only ever see the cookie.
"""

import os
import re
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from models.auth import (
    AccountRecoveryRequestIn,
    FirebaseLoginIn,
    LoginIn,
    OtpSendIn,
    PhoneOtpIn,
    PhoneVerifyIn,
    RegisterIn,
    ResetIn,
)
from lib.security import (
    UserPublic,
    clear_session_cookie,
    create_session_token,
    get_current_user,
    hash_password,
    set_session_cookie,
    verify_password,
)
from lib import quota as quota_rules, store
from lib import otp as otp_service
from lib.firebase_verify import verify_firebase_id_token
from lib.ratelimit import allow, client_ip

router = APIRouter(prefix="/auth", tags=["auth"])

# Emails that get the admin role when they first sign in through Firebase.
FIREBASE_ADMIN_EMAILS = [
    e.strip().lower() for e in os.environ.get("ADMIN_EMAILS", "").split(",") if e.strip()
]


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _user_out(doc: dict) -> UserPublic:
    return UserPublic(
        id=doc["id"],
        email=doc["email"],
        display_name=doc["display_name"],
        role=doc["role"],
        vip_until=doc.get("vip_until"),
        is_owner=doc.get("is_owner", False),
        phone=doc.get("phone"),
        cf_balance=int(doc.get("cf_balance") or 0),
    )


def _studio_pin_gate(user: dict, pin: str) -> None:
    """Separate-admin wall: admins additionally need the owner's STUDIO_PIN at login.
    Keeps the Studio decoupled from the public web login — a leaked password alone
    can never open the admin console."""
    expected = os.environ.get("STUDIO_PIN", "").strip()
    if user.get("role") == "admin" and expected:
        import hmac

        if not pin or not hmac.compare_digest(pin.strip(), expected):
            raise HTTPException(
                status_code=403,
                detail="studio_pin_required",
                headers={"X-Studio-Pin": "required"},
            )


def _owner_upgrade(user: dict) -> dict:
    """First owner sign-in stamps is_owner on the ADMIN_EMAILS seat (idempotent)."""
    if (
        user
        and user.get("role") == "admin"
        and not user.get("is_owner")
        and user["email"].lower() in FIREBASE_ADMIN_EMAILS
    ):
        store.update_user(user["id"], {"is_owner": True})
        user = store.get_user(user["id"]) or user
    return user


@router.post("/register", response_model=UserPublic, status_code=201)
async def register(payload: RegisterIn, response: Response, request: Request):
    """Owner rule: signup = trusted email domain + EMAIL OTP verification.
    The created account is ALWAYS role=user — staff roles exist only via Studio minting."""
    if not allow(f"register:{client_ip(request)}", 5, 900):
        raise HTTPException(status_code=429, detail="Too many sign-up attempts — try again in 15 minutes")
    if not otp_service.is_allowed_email(payload.email):
        raise HTTPException(
            status_code=422,
            detail=f"Only trusted email providers are allowed: {otp_service.ALLOWED_DOMAINS_NOTE}",
        )
    if len(payload.password) < 8 or not any(c.isdigit() for c in payload.password) or not any(c.isalpha() for c in payload.password):
        raise HTTPException(status_code=422, detail="Password must be 8+ characters with at least one letter and one number")
    current_year = datetime.now(timezone.utc).year
    if payload.birth_year and current_year - payload.birth_year < 9:
        raise HTTPException(status_code=422, detail="You must be at least 9 years old to create an account")
    # ---- owner rule: 1 number = 1 account (only when a number is provided) ----
    from lib import ip_intel

    ip = client_ip(request)
    intel = ip_intel.lookup(ip)
    # Global welcoming rule: All fans from across the globe and universe are welcomed!
    # No country-level blocking or VPN rejections.
    country = intel.get("country_code", "") or "GLOBAL"
    # phone is OPTIONAL at signup (the owner verifies it later from Account settings)
    phone_digits = re.sub(r"\D", "", payload.phone or "")
    if len(phone_digits) == 10 and phone_digits[0] in "6789":
        phone_digits = "91" + phone_digits
    phone = f"+{phone_digits}" if phone_digits else ""
    if phone and store.query("users", "phone_idx", "phone", phone, None, None, True):
        raise HTTPException(status_code=409, detail="This number already has an account — one number, one account")
    email = payload.email.lower()
    if store.get_user_by_email(email):
        raise HTTPException(status_code=409, detail="An account with this email already exists")
    # OTP verification if provided or required; direct registration enabled
    if payload.otp and not otp_service.verify(email, "register", payload.otp):
        raise HTTPException(status_code=403, detail="Invalid or expired verification code — request a new one")
    user = {
        "id": str(uuid.uuid4()),
        "email": email,
        "display_name": payload.display_name.strip(),
        "birth_year": payload.birth_year or None,
        "phone": phone or None,
        "registration_ip": ip,
        "registration_country": country or None,
        "role": "user",
        "password_hash": hash_password(payload.password),
        "watch_balance_seconds": quota_rules.SIGNUP_BONUS_SECONDS,  # 1-hour watch-time bonus
        "created_at": _now_iso(),
    }
    store.put_user(user)
    set_session_cookie(response, create_session_token(user["id"], user["role"]))
    return _user_out(user)


@router.get("/allowed-domains")
async def allowed_domains():
    """Public: the trusted email providers signups may use (owner's anti-spam rule)."""
    return {"domains": otp_service.ALLOWED_DOMAINS}


@router.post("/otp/send", status_code=200)
async def send_otp(payload: OtpSendIn, request: Request):
    """Email a 6-digit code (register = verify the mailbox, reset = prove ownership).
    Rate-limited 3 per 10 min per IP+email; reset never reveals whether the account exists."""
    if not allow(f"otp:{client_ip(request)}:{payload.email.lower()}", 3, 600):
        raise HTTPException(status_code=429, detail="Too many codes — wait 10 minutes")
    email = payload.email.lower()
    debug_code: str | None = None
    if payload.purpose == "register":
        if not otp_service.is_allowed_email(email):
            raise HTTPException(
                status_code=422,
                detail=f"Only trusted email providers are allowed: {otp_service.ALLOWED_DOMAINS_NOTE}",
            )
        if store.get_user_by_email(email):
            raise HTTPException(status_code=409, detail="An account with this email already exists — sign in instead")
        try:
            debug_code = otp_service.issue(email, "register")
        except Exception:
            raise HTTPException(
                status_code=503,
                detail="Email delivery is limited right now — our mail service is still in sandbox mode and can only message verified addresses. Try the owner's verified email or wait for production access.",
            )
    else:
        if store.get_user_by_email(email):
            debug_code = otp_service.issue(email, "reset")
        else:
            debug_code = None
    return {"sent": True, "debug_code": debug_code}



@router.post("/otp/phone/send", status_code=200)
async def send_phone_otp(payload: PhoneOtpIn, user: dict = Depends(get_current_user), request: Request = None):
    """Phone OTP for ACCOUNT-SETTINGS verification (owner moved it out of signup).
    The caller must be signed in; numbers already owned by ANOTHER account are
    rejected (1 number = 1 account)."""
    if not allow(f"otp:{client_ip(request)}", 5, 900):
        raise HTTPException(status_code=429, detail="Too many code requests — try again in 15 minutes")
    digits = re.sub(r"\D", "", payload.phone)
    if len(digits) == 10 and digits[0] in "6789":
        digits = "91" + digits
    phone = f"+{digits}" if digits else ""
    owner_rows = store.query("users", "phone_idx", "phone", phone, None, None, True)
    if any(r["id"] != user["id"] for r in owner_rows):
        raise HTTPException(status_code=409, detail="This number already has an account — one number, one account")
    try:
        debug_code = otp_service.issue_phone(phone)
    except RuntimeError as exc:
        raise HTTPException(status_code=503, detail=str(exc))
    return {"sent": True, "debug_code": debug_code}


@router.post("/otp/phone/verify", status_code=200)
async def verify_phone_otp(payload: PhoneVerifyIn, user: dict = Depends(get_current_user)):
    """Verify the signed-in user's OWN number from Account settings."""
    digits = re.sub(r"\D", "", payload.phone)
    if len(digits) == 10 and digits[0] in "6789":
        digits = "91" + digits
    phone = f"+{digits}" if digits else ""
    if user.get("phone") and user["phone"] != phone:
        raise HTTPException(status_code=409, detail="This isn't the number on your account — save it first")
    if not otp_service.verify(phone, "phone", payload.code):
        raise HTTPException(status_code=403, detail="Invalid or expired code")
    store.update_user(user["id"], {"phone": phone, "phone_verified": True})
    return {"verified": True, "phone": phone}


@router.post("/reset-password", status_code=403)
async def reset_password(payload: ResetIn):
    """Direct reset password disabled per security rules. Users must verify via Google or submit Admin Recovery."""
    raise HTTPException(
        status_code=403,
        detail="Direct password reset is disabled. Please verify via Google or submit an Account Recovery request to the admin (AnimeUnleashed@adown.com).",
    )


@router.post("/recover-request")
async def request_account_recovery(payload: AccountRecoveryRequestIn, request: Request):
    """If user forgot password and cannot use Google, submit recovery request directly to Admin with client IP."""
    c_ip = client_ip(request)
    req_id = f"rec-{uuid.uuid4().hex[:10]}"
    doc = {
        "id": req_id,
        "email_or_id": payload.email_or_id.lower().strip(),
        "user_note": payload.user_note,
        "client_ip": c_ip,
        "device_info": payload.device_info or "Unknown Browser",
        "status": "pending_admin_review",
        "created_at": _now_iso(),
    }
    store.put_item("recovery_requests", doc)

    # Route email to admin
    try:
        from lib.security import admin_emails
        import boto3
        import os

        owner_dest = admin_emails() or ["AnimeUnleashed@adown.com"]
        region = os.environ.get("SES_REGION", os.environ.get("AWS_REGION", "ap-south-1"))
        sender = os.environ.get("MAIL_FROM", "noreply@animeunleashed.in")
        subject = f"Account Recovery Request: {payload.email_or_id}"
        body = (
            f"Account Recovery Request Submitted on Anime-Unleashed:\n\n"
            f"• User / Email: {payload.email_or_id}\n"
            f"• Verified Client IP: {c_ip}\n"
            f"• Device Info: {payload.device_info}\n"
            f"• User Note / Questions: {payload.user_note}\n"
            f"• Date: {_now_iso()}\n\n"
            f"Owner action: Ask identity questions to verify ownership. If confirmed correct, unlock or reset password."
        )
        client = boto3.client("sesv2", region_name=region)
        client.send_email(
            FromEmailAddress=sender,
            Destination={"ToAddresses": owner_dest},
            Content={
                "Simple": {
                    "Subject": {"Data": subject, "Charset": "UTF-8"},
                    "Body": {"Text": {"Data": body, "Charset": "UTF-8"}},
                }
            },
        )
    except Exception:
        pass
    # Also log to server log
    import logging
    logging.getLogger("auth").info(f"[RECOVERY_REQUEST] {payload.email_or_id} from IP {c_ip} (device: {payload.device_info}): {payload.user_note}")

    return {
        "ok": True,
        "message": "Your recovery request has been submitted to the admin (AnimeUnleashed@adown.com). The admin will contact you to verify identity questions.",
        "verified_ip": c_ip,
    }


@router.get("/auto-login-ip", response_model=UserPublic)
async def auto_login_by_ip(request: Request, response: Response):
    """Auto-login user matching registered client IP for seamless recovery."""
    c_ip = client_ip(request)
    # Check if a user registered with this exact client IP exists
    try:
        matches = store.scan("users")
        target_user = None
        for u in matches:
            if u.get("last_login_ip") == c_ip and u.get("role") == "user":
                target_user = u
                break
        if not target_user:
            raise HTTPException(status_code=404, detail="No matching trusted IP session found for auto-login")

        set_session_cookie(response, create_session_token(target_user["id"], target_user["role"]))
        return _user_out(target_user)
    except Exception:
        raise HTTPException(status_code=404, detail="Auto-login by IP unavailable")


@router.post("/login", response_model=UserPublic)
async def login(payload: LoginIn, response: Response, request: Request):
    if not allow(f"login:{client_ip(request)}", 20, 300):
        raise HTTPException(status_code=429, detail="Too many login attempts — try again in 5 minutes")
    user = store.get_user_by_email(payload.email.lower())
    if not user or not verify_password(payload.password, user["password_hash"]):
        raise HTTPException(status_code=401, detail="Invalid email or password")
    _studio_pin_gate(user, payload.pin)
    user = _owner_upgrade(user)
    # Record trusted client IP on login for recovery / auto-login
    c_ip = client_ip(request)
    store.update_user(user["id"], {"last_login_ip": c_ip})
    set_session_cookie(response, create_session_token(user["id"], user["role"]))
    return _user_out(user)


@router.post("/logout", status_code=204)
async def logout(response: Response):
    clear_session_cookie(response)


@router.get("/me", response_model=UserPublic)
async def me(user: dict = Depends(get_current_user)):
    return _user_out(user)


@router.post("/firebase-login", response_model=UserPublic)
async def firebase_login(payload: FirebaseLoginIn, response: Response, request: Request):
    """Browser completed Firebase sign-in; exchange a verified ID token for our session cookie."""
    if not allow(f"fblogin:{client_ip(request)}", 10, 300):
        raise HTTPException(status_code=429, detail="Too many sign-in attempts — try again in 5 minutes")
    claims = await verify_firebase_id_token(payload.id_token)
    uid = claims["sub"]
    email = claims["email"].lower()
    if not otp_service.is_allowed_email(email):
        # owner rule: trusted providers only — applies to Firebase signups too
        raise HTTPException(
            status_code=403,
            detail=f"Only trusted email providers can sign up: {otp_service.ALLOWED_DOMAINS_NOTE}",
        )

    user = store.get_user_by_firebase_or_email(uid, email)
    if user is None:
        user = {
            "id": str(uuid.uuid4()),
            "firebase_uid": uid,
            "email": email,
            "display_name": (payload.display_name or email.split("@")[0].strip())[:40] or "Fan",
            "role": "admin" if email in FIREBASE_ADMIN_EMAILS else "user",
            "is_owner": email in FIREBASE_ADMIN_EMAILS,
            "password_hash": "",
            "watch_balance_seconds": quota_rules.SIGNUP_BONUS_SECONDS,
            "created_at": _now_iso(),
        }
        store.put_user(user)
    else:
        updates: dict = {"firebase_uid": uid}
        if email in FIREBASE_ADMIN_EMAILS and not user.get("is_owner"):
            updates["is_owner"] = True
        store.update_user(user["id"], updates)
        user = store.get_user(user["id"])

    _studio_pin_gate(user or {}, payload.pin)

    set_session_cookie(response, create_session_token(user["id"], user["role"]))
    return _user_out(user)
