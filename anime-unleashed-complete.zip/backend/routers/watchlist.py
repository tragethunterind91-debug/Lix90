"""Per-user watchlist ("My List"), backed by DynamoDB (lib/store)."""

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException

from lib import store
from lib.security import get_current_user
from models.catalog import TitleIdIn, TitleOut, WatchlistOut

router = APIRouter(prefix="/watchlist", tags=["watchlist"])


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _watchlist_out(user_id: str) -> WatchlistOut:
    docs = store.list_watchlist(user_id)
    title_ids = [d["title_id"] for d in docs]
    items: list[TitleOut] = []
    kept_ids: list[str] = []
    for tid in title_ids:
        title = store.get_title(tid)
        if title and title.get("status") == "published":
            items.append(TitleOut(**title))
            kept_ids.append(tid)
    return WatchlistOut(ids=kept_ids, items=items)


@router.get("", response_model=WatchlistOut)
async def get_watchlist(user: dict = Depends(get_current_user)):
    return _watchlist_out(user["id"])


@router.post("", response_model=WatchlistOut)
async def add_to_watchlist(payload: TitleIdIn, user: dict = Depends(get_current_user)):
    title = store.get_title(payload.title_id)
    if not title or title.get("status") != "published":
        raise HTTPException(status_code=404, detail="Title not found")
    store.add_watchlist(
        user["id"],
        payload.title_id,
        {
            "id": str(uuid.uuid4()),
            "user_id": user["id"],
            "title_id": payload.title_id,
            "created_at": _now_iso(),
        },
    )
    return _watchlist_out(user["id"])


@router.delete("/{title_id}", response_model=WatchlistOut)
async def remove_from_watchlist(title_id: str, user: dict = Depends(get_current_user)):
    store.remove_watchlist(user["id"], title_id)
    return _watchlist_out(user["id"])
