"""Playlists + watch history (per-user), backed by DynamoDB (lib/store). History pings
come from the watch page every few seconds so "Continue Watching" and the history page
survive across devices."""

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException

from lib import store
from lib.security import get_current_user, get_optional_user
from models.social import (
    HistoryItem,
    HistoryOut,
    HistoryPing,
    PlaylistIn,
    PlaylistOut,
    PlaylistUpdate,
    TitleRef,
)

router = APIRouter(tags=["social"])


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _title_refs(title_ids: list[str]) -> list[TitleRef]:
    refs: list[TitleRef] = []
    for tid in title_ids:
        title = store.get_title(tid)
        if title and title.get("status") == "published":
            refs.append(
                TitleRef(
                    id=tid,
                    slug=title["slug"],
                    name=title["name"],
                    poster_url=title.get("poster_url", ""),
                )
            )
    return refs


def _playlist_out(doc: dict, titles: list[TitleRef]) -> PlaylistOut:
    return PlaylistOut(
        id=doc["id"],
        name=doc["name"],
        owner_id=doc["owner_id"],
        is_public=doc["is_public"],
        title_ids=doc["title_ids"],
        titles=titles,
        created_at=doc["created_at"],
    )


# ------------------------------------------------------------------ history
@router.post("/history", status_code=204)
async def ping_history(payload: HistoryPing, user: dict = Depends(get_current_user)):
    if not payload.episode_id or not payload.title_id:
        raise HTTPException(status_code=404, detail="Episode not found")
    episode = store.get_episode(payload.episode_id)
    if not episode or episode.get("title_id") != payload.title_id or episode.get("status") != "published":
        raise HTTPException(status_code=404, detail="Episode not found")
    store.upsert_history(
        user["id"],
        payload.episode_id,
        {
            "title_id": payload.title_id,
            "episode_number": episode["number"],
            "position_seconds": payload.position_seconds,
            "updated_at": _now_iso(),
        },
    )


@router.get("/history", response_model=HistoryOut)
async def get_history(user: dict = Depends(get_current_user)):
    docs = store.list_history(user["id"])
    refs = {r.id: r for r in _title_refs([d["title_id"] for d in docs])}
    items = [
        HistoryItem(
            episode_id=d["episode_id"],
            title_id=d["title_id"],
            episode_number=d["episode_number"],
            position_seconds=d["position_seconds"],
            title=refs[d["title_id"]],
            updated_at=d["updated_at"],
        )
        for d in docs
        if d["title_id"] in refs
    ]
    return HistoryOut(items=items)


@router.delete("/history", status_code=204)
async def clear_history(user: dict = Depends(get_current_user)):
    store.clear_history(user["id"])


# ----------------------------------------------------------------- playlists
@router.get("/playlists", response_model=list[PlaylistOut])
async def my_playlists(user: dict = Depends(get_current_user)):
    docs = store.list_playlists(user["id"])
    return [_playlist_out(d, _title_refs(d["title_ids"])) for d in docs]


@router.post("/playlists", response_model=PlaylistOut, status_code=201)
async def create_playlist(payload: PlaylistIn, user: dict = Depends(get_current_user)):
    doc = {
        "id": str(uuid.uuid4()),
        "name": payload.name.strip(),
        "owner_id": user["id"],
        "is_public": False,
        "title_ids": [],
        "created_at": _now_iso(),
    }
    store.put_playlist(doc)
    return _playlist_out(doc, [])


@router.get("/playlists/{playlist_id}", response_model=PlaylistOut)
async def get_playlist(playlist_id: str, user: dict | None = Depends(get_optional_user)):
    """Owner always sees it; others only when the owner marked it public (share links)."""
    doc = store.get_playlist(playlist_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Playlist not found")
    is_owner = user is not None and user["id"] == doc["owner_id"]
    if not doc["is_public"] and not is_owner:
        raise HTTPException(status_code=404, detail="This playlist is private")
    return _playlist_out(doc, _title_refs(doc["title_ids"]))


@router.patch("/playlists/{playlist_id}", response_model=PlaylistOut)
async def update_playlist(
    playlist_id: str, payload: PlaylistUpdate, user: dict = Depends(get_current_user)
):
    doc = store.get_playlist(playlist_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Playlist not found")
    if doc["owner_id"] != user["id"]:
        raise HTTPException(status_code=403, detail="Not your playlist")

    updates: dict = {}
    if payload.name is not None:
        updates["name"] = payload.name.strip()[:80]
    if payload.is_public is not None:
        updates["is_public"] = payload.is_public
    if payload.add_title_id:
        title = store.get_title(payload.add_title_id)
        if not title or title.get("status") != "published":
            raise HTTPException(status_code=404, detail="Title not found")
        if payload.add_title_id not in doc["title_ids"]:
            updates["title_ids"] = doc["title_ids"] + [payload.add_title_id]
    if payload.remove_title_id:
        if payload.remove_title_id in doc["title_ids"]:
            updates["title_ids"] = [t for t in doc["title_ids"] if t != payload.remove_title_id]

    if updates:
        doc = store.update_playlist(playlist_id, updates)
    return _playlist_out(doc, _title_refs(doc["title_ids"]))


@router.delete("/playlists/{playlist_id}", status_code=204)
async def delete_playlist(playlist_id: str, user: dict = Depends(get_current_user)):
    doc = store.get_playlist(playlist_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Playlist not found")
    if doc["owner_id"] != user["id"]:
        raise HTTPException(status_code=403, detail="Not your playlist")
    store.delete_playlist(playlist_id)
