"""NFT Marketplace, Limited Editions, Admin Controls, and Auction House API Router.
Follows all user specifications:
- 50+ NFTs with Low, Mid, High tiers and categories (Anime, Dragons, Creatures, Characters).
- Admin creation of Limited Edition NFTs (Limit, Start, End, Price, Media/HTML/Animation).
- Admin grant / revoke NFT to/from any user.
- Peer-to-peer Transfer and Profile Showcase.
- 48-Hour Auction House:
    * Limited Edition NFTs only
    * Cancelable within first 24h only; locked after 24h
    * Highest bidder wins at ends_at, OR seller can confirm buyer early from bids.
- Ad / Reward conversion: 1 Ad = 1 VD, 3 VD = 1 CF, 1 VD = 1 LC.
"""

import uuid
from datetime import datetime, timezone, timedelta
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from lib import store
from lib.security import get_current_user, get_admin_user
from models.nft import (
    NFTItem,
    NFTOwnedItem,
    NFTPurchaseIn,
    NFTTransferIn,
    NFTAdminGrantIn,
    NFTAdminRevokeIn,
    NFTCreateAdminIn,
    AuctionItem,
    CreateAuctionIn,
    PlaceBidIn,
    SelectBuyerIn,
    BidItem,
    AdConversionIn,
    AdConversionOut,
)

router = APIRouter(prefix="/nft", tags=["nft"])


@router.delete("/admin/purge-all", status_code=204)
async def admin_purge_all_nfts(admin: dict = Depends(get_admin_user)):
    """ADMIN ONLY: Clear all NFTs and auctions so owner can curate manually."""
    for n in store.scan("nfts"):
        store.delete_item("nfts", n["id"])
    for o in store.scan("nft_owned"):
        store.delete_item("nft_owned", o["id"])
    for a in store.scan("auctions"):
        store.delete_item("auctions", a["id"])
    return None


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _now_iso() -> str:
    return _now().isoformat()

import os
import hmac
from fastapi import Header, BackgroundTasks

WEBHOOK_CRON_SECRET = os.environ.get("WEBHOOK_CRON_SECRET", "anime_unleashed_nft_cron_sec_9918237461")

def _settle_all_expired_auctions():
    auctions = store.scan("auctions")
    now_dt = _now()
    for auc in auctions:
        if auc.get("status") == "active" and auc.get("ends_at"):
            if _parse_iso(auc["ends_at"]) <= now_dt:
                _settle_auction_highest_bidder(auc)


@router.post("/cron/settle-auctions")
async def cron_settle_auctions(
    background_tasks: BackgroundTasks,
    authorization: Optional[str] = Header(None),
):
    # Cron endpoints must ack 2xx immediately; enqueue/background the actual work.
    if not authorization or not authorization.startswith("Bearer "):
        raise HTTPException(status_code=401, detail="Unauthorized")
    token = authorization.split("Bearer ", 1)[1].strip()
    if not hmac.compare_digest(token, WEBHOOK_CRON_SECRET):
        raise HTTPException(status_code=401, detail="Invalid webhook secret")

    background_tasks.add_task(_settle_all_expired_auctions)
    return {"ok": True, "enqueued": True}


def _parse_iso(s: str) -> datetime:
    try:
        return datetime.fromisoformat(s.replace("Z", "+00:00"))
    except Exception:
        return _now()


def _hydrate_nft(nft_doc: dict) -> dict:
    if not nft_doc:
        return {}
    # Convert Decimals/fields safely
    return {
        "id": str(nft_doc.get("id")),
        "name": str(nft_doc.get("name", "Unnamed NFT")),
        "description": str(nft_doc.get("description", "")),
        "media_url": str(nft_doc.get("media_url", "")),
        "media_type": str(nft_doc.get("media_type", "image")),
        "html": str(nft_doc.get("html", "")),
        "category": str(nft_doc.get("category", "anime")),
        "tier": str(nft_doc.get("tier", "low")),
        "edition": str(nft_doc.get("edition", "common")),
        "price_lc": int(nft_doc.get("price_lc", 50)),
        "supply": int(nft_doc.get("supply", 0)),
        "minted": int(nft_doc.get("minted", 0)),
        "start_from": nft_doc.get("start_from"),
        "end_at": nft_doc.get("end_at"),
        "active": bool(nft_doc.get("active", True)),
        "created_at": str(nft_doc.get("created_at", _now_iso())),
        "created_by": str(nft_doc.get("created_by", "system")),
    }


def _hydrate_owned(owned_doc: dict) -> dict:
    nft_id = owned_doc.get("nft_id")
    nft_raw = store.get_item("nfts", nft_id) if nft_id else None
    nft_hydrated = _hydrate_nft(nft_raw) if nft_raw else None

    return {
        "id": str(owned_doc.get("id")),
        "owner_id": str(owned_doc.get("owner_id")),
        "owner_name": str(owned_doc.get("owner_name", "Otaku")),
        "owner_email": str(owned_doc.get("owner_email", "")),
        "nft_id": str(nft_id),
        "nft": nft_hydrated,
        "serial": int(owned_doc.get("serial", 1)),
        "acquired_at": str(owned_doc.get("acquired_at", _now_iso())),
        "acquired_via": str(owned_doc.get("acquired_via", "purchase")),
        "showcase": bool(owned_doc.get("showcase", False)),
        "in_auction": bool(owned_doc.get("in_auction", False)),
    }


# ===========================================================================
# 1. NFT MARKETPLACE & CATALOG
# ===========================================================================

@router.get("/catalog", response_model=List[NFTItem])
async def list_nft_catalog(
    category: Optional[str] = None,
    tier: Optional[str] = None,
    edition: Optional[str] = None,
):
    """List all available NFTs in the marketplace with optional category/tier filters."""
    items = store.scan("nfts")
    now_ts = _now()
    results = []
    for it in items:
        # Check active status and start/end dates
        if not it.get("active", True):
            continue
        start_from = it.get("start_from")
        if start_from:
            try:
                if _parse_iso(start_from) > now_ts:
                    continue
            except Exception:
                pass
        end_at = it.get("end_at")
        if end_at:
            try:
                if _parse_iso(end_at) < now_ts:
                    continue
            except Exception:
                pass

        if category and category != "all" and it.get("category") != category:
            continue
        if tier and tier != "all" and it.get("tier") != tier:
            continue
        if edition and edition != "all" and it.get("edition") != edition:
            continue

        results.append(_hydrate_nft(it))

    # Sort: limited editions and high tiers first, then created_at
    tier_rank = {"limited": 4, "high": 3, "mid": 2, "low": 1}
    results.sort(key=lambda x: (tier_rank.get(x["tier"], 0), x.get("price_lc", 0)), reverse=True)
    return results


@router.get("/detail/{nft_id}", response_model=NFTItem)
async def get_nft_detail(nft_id: str):
    """Get single NFT metadata."""
    item = store.get_item("nfts", nft_id)
    if not item:
        raise HTTPException(status_code=404, detail="NFT not found")
    return _hydrate_nft(item)


@router.post("/buy")
async def buy_nft(payload: NFTPurchaseIn, user: dict = Depends(get_current_user)):
    """Purchase an NFT from marketplace using user coin balance (CF / LC)."""
    nft = store.get_item("nfts", payload.nft_id)
    if not nft or not nft.get("active", True):
        raise HTTPException(status_code=404, detail="NFT not available for purchase")

    # Check limited edition supply
    edition = nft.get("edition", "common")
    supply = int(nft.get("supply", 0))
    minted = int(nft.get("minted", 0))

    if edition == "limited" and supply > 0 and minted >= supply:
        raise HTTPException(status_code=400, detail="This Limited Edition NFT is sold out!")

    # Check end date
    end_at = nft.get("end_at")
    if end_at and _parse_iso(end_at) < _now():
        raise HTTPException(status_code=400, detail="This Limited Edition NFT offer has expired")

    price = int(nft.get("price_lc", 50))
    balance = int(user.get("lc_balance") or 0)

    if balance < price and user.get("role") != "admin":
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient LC (ZC) coins. You have {balance} LC, but this NFT costs {price} LC.",
        )

    # Deduct coins in LC (ZC)
    if user.get("role") != "admin":
        store.update_user(user["id"], {"lc_balance": balance - price})

    # Increment minted serial
    new_minted = minted + 1
    store.update_item("nfts", nft["id"], set_updates={"minted": new_minted})

    # Create owned item
    owned_id = f"own-{uuid.uuid4().hex[:12]}"
    owned_doc = {
        "id": owned_id,
        "owner_id": user["id"],
        "owner_name": user.get("display_name") or user.get("email", "").split("@")[0],
        "owner_email": user.get("email", ""),
        "nft_id": nft["id"],
        "serial": new_minted,
        "acquired_at": _now_iso(),
        "acquired_via": "purchase",
        "showcase": False,
        "in_auction": False,
    }
    store.put_item("nft_owned", owned_doc)

    return {
        "ok": True,
        "message": f"Successfully purchased {nft.get('name')} #{new_minted}!",
        "owned": _hydrate_owned(owned_doc),
        "remaining_balance": balance - price if user.get("role") != "admin" else balance,
    }


# ===========================================================================
# 2. USER INVENTORY & PROFILE SHOWCASE
# ===========================================================================

@router.get("/my/inventory", response_model=List[NFTOwnedItem])
async def my_nfts(user: dict = Depends(get_current_user)):
    """Get all NFTs owned by the authenticated user."""
    rows = store.query("nft_owned", "by_owner", "owner_id", user["id"])
    return [_hydrate_owned(r) for r in rows]


@router.get("/user/{user_id}/showcase", response_model=List[NFTOwnedItem])
async def get_user_showcase(user_id: str):
    """Public showcase of NFTs on a user's profile."""
    rows = store.query("nft_owned", "by_owner", "owner_id", user_id)
    # Return items marked for showcase (or all if none specifically pinned)
    showcased = [r for r in rows if r.get("showcase")]
    target = showcased if showcased else rows[:6]
    return [_hydrate_owned(r) for r in target]


@router.post("/my/{owned_id}/toggle-showcase")
async def toggle_showcase(owned_id: str, user: dict = Depends(get_current_user)):
    """Pin or unpin an owned NFT on user's public profile showcase."""
    item = store.get_item("nft_owned", owned_id)
    if not item or item.get("owner_id") != user["id"]:
        raise HTTPException(status_code=404, detail="NFT item not found in your inventory")

    new_val = not bool(item.get("showcase", False))
    store.update_item("nft_owned", owned_id, set_updates={"showcase": new_val})
    return {"ok": True, "showcase": new_val}


@router.post("/transfer")
async def transfer_nft(payload: NFTTransferIn, user: dict = Depends(get_current_user)):
    """Transfer an owned NFT to another user by email."""
    item = store.get_item("nft_owned", payload.owned_id)
    if not item or item.get("owner_id") != user["id"]:
        raise HTTPException(status_code=404, detail="NFT item not found in your inventory")

    if item.get("in_auction"):
        raise HTTPException(status_code=400, detail="Cannot transfer an NFT that is currently in auction")

    target_user = store.get_user_by_email(payload.recipient_email.strip())
    if not target_user:
        raise HTTPException(status_code=404, detail=f"Recipient '{payload.recipient_email}' not found")

    if target_user["id"] == user["id"]:
        raise HTTPException(status_code=400, detail="Cannot transfer NFT to yourself")

    # Transfer ownership
    store.update_item(
        "nft_owned",
        payload.owned_id,
        set_updates={
            "owner_id": target_user["id"],
            "owner_name": target_user.get("display_name") or target_user.get("email", "").split("@")[0],
            "owner_email": target_user.get("email", ""),
            "acquired_at": _now_iso(),
            "acquired_via": f"transfer from {user.get('email')}",
            "showcase": False,
        },
    )

    return {
        "ok": True,
        "message": f"Successfully transferred to {payload.recipient_email}!",
    }


# ===========================================================================
# 3. ADMIN NFT CONTROLS & CREATION SYSTEM
# ===========================================================================

@router.post("/admin/create", response_model=NFTItem)
async def admin_create_nft(payload: NFTCreateAdminIn, admin: dict = Depends(get_admin_user)):
    """Admin creates a new Limited Edition or Custom NFT with custom images, videos, animation, HTML, limit and dates."""
    if payload.start_from and payload.end_at:
        start_d = _parse_iso(payload.start_from)
        end_d = _parse_iso(payload.end_at)
        if end_d < start_d:
            raise HTTPException(status_code=400, detail="end_at date cannot be before start_from date")

    nft_id = f"nft-{uuid.uuid4().hex[:10]}"
    now_ts = _now_iso()

    doc = {
        "id": nft_id,
        "name": payload.name,
        "description": payload.description or "",
        "media_url": payload.media_url or "",
        "media_type": payload.media_type or "image",
        "html": payload.html or "",
        "category": payload.category or "anime",
        "tier": payload.tier or "limited",
        "edition": payload.edition or "limited",
        "price_lc": payload.price_lc,
        "supply": payload.supply,
        "minted": 0,
        "start_from": payload.start_from or now_ts,
        "end_at": payload.end_at,
        "active": True,
        "created_at": now_ts,
        "created_by": admin.get("email", "admin"),
    }
    store.put_item("nfts", doc)
    return _hydrate_nft(doc)


@router.post("/admin/grant")
async def admin_grant_nft(payload: NFTAdminGrantIn, admin: dict = Depends(get_admin_user)):
    """Admin grants an NFT directly to any user account."""
    nft = store.get_item("nfts", payload.nft_id)
    if not nft:
        raise HTTPException(status_code=404, detail="NFT not found")

    target_user = store.get_user_by_email(payload.user_email.strip())
    if not target_user:
        raise HTTPException(status_code=404, detail=f"User '{payload.user_email}' not found")

    # Respect limited supply
    edition = nft.get("edition", "common")
    supply = int(nft.get("supply", 0))
    minted = int(nft.get("minted", 0))
    if edition == "limited" and supply > 0 and minted >= supply:
        raise HTTPException(status_code=400, detail="Cannot grant NFT: limited supply limit has been reached")

    new_minted = minted + 1
    store.update_item("nfts", nft["id"], set_updates={"minted": new_minted})

    owned_id = f"own-{uuid.uuid4().hex[:12]}"
    owned_doc = {
        "id": owned_id,
        "owner_id": target_user["id"],
        "owner_name": target_user.get("display_name") or target_user.get("email", "").split("@")[0],
        "owner_email": target_user.get("email", ""),
        "nft_id": nft["id"],
        "serial": new_minted,
        "acquired_at": _now_iso(),
        "acquired_via": f"admin grant by {admin.get('email')}",
        "showcase": False,
        "in_auction": False,
    }
    store.put_item("nft_owned", owned_doc)

    return {
        "ok": True,
        "message": f"Successfully granted {nft.get('name')} #{new_minted} to {payload.user_email}",
        "owned": _hydrate_owned(owned_doc),
    }


@router.post("/admin/revoke")
async def admin_revoke_nft(payload: NFTAdminRevokeIn, admin: dict = Depends(get_admin_user)):
    """Admin removes an NFT from any user's account."""
    owned = store.get_item("nft_owned", payload.owned_id)
    if not owned:
        raise HTTPException(status_code=404, detail="Owned NFT record not found")

    # If it was in active auction, cancel the auction and refund current top bidder
    if owned.get("in_auction"):
        auctions = store.scan("auctions")
        for auc in auctions:
            if auc.get("owned_id") == payload.owned_id and auc.get("status") == "active":
                top_b_id = auc.get("top_bidder_id")
                curr_p = int(auc.get("current_price", 0))
                if top_b_id:
                    top_u = store.get_user(top_b_id)
                    if top_u:
                        curr_bal = int(top_u.get("cf_balance") or 0)
                        store.update_user(top_b_id, {"cf_balance": curr_bal + curr_p})
                store.update_item("auctions", auc["id"], set_updates={"status": "cancelled", "settled_at": _now_iso()})

    store.delete_item("nft_owned", payload.owned_id)
    return {
        "ok": True,
        "message": f"NFT {payload.owned_id} has been revoked from user {owned.get('owner_email') or owned.get('owner_id')}",
    }


# ===========================================================================
# 4. AUCTION HOUSE (48h Duration, 24h Cancel Gate, Highest Bidder / Confirm Buyer)
# ===========================================================================

def _hydrate_auction(doc: dict) -> dict:
    if not doc:
        return {}
    nft_id = doc.get("nft_id")
    nft_raw = store.get_item("nfts", nft_id) if nft_id else None
    nft_hydrated = _hydrate_nft(nft_raw) if nft_raw else None

    # Parse bids list
    raw_bids = doc.get("top_bids") or []
    bids = []
    for b in raw_bids:
        bids.append(
            {
                "user_id": str(b.get("user_id")),
                "user_name": str(b.get("user_name", "Anonymous")),
                "amount": int(b.get("amount", 0)),
                "created_at": str(b.get("created_at", "")),
            }
        )

    # Server-side timer check: if ends_at < now and still active, auto-settle to highest bidder
    status = str(doc.get("status", "active"))
    ends_at_str = str(doc.get("ends_at", ""))
    if status == "active" and ends_at_str:
        if _parse_iso(ends_at_str) <= _now():
            status = _settle_auction_highest_bidder(doc)

    return {
        "id": str(doc.get("id")),
        "owned_id": str(doc.get("owned_id")),
        "nft_id": str(nft_id),
        "nft_name": str(doc.get("nft_name", "Limited NFT")),
        "nft": nft_hydrated,
        "serial": int(doc.get("serial", 1)),
        "seller_id": str(doc.get("seller_id")),
        "seller_name": str(doc.get("seller_name", "Seller")),
        "start_price": int(doc.get("start_price", 1)),
        "current_price": int(doc.get("current_price", 1)),
        "start_at": str(doc.get("start_at", "")),
        "ends_at": ends_at_str,
        "can_cancel_until": str(doc.get("can_cancel_until", "")),
        "status": status,
        "top_bidder_id": str(doc.get("top_bidder_id", "")),
        "top_bidder_name": str(doc.get("top_bidder_name", "")),
        "bid_count": int(doc.get("bid_count", len(bids))),
        "top_bids": bids,
        "settled_at": doc.get("settled_at"),
        "created_at": str(doc.get("created_at", "")),
    }


def _settle_auction_highest_bidder(doc: dict) -> str:
    """Helper: settle auction to the highest bidder if time has expired."""
    auction_id = doc["id"]
    owned_id = doc["owned_id"]
    top_bidder_id = doc.get("top_bidder_id")
    seller_id = doc.get("seller_id")
    current_price = int(doc.get("current_price", 0))

    now_ts = _now_iso()

    if top_bidder_id:
        # Transfer NFT to winner
        winner = store.get_user(top_bidder_id)
        winner_name = winner.get("display_name") if winner else doc.get("top_bidder_name", "Winner")
        winner_email = winner.get("email") if winner else ""

        store.update_item(
            "nft_owned",
            owned_id,
            set_updates={
                "owner_id": top_bidder_id,
                "owner_name": winner_name,
                "owner_email": winner_email,
                "in_auction": False,
                "acquired_at": now_ts,
                "acquired_via": f"won auction #{auction_id}",
            },
        )

        # Pay seller in LC (ZC)
        seller = store.get_user(seller_id)
        if seller:
            seller_bal = int(seller.get("lc_balance") or 0)
            store.update_user(seller_id, {"lc_balance": seller_bal + current_price})

        # Mark auction sold
        store.update_item("auctions", auction_id, set_updates={"status": "sold", "settled_at": now_ts})
        return "sold"
    else:
        # No bids: return item to seller
        store.update_item("nft_owned", owned_id, set_updates={"in_auction": False})
        store.update_item("auctions", auction_id, set_updates={"status": "expired", "settled_at": now_ts})
        return "expired"


@router.get("/auctions", response_model=List[AuctionItem])
async def list_auctions(status: Optional[str] = "active"):
    """List all auctions in the Auction House."""
    items = store.scan("auctions")
    results = []
    for it in items:
        hydrated = _hydrate_auction(it)
        if status and status != "all" and hydrated["status"] != status:
            continue
        results.append(hydrated)

    # Sort active first, then soonest ending
    results.sort(key=lambda x: (x["status"] == "active", x.get("ends_at", "")), reverse=True)
    return results


@router.get("/auctions/{auction_id}", response_model=AuctionItem)
async def get_auction(auction_id: str):
    """Get single auction details."""
    doc = store.get_item("auctions", auction_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Auction not found")
    return _hydrate_auction(doc)


@router.post("/auctions/create", response_model=AuctionItem)
async def create_auction(payload: CreateAuctionIn, user: dict = Depends(get_current_user)):
    """User lists an owned Limited Edition NFT for 48h Auction.

    Rules:
    - Limited Edition NFTs only
    - Maximum duration: 48 hours
    - Cancellation allowed within first 24 hours only.
    """
    owned = store.get_item("nft_owned", payload.owned_id)
    if not owned or owned.get("owner_id") != user["id"]:
        raise HTTPException(status_code=404, detail="NFT not found in your inventory")

    if owned.get("in_auction"):
        raise HTTPException(status_code=400, detail="This NFT is already listed in an active auction")

    # RULE: Auctions are available only for Limited Edition NFTs
    nft = store.get_item("nfts", owned.get("nft_id"))
    if not nft or nft.get("edition") != "limited":
        raise HTTPException(
            status_code=400,
            detail="Auctions are strictly available for Limited Edition NFTs only. Common NFTs cannot be auctioned.",
        )

    now = _now()
    start_dt = _parse_iso(payload.start_at) if payload.start_at else now
    if start_dt < now:
        start_dt = now

    ends_dt = start_dt + timedelta(hours=48)
    cancel_until_dt = start_dt + timedelta(hours=24)

    auction_id = f"auc-{uuid.uuid4().hex[:10]}"
    auction_doc = {
        "id": auction_id,
        "owned_id": owned["id"],
        "nft_id": nft["id"],
        "nft_name": nft.get("name", "Limited NFT"),
        "serial": int(owned.get("serial", 1)),
        "seller_id": user["id"],
        "seller_name": user.get("display_name") or user.get("email", "").split("@")[0],
        "start_price": payload.start_price,
        "current_price": payload.start_price,
        "start_at": start_dt.isoformat(),
        "ends_at": ends_dt.isoformat(),
        "can_cancel_until": cancel_until_dt.isoformat(),
        "status": "active",
        "top_bidder_id": "",
        "top_bidder_name": "",
        "bid_count": 0,
        "top_bids": [],
        "created_at": now.isoformat(),
    }

    store.put_item("auctions", auction_doc)
    store.update_item("nft_owned", owned["id"], set_updates={"in_auction": True})

    return _hydrate_auction(auction_doc)


@router.post("/auctions/{auction_id}/bid")
async def place_bid(auction_id: str, payload: PlaceBidIn, user: dict = Depends(get_current_user)):
    """Place a bid on an active auction.

    Amount must strictly exceed current highest price.
    Coins are escrowed / verified from user balance.
    """
    auc = store.get_item("auctions", auction_id)
    if not auc:
        raise HTTPException(status_code=404, detail="Auction not found")

    hydrated = _hydrate_auction(auc)
    if hydrated["status"] != "active":
        raise HTTPException(status_code=400, detail="Auction is no longer active")

    if hydrated["seller_id"] == user["id"]:
        raise HTTPException(status_code=400, detail="You cannot bid on your own auction")

    # Time check
    if _parse_iso(hydrated["ends_at"]) <= _now():
        _settle_auction_highest_bidder(auc)
        raise HTTPException(status_code=400, detail="Auction has ended")

    current_price = hydrated["current_price"]
    # If first bid and no bids placed yet, bid can equal start_price; otherwise must be greater
    if hydrated["bid_count"] > 0 and payload.amount <= current_price:
        raise HTTPException(
            status_code=400,
            detail=f"Bid amount must be greater than current price of {current_price} coins",
        )
    elif hydrated["bid_count"] == 0 and payload.amount < current_price:
        raise HTTPException(
            status_code=400,
            detail=f"Bid amount must be at least the starting price of {current_price} coins",
        )

    user_bal = int(user.get("lc_balance") or 0)
    prev_top_id = hydrated.get("top_bidder_id")
    # If user is already the top bidder, they are topping up their bid: only deduct the delta
    if prev_top_id == user["id"]:
        delta = payload.amount - current_price
        if user_bal < delta and user.get("role") != "admin":
            raise HTTPException(
                status_code=400,
                detail=f"Insufficient LC (ZC) coins to increase bid by {delta}. You have {user_bal} LC.",
            )
        if user.get("role") != "admin":
            store.update_user(user["id"], {"lc_balance": user_bal - delta})
    else:
        # User is placing fresh bid: check and deduct full amount
        if user_bal < payload.amount and user.get("role") != "admin":
            raise HTTPException(
                status_code=400,
                detail=f"Insufficient LC (ZC) coins. You have {user_bal} LC, but your bid is {payload.amount} LC.",
            )
        if user.get("role") != "admin":
            store.update_user(user["id"], {"lc_balance": user_bal - payload.amount})

        # Refund previous top bidder if existed
        if prev_top_id:
            prev_user = store.get_user(prev_top_id)
            if prev_user:
                prev_bal = int(prev_user.get("lc_balance") or 0)
                store.update_user(prev_top_id, {"lc_balance": prev_bal + current_price})

    # Add new bid entry
    new_bid = {
        "user_id": user["id"],
        "user_name": user.get("display_name") or user.get("email", "").split("@")[0],
        "amount": payload.amount,
        "created_at": _now_iso(),
    }
    updated_bids = [new_bid] + (auc.get("top_bids") or [])
    # Keep top 3 bids sorted by amount
    updated_bids = sorted(updated_bids, key=lambda x: int(x.get("amount", 0)), reverse=True)[:3]

    store.update_item(
        "auctions",
        auction_id,
        set_updates={
            "current_price": payload.amount,
            "top_bidder_id": user["id"],
            "top_bidder_name": new_bid["user_name"],
            "bid_count": hydrated["bid_count"] + 1,
            "top_bids": updated_bids,
        },
    )

    return {
        "ok": True,
        "message": f"Bid of {payload.amount} coins placed successfully!",
        "current_price": payload.amount,
        "top_bidder_name": new_bid["user_name"],
    }


@router.post("/auctions/{auction_id}/cancel")
async def cancel_auction(auction_id: str, user: dict = Depends(get_current_user)):
    """Seller cancels their auction within the first 24 hours.

    RULE: After 24 hours, the user CANNOT cancel the auction.
    """
    auc = store.get_item("auctions", auction_id)
    if not auc:
        raise HTTPException(status_code=404, detail="Auction not found")

    if auc.get("seller_id") != user["id"] and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Only the seller can cancel this auction")

    if auc.get("status") != "active":
        raise HTTPException(status_code=400, detail="Auction is no longer active")

    now = _now()
    cancel_until = _parse_iso(auc.get("can_cancel_until", ""))

    # Strict 24-hour rule check
    if now > cancel_until and user.get("role") != "admin":
        raise HTTPException(
            status_code=400,
            detail="The 24-hour cancellation period has expired. This auction can no longer be cancelled.",
        )

    # Refund current top bidder if any
    top_bidder_id = auc.get("top_bidder_id")
    current_price = int(auc.get("current_price", 0))
    if top_bidder_id:
        top_user = store.get_user(top_bidder_id)
        if top_user:
            tb_bal = int(top_user.get("lc_balance") or 0)
            store.update_user(top_bidder_id, {"lc_balance": tb_bal + current_price})

    # Return NFT to seller
    store.update_item("nft_owned", auc["owned_id"], set_updates={"in_auction": False})

    # Mark auction cancelled
    store.update_item("auctions", auction_id, set_updates={"status": "cancelled", "settled_at": now.isoformat()})

    return {"ok": True, "message": "Auction successfully cancelled. NFT returned to your inventory."}


@router.post("/auctions/{auction_id}/confirm-buyer")
async def confirm_buyer(auction_id: str, payload: SelectBuyerIn, user: dict = Depends(get_current_user)):
    """The seller confirms the bid / confirms the buyer to whom they want to sell the NFT early.

    RULE: User can confirm their bid or confirm the buyer to whom they want to sell the NFT.
    """
    auc = store.get_item("auctions", auction_id)
    if not auc:
        raise HTTPException(status_code=404, detail="Auction not found")

    if auc.get("seller_id") != user["id"] and user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Only the seller can confirm a buyer")

    if auc.get("status") != "active":
        raise HTTPException(status_code=400, detail="Auction is no longer active")

    # Find the bid for the chosen buyer
    top_bids = auc.get("top_bids") or []
    chosen_bid = next((b for b in top_bids if b.get("user_id") == payload.buyer_id), None)
    if not chosen_bid:
        raise HTTPException(status_code=400, detail="The selected buyer has not placed a valid bid in this auction")

    winning_amount = int(chosen_bid.get("amount", 0))
    now_ts = _now_iso()

    # If the chosen buyer wasn't the current top bidder, refund other bidders accordingly
    # and charge the chosen buyer their winning amount (since their earlier bid was refunded when outbid)
    current_top_id = auc.get("top_bidder_id")
    if current_top_id and current_top_id != payload.buyer_id:
        top_user = store.get_user(current_top_id)
        if top_user:
            top_bal = int(top_user.get("lc_balance") or 0)
            store.update_user(current_top_id, {"lc_balance": top_bal + int(auc.get("current_price", 0))})

        # Charge the chosen lower bidder their winning bid amount
        chosen_user = store.get_user(payload.buyer_id)
        if chosen_user:
            c_bal = int(chosen_user.get("lc_balance") or 0)
            store.update_user(payload.buyer_id, {"lc_balance": max(0, c_bal - winning_amount)})

    # Transfer NFT to chosen buyer
    winner = store.get_user(payload.buyer_id)
    winner_name = winner.get("display_name") if winner else chosen_bid.get("user_name", "Buyer")
    winner_email = winner.get("email") if winner else ""

    store.update_item(
        "nft_owned",
        auc["owned_id"],
        set_updates={
            "owner_id": payload.buyer_id,
            "owner_name": winner_name,
            "owner_email": winner_email,
            "in_auction": False,
            "acquired_at": now_ts,
            "acquired_via": f"early seller confirmation on auction #{auction_id}",
        },
    )

    # Pay seller in LC (ZC)
    seller_bal = int(user.get("lc_balance") or 0)
    store.update_user(user["id"], {"lc_balance": seller_bal + winning_amount})

    # Mark auction sold
    store.update_item(
        "auctions",
        auction_id,
        set_updates={
            "status": "sold",
            "top_bidder_id": payload.buyer_id,
            "top_bidder_name": winner_name,
            "current_price": winning_amount,
            "settled_at": now_ts,
        },
    )

    return {
        "ok": True,
        "message": f"Successfully confirmed sale to {winner_name} for {winning_amount} coins!",
    }


# ===========================================================================
# 5. ADVERTISEMENT / REWARD CONVERSION (1 Ad = 1 VD, 3 VD = 1 CF, 1 VD = 1 LC)
# ===========================================================================

@router.post("/convert-rewards", response_model=AdConversionOut)
async def convert_ad_rewards(payload: AdConversionIn, user: dict = Depends(get_current_user)):
    """Convert accumulated View Duration / Ad tokens into marketplace coins:
    * 1 Ad = 1 VD (View Duration token) = 30 min VD watch time
    * 3 VD = 1 CF (Conversation Fees)
    * 1 VD = 1 LC (Leashed Coins)
    * Note: LC (Leashed Coins) cannot be converted to CF or VD.
    """
    vd_to_convert = payload.ad_tokens_to_convert
    target = payload.target_currency.upper()

    # Calculate user's earned VD from ad rewards
    events = [
        e
        for e in store.query("analytics_events", "user_created", "user_id", user["id"])
        if e.get("type") in ("ad_reward", "link_reward")
    ]
    total_ads_earned = len(events)
    # Deduct previously converted VD tokens
    converted_vd_total = int(user.get("converted_vd_tokens") or 0)
    available_vd = max(0, total_ads_earned - converted_vd_total)

    if available_vd < vd_to_convert:
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient VD tokens. You have {available_vd} VD available from watched ads, but requested {vd_to_convert} VD.",
        )

    cf_add = 0
    lc_add = 0
    formula = ""

    if target == "CF":
        if vd_to_convert < 3:
            raise HTTPException(status_code=400, detail="Minimum conversion for CF is 3 VD tokens (3 VD = 1 CF)")
        cf_add = vd_to_convert // 3
        vd_used = cf_add * 3
        formula = f"{vd_used} VD converted to {cf_add} CF (3 VD = 1 CF)"
    elif target == "LC":
        lc_add = vd_to_convert
        vd_used = vd_to_convert
        formula = f"{vd_used} VD converted to {lc_add} LC (1 VD = 1 LC)"
    else:
        raise HTTPException(status_code=400, detail="Target currency must be either 'CF' or 'LC'")

    total_coins_to_add = cf_add + lc_add
    current_bal = int(user.get("cf_balance") or 0)
    new_bal = current_bal + total_coins_to_add

    store.update_user(
        user["id"],
        {
            "cf_balance": new_bal,
            "lc_balance": int(user.get("lc_balance") or 0) + lc_add,
            "converted_vd_tokens": converted_vd_total + vd_used,
        },
    )

    return AdConversionOut(
        vd_deducted=vd_used,
        cf_added=cf_add,
        lc_added=lc_add,
        current_cf_balance=new_bal,
        current_lc_balance=int(user.get("lc_balance") or 0) + lc_add,
        formula_used=formula,
    )



class TransferCurrencyIn(BaseModel):
    recipient_email: str
    currency: str = Field(default="LC", description="LC (ZC), CF, or VD")
    amount: int = Field(..., ge=1, description="Amount to transfer")


@router.post("/transfer-currency")
async def transfer_currency(payload: TransferCurrencyIn, user: dict = Depends(get_current_user)):
    """Users can transfer currency (LC / ZC, CF, VD) to other users."""
    recipient = store.get_user_by_email(payload.recipient_email.strip().lower())
    if not recipient:
        raise HTTPException(status_code=404, detail=f"Recipient {payload.recipient_email} not found")
    if recipient["id"] == user["id"]:
        raise HTTPException(status_code=400, detail="Cannot transfer currency to yourself")

    curr = payload.currency.upper()
    amt = payload.amount

    if curr in ("LC", "ZC"):
        sender_bal = int(user.get("lc_balance") or 0)
        if sender_bal < amt and user.get("role") != "admin":
            raise HTTPException(status_code=400, detail=f"Insufficient LC balance. You have {sender_bal} LC.")
        if user.get("role") != "admin":
            store.update_user(user["id"], {"lc_balance": sender_bal - amt})
        rec_bal = int(recipient.get("lc_balance") or 0)
        store.update_user(recipient["id"], {"lc_balance": rec_bal + amt})
    elif curr == "CF":
        sender_bal = int(user.get("cf_balance") or 0)
        if sender_bal < amt and user.get("role") != "admin":
            raise HTTPException(status_code=400, detail=f"Insufficient CF balance. You have {sender_bal} CF.")
        if user.get("role") != "admin":
            store.update_user(user["id"], {"cf_balance": sender_bal - amt})
        rec_bal = int(recipient.get("cf_balance") or 0)
        store.update_user(recipient["id"], {"cf_balance": rec_bal + amt})
    else:
        raise HTTPException(status_code=400, detail="Transfer supported for LC (ZC) and CF currencies")

    return {
        "ok": True,
        "message": f"Successfully transferred {amt} {curr} to {payload.recipient_email}!",
    }


class ConvertToLCIn(BaseModel):
    from_currency: str = Field(..., description="'VD' (1 VD = 1 LC) or 'CF' (1 CF = 3 LC)")
    amount: int = Field(..., ge=1)


@router.post("/convert-to-lc")
async def convert_to_lc(payload: ConvertToLCIn, user: dict = Depends(get_current_user)):
    """Convert VD or CF into LC (ZC):
    - 1 VD = 1 LC
    - 1 CF = 3 LC
    Rule: LC cannot be converted back into VD or CF.
    """
    from_curr = payload.from_currency.upper()
    amt = payload.amount
    current_lc = int(user.get("lc_balance") or 0)

    if from_curr == "VD":
        # Check user's available VD watch duration minutes / tokens
        curr_vd_sec = int(user.get("watch_balance_seconds") or 0)
        needed_sec = amt * 60
        if curr_vd_sec < needed_sec and user.get("role") != "admin":
            raise HTTPException(status_code=400, detail=f"Insufficient VD. You have {curr_vd_sec // 60} mins, need {amt} mins.")
        if user.get("role") != "admin":
            store.update_item("users", user["id"], set_updates={"watch_balance_seconds": curr_vd_sec - needed_sec})
        new_lc = current_lc + amt
        store.update_user(user["id"], {"lc_balance": new_lc})
        return {
            "ok": True,
            "message": f"Successfully converted {amt} VD into {amt} LC!",
            "lc_balance": new_lc,
        }
    elif from_curr == "CF":
        curr_cf = int(user.get("cf_balance") or 0)
        if curr_cf < amt and user.get("role") != "admin":
            raise HTTPException(status_code=400, detail=f"Insufficient CF balance. You have {curr_cf} CF.")
        if user.get("role") != "admin":
            store.update_user(user["id"], {"cf_balance": curr_cf - amt})
        added_lc = amt * 3
        new_lc = current_lc + added_lc
        store.update_user(user["id"], {"lc_balance": new_lc})
        return {
            "ok": True,
            "message": f"Successfully converted {amt} CF into {added_lc} LC (1 CF = 3 LC)!",
            "lc_balance": new_lc,
        }
    else:
        raise HTTPException(status_code=400, detail="from_currency must be 'VD' or 'CF'")
