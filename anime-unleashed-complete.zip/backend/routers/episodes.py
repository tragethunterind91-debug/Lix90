"""Episode CRUD (admin), backed by DynamoDB (lib/store). Maintains the denormalised
episode_count on the parent title."""

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Response, UploadFile
from fastapi.responses import FileResponse

from lib import r2, storage, store
from lib.ratelimit import allow, client_ip
from lib.security import UserPublic, get_admin_user, get_worker_user, get_vip_user
from lib.translate import translate_vtt
from models.catalog import EpisodeIn, EpisodeOut, EpisodeUpdate, TranslateIn

router = APIRouter(tags=["episodes"])


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _vtt_response(episode_id: str, name: str):
    path = storage.sub_path(name)
    if path.exists():
        return FileResponse(path, media_type="text/vtt", headers={"Cache-Control": "private, max-age=3600"})
    # R2-era subtitles are proxied (tiny files; keeps VIP fetch() CORS-free)
    if r2.enabled():
        try:
            body = r2.client().get_object(Bucket=r2.bucket(), Key=f"subs/{name}")["Body"].read()
            return Response(content=body, media_type="text/vtt", headers={"Cache-Control": "private, max-age=3600"})
        except Exception:
            pass
    raise HTTPException(status_code=404, detail="Subtitle file missing")


@router.post("/episodes/{episode_id}/audio", response_model=EpisodeOut, status_code=201)
async def upload_episode_audio(
    episode_id: str, file: UploadFile, _: UserPublic = Depends(get_admin_user)
):
    """Attach a VIP-only dub/audio track (mp3/m4a/ogg/wav, ≤50 MB) to an episode."""
    episode = store.get_episode(episode_id)
    if not episode:
        raise HTTPException(status_code=404, detail="Episode not found")
    data = await file.read()
    try:
        name = storage.new_audio_name(file.filename or "")
        storage.save_audio(name, data)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    return _episode_out(store.update_episode(episode_id, {"audio_key": name}))


@router.post("/episodes/{episode_id}/subtitles", response_model=EpisodeOut, status_code=201)
async def upload_episode_subtitles(
    episode_id: str, file: UploadFile, _: UserPublic = Depends(get_admin_user)
):
    """Attach a VIP-only subtitle track (.vtt/.srt — SRT auto-converts to WebVTT)."""
    episode = store.get_episode(episode_id)
    if not episode:
        raise HTTPException(status_code=404, detail="Episode not found")
    data = await file.read()
    try:
        name = storage.new_sub_name(file.filename or "")
        storage.save_subtitle(name, data)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    return _episode_out(store.update_episode(episode_id, {"subtitle_key": name}))


@router.get("/episodes/{episode_id}/audio-stream")
async def stream_episode_audio(episode_id: str, _: dict = Depends(get_vip_user)):
    """VIP-only dub audio. Free users get 403 with an upsell message."""
    ep = store.get_episode(episode_id)
    if not ep or not ep.get("audio_key"):
        raise HTTPException(status_code=404, detail="No audio track attached")
    path = storage.audio_path(ep["audio_key"])
    if path.exists():
        return FileResponse(path, media_type=storage.audio_content_type(ep["audio_key"]))
    # R2-era audio is proxied through the backend (VIP-gated; small files, CORS-free)
    if r2.enabled() and r2.exists(f"audio/{ep['audio_key']}"):
        from fastapi import Response

        body = r2.client().get_object(Bucket=r2.bucket(), Key=f"audio/{ep['audio_key']}")["Body"].read()
        return Response(content=body, media_type=storage.audio_content_type(ep["audio_key"]))
    raise HTTPException(status_code=404, detail="Audio file missing")


@router.get("/episodes/{episode_id}/subtitles")
async def episode_subtitles(episode_id: str, lang: str = "", _: dict = Depends(get_vip_user)):
    """VIP-only WebVTT subtitles. ?lang=hi serves a translated variant if one exists."""
    ep = store.get_episode(episode_id)
    if not ep or not ep.get("subtitle_key"):
        raise HTTPException(status_code=404, detail="No subtitle track attached")
    if lang:
        variant = (ep.get("subtitle_variants") or {}).get(lang)
        if not variant:
            raise HTTPException(status_code=404, detail=f"No {lang} translation yet — translate it first")
        return _vtt_response(episode_id, variant)
    return _vtt_response(episode_id, ep["subtitle_key"])


@router.post("/episodes/{episode_id}/subtitles/translate", status_code=201)
async def translate_episode_subtitles(episode_id: str, payload: TranslateIn, _: dict = Depends(get_vip_user)):
    """VIP-only: translate the episode's subtitles (EN⇄HI) with cue timings preserved.
    The result is cached on the episode — later views are instant."""
    ep = store.get_episode(episode_id)
    if not ep or not ep.get("subtitle_key"):
        raise HTTPException(status_code=404, detail="No subtitle track attached")
    variants = ep.get("subtitle_variants") or {}
    if payload.target in variants:
        return {"lang": payload.target, "cached": True}
    src = storage.sub_path(ep["subtitle_key"])
    if src.exists():
        original = src.read_text(encoding="utf-8")
    elif r2.enabled():
        try:
            original = r2.client().get_object(Bucket=r2.bucket(), Key=f"subs/{ep['subtitle_key']}")["Body"].read().decode("utf-8")
        except Exception:
            raise HTTPException(status_code=404, detail="Subtitle file missing")
    else:
        raise HTTPException(status_code=404, detail="Subtitle file missing")
    if not allow(f"translate:{src.name}", 10, 300):
        raise HTTPException(status_code=429, detail="Too many translations — try again shortly")
    try:
        translated = await translate_vtt(original, payload.target)
        name = storage.new_sub_name(f"{payload.target}.vtt")
        storage.save_subtitle(name, translated.encode("utf-8"))
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    variants = dict(variants)
    variants[payload.target] = name
    store.update_episode(episode_id, {"subtitle_variants": variants})
    store.put_audit(
        {
            "id": str(uuid.uuid4()),
            "actor": "vip-subtitle",
            "action": "subtitle.translate",
            "target": f"episode {episode_id} → {payload.target}",
            "created_at": _now_iso(),
        }
    )
    return {"lang": payload.target, "cached": False}


def _episode_out(doc: dict) -> EpisodeOut:
    return EpisodeOut(**doc)


@router.post("/titles/{title_id}/episodes", response_model=EpisodeOut, status_code=201)
async def create_episode(
    title_id: str, payload: EpisodeIn, user: UserPublic = Depends(get_worker_user)
):
    if not store.get_title(title_id):
        raise HTTPException(status_code=404, detail="Title not found")
    if payload.video_key and not storage.video_exists(payload.video_key):
        raise HTTPException(status_code=422, detail="Unknown video_key — upload the file first")
    if store.get_episode_by_title_number(title_id, payload.number, payload.season):
        raise HTTPException(
            status_code=409,
            detail=f"Season {payload.season} already has an episode {payload.number} for this title",
        )
    size = storage.video_size(payload.video_key) if payload.video_key else 0
    doc = payload.model_dump()
    if user["role"] == "worker":
        doc["status"] = "draft"  # workers can only hand in drafts — the owner publishes
    doc.update(
        {
            "id": str(uuid.uuid4()),
            "title_id": title_id,
            "size_bytes": size,
            "created_at": _now_iso(),
        }
    )
    store.put_episode(doc)
    if payload.status == "published" and user["role"] != "worker":
        store.inc_title(title_id, {"episode_count": 1})
    if payload.video_key:
        # owner rule: viewers can watch BELOW the original too — auto-derive
        # smaller variants + audio + captions in the background right after upload
        import threading

        from lib import convert as _convert

        threading.Thread(target=_convert.auto_generate, args=(doc["id"],), daemon=True).start()
    return _episode_out(doc)


@router.patch("/episodes/{episode_id}", response_model=EpisodeOut)
async def update_episode(
    episode_id: str, payload: EpisodeUpdate, user: UserPublic = Depends(get_worker_user)
):
    doc = store.get_episode(episode_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Episode not found")
    updates = {k: v for k, v in payload.model_dump(exclude_unset=True).items()}
    if user["role"] == "worker":
        parent = store.get_title(doc["title_id"])
        if not parent or parent.get("status") != "draft":
            raise HTTPException(status_code=403, detail="Workers can only edit episodes of draft titles")
        if "status" in updates and updates["status"] != "draft":
            raise HTTPException(status_code=403, detail="Workers can't publish — ask the owner to publish")
    if "video_key" in updates:
        if updates["video_key"] and not storage.video_exists(updates["video_key"]):
            raise HTTPException(status_code=422, detail="Unknown video_key — upload the file first")
        updates["size_bytes"] = (
            storage.video_size(updates["video_key"]) if updates["video_key"] else 0
        )
    if "status" in updates and updates["status"] != doc["status"]:
        store.inc_title(
            doc["title_id"], {"episode_count": 1 if updates["status"] == "published" else -1}
        )
    if "title_id" in updates and updates["title_id"] and updates["title_id"] != doc["title_id"]:
        # MOVE to another playlist: admins only; keeps episode_count honest on both sides
        if user["role"] != "admin":
            raise HTTPException(status_code=403, detail="Only the admin can move episodes between playlists")
        target = store.get_title(updates["title_id"])
        if not target:
            raise HTTPException(status_code=404, detail="Target playlist (title) not found")
        if doc["status"] == "published" and target.get("status") != "published":
            store.inc_title(doc["title_id"], {"episode_count": -1})
    updated = store.update_episode(episode_id, updates)
    if not updated:
        raise HTTPException(status_code=404, detail="Episode not found")
    return _episode_out(updated)


@router.delete("/episodes/{episode_id}", status_code=204)
async def delete_episode(episode_id: str, _: UserPublic = Depends(get_admin_user)):
    doc = store.get_episode(episode_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Episode not found")
    # the original video STAYS in the upload-once library (no-re-upload rule);
    # only the derived files die with the episode
    from lib import convert

    convert.delete_variant_objects(doc.get("video_key") or "")
    store.delete_episode(episode_id)
    if doc.get("status") == "published":
        store.inc_title(doc["title_id"], {"episode_count": -1})
