"""Tasks — admin creates them, users claim them for EXTRA watch-duration.
Notebook rules: duration = countdown (expires_at) or permanent; reward = extra Duration."""

import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException

from lib import analytics, quota, store
from lib.security import admin_emails, get_admin_user, get_current_user
from models.tasks import TaskIn, TaskOut

router = APIRouter(tags=["tasks"])


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _task_out(doc: dict, claimed: bool = False, claimed_link: bool = False) -> TaskOut:
    expires = doc.get("expires_at")
    return TaskOut(
        id=doc["id"],
        title=doc["title"],
        description=doc.get("description", ""),
        reward_seconds=int(doc.get("reward_seconds", 0)),
        expires_at=expires,
        permanent=not expires,
        claimed=claimed,
        link_url=doc.get("link_url"),
        link_label=doc.get("link_label", ""),
        link_claimed_by_me=claimed_link,
        created_at=doc["created_at"],
    )


def _active(rows: list[dict]) -> list[dict]:
    now = _now_iso()
    return [r for r in rows if not r.get("expires_at") or r["expires_at"] > now]


@router.get("/tasks", response_model=list[TaskOut])
async def list_tasks(user: dict = Depends(get_current_user)):
    rows = _active(store.query("tasks", "all", "gsipk", "t", "created_at", None, False))
    claimed = {c["task_id"] for c in store.query("task_claims", "user_task", "user_id", user["id"])}
    claimed_links = {c["task_id"] for c in store.query("link_rewards", "user_task", "user_id", user["id"])}
    return [
        _task_out(t, claimed=t["id"] in claimed, claimed_link=t["id"] in claimed_links)
        for t in rows
    ]


@router.post("/tasks/{task_id}/link-claim")
async def claim_task_link(task_id: str, user: dict = Depends(get_current_user)):
    """Visit-link tasks: the user clicks the link, stays away 5s (gate) + 10s
    (background countdown — pauses while they're back on the site, never restarts),
    then claims the reward once per task. Server re-verifies everything."""
    task = store.get_item("tasks", task_id)
    if not task or not _active([task]):
        raise HTTPException(status_code=404, detail="Task not found or expired")
    if not task.get("link_url"):
        raise HTTPException(status_code=422, detail="This task has no link to visit")
    already = store.query("link_rewards", "user_task", "user_id", user["id"])
    if any(c.get("task_id") == task_id for c in already):
        raise HTTPException(status_code=409, detail="Reward already claimed for this task")
    seconds = int(task.get("reward_seconds", 0)) or 300
    new_balance = quota.grant_seconds(user["id"], seconds)  # capped at the 3.5 h store
    store.put_item(
        "link_rewards",
        {
            "id": f"{task_id}:{user['id']}",
            "user_id": user["id"],
            "task_id": task_id,
            "minutes": round(seconds / 60, 1),
            "created_at": _now_iso(),
        },
    )
    analytics.record_event(
        "link_reward",
        user_id=user["id"],
        minutes=seconds / 60,
        country=user.get("country", ""),
    )
    return {"ok": True, "balance_seconds": new_balance, "reward_seconds": seconds}


@router.get("/tasks/apply-email")
async def task_apply_email(_: dict = Depends(get_current_user)):
    """Notebook rule: users apply for tasks BY EMAIL — this is the owner's address."""
    emails = admin_emails()
    if not emails:
        raise HTTPException(status_code=404, detail="No application email configured")
    return {"email": emails[0]}


# ---------------------------------------------------------------- admin
@router.post("/admin/tasks", response_model=TaskOut, status_code=201)
async def create_task(payload: TaskIn, admin: dict = Depends(get_admin_user)):
    """Notebook: TASK (Admin) — title / distribution / duration / reward."""
    doc = {
        "id": str(uuid.uuid4()),
        "gsipk": "t",
        **payload.model_dump(mode="json"),
        "created_at": _now_iso(),
        "created_by": admin["email"],
    }
    store.put_item("tasks", doc)
    return _task_out(doc)


@router.get("/admin/tasks", response_model=list[TaskOut])
async def admin_tasks(_: dict = Depends(get_admin_user)):
    rows = store.query("tasks", "all", "gsipk", "t", "created_at", None, False)
    return [_task_out(r) for r in rows]


@router.delete("/admin/tasks/{task_id}", status_code=204)
async def delete_task(task_id: str, _: dict = Depends(get_admin_user)):
    if not store.get_item("tasks", task_id):
        raise HTTPException(status_code=404, detail="Task not found")
    store.delete_item("tasks", task_id)
