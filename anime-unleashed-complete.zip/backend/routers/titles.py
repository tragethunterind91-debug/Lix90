"""Public catalog reads + admin CRUD for titles, backed by DynamoDB (lib/store).
Titles are the R2-metadata records: every field here is managed from the admin panel
(AniList auto-import is Phase 2)."""

import re
import uuid
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from lib import storage, store
from lib.security import UserPublic, get_admin_user, get_optional_user, get_worker_user
from models.catalog import TitleDetail, TitleIn, TitleOut, TitleUpdate

router = APIRouter(tags=["titles"])


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug[:80] or "title"


def _unique_slug(name: str) -> str:
    base = _slugify(name)
    candidate = base
    n = 2
    while store.get_title_by_slug(candidate):
        candidate = f"{base}-{n}"
        n += 1
    return candidate


def _title_out(doc: dict) -> TitleOut:
    return TitleOut(**doc)


@router.get("/titles", response_model=list[TitleOut])
async def list_titles(
    request: Request,
    q: str = Query(default="", max_length=100),
    genre: str = Query(default="", max_length=60),
    year: int | None = Query(default=None),
    type: str = Query(default="", max_length=10),
    kind: str = Query(default="", max_length=10),
    sort: str = Query(default="latest", max_length=10),
    all: int = Query(default=0),
):
    """Public catalog (published only). `all=1` includes drafts for studio staff."""
    if all:
        await get_worker_user(request)  # raises 401/403 for non-staff
    docs = store.list_titles(
        status=None if all else "published",
        q=q.strip(),
        genre=genre,
        year=year,
        title_type=type if type in ("series", "movie") else None,
        kind=kind if kind in ("anime", "movie", "cartoon", "kdrama", "webseries") else None,
        sort=sort,
        limit=200,
        visibility=None if all else "listed",
    )
    return [_title_out(d) for d in docs]


@router.get("/titles/upcoming", response_model=list[TitleOut])
async def upcoming_titles():
    """Coming-Soon shelf — published titles switched to the 'upcoming' option, soonest first."""
    docs = store.list_titles(status="published", sort="latest", limit=200, visibility="upcoming")
    docs.sort(key=lambda t: t.get("release_at") or "9999")
    return [_title_out(d) for d in docs]


@router.get("/titles/featured", response_model=list[TitleOut])
async def featured_titles(limit: int = Query(default=4, ge=1, le=10)):
    docs = store.list_titles(status="published", sort="latest", limit=50, visibility="listed")
    return [_title_out(d) for d in docs if d.get("featured")][:limit]


@router.get("/titles/genres", response_model=list[str])
async def list_genres():
    return store.all_genres("published")


@router.post("/titles/{title_id}/view", status_code=204)
async def record_view(title_id: str, user: dict | None = Depends(get_optional_user)):
    """Public view counter — fired once when the watch page opens an episode."""
    doc = store.get_title(title_id)
    if not doc:
        return
    store.inc_title(title_id, {"views": 1})
    from lib import analytics

    analytics.record_event(
        "view",
        title_id=title_id,
        supplier_email=doc.get("supplier_email", ""),
        user_id=(user or {}).get("id", ""),
        country=(user or {}).get("country", ""),
    )


@router.get("/titles/{slug}", response_model=TitleDetail)
async def get_title(request: Request, slug: str, all: int = Query(default=0)):
    doc = store.get_title_by_slug(slug)
    if not doc:
        raise HTTPException(status_code=404, detail="Title not found")
    drafts_visible = False
    if all:
        await get_worker_user(request)  # drafts visible to studio staff only
        drafts_visible = True
    if doc.get("status") == "draft" and not drafts_visible:
        raise HTTPException(status_code=404, detail="Title not found")  # worker drafts stay private
    episodes = store.get_episodes_by_title(doc["id"], published_only=not drafts_visible)
    return TitleDetail(**_title_out(doc).model_dump(), episodes=episodes)


@router.post("/titles", response_model=TitleOut, status_code=201)
async def create_title(payload: TitleIn, user: UserPublic = Depends(get_worker_user)):
    if payload.status == "published" and payload.visibility == "upcoming" and not payload.release_at:
        raise HTTPException(status_code=422, detail="Upcoming titles need a release date for the countdown")
    doc = payload.model_dump(mode="json")
    doc.update(
        {
            "id": str(uuid.uuid4()),
            "slug": _unique_slug(payload.name),
            "episode_count": 0,
            "views": 0,
            "created_at": _now_iso(),
            "created_by_role": user["role"],
        }
    )
    if user["role"] == "worker":
        # workers hand in drafts only — the owner fills details and picks a launch option
        doc["status"] = "draft"
        doc["visibility"] = None
        doc["featured"] = False
    elif doc.get("status") == "published" and not doc.get("visibility"):
        doc["visibility"] = "listed"
    store.put_title(doc)
    return _title_out(doc)


@router.patch("/titles/{title_id}", response_model=TitleOut)
async def update_title(
    title_id: str, payload: TitleUpdate, user: UserPublic = Depends(get_worker_user)
):
    updates = {k: v for k, v in payload.model_dump(mode="json", exclude_unset=True).items()}
    if not updates:
        raise HTTPException(status_code=422, detail="Nothing to update")
    doc = store.get_title(title_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Title not found")
    if user["role"] == "worker":
        if doc.get("status") != "draft":
            raise HTTPException(status_code=403, detail="Workers can only edit drafts — ask the owner to change published titles")
        for k in ("status", "visibility", "release_at", "featured"):
            updates.pop(k, None)  # workers can never publish or feature
        if not updates:
            raise HTTPException(status_code=403, detail="Nothing you may change — draft details are owner-only beyond metadata")
    # validate the EFFECTIVE state after this update (single visibility field = the two
    # launch options are mutually exclusive by construction)
    eff_status = updates.get("status", doc.get("status"))
    eff_visibility = updates.get("visibility", doc.get("visibility"))
    eff_release = updates.get("release_at", doc.get("release_at"))
    if eff_status == "published":
        if eff_visibility == "upcoming" and not eff_release:
            raise HTTPException(status_code=422, detail="Upcoming titles need a release date for the countdown")
        if not eff_visibility:
            updates.setdefault("visibility", "listed")
    doc = store.update_title(title_id, updates)
    if not doc:
        raise HTTPException(status_code=404, detail="Title not found")
    return _title_out(doc)


@router.delete("/titles/{title_id}", status_code=204)
async def delete_title(title_id: str, _: UserPublic = Depends(get_admin_user)):
    if not store.get_title(title_id):
        raise HTTPException(status_code=404, detail="Title not found")
    for ep in store.get_episodes_by_title(title_id, published_only=False):
        if ep.get("video_key"):
            from lib import convert

            convert.delete_variant_objects(ep["video_key"])  # variants die with the playlist too
        storage.delete_video(ep.get("video_key"))
        store.delete_episode(ep["id"])
    store.remove_watchlist_for_title(title_id)
    store.remove_history_for_title(title_id)
    store.delete_title(title_id)
