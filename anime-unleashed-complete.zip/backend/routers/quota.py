"""Watch-time quota endpoints — the free-tier metering wall.

GET  /quota/me             → balance + mode (limited only for signed-in free viewers)
POST /quota/consume        → spend playback seconds (client pings every 15s while playing)
POST /quota/rewarded-ad    → mock rewarded ad: +30 min (45s cooldown)
POST /quota/download-check → downloads charge the episode's length upfront (403 if short)
"""

from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException

from lib import analytics, quota, store
from lib.security import get_current_user
from models.quota import ConsumeIn, DownloadCheckIn, DownloadCheckOut, QuotaOut, RewardHistoryOut

router = APIRouter(prefix="/quota", tags=["quota"])


def _out(user: dict) -> QuotaOut:
    limited = quota.is_limited(user)
    return QuotaOut(
        mode="limited" if limited else "unlimited",
        balance_seconds=quota.ensure_balance(user) if limited else 0,
        ad_cooldown_seconds=quota.cooldown_remaining(user) if limited else 0,
    )


@router.get("/me", response_model=QuotaOut)
async def my_quota(user: dict = Depends(get_current_user)):
    return _out(user)


@router.post("/consume", response_model=QuotaOut)
async def consume(payload: ConsumeIn, user: dict = Depends(get_current_user)):
    if not quota.is_limited(user):
        return _out(user)
    if not store.get_episode(payload.episode_id):
        raise HTTPException(status_code=404, detail="Episode not found")
    multiplier = {"video": 1.0, "audio": 0.5, "subtitle": 0.3}.get(payload.mode, 1.0)
    quota.consume(user["id"], max(1, round(payload.seconds * multiplier)))
    fresh = store.get_user(user["id"]) or user
    return _out(fresh)


@router.post("/rewarded-ad", response_model=QuotaOut)
async def rewarded_ad(user: dict = Depends(get_current_user)):
    """Mock rewarded ad (+30 min) until the owner's AdSense/GAM account is approved."""
    if not quota.is_limited(user):
        raise HTTPException(status_code=400, detail="Only free accounts earn ad time — VIP is unlimited")
    if not user.get("features", {}).get("refill_ads", True):
        raise HTTPException(status_code=403, detail="Rewarded ads are turned off for your account")
    balance, cooldown = quota.grant_ad_reward(user["id"])
    if cooldown > 0:
        raise HTTPException(status_code=429, detail=f"Ad reward on cooldown — wait {cooldown}s")
    analytics.record_event("ad_reward", user_id=user["id"], minutes=30.0, country=user.get("country", ""))
    return QuotaOut(mode="limited", balance_seconds=balance, ad_cooldown_seconds=0)


@router.get("/reward-history", response_model=RewardHistoryOut)
async def reward_history(user: dict = Depends(get_current_user)):
    """The earn center: every ad reward on the account + today/lifetime stats."""
    events = [
        e
        for e in store.query("analytics_events", "user_created", "user_id", user["id"])
        if e.get("type") in ("ad_reward", "link_reward")
    ]
    events.sort(key=lambda e: e.get("created_at", ""), reverse=True)
    today = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    today_events = [e for e in events if (e.get("created_at") or "").startswith(today)]
    return RewardHistoryOut(
        items=[
            {"created_at": e["created_at"], "minutes": e.get("minutes", 0), "kind": e.get("type", "ad_reward")}
            for e in events[:20]
        ],
        total_ads=len(events),
        minutes_total=round(sum(float(e.get("minutes") or 0) for e in events), 1),
        ads_today=len(today_events),
        minutes_today=round(sum(float(e.get("minutes") or 0) for e in today_events), 1),
    )


@router.post("/download-check", response_model=DownloadCheckOut)
async def download_check(payload: DownloadCheckIn, user: dict = Depends(get_current_user)):
    """Free accounts may only download when balance ≥ episode length; the length is charged."""
    episode = store.get_episode(payload.episode_id)
    if not episode:
        raise HTTPException(status_code=404, detail="Episode not found")
    if not quota.is_limited(user):
        return DownloadCheckOut(ok=True)
    required = int(episode.get("duration_seconds") or quota.DEFAULT_EPISODE_SECONDS)
    balance = quota.ensure_balance(user)
    if balance < required:
        raise HTTPException(
            status_code=403,
            detail={"code": "insufficient_balance", "required_seconds": required, "balance_seconds": balance},
        )
    new_balance = quota.consume(user["id"], required)
    return DownloadCheckOut(ok=True, balance_seconds=new_balance, charged_seconds=required)
