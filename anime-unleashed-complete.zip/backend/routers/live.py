"""Live Streams & 24/7 Anime Radio Broadcast system with SuperChat Tips and Schedule Countdowns."""

import uuid
from datetime import datetime, timezone
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from lib import store
from lib.security import get_current_user

router = APIRouter(prefix="/live", tags=["live"])


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class CreateLiveStreamIn(BaseModel):
    title: str = Field(..., min_length=3, max_length=120)
    description: str = Field("", max_length=1000)
    stream_url: str = Field(..., description="Direct HLS (.m3u8), MP4, or embed stream URL")
    thumbnail_url: Optional[str] = None
    category: str = Field("Anime Premieres", max_length=50)
    is_24_7: bool = False


class LiveChatMessageIn(BaseModel):
    text: str = Field(..., min_length=1, max_length=300)


class SuperChatIn(BaseModel):
    text: str = Field(..., min_length=1, max_length=200)
    coins: int = Field(..., ge=10, le=1000, description="Coin tip amount")


# Seed initial live streams
DEFAULT_LIVE_STREAMS = [
    {
        "id": "live-stream-247-lofi",
        "title": "24/7 Anime Unleashed Radio · Relaxing Beats & OSTs",
        "description": "Continuous 24/7 anime soundtrack chillstream, official openings, and community chat.",
        "stream_url": "https://vjs.zencdn.net/v/oceans.mp4",
        "thumbnail_url": "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=1280&q=80",
        "category": "24/7 Radio",
        "is_24_7": True,
        "status": "live",
        "creator_name": "Anime-Unleashed Studio",
        "creator_id": "system",
        "viewer_count": 142,
        "likes": 89,
        "created_at": _now_iso(),
    },
    {
        "id": "live-stream-shibuya-marathon",
        "title": "JUJUTSU KAISEN · Shibuya Arc Community Marathon",
        "description": "Live non-stop premiere marathon with live reaction room and synchronized playback.",
        "stream_url": "https://vjs.zencdn.net/v/oceans.mp4",
        "thumbnail_url": "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=1280&q=80",
        "category": "Special Event",
        "is_24_7": False,
        "status": "live",
        "creator_name": "Studio Unleashed",
        "creator_id": "system",
        "viewer_count": 328,
        "likes": 215,
        "created_at": _now_iso(),
    },
]

# Weekend upcoming schedule premieres
DEFAULT_SCHEDULE = [
    {
        "id": "prem-1",
        "title": "Demon Slayer: Infinity Castle Arc · Episode 1 Special Drop",
        "subtitle": "Hindi & Tamil Dub Premiere",
        "scheduled_time": "2026-11-08T18:30:00Z",
        "thumbnail": "https://images.unsplash.com/photo-1578632767115-351597cf2477?w=600&q=80",
        "category": "Season Premiere",
        "subscribers": 1420,
    },
    {
        "id": "prem-2",
        "title": "Solo Leveling: Arise · Mid-Season Special Broadcast",
        "subtitle": "Original Japanese + English Subtitles",
        "scheduled_time": "2026-11-09T20:00:00Z",
        "thumbnail": "https://images.unsplash.com/photo-1534447677768-be436bb09401?w=600&q=80",
        "category": "Community Watch Party",
        "subscribers": 890,
    },
    {
        "id": "prem-3",
        "title": "Chainsaw Man: Reze Arc Movie Live Announcement",
        "subtitle": "Official Trailer Breakdown & Panel",
        "scheduled_time": "2026-11-10T15:00:00Z",
        "thumbnail": "https://images.unsplash.com/photo-1607604276583-eef5d076aa5f?w=600&q=80",
        "category": "Special Event",
        "subscribers": 2150,
    },
]


@router.get("")
async def list_live_streams():
    """List all active live streams."""
    try:
        streams = store.scan("live_streams")
    except Exception:
        streams = []

    if not streams:
        for s in DEFAULT_LIVE_STREAMS:
            try:
                store.put_item("live_streams", s)
            except Exception:
                pass
        return DEFAULT_LIVE_STREAMS

    return sorted(streams, key=lambda x: x.get("viewer_count", 0), reverse=True)


@router.get("/schedule")
async def get_schedule():
    """Get scheduled upcoming anime premieres."""
    try:
        schedule = store.scan("live_schedule")
    except Exception:
        schedule = []

    if not schedule:
        for s in DEFAULT_SCHEDULE:
            try:
                store.put_item("live_schedule", s)
            except Exception:
                pass
        return DEFAULT_SCHEDULE

    return schedule


@router.get("/{stream_id}")
async def get_live_stream(stream_id: str):
    """Get single live stream by ID."""
    stream = store.get_item("live_streams", stream_id)
    if not stream:
        for s in DEFAULT_LIVE_STREAMS:
            if s["id"] == stream_id:
                return s
        raise HTTPException(status_code=404, detail="Live stream not found")
    return stream


@router.post("")
async def create_live_stream(payload: CreateLiveStreamIn, user: dict = Depends(get_current_user)):
    """Only admins and verified publishers can start a live broadcast."""
    if user.get("role") not in ("admin", "publisher", "worker"):
        raise HTTPException(status_code=403, detail="Only verified publishers and staff can broadcast live")

    stream_id = f"stream-{uuid.uuid4().hex[:12]}"
    doc = {
        "id": stream_id,
        "title": payload.title,
        "description": payload.description,
        "stream_url": payload.stream_url,
        "thumbnail_url": payload.thumbnail_url or "",
        "category": payload.category,
        "is_24_7": payload.is_24_7,
        "status": "live",
        "creator_name": user.get("display_name") or user.get("email", "Publisher"),
        "creator_id": user.get("id"),
        "viewer_count": 1,
        "likes": 0,
        "created_at": _now_iso(),
    }
    store.put_item("live_streams", doc)
    return doc


@router.post("/{stream_id}/chat")
async def send_live_chat(stream_id: str, payload: LiveChatMessageIn, user: dict = Depends(get_current_user)):
    """Post a normal message to the live broadcast chatroom."""
    # Verify stream exists
    stream = store.get_item("live_streams", stream_id)
    if not stream:
        raise HTTPException(status_code=404, detail="Stream not found")

    msg = {
        "id": f"lmsg-{uuid.uuid4().hex[:12]}",
        "stream_id": stream_id,
        "user_id": user.get("id"),
        "user_name": user.get("display_name") or user.get("email", "").split("@")[0] or "Otaku",
        "is_vip": bool(user.get("vip_until")),
        "role": user.get("role", "user"),
        "text": payload.text,
        "is_superchat": False,
        "coins": 0,
        "created_at": _now_iso(),
    }
    store.put_item("live_chat", msg)
    return msg


@router.post("/{stream_id}/superchat")
async def send_superchat(stream_id: str, payload: SuperChatIn, user: dict = Depends(get_current_user)):
    """Send a highlighted SuperChat tip message using user's coin balance."""
    # Verify stream exists
    stream = store.get_item("live_streams", stream_id)
    if not stream:
        raise HTTPException(status_code=404, detail="Stream not found")

    cf_balance = int(user.get("cf_balance") or 0)
    # 1 CF = 1 coin unit in chat
    if cf_balance < payload.coins and user.get("role") != "admin":
        raise HTTPException(
            status_code=400,
            detail=f"Insufficient coins. You have {cf_balance} coins, but {payload.coins} are required. Earn more in Tasks!",
        )

    # Deduct coins from user balance
    if user.get("role") != "admin":
        store.update_user(user["id"], {"cf_balance": cf_balance - payload.coins})

    msg = {
        "id": f"sc-{uuid.uuid4().hex[:12]}",
        "stream_id": stream_id,
        "user_id": user.get("id"),
        "user_name": user.get("display_name") or user.get("email", "").split("@")[0] or "Otaku",
        "is_vip": bool(user.get("vip_until")),
        "role": user.get("role", "user"),
        "text": payload.text,
        "is_superchat": True,
        "coins": payload.coins,
        "created_at": _now_iso(),
    }
    store.put_item("live_chat", msg)
    return msg


@router.get("/{stream_id}/chat")
async def get_live_chat(stream_id: str):
    """Fetch recent live chat messages including SuperChats."""
    try:
        msgs = store.query("live_chat", "by_stream", "stream_id", stream_id, limit=50)
        if msgs:
            return sorted(msgs, key=lambda x: x.get("created_at", ""))[-40:]
    except Exception as e:
        pass

    return [
        {
            "id": "welcome-1",
            "stream_id": stream_id,
            "user_name": "AnimeMod",
            "is_vip": True,
            "role": "admin",
            "text": "Welcome to the live broadcast! Keep chat respectful and enjoy the stream! 🍿✨",
            "is_superchat": False,
            "coins": 0,
            "created_at": _now_iso(),
        },
        {
            "id": "sc-seed-1",
            "stream_id": stream_id,
            "user_name": "GojoSatoru_Fan",
            "is_vip": True,
            "role": "user",
            "text": "Lofi vibes are unmatched today! Keep this playlist running! 🔥",
            "is_superchat": True,
            "coins": 100,
            "created_at": _now_iso(),
        },
    ]


class StreamDonationIn(BaseModel):
    amount: float = Field(..., ge=1.0, description="Donation amount in ₹ / coins")
    donor_name: Optional[str] = "Anonymous"
    message: Optional[str] = ""
    is_webview: bool = Field(default=False, description="True if YouTube/Social Media webview, False if Anime Unleashed live")
    creator_user_id: Optional[str] = None
    hype_count: int = 0
    likes_count: int = 0


@router.post("/{stream_id}/donate")
async def live_stream_donation(stream_id: str, payload: StreamDonationIn, user: dict = Depends(get_current_user)):
    """Live stream donation with rules:
    - If Native Anime Unleashed live: 60% to Creator, 40% to Anime Unleashed Platform.
    - If WebView streaming (YouTube/social): 60% to Anime Unleashed, 40% to Creator/User.
    - Supports sending hype, likes, pop-up messages.
    """
    stream = store.get_item("live_streams", stream_id)
    # Deduct from user deposit / wallet balance
    user_deposit = float(user.get("deposit_balance") or 0.0)
    user_cf = float(user.get("cf_balance") or 0.0)
    total_avail = user_deposit + user_cf

    if total_avail < payload.amount and user.get("role") != "admin":
        raise HTTPException(status_code=400, detail=f"Insufficient balance for ₹{payload.amount} donation. Please deposit funds first.")

    # Deduct from deposit balance first, then CF
    if user.get("role") != "admin":
        if user_deposit >= payload.amount:
            store.update_user(user["id"], {"deposit_balance": round(user_deposit - payload.amount, 2)})
        else:
            rem = payload.amount - user_deposit
            store.update_user(user["id"], {"deposit_balance": 0.0, "cf_balance": max(0, int(user_cf - rem))})

    # Distribution split
    if payload.is_webview:
        platform_pct = 0.60
        creator_pct = 0.40
        split_desc = "WebView video: 60% Anime Unleashed platform / 40% Creator/User"
    else:
        platform_pct = 0.40
        creator_pct = 0.60
        split_desc = "Anime Unleashed live: 60% Creator / 40% Anime Unleashed platform"

    creator_cut = round(payload.amount * creator_pct, 2)
    platform_cut = round(payload.amount * platform_pct, 2)

    # Credit creator if target known
    target_creator_id = payload.creator_user_id or (stream.get("creator_id") if stream else None)
    if target_creator_id and target_creator_id != "system":
        c_user = store.get_user(target_creator_id)
        if c_user:
            c_dep = float(c_user.get("deposit_balance") or 0.0)
            store.update_user(target_creator_id, {"deposit_balance": round(c_dep + creator_cut, 2)})

    # Log into revenue ledger for platform share
    store.put_revenue(
        {
            "id": str(uuid.uuid4()),
            "amount": platform_cut,
            "note": f"Live Donation — {payload.donor_name} on {stream_id} ({split_desc})",
            "created_at": _now_iso(),
        }
    )

    # Record donation event
    don_id = f"don-{uuid.uuid4().hex[:10]}"
    don_doc = {
        "id": don_id,
        "stream_id": stream_id,
        "user_id": user["id"],
        "donor_name": payload.donor_name or user.get("display_name") or "Otaku",
        "amount": payload.amount,
        "message": payload.message or "",
        "creator_cut": creator_cut,
        "platform_cut": platform_cut,
        "is_webview": payload.is_webview,
        "hype_count": payload.hype_count,
        "likes_count": payload.likes_count,
        "created_at": _now_iso(),
    }
    try:
        store.put_item("stream_donations", don_doc)
    except Exception:
        pass

    # Broadcast as superchat / pop-up donation in chat
    pop_msg = {
        "id": f"sc-{uuid.uuid4().hex[:12]}",
        "stream_id": stream_id,
        "user_id": user.get("id"),
        "user_name": don_doc["donor_name"],
        "is_vip": bool(user.get("vip_until")),
        "role": user.get("role", "user"),
        "text": f"🎉 DONATED ₹{payload.amount}! {payload.message or ''} (💥 {payload.hype_count} Hypes)",
        "is_superchat": True,
        "coins": int(payload.amount),
        "is_popup_donation": True,
        "created_at": _now_iso(),
    }
    store.put_item("live_chat", pop_msg)

    return {
        "ok": True,
        "message": f"Donation of ₹{payload.amount} sent! ({split_desc})",
        "creator_cut": creator_cut,
        "platform_cut": platform_cut,
        "chat_message": pop_msg,
    }


class StreamReactionIn(BaseModel):
    hype_delta: int = 0
    likes_delta: int = 0


@router.post("/{stream_id}/reaction")
async def live_stream_reaction(stream_id: str, payload: StreamReactionIn, user: dict = Depends(get_current_user)):
    """Send live hype or likes reaction during live or webview stream."""
    stream = store.get_item("live_streams", stream_id)
    cur_likes = int(stream.get("likes") or 0) if stream else 0
    cur_hypes = int(stream.get("hypes") or 0) if stream else 0
    new_likes = cur_likes + payload.likes_delta
    new_hypes = cur_hypes + payload.hype_delta
    if stream:
        store.update_item("live_streams", stream_id, set_updates={"likes": new_likes, "hypes": new_hypes})
    return {"ok": True, "likes": new_likes, "hypes": new_hypes}
