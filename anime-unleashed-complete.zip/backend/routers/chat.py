"""Social layer — personal chat (friends + DMs) and global chat (region rooms).

Notebook rules implemented here:
- friends: request → accept/decline/block/mute; free 15 friends, VIP 30; no re-request spam
- DMs: text + links + emoji stickers only — NO video/image attachments (nothing accepts media)
- global chat: region rooms (asia/americas/europe), no links, anti-spam rate limit
- cost: free users PAY 3 MINUTES of watch-time per global message (ICF = 3 min duration);
  VIP sends 300 free/day; staff unlimited
"""

import random
import uuid
from datetime import datetime, timedelta, timezone

from boto3.dynamodb.conditions import Attr
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from lib import quota, store
from lib.dates import today_iso
from lib.ratelimit import allow, client_ip
from lib.security import get_current_user, is_vip
from models.chat import (
    AccountOut,
    AccountUpdateIn,
    ChatMessageOut,
    ConvertIn,
    ConvertOut,
    DmIn,
    FriendOut,
    FriendRequestIn,
    FriendRespondIn,
    FriendsOut,
    GlobalIn,
)

router = APIRouter(tags=["chat"])

FRIEND_LIMIT_FREE = 15
FRIEND_LIMIT_VIP = 30
CF_RATE_SECONDS = 180  # 1 CF = 3 minutes of watch-time (the notes' ICF = 3 min duration)
GLOBAL_MESSAGE_CF = 1  # one global message burns 1 CF
VIP_FREE_MESSAGES = 300  # VIP daily free allowance
GLOBAL_WINDOW_SECONDS = 300  # notebook: only the last 5 MINUTES of global chat stay alive
REGIONS = ("asia", "americas", "europe")


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _purge_old_global(region: str) -> int:
    """Ephemeral rooms — delete this region's messages older than 5 minutes."""
    cutoff = (datetime.now(timezone.utc) - timedelta(seconds=GLOBAL_WINDOW_SECONDS)).isoformat()
    rows = store.query("messages", "global_region", "region", region, "created_at", None, False)
    removed = 0
    for r in rows:
        if r.get("created_at", "") < cutoff:
            store.delete_item("messages", r["id"])
            removed += 1
    return removed


def _pair_key(a: str, b: str) -> str:
    return "|".join(sorted([a, b]))


def _find_by_account(account_id: str) -> dict | None:
    """Scan lookup — works on the LIVE users table (no new GSI needed)."""
    rows = store.scan("users", Attr("account_id").eq(account_id.strip()))
    return rows[0] if rows else None


def _gen_account_id() -> str:
    for _ in range(8):
        candidate = f"{random.randint(100000, 999999)}"
        if not _find_by_account(candidate):
            return candidate
    return f"{random.randint(1000000, 9999999)}"


def _ensure_account(user: dict) -> dict:
    if not user.get("account_id"):
        store.update_user(user["id"], {"account_id": _gen_account_id()})
        user = store.get_user(user["id"]) or user
    return user


def _vip(user: dict) -> bool:
    return is_vip(user)


# ---------------------------------------------------------------- account
@router.get("/me/account", response_model=AccountOut)
async def my_account(user: dict = Depends(get_current_user)):
    user = _ensure_account(user)
    vip = _vip(user)
    return AccountOut(
        account_id=user["account_id"],
        display_name=user["display_name"],
        avatar_url=user.get("avatar_url", ""),
        country=user.get("country", "asia"),
        role=user.get("role", "user"),
        vip_active=vip,
        friends_limit=FRIEND_LIMIT_VIP if vip else FRIEND_LIMIT_FREE,
        chat_free_limit=VIP_FREE_MESSAGES if vip else 0,
        member_since=user.get("created_at", ""),
        cf_balance=int(user.get("cf_balance") or 0),
    )


# ------------------------------------------------- convert system: VD ↔ CF
@router.post("/me/convert", response_model=ConvertOut)
async def convert_currency(payload: ConvertIn, user: dict = Depends(get_current_user)):
    """View-duration → CF for chatting, or CF → view-duration to keep watching."""
    user = _ensure_account(user)
    cf = int(user.get("cf_balance") or 0)
    vd = quota.balance_of(user)

    if payload.direction == "vd_to_cf":
        seconds = payload.amount * 60  # amount is MINUTES of watch-time
        if seconds > vd:
            raise HTTPException(
                status_code=403,
                detail={"code": "insufficient_balance", "required_seconds": seconds, "balance_seconds": vd},
            )
        gained = seconds // CF_RATE_SECONDS
        if gained < 1:
            raise HTTPException(status_code=422, detail=f"Convert at least {CF_RATE_SECONDS // 60} minutes (1 CF)")
        cf += gained
        vd -= seconds
    else:
        if payload.amount > cf:
            raise HTTPException(
                status_code=403,
                detail={"code": "insufficient_cf", "required_cf": payload.amount, "cf_balance": cf},
            )
        cf -= payload.amount
        vd = min(quota.MAX_BALANCE_SECONDS, vd + payload.amount * CF_RATE_SECONDS)

    store.update_user(user["id"], {"cf_balance": cf, "watch_balance_seconds": vd})
    return ConvertOut(cf_balance=cf, balance_seconds=vd)


@router.patch("/me/account", response_model=AccountOut)
async def update_account(payload: AccountUpdateIn, user: dict = Depends(get_current_user)):
    user = _ensure_account(user)
    updates = {k: v for k, v in payload.model_dump(exclude_unset=True).items() if v is not None and k != "downgrade_vip"}
    if "phone" in updates:
        import re as _re

        digits = _re.sub(r"\D", "", str(updates.get("phone") or ""))
        if len(digits) == 10 and digits[0] in "6789":
            digits = "91" + digits
        if not digits or len(digits) < 10:
            raise HTTPException(status_code=422, detail="Enter a valid mobile number")
        phone = f"+{digits}"
        existing = store.query("users", "phone_idx", "phone", phone, None, None, True)
        if any(r["id"] != user["id"] for r in existing):
            raise HTTPException(status_code=409, detail="This number is already on an account — one number, one account")
        updates["phone"] = phone
        updates["phone_verified"] = False  # re-verify via SMS after a change
    if payload.downgrade_vip:
        updates["vip_until"] = None  # REMOVE attribute — VIP off immediately
    if updates:
        store.update_user(user["id"], updates)
    return await my_account(user)


# ---------------------------------------------------------------- friends
def _friend_out(doc: dict, other_id: str, other: dict, status: str) -> FriendOut:
    return FriendOut(
        request_id=doc["id"],
        user_id=other_id,
        account_id=other.get("account_id", ""),
        display_name=other.get("display_name", ""),
        avatar_url=other.get("avatar_url", ""),
        status=status,
        created_at=doc.get("created_at", ""),
    )


def _friends_between(a: str, b: str) -> list[dict]:
    out = []
    out += store.query("friends", "from_user", "from_id", a, "created_at", None, True)
    out += store.query("friends", "to_user", "to_id", a, "created_at", None, True)
    return [
        d for d in out
        if b in (d.get("from_id"), d.get("to_id"))
    ]


class FriendUserOut(BaseModel):
    user_id: str
    account_id: str
    display_name: str
    avatar_url: str = ""
    vip_active: bool = False
    role: str = "user"


@router.get("/users/search-by-id", response_model=FriendUserOut)
async def search_user_by_id(account_id: str, user: dict = Depends(get_current_user)):
    """Search user by account_id / user_id with limited, safe public details for regular users."""
    aid = account_id.strip()
    peer = _find_by_account(aid)
    if not peer:
        # also check by user primary id
        peer = store.get_user(aid)

    if not peer:
        raise HTTPException(status_code=404, detail="No user found with that ID")

    # Limited details returned to users (NO email, NO IP, NO internal auth tokens)
    return FriendUserOut(
        user_id=peer["id"],
        account_id=peer.get("account_id") or aid,
        display_name=peer.get("display_name") or "Otaku Fan",
        avatar_url=peer.get("avatar_url") or "",
        vip_active=bool(peer.get("vip_until")),
        role=peer.get("role", "user"),
    )


@router.post("/friends/request", status_code=201)
async def request_friend(payload: FriendRequestIn, user: dict = Depends(get_current_user)):
    user = _ensure_account(user)
    peer = _find_by_account(payload.account_id)
    if not peer:
        raise HTTPException(status_code=404, detail="No account with that ID")
    if peer["id"] == user["id"]:
        raise HTTPException(status_code=400, detail="That's your own ID")
    existing = _friends_between(user["id"], peer["id"])
    if any(d.get("status") in ("pending", "accepted") for d in existing):
        raise HTTPException(status_code=409, detail="You already have a pending or accepted connection with them")
    if any(d.get("status") == "blocked" for d in existing):
        raise HTTPException(status_code=403, detail="You can't send this request — one of you blocked the other")
    doc = {
        "id": str(uuid.uuid4()),
        "from_id": user["id"],
        "from_name": user["display_name"],
        "to_id": peer["id"],
        "to_name": peer["display_name"],
        "status": "pending",
        "created_at": _now_iso(),
    }
    store.put_item("friends", doc)
    return {"ok": True, "to": peer["display_name"]}


@router.get("/friends", response_model=FriendsOut)
async def list_friends(user: dict = Depends(get_current_user)):
    user = _ensure_account(user)
    mine = store.query("friends", "from_user", "from_id", user["id"], "created_at", None, True)
    theirs = store.query("friends", "to_user", "to_id", user["id"], "created_at", None, True)
    friends, incoming, outgoing = [], [], []
    for doc in mine + theirs:
        i_am_from = doc.get("from_id") == user["id"]
        other_id = doc["to_id"] if i_am_from else doc["from_id"]
        other = store.get_user(other_id) or {}
        status = doc.get("status")
        if status == "accepted":
            friends.append(_friend_out(doc, other_id, other, "accepted"))
        elif status == "pending":
            (outgoing if i_am_from else incoming).append(_friend_out(doc, other_id, other, "pending"))
    return FriendsOut(friends=friends, incoming=incoming, outgoing=outgoing)


@router.post("/friends/respond", response_model=FriendsOut)
async def respond_friend(payload: FriendRespondIn, user: dict = Depends(get_current_user)):
    doc = store.get_item("friends", payload.request_id)
    if not doc or user["id"] not in (doc.get("from_id"), doc.get("to_id")):
        raise HTTPException(status_code=404, detail="Request not found")
    if payload.action == "accept":
        if doc.get("status") != "pending" or doc["to_id"] != user["id"]:
            raise HTTPException(status_code=409, detail="Only the receiver can accept a pending request")
        accepted = sum(
            1
            for d in store.query("friends", "from_user", "from_id", user["id"]) + store.query("friends", "to_user", "to_id", user["id"])
            if d.get("status") == "accepted"
        )
        limit = FRIEND_LIMIT_VIP if _vip(user) else FRIEND_LIMIT_FREE
        if accepted >= limit:
            raise HTTPException(status_code=403, detail=f"Friend limit reached ({limit}) — go VIP for 30 friends")
        store.update_item("friends", doc["id"], set_updates={"status": "accepted"})
    elif payload.action == "decline":
        if doc.get("status") != "pending":
            raise HTTPException(status_code=409, detail="Only pending requests can be declined")
        store.update_item("friends", doc["id"], set_updates={"status": "declined"})
    else:  # block
        store.update_item("friends", doc["id"], set_updates={"status": "blocked"})
    return await list_friends(user)


@router.delete("/friends/{request_id}", status_code=204)
async def unfriend(request_id: str, user: dict = Depends(get_current_user)):
    doc = store.get_item("friends", request_id)
    if not doc or user["id"] not in (doc.get("from_id"), doc.get("to_id")):
        raise HTTPException(status_code=404, detail="Not found")
    store.delete_item("friends", request_id)


# ---------------------------------------------------------------- DMs
@router.get("/messages/dm/{peer_id}", response_model=list[ChatMessageOut])
async def dm_history(peer_id: str, after: str = "", user: dict = Depends(get_current_user)):
    links = _friends_between(user["id"], peer_id)
    if not any(d.get("status") == "accepted" for d in links):
        raise HTTPException(status_code=403, detail="You can only chat with accepted friends")
    rows = store.query("messages", "dm_pair", "pair_key", _pair_key(user["id"], peer_id), "created_at", None, True)
    if after:
        rows = [r for r in rows if r.get("created_at", "") > after]
    return [
        ChatMessageOut(
            id=r["id"],
            from_id=r["from_id"],
            from_name=r.get("from_name", ""),
            text=r.get("text", ""),
            created_at=r["created_at"],
        )
        for r in rows[-100:]
    ]


@router.post("/messages/dm", response_model=ChatMessageOut, status_code=201)
async def send_dm(payload: DmIn, user: dict = Depends(get_current_user)):
    if not allow(f"dm:{user['id']}", 20, 60):
        raise HTTPException(status_code=429, detail="Slow down — too many messages")
    links = _friends_between(user["id"], payload.peer_id)
    if not any(d.get("status") == "accepted" for d in links):
        raise HTTPException(status_code=403, detail="You can only chat with accepted friends")
    doc = {
        "id": str(uuid.uuid4()),
        "kind": "dm",
        "pair_key": _pair_key(user["id"], payload.peer_id),
        "from_id": user["id"],
        "from_name": user["display_name"],
        "to_id": payload.peer_id,
        "text": payload.text.strip(),
        "created_at": _now_iso(),
    }
    store.put_item("messages", doc)
    return ChatMessageOut(**doc)


# ---------------------------------------------------------------- global chat
@router.get("/messages/global/{region}", response_model=list[ChatMessageOut])
async def global_history(region: str, after: str = "", _: dict = Depends(get_current_user)):
    if region not in REGIONS:
        raise HTTPException(status_code=422, detail="Region must be asia, americas or europe")
    _purge_old_global(region)
    cutoff = (datetime.now(timezone.utc) - timedelta(seconds=GLOBAL_WINDOW_SECONDS)).isoformat()
    rows = store.query("messages", "global_region", "region", region, "created_at", None, True)
    rows = [r for r in rows if r.get("created_at", "") >= cutoff]
    if after:
        rows = [r for r in rows if r.get("created_at", "") > after]
    return [
        ChatMessageOut(id=r["id"], from_id=r["from_id"], from_name=r.get("from_name", ""), text=r.get("text", ""), created_at=r["created_at"])
        for r in rows[-100:]
    ]


@router.post("/messages/global", response_model=ChatMessageOut, status_code=201)
async def send_global(payload: GlobalIn, user: dict = Depends(get_current_user)):
    if not user.get("features", {}).get("global_chat", True):
        raise HTTPException(status_code=403, detail="Global chat is turned off for your account")
    if not allow(f"global:{user['id']}", 5, 60):
        raise HTTPException(status_code=429, detail="Anti-spam — wait a moment before chatting again")
    user = _ensure_account(user)
    region = user.get("country", "asia")
    vip = _vip(user)
    if payload.region and payload.region != region:
        if not vip:
            raise HTTPException(status_code=403, detail="Only VIP can chat across continents")
        region = payload.region
    text = payload.text.strip()
    if "http://" in text.lower() or "https://" in text.lower() or "www." in text.lower():
        raise HTTPException(status_code=403, detail="Links are not allowed in global chat")

    # cost: chatting spends CF (1 CF = 3 min of watch-time, converted by the user).
    # VIP gets 300 free messages/day, then CF kicks in. Staff chat free.
    if user.get("role") == "user":
        today = today_iso()
        used = int(user.get("chat_uses_today") or 0) if user.get("last_chat_day") == today else 0
        free_left = max(0, VIP_FREE_MESSAGES - used) if vip else 0
        if free_left > 0:
            store.update_user(user["id"], {"chat_uses_today": used + 1, "last_chat_day": today})
        else:
            cf = int(user.get("cf_balance") or 0)
            if cf < GLOBAL_MESSAGE_CF:
                raise HTTPException(
                    status_code=403,
                    detail={
                        "code": "insufficient_cf",
                        "required_cf": GLOBAL_MESSAGE_CF,
                        "cf_balance": cf,
                    },
                )
            store.update_user(
                user["id"],
                {"cf_balance": cf - GLOBAL_MESSAGE_CF, "chat_uses_today": used + 1, "last_chat_day": today},
            )

    doc = {
        "id": str(uuid.uuid4()),
        "kind": "global",
        "region": region,
        "from_id": user["id"],
        "from_name": user["display_name"],
        "text": text,
        "created_at": _now_iso(),
    }
    store.put_item("messages", doc)
    _purge_old_global(region)  # keep the room ephemeral
    return ChatMessageOut(**doc)
