"""Video pipeline — the R2 stand-in, backed by DynamoDB (lib/store):

- POST /videos/upload      admin/worker multipart upload; R2-style credentials never touch the
                            browser — the file is registered so it can be REUSED without re-upload
- GET  /stream/{video_key} byte-range streaming (206); ?res=720p serves a converted variant
- POST /videos/{id}/convert        background ffmpeg job → resolution variants + audio-only
- GET  /videos/{id}/variants       conversion status per resolution
- GET  /videos/library             the upload-once library (attach videos without re-uploading)
- POST /videos/attach              attach an existing library video to an episode
- POST /videos/{id}/download-link  10-min signed link (?format=video|audio&res=)
- GET  /videos/{id}/subtitles/{lang}/download  subtitle file as an attachment
- GET  /download/{id}      signed-link redemption; serves the file as an attachment
"""

import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, RedirectResponse, Response, StreamingResponse

from lib import analytics, convert, r2, security, storage, store, watermark
from lib.security import (
    UserPublic,
    create_download_token,
    decode_token,
    get_admin_user,
    get_current_user,
    get_vip_user,
    get_worker_user,
)
from models.catalog import (
    AttachVideoIn,
    ConvertIn,
    DownloadLink,
    DownloadOptionsIn,
    EpisodeOut,
    UploadOut,
    VideoLibItem,
    VideoVariantOut,
)

router = APIRouter(tags=["videos"])

MAX_UPLOAD_BYTES = 2 * 1024 * 1024 * 1024  # 2 GiB


def _register_video(key: str, size: int, by: str) -> None:
    """Upload-once registry: videos are objects admins can attach to any episode later."""
    store.put_item(
        "videos",
        {
            "id": key,
            "gsipk": "library",
            "size_bytes": size,
            "attached_episode": "",
            "uploaded_by": by,
            "created_at": datetime.now(timezone.utc).isoformat(),
        },
    )


def _published_episode_with_video(episode_id: str) -> dict:
    ep = store.get_episode(episode_id)
    if not ep or ep.get("status") != "published":
        raise HTTPException(status_code=404, detail="Episode not found")
    if not ep.get("video_key"):
        raise HTTPException(status_code=404, detail="Episode has no video yet")
    return ep


@router.post("/videos/upload", response_model=UploadOut, status_code=201)
async def upload_video(file: UploadFile, _: UserPublic = Depends(get_worker_user)):
    filename = file.filename or "video.mp4"
    try:
        video_key = storage.new_video_key(filename)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc))

    async def chunks():
        while data := await file.read(storage.CHUNK):
            yield data

    try:
        written = await storage.save_upload(video_key, chunks())
    except ValueError as exc:
        storage.delete_video(video_key)  # never keep rejected bytes around
        raise HTTPException(status_code=422, detail=str(exc))
    except Exception:
        storage.delete_video(video_key)
        raise
    if written > MAX_UPLOAD_BYTES:
        storage.delete_video(video_key)
        raise HTTPException(status_code=413, detail="File too large (max 2 GiB)")
    _register_video(video_key, written, _.get("email", "unknown"))  # get_worker_user returns a dict
    return UploadOut(
        video_key=video_key,
        size_bytes=written,
        content_type=storage.content_type_for(video_key),
    )


# ------------------------------------------------------------ convert system
@router.post("/videos/{episode_id}/convert", status_code=202)
async def convert_episode(
    episode_id: str,
    payload: ConvertIn,
    background: BackgroundTasks,
    _: UserPublic = Depends(get_worker_user),
):
    """One upload → many resolutions (+ audio-only). ffmpeg runs server-side in the
    background; the player gets a resolution switcher (lower↔higher both allowed)."""
    if not convert.ffmpeg_available():
        raise HTTPException(status_code=503, detail="ffmpeg is not installed on this server yet")
    ep = store.get_episode(episode_id)
    if not ep or not ep.get("video_key"):
        raise HTTPException(status_code=404, detail="Episode has no video to convert")
    if not payload.resolutions and not payload.extract_audio:
        raise HTTPException(status_code=422, detail="Pick at least one resolution or the audio track")
    for res in payload.resolutions:
        _set_variant_status(episode_id, res)
    if payload.extract_audio:
        _set_variant_status(episode_id, "audio")
    background.add_task(convert.run_conversion, episode_id, payload.resolutions, payload.extract_audio)
    return {"queued": payload.resolutions, "audio": payload.extract_audio}


def _set_variant_status(episode_id: str, tag: str) -> None:
    ep = store.get_episode(episode_id)
    variants = dict(ep.get("video_variants") or {})
    variants[tag] = {"key": convert.variant_key(ep["video_key"], tag), "status": "processing", "size_bytes": 0}
    store.update_episode(episode_id, {"video_variants": variants})


@router.get("/videos/{episode_id}/variants", response_model=dict[str, VideoVariantOut])
async def episode_variants(episode_id: str, _: UserPublic = Depends(get_current_user)):
    ep = store.get_episode(episode_id)
    if not ep:
        raise HTTPException(status_code=404, detail="Episode not found")
    return {tag: VideoVariantOut(**v) for tag, v in (ep.get("video_variants") or {}).items()}


@router.get("/videos/library", response_model=list[VideoLibItem])
async def video_library(_: UserPublic = Depends(get_worker_user)):
    """Upload-once library — every stored video, attached or waiting for an episode."""
    rows = store.scan("videos")
    rows.sort(key=lambda r: r.get("created_at", ""), reverse=True)
    return [VideoLibItem(key=r["id"], size_bytes=r.get("size_bytes", 0), attached_episode=r.get("attached_episode", ""), uploaded_by=r.get("uploaded_by", ""), created_at=r.get("created_at", "")) for r in rows]


@router.post("/videos/attach", response_model=EpisodeOut)
async def attach_video(payload: AttachVideoIn, _: UserPublic = Depends(get_admin_user)):
    """THE no-re-upload rule: point an episode at an already-stored video."""
    ep = store.get_episode(payload.episode_id)
    if not ep:
        raise HTTPException(status_code=404, detail="Episode not found")
    if not storage.video_exists(payload.video_key):
        raise HTTPException(status_code=422, detail="That video isn't in the store")
    updated = store.update_episode(payload.episode_id, {"video_key": payload.video_key})
    reg = store.get_item("videos", payload.video_key)
    if reg:
        store.update_item("videos", payload.video_key, set_updates={"attached_episode": payload.episode_id})
    return EpisodeOut(**updated)


def _range_parse(range_header: str | None, size: int) -> tuple[int, int, bool]:
    """Returns (start, end, is_partial). Invalid/absent Range → full body."""
    if not range_header:
        return 0, size - 1, False
    match = re.match(r"bytes=(\d*)-(\d*)$", range_header.strip())
    if not match:
        return 0, size - 1, False
    start_s, end_s = match.groups()
    start = int(start_s) if start_s else 0
    end = int(end_s) if end_s else size - 1
    if start_s == "" and end_s:
        # suffix range: last N bytes
        start = max(0, size - int(end_s))
        end = size - 1
    end = min(end, size - 1)
    if start > end or start >= size:
        raise HTTPException(
            status_code=416,
            detail="Range not satisfiable",
            headers={"Content-Range": f"bytes */{size}"},
        )
    return start, end, True


def _file_iterator(path: Path, start: int, end: int):
    def gen():
        remaining = end - start + 1
        with open(path, "rb") as handle:
            handle.seek(start)
            while remaining > 0:
                data = handle.read(min(storage.CHUNK, remaining))
                if not data:
                    break
                remaining -= len(data)
                yield data

    return gen()


@router.get("/stream/{video_key}")
async def stream_video(video_key: str, request: Request, res: str = ""):
    # Only videos attached to a published episode are streamable.
    ep = store.get_episode_by_video(video_key)
    if not ep or ep.get("status") != "published":
        raise HTTPException(status_code=404, detail="Video not found")

    path = storage.video_path(video_key)
    if not path.exists():
        # R2-era upload: hand the player a 2h presigned URL — R2 speaks byte-range natively
        if r2.enabled() and r2.exists(video_key):
            return RedirectResponse(r2.presign_get(video_key, 7200), status_code=307,
                                    headers={"Cache-Control": "no-store"})
        raise HTTPException(status_code=404, detail="Video file missing")

    size = path.stat().st_size
    start, end, is_partial = _range_parse(request.headers.get("range"), size)
    headers = {
        "Accept-Ranges": "bytes",
        "Content-Length": str(end - start + 1),
        "Cache-Control": "no-store",
    }
    if is_partial:
        headers["Content-Range"] = f"bytes {start}-{end}/{size}"
    return StreamingResponse(
        _file_iterator(path, start, end),
        status_code=206 if is_partial else 200,
        media_type=storage.content_type_for(video_key),
        headers=headers,
    )


@router.post("/videos/{episode_id}/download-link", response_model=DownloadLink)
async def create_download_link(episode_id: str, user: UserPublic = Depends(get_admin_user), options: DownloadOptionsIn | None = None):
    """Admin-only: fetch a time-limited signed download URL (10 min).
    format=video (original or a resolution) / format=audio (m4a track)."""
    if not user.get("features", {}).get("downloads", True):
        raise HTTPException(status_code=403, detail="Downloads are turned off for your account")
    ep = _published_episode_with_video(episode_id)
    opts = options or DownloadOptionsIn()
    title = store.get_title(ep["title_id"])
    analytics.record_event(
        "download_video" if (opts.format or "video") == "video" else "download_audio",
        title_id=ep["title_id"],
        episode_id=episode_id,
        supplier_email=(title or {}).get("supplier_email", ""),
        user_id=user.get("id", ""),
        country=user.get("country", ""),
    )
    token = create_download_token(episode_id)
    expires_at = datetime.now(timezone.utc) + timedelta(
        seconds=security.DOWNLOAD_TOKEN_TTL_SECONDS
    )
    if (opts.format or "video") == "video":
        # ANTI-PIRACY: video downloads burn the downloader's ID into the file
        # (one ffmpeg pass per user+video, cached in R2 — see lib/watermark.py)
        variant_key = _pick_media_key(ep, "video", opts.resolution)
        _, ready = watermark.request_watermark(variant_key, user)
        url = f"/api/videos/{episode_id}/download-protected?token={token}&format=video"
        if opts.resolution:
            url += f"&res={opts.resolution}"
        return DownloadLink(url=url, expires_at=expires_at.isoformat(), watermark="ready" if ready else "preparing")
    url = f"/api/download/{episode_id}?token={token}&format={opts.format}"
    if opts.resolution:
        url += f"&res={opts.resolution}"
    return DownloadLink(url=url, expires_at=expires_at.isoformat())


@router.get("/videos/{episode_id}/download-protected")
async def download_protected(
    episode_id: str,
    token: str,
    format: str = "video",
    res: str | None = None,
    user: UserPublic = Depends(get_current_user),
):
    """Watermarked-download redemption: 202 while the burn runs, then a presigned
    attachment URL of the file stamped with THIS downloader's account ID."""
    claims = decode_token(token, "download")
    if claims.get("sub") != episode_id:
        raise HTTPException(status_code=401, detail="Invalid token")
    ep = store.get_episode(episode_id)
    if not ep:
        raise HTTPException(status_code=404, detail="Episode not found")
    if format != "video":
        raise HTTPException(status_code=422, detail="Only video downloads are watermarked")
    video_key = _pick_media_key(ep, "video", res)
    wm_key, ready = watermark.request_watermark(video_key, user)
    if ready:
        safe = re.sub(r"[^A-Za-z0-9 ._-]", "_", ep.get("name") or "episode")
        return RedirectResponse(r2.presign_get(wm_key, 600, disposition=f"{safe}-watermarked.mp4"))
    return Response(status_code=202, content='{"status":"preparing"}', media_type="application/json")


def _pick_media_key(ep: dict, format: str, res: str | None) -> str:
    variants = ep.get("video_variants") or {}
    if format == "audio":
        track = variants.get("audio") or {}
        if track.get("status") != "ready" or not track.get("key"):
            raise HTTPException(status_code=404, detail="No converted audio track — run the convert system first")
        return track["key"]
    if res:
        variant = variants.get(res) or {}
        if variant.get("status") == "ready" and variant.get("key"):
            return variant["key"]
        raise HTTPException(status_code=404, detail=f"No {res} variant yet — run the convert system first")
    return ep["video_key"]


@router.get("/download/{episode_id}")
async def download_episode(episode_id: str, token: str, format: str = "video", res: str = ""):
    decode_token(token, "download")  # expiry + signature + purpose
    ep = _published_episode_with_video(episode_id)
    title = store.get_title(ep["title_id"])
    slug = title["slug"] if title else "episode"
    media_key = _pick_media_key(ep, format, res or None)
    ext = Path(media_key).suffix.lower()
    label = f"{slug}-ep{ep['number']}-{res}" if (format == "video" and res) else f"{slug}-ep{ep['number']}-audio" if format == "audio" else f"{slug}-ep{ep['number']}"
    path = storage.video_path(media_key)
    if not path.exists() and r2.enabled() and r2.exists(media_key):
        disposition = f'attachment; filename="{label}{ext}"'
        return RedirectResponse(r2.presign_get(media_key, 600, disposition=disposition), status_code=302)
    return FileResponse(
        path,
        media_type=storage.content_type_for(media_key) if format == "video" else "audio/mp4",
        filename=f"{label}{ext}",
    )


@router.get("/videos/{episode_id}/subtitles/{lang}/download")
async def download_subtitles(episode_id: str, lang: str = "en", user: UserPublic = Depends(get_vip_user)):
    """Subtitle download (EN or translated HI) — VIP tracks stay VIP-gated."""
    if not user.get("features", {}).get("downloads", True):
        raise HTTPException(status_code=403, detail="Downloads are turned off for your account")
    ep = store.get_episode(episode_id)
    if not ep:
        raise HTTPException(status_code=404, detail="Episode not found")
    title = store.get_title(ep.get("title_id", ""))
    analytics.record_event(
        "download_subtitle",
        title_id=ep.get("title_id", ""),
        episode_id=episode_id,
        supplier_email=(title or {}).get("supplier_email", ""),
        user_id=user.get("id", ""),
        country=user.get("country", ""),
    )
    name = (ep.get("subtitle_variants") or {}).get(lang) if lang != "en" else ep.get("subtitle_key")
    if not name:
        raise HTTPException(status_code=404, detail="No subtitle track for that language")
    path = storage.sub_path(name)
    if path.exists():
        return FileResponse(path, media_type="text/vtt", filename=f"episode-{episode_id[:8]}-{lang}.vtt")
    if r2.enabled():
        try:
            body = r2.client().get_object(Bucket=r2.bucket(), Key=f"subs/{name}")["Body"].read()
            return Response(
                content=body,
                media_type="text/vtt",
                headers={"Content-Disposition": f'attachment; filename="episode-{episode_id[:8]}-{lang}.vtt"'},
            )
        except Exception:
            pass
    raise HTTPException(status_code=404, detail="Subtitle file missing")


FREE_DOWNLOADS_LIFETIME = 4  # owner rule: 4 direct downloads per video, per user, for life


@router.get("/videos/{episode_id}/direct-download")
async def direct_download(episode_id: str, user: UserPublic = Depends(get_admin_user)):
    """Admin-only: DIRECT download of the original file."""
    from datetime import datetime, timezone

    ep = store.get_episode(episode_id)
    if not ep or not ep.get("video_key"):
        raise HTTPException(status_code=404, detail="This episode has no downloadable file")
    base = Path(ep["video_key"]).name

    vip = False
    if user.get("vip_until"):
        try:
            vip = datetime.fromisoformat(str(user["vip_until"])) > datetime.now(timezone.utc)
        except ValueError:
            vip = False

    remaining = None
    if not vip:
        rec_id = f"{user['id']}:{base}"
        rec = store.get_item("video_downloads", rec_id)
        count = int((rec or {}).get("count", 0))
        if count >= FREE_DOWNLOADS_LIFETIME:
            raise HTTPException(
                status_code=429,
                detail="You've used all 4 lifetime downloads for this video — VIP downloads unlimited",
            )
        store.put_item(
            "video_downloads",
            {
                "id": rec_id,
                "user_id": user["id"],
                "video_key": base,
                "count": count + 1,
                "last_at": datetime.now(timezone.utc).isoformat(),
            },
        )
        remaining = FREE_DOWNLOADS_LIFETIME - (count + 1)

    if not r2.enabled():
        raise HTTPException(status_code=503, detail="Downloads aren't available right now — try again shortly")
    try:
        url = r2.presign_get(base, 600, disposition=f'attachment; filename="animeunleashed-{base}"')
    except Exception:
        raise HTTPException(status_code=503, detail="Download link failed — try again shortly")
    return {"url": url, "remaining": remaining, "vip": vip}


@router.delete("/videos/library/{key:path}", status_code=204)
async def delete_library_video(key: str, _: UserPublic = Depends(get_admin_user)):
    """Admin: remove a library video — the stored object + its registry row."""
    ep = store.get_episode_by_video(key)
    if ep:
        store.update_episode(ep["id"], {"video_key": None})
    if store.get_item("videos", key):
        store.delete_item("videos", key)
    from lib import convert

    convert.delete_variant_objects(key)  # every -720p/-480p/audio/subtitle file too
    storage.delete_video(key)
