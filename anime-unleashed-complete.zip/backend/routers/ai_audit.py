"""AI Auditor — controlled, read-only inspection access for AI coding agents.

The owner's rule, implemented:
  - the Studio mints ONE active AI audit link at a time (link + pass shown once),
  - an audit key reaches exactly ONE endpoint that returns the PUBLIC catalog
    (which videos exist, bios, episode counts) — never users, revenue, env,
    database names, API keys or anything sensitive,
  - revoking is permanent: the token hash is kept only so the deleted key
    can never match again.

Endpoints (all /api-prefixed by server.py):
  POST /ai-audit           admin — mint the single active audit key (returns it ONCE)
  GET  /ai-audit           admin — audit history (masked)
  DELETE /ai-audit/{id}    admin — revoke FOREVER
  GET  /audit/catalog      with X-Audit-Key header — the public catalog only
"""

import hashlib
import secrets
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Header, HTTPException

from lib import store
from lib.security import get_admin_user

router = APIRouter(tags=["ai-auditor"])


def _hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _active() -> dict | None:
    rows = [r for r in store.scan("ai_audits") if not r.get("revoked")]
    rows.sort(key=lambda r: r.get("created_at", ""), reverse=True)
    return rows[0] if rows else None


@router.post("/ai-audit", status_code=201)
async def create_audit(label: str = "AI review", _: dict = Depends(get_admin_user)):
    """Mint THE single AI-audit key. Blocked while one is already active."""
    if _active():
        raise HTTPException(status_code=409, detail="One AI audit link is already active — delete it first (deletion is forever)")
    token = "au_" + secrets.token_urlsafe(24)
    doc = {
        "id": secrets.token_hex(8),
        "token_hash": _hash(token),
        "label": (label or "AI review")[:60],
        "revoked": False,
        "created_at": _now(),
        "last_used": "",
    }
    store.put_item("ai_audits", doc)
    # the plaintext token leaves the server exactly once — only its hash is stored
    return {
        "id": doc["id"],
        "label": doc["label"],
        "token": token,
        "how_to_use": "The AI sends header X-Audit-Key: <token> to GET /api/audit/catalog",
        "warning": "Copy it now — it is never shown again. Deleting the audit kills it forever.",
    }


@router.get("/ai-audit")
async def list_audits(_: dict = Depends(get_admin_user)):
    rows = store.scan("ai_audits")
    rows.sort(key=lambda r: r.get("created_at", ""), reverse=True)
    return [
        {
            "id": r["id"],
            "label": r.get("label", ""),
            "active": not r.get("revoked"),
            "created_at": r.get("created_at", ""),
            "last_used": r.get("last_used", ""),
        }
        for r in rows
    ]


@router.delete("/ai-audit/{audit_id}", status_code=204)
async def revoke_audit(audit_id: str, _: dict = Depends(get_admin_user)):
    """Permanent: the link + password die forever (the hash only rejects)."""
    doc = store.get_item("ai_audits", audit_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Audit not found")
    store.update_item("ai_audits", audit_id, set_updates={"revoked": True, "revoked_at": _now()})
    return None


def require_audit_key(x_audit_key: str = Header(default="")) -> dict:
    """Dependency for audit-reachable endpoints — the ONLY door an audit key opens."""
    if not x_audit_key:
        raise HTTPException(status_code=401, detail="AI audit key required (X-Audit-Key header)")
    matches = [r for r in store.scan("ai_audits") if r.get("token_hash") == _hash(x_audit_key)]
    doc = matches[0] if matches else None
    if not doc or doc.get("revoked"):
        raise HTTPException(status_code=403, detail="This audit link was deleted forever — ask the owner for a new one")
    store.update_item("ai_audits", doc["id"], set_updates={"last_used": _now()})
    return doc


@router.get("/audit/catalog")
async def audit_catalog(_: dict = Depends(require_audit_key)):
    """The ONLY surface an audit key can reach: the published catalog —
    no users, no revenue, no env, no secrets. Exactly what an AI needs to
    suggest upgrades without seeing anything sensitive."""
    titles = [t for t in store.scan("titles") if t.get("status") == "published"]
    out = []
    for t in titles:
        eps = store.get_episodes_by_title(t["id"], published_only=True)
        out.append(
            {
                "name": t.get("name", ""),
                "slug": t.get("slug", ""),
                "kind": t.get("kind", ""),
                "bio": (t.get("description") or t.get("bio") or "")[:500],
                "rating": t.get("rating"),
                "release_year": t.get("release_year"),
                "episode_count": len(eps),
                "episodes": [
                    {
                        "number": e.get("number"),
                        "name": e.get("name", e.get("title", "")),
                        "duration_seconds": e.get("duration_seconds"),
                    }
                    for e in eps
                ],
            }
        )
    return {
        "total_titles": len(out),
        "titles": out,
        "scope": "Public catalog only — secrets, users and internal data are never exposed to audits.",
    }
