"""One-click AniList import for the Studio Catalog.

GET /import/search?q= — queries the PUBLIC AniList GraphQL API (no key, no account).
If the pod has no internet (or AniList is down) it degrades to a small offline
catalogue so the flow never dead-ends ("api keep fake" fallback).

POST /import/title — admin takes a search result and creates a DRAFT title
(episodes still get uploaded by hand; no video is imported).
"""

import re
from datetime import datetime, timezone

import httpx
from fastapi import APIRouter, Depends, HTTPException, Query

from models.catalog import TitleOut
from models.imports import AniListResult
from lib import store
from lib.security import get_admin_user

router = APIRouter(prefix="/import", tags=["import"])

ANILIST_URL = "https://graphql.anilist.co"
QUERY = """
query ($search: String, $perPage: Int) {
  Page(page: 1, perPage: $perPage) {
    media(search: $search, type: ANIME, sort: SEARCH_MATCH) {
      id
      title { romaji english }
      description(asHtml: false)
      genres
      seasonYear
      format
      episodes
      averageScore
      studios(isMain: true) { nodes { name } }
      status
      coverImage { large }
    }
  }
}
"""

# Offline fallback ("fake API") — used only when the public API is unreachable.
OFFLINE_RESULTS = [
    {"id": 101922, "title": {"romaji": "Demon Slayer: Kimetsu no Yaiba", "english": "Demon Slayer: Kimetsu no Yaiba"}, "description": "A youth becomes a demon slayer to save his sister.", "genres": ["Action", "Fantasy"], "seasonYear": 2019, "format": "TV", "episodes": 26, "averageScore": 84, "coverImage": {"large": ""}},
    {"id": 113415, "title": {"romaji": "Jujutsu Kaisen", "english": "Jujutsu Kaisen"}, "description": "A student swallows a cursed finger and joins a school for sorcerers.", "genres": ["Action", "Supernatural"], "seasonYear": 2020, "format": "TV", "episodes": 24, "averageScore": 86, "coverImage": {"large": ""}},
    {"id": 21, "title": {"romaji": "One Piece", "english": "One Piece"}, "description": "Pirates hunt the world's greatest treasure.", "genres": ["Adventure", "Fantasy"], "seasonYear": 1999, "format": "TV", "episodes": 1100, "averageScore": 88, "coverImage": {"large": ""}},
    {"id": 16498, "title": {"romaji": "Attack on Titan", "english": "Attack on Titan"}, "description": "Humanity fights man-eating giants behind huge walls.", "genres": ["Action", "Drama"], "seasonYear": 2013, "format": "TV", "episodes": 25, "averageScore": 85, "coverImage": {"large": ""}},
    {"id": 20, "title": {"romaji": "Naruto", "english": "Naruto"}, "description": "A loud ninja dreams of leading his village.", "genres": ["Action", "Adventure"], "seasonYear": 2002, "format": "TV", "episodes": 220, "averageScore": 80, "coverImage": {"large": ""}},
    {"id": 11061, "title": {"romaji": "Hunter x Hunter", "english": "Hunter x Hunter"}, "description": "A boy takes the hunter exam to find his father.", "genres": ["Adventure", "Fantasy"], "seasonYear": 2011, "format": "TV", "episodes": 148, "averageScore": 89, "coverImage": {"large": ""}},
]


def _slugify(name: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")
    return slug[:80] or "title"


def _map_media(m: dict, source: str) -> AniListResult:
    desc = re.sub(r"<[^>]+>", "", m.get("description") or "").strip()
    fmt = (m.get("format") or "TV").upper()
    score = m.get("averageScore") or 0
    return AniListResult(
        anilist_id=m["id"],
        name=(m["title"].get("english") or m["title"].get("romaji") or "Untitled").strip(),
        name_english=m["title"].get("english"),
        synopsis=desc[:1200],
        genres=(m.get("genres") or [])[:5],
        release_year=m.get("seasonYear"),
        type="movie" if fmt in ("MOVIE", "SPECIAL") else "series",
        episodes_count=m.get("episodes") or 0,
        rating=round(score / 10, 1),
        poster_url=(m.get("coverImage") or {}).get("large") or "",
        studio=((m.get("studios") or {}).get("nodes") or [{}])[0].get("name", "") if m.get("studios") else "",
        airing_status={"RELEASING": "ongoing", "FINISHED": "completed", "NOT_YET_RELEASED": "upcoming"}.get(m.get("status") or "", ""),
        source=source,
    )


def _search_offline(q: str) -> list[AniListResult]:
    needle = q.strip().lower()
    hits = [m for m in OFFLINE_RESULTS if needle in (m["title"]["english"] or "").lower() + m["title"]["romaji"].lower()]
    return [_map_media(m, "offline") for m in (hits or OFFLINE_RESULTS)]


@router.get("/search", response_model=list[AniListResult])
async def import_search(q: str = Query(min_length=2, max_length=80)):
    try:
        async with httpx.AsyncClient(timeout=8) as client:
            resp = await client.post(
                ANILIST_URL,
                json={"query": QUERY, "variables": {"search": q.strip(), "perPage": 8}},
                headers={"Content-Type": "application/json"},
            )
            resp.raise_for_status()
            media = resp.json()["data"]["Page"]["media"]
            return [_map_media(m, "anilist") for m in media]
    except Exception:
        # No internet / AniList down — serve the offline fake catalogue.
        return _search_offline(q)


@router.post("/title", response_model=TitleOut, status_code=201)
async def import_title(result: AniListResult, user: dict = Depends(get_admin_user)):
    """Create a DRAFT title from an imported result (studio fills episodes later)."""
    base = _slugify(result.name)
    candidate, n = base, 2
    while store.get_title_by_slug(candidate):
        candidate = f"{base}-{n}"
        n += 1
    import uuid as _uuid

    doc = {
        "id": str(_uuid.uuid4()),
        "slug": candidate,
        "name": result.name.strip(),
        "synopsis": result.synopsis,
        "genres": result.genres,
        "release_year": result.release_year or 0,
        "type": result.type if result.type in ("series", "movie") else "series",
        "kind": "anime",
        "audio": ["Eng Sub"],
        "rating": result.rating,
        "featured": False,
        "poster_url": result.poster_url,
        "studio": result.studio,
        "airing_status": result.airing_status,
        "status": "draft",
        "episode_count": 0,
        "views": 0,
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    return store.put_title(doc)
