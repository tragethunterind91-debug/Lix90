"""Direct image uploads (posters, episode thumbnails) — the R2 stand-in path:
files go to the backend's media disk, served back through /media/images/{name}."""

import re

from fastapi import APIRouter, Depends, HTTPException, UploadFile
from fastapi.responses import FileResponse, RedirectResponse

from models.uploads import ImageUploadOut
from lib import r2, storage
from lib.security import get_admin_user, get_worker_user

router = APIRouter(tags=["uploads"])

_SAFE_NAME = re.compile(r"^[0-9a-f]{32}\.(jpg|jpeg|png|webp|avif)$")


@router.post("/uploads/image", response_model=ImageUploadOut, status_code=201)
async def upload_image(file: UploadFile, user: dict = Depends(get_worker_user)):
    data = await file.read()
    if not data:
        raise HTTPException(status_code=422, detail="Empty file")
    try:
        name = storage.new_image_name(file.filename or "")
        storage.save_image(name, data)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
    return ImageUploadOut(url=f"/api/media/images/{name}")


@router.get("/media/images/{name}")
async def serve_image(name: str):
    if not _SAFE_NAME.match(name):
        raise HTTPException(status_code=404, detail="Not found")
    path = storage.image_path(name)
    if path.exists():
        return FileResponse(path, media_type=storage.image_content_type(name))
    # legacy files live on disk; R2-era files redirect to a 1h presigned URL
    if r2.enabled() and r2.exists(f"images/{name}"):
        return RedirectResponse(r2.presign_get(f"images/{name}", 3600), status_code=302,
                                headers={"Cache-Control": "public, max-age=600"})
    raise HTTPException(status_code=404, detail="Not found")
