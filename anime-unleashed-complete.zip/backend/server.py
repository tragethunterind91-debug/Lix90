import asyncio
import os
import uuid
import logging
from contextlib import asynccontextmanager
from datetime import datetime
from pathlib import Path
from typing import List

from dotenv import load_dotenv
from fastapi import FastAPI, APIRouter, Depends
from pydantic import BaseModel, Field
from starlette.middleware.cors import CORSMiddleware
from lib.security import get_admin_user


ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection (template legacy; app data now lives in DynamoDB — lib/store)
from lib import store


# Startup runs before the yield, shutdown after it.
@asynccontextmanager
async def lifespan(app: FastAPI):
    await asyncio.to_thread(store.ensure_tables)  # creates/waits for the animehub-* tables (fast after first run)
    yield


# Create the main app without a prefix
app = FastAPI(lifespan=lifespan)

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Define Models
class StatusCheck(BaseModel):
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    client_name: str
    timestamp: datetime = Field(default_factory=datetime.utcnow)

class StatusCheckCreate(BaseModel):
    client_name: str

# Add your routes to the router instead of directly to app
@api_router.get("/")
async def root():
    return {"message": "Hello World"}

@api_router.post("/status", response_model=StatusCheck)
async def create_status_check(input: StatusCheckCreate):
    status_dict = input.model_dump()
    status_obj = StatusCheck(**status_dict)
    item = status_obj.model_dump()
    item["timestamp"] = item["timestamp"].isoformat() if hasattr(item["timestamp"], "isoformat") else item["timestamp"]
    store.put_status(item)
    return status_obj

@api_router.post("/admin/reset-content-data")
async def admin_reset_content_data(admin: dict = Depends(get_admin_user)):
    """ADMIN ONLY: Delete all playlist titles, episodes, videos, nfts, information, trailers & social embeds
    so the owner can manually upload and curate content directly on the web."""
    # 1. Purge titles
    try:
        titles = store.scan("titles")
        for t in titles:
            store.delete_title(t["id"])
    except Exception as e:
        logger.warning(f"Error purging titles: {e}")

    # 2. Purge episodes
    try:
        episodes = store.scan("episodes")
        for ep in episodes:
            store.delete_item("episodes", ep["id"])
    except Exception as e:
        logger.warning(f"Error purging episodes: {e}")

    # 3. Purge videos
    try:
        videos = store.scan("videos")
        for v in videos:
            store.delete_item("videos", v["id"])
    except Exception as e:
        logger.warning(f"Error purging videos: {e}")

    # 4. Purge NFTs and Auctions
    try:
        for n in store.scan("nfts"):
            store.delete_item("nfts", n["id"])
        for o in store.scan("nft_owned"):
            store.delete_item("nft_owned", o["id"])
        for a in store.scan("auctions"):
            store.delete_item("auctions", a["id"])
    except Exception as e:
        logger.warning(f"Error purging NFTs: {e}")

    # 5. Purge Movie Info
    try:
        for info in store.scan("movie_info"):
            store.delete_item("movie_info", info["id"])
    except Exception as e:
        logger.warning(f"Error purging movie_info: {e}")

    # 6. Purge Social Embeds / Trailers
    try:
        for emb in store.scan("social_embeds"):
            store.delete_item("social_embeds", emb["id"])
    except Exception as e:
        logger.warning(f"Error purging social_embeds: {e}")

    return {
        "ok": True,
        "message": "All demo playlists, titles, episodes, videos, NFTs, info stats, and trailers cleared. Catalog is ready for fresh manual curation.",
    }


# --- AnimeHub feature routers (each exposes an APIRouter under /api) ---
from routers.auth import router as auth_router
from routers.titles import router as titles_router
from routers.episodes import router as episodes_router
from routers.videos import router as videos_router
from routers.watchlist import router as watchlist_router
from routers.social import router as social_router
from routers.admin import router as admin_router
from routers.payments import router as payments_router
from routers.imports import router as imports_router
from routers.uploads import router as uploads_router
from routers.quota import router as quota_router
from routers.supplier import router as supplier_router
from routers.engagement import router as engagement_router
from routers.ai_audit import router as ai_audit_router
from routers.chat import router as chat_router
from routers.tasks import router as tasks_router
from routers.analytics import router as analytics_router
from routers.live import router as live_router
from routers.info import router as info_router
from routers.social_embeds import router as social_embeds_router
from routers.nft import router as nft_router

api_router.include_router(auth_router)
api_router.include_router(titles_router)
api_router.include_router(episodes_router)
api_router.include_router(videos_router)
api_router.include_router(watchlist_router)
api_router.include_router(social_router)
api_router.include_router(admin_router)
api_router.include_router(payments_router)
api_router.include_router(imports_router)
api_router.include_router(uploads_router)
api_router.include_router(quota_router)
api_router.include_router(supplier_router)
api_router.include_router(engagement_router)
api_router.include_router(ai_audit_router)
api_router.include_router(chat_router)
api_router.include_router(tasks_router)
api_router.include_router(analytics_router)
api_router.include_router(live_router)
api_router.include_router(info_router)
api_router.include_router(social_embeds_router)
api_router.include_router(nft_router)

# Include the router in the main app — keep this the LAST registration
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

from lib.waf import WafMiddleware

# L3/L4/L5 — request firewall FIRST (inner-most, sees the raw request first)
app.add_middleware(WafMiddleware)


# ---- security headers on every response (API + media) ----
@app.middleware("http")
async def security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "strict-origin-when-cross-origin"
    response.headers["Permissions-Policy"] = "camera=(), microphone=(), geolocation=()"
    response.headers["Cross-Origin-Resource-Policy"] = "cross-origin"
    return response


@app.get("/api/health", tags=["ops"])
async def health():
    """Minimal unauthenticated probe for uptime monitors. `ffmpeg` shows whether
    video conversion capability is live — False means variants can't be built."""
    from lib import convert

    return {"ok": True, "ffmpeg": convert.ffmpeg_available()}


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)
