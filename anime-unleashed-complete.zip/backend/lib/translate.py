"""Subtitle translation (English ⇄ Hindi) via the Emergent LLM universal key.

Timings are NEVER touched — only the human-readable cue text is translated, so the
WebVTT stays perfectly synced. Results are cached per (episode, language) by the caller.
"""

import os

from dotenv import load_dotenv

load_dotenv()  # backend/.env — EMERGENT_LLM_KEY

_SYSTEM = (
    "You are a professional subtitle translator for a streaming service. "
    "You translate WebVTT subtitle files between English and Hindi. "
    "You output ONLY the translated WebVTT — no commentary, no code fences."
)

_PROMPT = (
    "Translate the dialogue text inside each cue of this WebVTT file into {lang}. "
    "RULES:\n"
    "1. Keep the 'WEBVTT' header, every timestamp line (e.g. 00:00:01.000 --> 00:00:04.000) "
    "and cue ordering EXACTLY as-is — never modify or renumber timings.\n"
    "2. Translate ONLY the dialogue text lines.\n"
    "3. Keep names/natural-sounding, keep lines short enough to read as subtitles.\n"
    "4. Output ONLY the complete translated WebVTT file, nothing else.\n\n"
    "WEBVTT FILE:\n{vtt}"
)


async def translate_vtt(vtt_text: str, target: str) -> str:
    """target: 'hi' (→ Hindi) or 'en' (→ English). Returns the translated VTT text."""
    from emergentintegrations.llm.chat import LlmChat, UserMessage

    lang = {"hi": "Hindi (Devanagari script)", "en": "English"}.get(target)
    if not lang:
        raise ValueError(f"Unsupported target language: {target}")

    chat = (
        LlmChat(
            api_key=os.environ["EMERGENT_LLM_KEY"],
            session_id=f"subtitle-{target}",
            system_message=_SYSTEM,
        )
        .with_model("openai", "gpt-5.4")
    )
    response = await chat.send_message(UserMessage(text=_PROMPT.format(lang=lang, vtt=vtt_text)))
    out = str(response).strip()
    if out.startswith("```"):  # strip a fenced code block if the model added one
        fence = out.split("```")
        out = max(fence, key=len).strip()
        if not out.upper().startswith("WEBVTT"):
            out = "WEBVTT\n\n" + out
    if not out.upper().startswith("WEBVTT"):
        raise ValueError("Translation did not return a WebVTT file")
    return out
