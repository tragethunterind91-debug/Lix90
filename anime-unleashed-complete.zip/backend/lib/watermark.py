"""Per-user download watermarks — the anti-piracy deterrent the owner asked for.

Every VIDEO download is burned with the downloader's identity:
    animeunleashed.in | ID <account> | <email>
Two semi-transparent corner stamps (ffmpeg drawtext). Anyone who re-uploads a
downloaded episode somewhere else carries the exact account that downloaded it —
ban + proof in one step.

The watermarked copy is cached in R2 per (user, video-variant): ONE transcode,
then instant downloads forever. Burned in a daemon thread — the API never blocks.
Audio/subtitle downloads are not theft vectors and stay unwatermarked.
"""

import os
import subprocess
import tempfile
import threading
from datetime import datetime, timezone

from lib import r2, store

WM_PREFIX = "wm/"
_FONT_CANDIDATES = (
    "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Bold.ttf",
    "/usr/share/fonts/truetype/liberation/LiberationSans-Regular.ttf",
    "/usr/share/fonts/TTF/DejaVuSans.ttf",
)
FFMPEG_TIMEOUT = 3600  # 1 h ceiling for very long episodes


def _font() -> str:
    """Any usable TTF — distros differ (DejaVu on Ubuntu, Liberation here)."""
    for cand in _FONT_CANDIDATES:
        if os.path.exists(cand):
            return cand
    import glob

    hits = sorted(glob.glob("/usr/share/fonts/**/*.ttf", recursive=True))
    if hits:
        return hits[0]
    raise RuntimeError("no ttf font found for the watermark burn (install fonts-dejavu-core)")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def downloader_label(user: dict) -> str:
    acct = user.get("account_id") or (user.get("id", "")[:8] or "guest")
    return f"animeunleashed.in | ID {acct} | {user.get('email', '')}"


def request_watermark(video_key: str, user: dict, label: str | None = None) -> tuple[str, bool]:
    """Idempotent: returns (watermarked_r2_key, ready). Starts the burn thread the
    first time this user requests this video; later calls get the cached copy."""
    uid = user["id"]
    wm_key = f"{WM_PREFIX}{uid}/{video_key}"
    sid = f"{uid}:{video_key}"
    row = store.get_item("watermarks", sid)
    if row and row.get("status") == "ready" and r2.exists(wm_key):
        return wm_key, True
    if not row or row.get("status") == "failed":
        store.put_item("watermarks", {"id": sid, "status": "processing", "updated_at": _now()})
        threading.Thread(target=_burn, args=(video_key, uid, label or downloader_label(user)), daemon=True).start()
    return wm_key, False


def _escape_drawtext(text: str) -> str:
    # ffmpeg drawtext: colon is the option separator, quote/backslash need escapes
    return text.replace("\\", "").replace(":", r"\:").replace("'", r"\'")


def _burn(video_key: str, uid: str, label: str) -> None:
    sid = f"{uid}:{video_key}"
    wm_key = f"{WM_PREFIX}{uid}/{video_key}"
    try:
        font = _font()
        with tempfile.TemporaryDirectory() as td:
            src = os.path.join(td, "src.mp4")
            out = os.path.join(td, "out.mp4")
            r2.client().download_file(r2.bucket(), video_key, src)
            esc = _escape_drawtext(label)
            vf = (
                f"drawtext=fontfile={font}:text='{esc}':fontsize=26:fontcolor=white@0.42:"
                f"x=w-tw-28:y=h-th-28:box=1:boxcolor=black@0.3:boxborderw=8,"
                f"drawtext=fontfile={font}:text='animeunleashed.in':fontsize=20:fontcolor=white@0.32:"
                f"x=28:y=28:box=1:boxcolor=black@0.25:boxborderw=6"
            )
            subprocess.run(
                ["ffmpeg", "-y", "-i", src, "-vf", vf, "-c:v", "libx264", "-preset", "veryfast",
                 "-crf", "23", "-c:a", "copy", "-movflags", "+faststart", out],
                check=True, capture_output=True, timeout=FFMPEG_TIMEOUT,
            )
            r2.client().upload_file(out, r2.bucket(), wm_key, ExtraArgs={"ContentType": "video/mp4"})
        store.put_item("watermarks", {"id": sid, "status": "ready", "updated_at": _now()})
    except Exception as exc:
        store.put_item(
            "watermarks",
            {"id": sid, "status": "failed", "error": str(exc)[:300], "updated_at": _now()},
        )
