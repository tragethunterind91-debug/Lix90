"""DynamoDB-backed data store — replaces MongoDB per the owner's stack decision
("do not use mongo"). Table-per-collection under the `animehub-` prefix, pay-per-request,
with GSIs for every query pattern the routers use.

Credentials come from the environment (backend/.env): AWS_ACCESS_KEY_ID,
AWS_SECRET_ACCESS_KEY, AWS_REGION. boto3 reads them natively.

Note: calls are synchronous (single-digit-ms DynamoDB ops; fine at this scale).
Numbers are Decimal on the wire — `_numify`/`_clean` convert at the boundaries.
"""

import os
from decimal import Decimal
from pathlib import Path
from typing import Any

from botocore.exceptions import ClientError

from dotenv import load_dotenv

# Load the backend .env before boto3 reads credentials at import time.
load_dotenv(Path(__file__).parent.parent / ".env")

import boto3
from boto3.dynamodb.conditions import Attr, Key

REGION = os.environ.get("AWS_REGION", "ap-south-1")
PREFIX = "animehub-"

# collection -> list of GSIs: (name, partition_attr, sort_attr|None). Attribute types
# are inferred: numeric SKs (number/rating/release_year) become N, everything else S.
_NUM_ATTRS = {"number", "rating", "release_year"}
TABLES: dict[str, list[tuple]] = {
    "users": [("email", "email", None), ("firebase_uid", "firebase_uid", None), ("reg_ip", "registration_ip", None), ("phone_idx", "phone", None)],
    "ip_intel": [],
    "titles": [
        ("slug", "slug", None),
        ("status_created", "status", "created_at"),
        ("status_rating", "status", "rating"),
        ("status_year", "status", "release_year"),
        ("status_name", "status", "name_lower"),
    ],
    "episodes": [("title_number", "title_id", "number"), ("video_key", "video_key", None)],
    "watchlist": [
        ("user_title", "user_id", "title_id"),
        ("user_created", "user_id", "created_at"),
        ("title_watch", "title_id", None),
    ],
    "history": [
        ("user_episode", "user_id", "episode_id"),
        ("user_updated", "user_id", "updated_at"),
        ("title_hist", "title_id", None),
    ],
    "playlists": [("owner_created", "owner_id", "created_at")],
    "audit": [("recent", "gsipk", "created_at")],
    "revenue": [("created", "gsipk", "created_at")],
    "feedback": [("created", "gsipk", "created_at")],
    "supplier_apps": [
        ("status_created", "status", "created_at"),
        ("user_created", "user_id", "created_at"),
    ],
    "supplier_submissions": [
        ("status_created", "status", "created_at"),
        ("user_created", "user_id", "created_at"),
    ],
    "payments": [("user_created", "user_id", "created_at")],
    "ai_audits": [],
    "video_downloads": [("by_user", "user_id", None)],
    "follows": [("by_user", "user_id", None)],
    "reactions": [("by_episode", "episode_id", None)],
    "comments": [("by_episode", "episode_id", "created_at")],
    "friends": [
        ("from_user", "from_id", "created_at"),
        ("to_user", "to_id", "status"),
    ],
    "messages": [
        ("dm_pair", "pair_key", "created_at"),
        ("global_region", "region", "created_at"),
    ],
    "tasks": [("all", "gsipk", "created_at")],
    "task_claims": [("user_task", "user_id", "task_id")],
    "videos": [],  # upload-once registry: workers upload, admins attach without re-uploading
    "otps": [],  # email OTP codes for register / password reset (hashed, single-use)
    "analytics_events": [
        ("supplier_created", "supplier_email", "created_at"),
        ("user_created", "user_id", "created_at"),
    ],
    "link_rewards": [("user_task", "user_id", None)],
    "watermarks": [],  # per-user burned-download cache: {user}:{video} -> ready/processing/failed
    "notices": [("all", "gsipk", "created_at")],
    "config": [],
    "visits": [],
    "status": [],
    "recovery_requests": [],
    "live_streams": [],
    "live_chat": [("by_stream", "stream_id", "created_at")],
    "live_schedule": [],
}

_client = boto3.client("dynamodb", region_name=REGION)
_resource = boto3.resource("dynamodb", region_name=REGION)
_tables: dict[str, Any] = {}


def _attr_type(name: str) -> str:
    return "N" if name in _NUM_ATTRS else "S"


def ensure_tables() -> None:
    """Create any missing tables + GSIs. Idempotent; waits until each is ACTIVE."""
    existing = set(_client.list_tables().get("TableNames", []))
    for name, indexes in TABLES.items():
        full = PREFIX + name
        if full not in existing:
            attr_defs = {"id": "S"}
            gsi_list = []
            for idx_name, pk, sk in indexes:
                attr_defs[pk] = _attr_type(pk)
                key_schema = [{"AttributeName": pk, "KeyType": "HASH"}]
                if sk:
                    attr_defs[sk] = _attr_type(sk)
                    key_schema.append({"AttributeName": sk, "KeyType": "RANGE"})
                gsi_list.append({
                    "IndexName": idx_name,
                    "KeySchema": key_schema,
                    "Projection": {"ProjectionType": "ALL"},
                })
            params = {
                "TableName": full,
                "KeySchema": [{"AttributeName": "id", "KeyType": "HASH"}],
                "AttributeDefinitions": [
                    {"AttributeName": k, "AttributeType": v} for k, v in attr_defs.items()
                ],
                "BillingMode": "PAY_PER_REQUEST",
            }
            if gsi_list:
                params["GlobalSecondaryIndexes"] = gsi_list
            _client.create_table(**params)
        table = _resource.Table(full)
        table.wait_until_exists()
        _tables[name] = table
        # migrate: add GSIs that newer code expects but the table was created without
        missing = [i for i in indexes if not table.global_secondary_indexes or i[0] not in {g["IndexName"] for g in table.global_secondary_indexes}]
        for idx_name, pk, sk in missing:
            _add_gsi_in_background(full, idx_name, pk, sk)
    print(f"[store] {len(_tables)} DynamoDB tables ready in {REGION}")


def _add_gsi_in_background(full: str, idx_name: str, pk: str, sk: str | None) -> None:
    """Add one GSI; DynamoDB allows only one online-index build per table at a
    time, so on LimitExceeded retry in a daemon thread (never blocks boot)."""

    def _try_once() -> tuple[bool, bool]:  # (ok, retryable)
        try:
            table = _resource.Table(full)
            existing_attrs = {a["AttributeName"] for a in table.attribute_definitions}
            kwargs: dict = {
                "GlobalSecondaryIndexUpdates": [
                    {"Create": {"IndexName": idx_name, "KeySchema": (
                        [{"AttributeName": pk, "KeyType": "HASH"}]
                        + ([{"AttributeName": sk, "KeyType": "RANGE"}] if sk else [])
                    ), "Projection": {"ProjectionType": "ALL"}}}
                ]
            }
            new_attrs = {a for a in (pk, sk) if a and a not in existing_attrs and a != "id"}
            if new_attrs:
                kwargs["AttributeDefinitions"] = [{"AttributeName": a, "AttributeType": _attr_type(a)} for a in new_attrs]
            _client.update_table(TableName=full, **kwargs)
            print(f"[store] added GSI {idx_name} to {full}")
            return True, False
        except Exception as exc:
            if "LimitExceeded" in str(exc) or "limit exceeded" in str(exc).lower():
                return False, True
            print(f"[store] GSI {idx_name} on {full}: {exc}")
            return True, False

    ok, retryable = _try_once()
    if ok or not retryable:
        return

    import threading
    import time as _time

    def _retry() -> None:
        for _ in range(20):  # up to ~10 minutes of retries
            _time.sleep(30)
            done, again = _try_once()
            if done or not again:
                return

    threading.Thread(target=_retry, daemon=True).start()


def _table(name: str):
    if name not in _tables:
        _tables[name] = _resource.Table(PREFIX + name)
    return _tables[name]


def _numify(value: Any) -> Any:
    """floats/ints -> Decimal (DynamoDB requirement), recursively."""
    if isinstance(value, bool):
        return value
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, int):
        return Decimal(value)
    if isinstance(value, dict):
        return {k: _numify(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_numify(v) for v in value]
    return value


def _clean(value: Any) -> Any:
    """Decimal -> int/float, recursively (boto3 returns Decimal for numbers)."""
    if isinstance(value, Decimal):
        return int(value) if value == value.to_integral_value() else float(value)
    if isinstance(value, dict):
        return {k: _clean(v) for k, v in value.items()}
    if isinstance(value, list):
        return [_clean(v) for v in value]
    return value


def _strip_none(value: Any) -> Any:
    """Drop None values — DynamoDB rejects them. (A PATCH null becomes REMOVE.)
    Empty strings are kept: DynamoDB allows them on non-key attributes, and the
    response models fill them back in with defaults."""
    if isinstance(value, dict):
        out = {}
        for k, v in value.items():
            cleaned = _strip_none(v)
            if cleaned is not None:
                out[k] = cleaned
        return out
    if isinstance(value, list):
        return [x for x in (_strip_none(v) for v in value) if x is not None]
    return value


def get_item(table: str, item_id: str) -> dict | None:
    if not item_id:
        return None
    item = _table(table).get_item(Key={"id": item_id}).get("Item")
    return _clean(item) if item else None


def put_item(table: str, item: dict) -> dict:
    _table(table).put_item(Item=_numify(_strip_none(item)))
    return item


def delete_item(table: str, item_id: str) -> None:
    _table(table).delete_item(Key={"id": item_id})


def query(
    table: str,
    index: str,
    pk_attr: str,
    pk_val: str,
    sk_attr: str | None = None,
    sk_val: Any = None,
    forward: bool = True,
    filters: Any = None,
    limit: int | None = None,
) -> list[dict]:
    expr = Key(pk_attr).eq(_numify(pk_val))
    if sk_attr and sk_val is not None:
        expr = expr & Key(sk_attr).eq(_numify(sk_val))
    kwargs: dict[str, Any] = {
        "IndexName": index,
        "KeyConditionExpression": expr,
        "ScanIndexForward": forward,
    }
    if filters is not None:
        kwargs["FilterExpression"] = filters
    items: list[dict] = []
    while True:
        try:
            response = _table(table).query(**kwargs)
        except Exception as exc:
            if "does not have the specified index" in str(exc) or "backfilling" in str(exc):
                return []  # GSI building/backfilling (background migration) — fail soft
            raise
        items.extend(response.get("Items", []))
        last = response.get("LastEvaluatedKey")
        if not last or (limit and len(items) >= limit):
            break
        kwargs["ExclusiveStartKey"] = last
    cleaned = [_clean(i) for i in items]
    return cleaned[:limit] if limit else cleaned


def scan(table: str, filters: Any = None) -> list[dict]:
    kwargs: dict[str, Any] = {}
    if filters is not None:
        kwargs["FilterExpression"] = filters
    items: list[dict] = []
    while True:
        response = _table(table).scan(**kwargs)
        items.extend(response.get("Items", []))
        last = response.get("LastEvaluatedKey")
        if not last:
            break
        kwargs["ExclusiveStartKey"] = last
    return [_clean(i) for i in items]


def count(table: str, filters: Any = None) -> int:
    kwargs: dict[str, Any] = {"Select": "COUNT"}
    if filters is not None:
        kwargs["FilterExpression"] = filters
    total = 0
    while True:
        response = _table(table).scan(**kwargs)
        total += response.get("Count", 0)
        last = response.get("LastEvaluatedKey")
        if not last:
            return total
        kwargs["ExclusiveStartKey"] = last


def update_item(table: str, item_id: str, set_updates: dict | None = None, add_updates: dict | None = None) -> dict | None:
    """Partial update: SET fields (None/'' → REMOVE the attribute) and/or ADD numeric
    counters. Grammar note: SET/REMOVE/ADD each appear once, comma-separated within.
    The item must EXIST — ConditionExpression prevents ghost upserts (returns None)."""
    set_parts, remove_parts, add_parts = [], [], []
    values, names = {}, {}

    if set_updates:
        for i, (key, val) in enumerate(set_updates.items()):
            names[f"#s{i}"] = key
            if val is None or val == "":
                remove_parts.append(f"#s{i}")
            else:
                set_parts.append(f"#s{i} = :s{i}")
                values[f":s{i}"] = _numify(val)
    if add_updates:
        for i, (key, delta) in enumerate(add_updates.items()):
            names[f"#a{i}"] = key
            values[f":a{i}"] = _numify(delta)
            add_parts.append(f"#a{i} :a{i}")

    clauses = []
    if set_parts:
        clauses.append("SET " + ", ".join(set_parts))
    if remove_parts:
        clauses.append("REMOVE " + ", ".join(remove_parts))
    if add_parts:
        clauses.append("ADD " + ", ".join(add_parts))
    if not clauses:
        return get_item(table, item_id)
    update_kwargs: dict = {
        "Key": {"id": item_id},
        "UpdateExpression": " ".join(clauses),
        "ExpressionAttributeNames": names,
        "ReturnValues": "ALL_NEW",
        "ConditionExpression": "attribute_exists(id)",  # never ghost-upsert
    }
    if values:  # REMOVE-only updates must not send an empty values map
        update_kwargs["ExpressionAttributeValues"] = values
    try:
        updated = _table(table).update_item(**update_kwargs).get("Attributes")
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            return None
        raise
    return _clean(updated) if updated else None


def delete_where(table: str, index: str, pk_attr: str, pk_val: str, sk_attr: str | None = None, sk_val: Any = None) -> int:
    """Delete every item matching a GSI query (used by cascades + clear-all)."""
    items = query(table, index, pk_attr, pk_val, sk_attr, sk_val)
    for item in items:
        delete_item(table, item["id"])
    return len(items)


# --------------------------------------------------------------------- users
def get_user(user_id: str) -> dict | None:
    return get_item("users", user_id)


def get_user_by_email(email: str) -> dict | None:
    rows = query("users", "email", "email", email.lower())
    return rows[0] if rows else None


def get_user_by_firebase_or_email(uid: str, email: str) -> dict | None:
    rows = query("users", "firebase_uid", "firebase_uid", uid)
    if rows:
        return rows[0]
    return get_user_by_email(email)


def put_user(doc: dict) -> dict:
    return put_item("users", doc)


def update_user(user_id: str, updates: dict) -> dict | None:
    return update_item("users", user_id, set_updates=updates)


def count_users() -> int:
    return count("users")


# -------------------------------------------------------------------- titles
def put_title(doc: dict) -> dict:
    doc.setdefault("rating", 0.0)
    doc.setdefault("views", 0)
    doc["name_lower"] = doc["name"].lower()
    return put_item("titles", doc)


def _norm_title(doc: dict) -> dict:
    """Normalize legacy rows: published titles without a visibility default to 'listed'."""
    if doc.get("status") == "published" and not doc.get("visibility"):
        doc["visibility"] = "listed"
    return doc


def get_title(title_id: str) -> dict | None:
    row = get_item("titles", title_id)
    return _norm_title(row) if row else None


def get_title_by_slug(slug: str) -> dict | None:
    rows = query("titles", "slug", "slug", slug)
    return _norm_title(rows[0]) if rows else None


def update_title(title_id: str, updates: dict) -> dict | None:
    if "name" in updates:
        updates = {**updates, "name_lower": updates["name"].lower()}
    return update_item("titles", title_id, set_updates=updates)


def delete_title(title_id: str) -> None:
    delete_item("titles", title_id)


def inc_title(title_id: str, counters: dict) -> None:
    update_item("titles", title_id, add_updates=counters)


_SORT_GSI = {
    "latest": ("status_created", "created_at", False),
    "rating": ("status_rating", "rating", False),
    "year": ("status_year", "release_year", False),
    "az": ("status_name", "name_lower", True),
}


def list_titles(
    status: str | None = "published",
    q: str = "",
    genre: str = "",
    year: int | None = None,
    title_type: str | None = None,
    kind: str | None = None,
    sort: str = "latest",
    limit: int = 200,
    visibility: str | None = None,
) -> list[dict]:
    """status=None -> all (admin view). visibility filters the two launch options:
    'listed' keeps only Home-listed titles (legacy rows count as listed);
    'upcoming' keeps only countdown titles. Filters compose as FilterExpressions."""
    filters = None
    if visibility == "listed":
        f = Attr("visibility").ne("upcoming") | Attr("visibility").not_exists()
        filters = f if filters is None else filters & f
    elif visibility == "upcoming":
        f = Attr("visibility").eq("upcoming")
        filters = f if filters is None else filters & f
    if q:
        f = Attr("name_lower").contains(q.lower())
        filters = f if filters is None else filters & f
    if genre:
        f = Attr("genres").contains(genre)
        filters = f if filters is None else filters & f
    if year is not None:
        f = Attr("release_year").eq(year)
        filters = f if filters is None else filters & f
    if title_type:
        f = Attr("type").eq(title_type)
        filters = f if filters is None else filters & f
    if kind:
        f = Attr("kind").eq(kind)
        filters = f if filters is None else filters & f

    if status:
        gsi, sk, forward = _SORT_GSI.get(sort, _SORT_GSI["latest"])
        rows = query("titles", gsi, "status", status, sk, None if sk in ("created_at", "name_lower") else None, forward, filters, limit)
        return [_norm_title(t) for t in rows]

    items = scan("titles", filters)
    keymap = {
        "latest": lambda t: t.get("created_at", ""),
        "rating": lambda t: t.get("rating", 0),
        "year": lambda t: t.get("release_year", 0),
        "az": lambda t: t.get("name_lower", ""),
    }
    items.sort(key=keymap.get(sort, keymap["latest"]), reverse=sort != "az")
    return [_norm_title(t) for t in items[:limit]]


def sum_views() -> int:
    return sum(t.get("views", 0) for t in scan("titles"))


def all_genres(status: str = "published") -> list[str]:
    genres: set[str] = set()
    for t in scan("titles", Attr("status").eq(status)):
        genres.update(t.get("genres", []))
    return sorted(genres)


# ------------------------------------------------------------------ episodes
def put_episode(doc: dict) -> dict:
    # video_key is a GSI partition key — empty strings are invalid there; omit until uploaded.
    if not doc.get("video_key"):
        doc = {k: v for k, v in doc.items() if k != "video_key"}
    return put_item("episodes", doc)


def get_episode(episode_id: str) -> dict | None:
    return get_item("episodes", episode_id)


def get_episode_by_video(video_key: str) -> dict | None:
    rows = query("episodes", "video_key", "video_key", video_key)
    return rows[0] if rows else None


def get_episode_by_title_number(title_id: str, number: int, season: int | None = None) -> dict | None:
    """Episode numbers are unique WITHIN a season (S1E1 and S2E1 may coexist)."""
    rows = query("episodes", "title_number", "title_id", title_id, "number", number)
    if season is not None:
        rows = [r for r in rows if r.get("season", 1) == season]
    return rows[0] if rows else None


def get_episodes_by_title(title_id: str, published_only: bool = True) -> list[dict]:
    filters = Attr("status").eq("published") if published_only else None
    rows = query("episodes", "title_number", "title_id", title_id, "number", None, True, filters)
    rows.sort(key=lambda r: (r.get("season", 1), r.get("number", 0)))
    return rows


def update_episode(episode_id: str, updates: dict) -> dict | None:
    return update_item("episodes", episode_id, set_updates=updates)


def delete_episode(episode_id: str) -> None:
    delete_item("episodes", episode_id)


# ----------------------------------------------------------------- watchlist
def watchlist_item(user_id: str, title_id: str) -> dict | None:
    rows = query("watchlist", "user_title", "user_id", user_id, "title_id", title_id)
    return rows[0] if rows else None


def add_watchlist(user_id: str, title_id: str, item: dict) -> None:
    if not watchlist_item(user_id, title_id):
        put_item("watchlist", item)


def remove_watchlist(user_id: str, title_id: str) -> None:
    delete_where("watchlist", "user_title", "user_id", user_id, "title_id", title_id)


def list_watchlist(user_id: str) -> list[dict]:
    return query("watchlist", "user_created", "user_id", user_id, "created_at", None, False)


def remove_watchlist_for_title(title_id: str) -> None:
    delete_where("watchlist", "title_watch", "title_id", title_id)


# ------------------------------------------------------------------- history
def history_item(user_id: str, episode_id: str) -> dict | None:
    rows = query("history", "user_episode", "user_id", user_id, "episode_id", episode_id)
    return rows[0] if rows else None


def upsert_history(user_id: str, episode_id: str, fields: dict) -> None:
    import uuid

    existing = history_item(user_id, episode_id)
    if existing:
        update_item("history", existing["id"], set_updates=fields)
    else:
        # Mongo got episode_id for free from the upsert filter — DynamoDB needs it explicit
        # (it's also the GSI sort key; without it the item vanishes from the index and dedupe).
        put_item("history", {"id": str(uuid.uuid4()), "user_id": user_id, "episode_id": episode_id, **fields})


def list_history(user_id: str, limit: int = 50) -> list[dict]:
    return query("history", "user_updated", "user_id", user_id, "updated_at", None, False, None, limit)


def clear_history(user_id: str) -> None:
    delete_where("history", "user_episode", "user_id", user_id)


def remove_history_for_title(title_id: str) -> None:
    delete_where("history", "title_hist", "title_id", title_id)


# ----------------------------------------------------------------- playlists
def put_playlist(doc: dict) -> dict:
    return put_item("playlists", doc)


def get_playlist(playlist_id: str) -> dict | None:
    return get_item("playlists", playlist_id)


def list_playlists(owner_id: str) -> list[dict]:
    return query("playlists", "owner_created", "owner_id", owner_id, "created_at", None, False)


# --------------------------------------------------------------- platform config
def get_platform_config() -> dict:
    """Single 'platform' item: maintenance flag, editable VIP plan, etc."""
    return get_item("config", "platform") or {}


def save_platform_config(updates: dict) -> dict:
    existing = get_item("config", "platform")
    if existing:
        return update_item("config", "platform", set_updates=updates) or get_item("config", "platform")
    return put_item("config", {"id": "platform", **updates})


def list_notices(limit: int = 20) -> list[dict]:
    rows = query("notices", "all", "gsipk", "n", "created_at", None, False)
    return rows[:limit]


def update_playlist(playlist_id: str, updates: dict) -> dict | None:
    return update_item("playlists", playlist_id, set_updates=updates)


def delete_playlist(playlist_id: str) -> None:
    delete_item("playlists", playlist_id)


# -------------------------------------------------------------------- status
def put_status(item: dict) -> dict:
    return put_item("status", item)


def list_status(limit: int = 1000) -> list[dict]:
    return scan("status")[:limit]


# --------------------------------------------------------------------- users
def list_users() -> list[dict]:
    return scan("users")


def delete_user(user_id: str) -> None:
    delete_item("users", user_id)


def cascade_delete_user(user_id: str) -> None:
    """Remove an account and everything it owns."""
    delete_where("watchlist", "user_created", "user_id", user_id)
    delete_where("history", "user_episode", "user_id", user_id)
    for pl in list_playlists(user_id):
        delete_playlist(pl["id"])
    delete_user(user_id)


# --------------------------------------------------------------------- audit
def put_audit(entry: dict) -> dict:
    """Append-only admin action log (gsipk='a' is the GSI partition; sorted by created_at)."""
    entry.setdefault("gsipk", "a")
    return put_item("audit", entry)


def list_audit(limit: int = 100) -> list[dict]:
    return query("audit", "recent", "gsipk", "a", "created_at", None, False)[:limit]


# ------------------------------------------------------------------- revenue
def put_revenue(entry: dict) -> dict:
    entry.setdefault("gsipk", "r")  # constant GSI partition; sorted by created_at
    return put_item("revenue", entry)


def list_revenue() -> list[dict]:
    return query("revenue", "created", "gsipk", "r", "created_at", None, False)


def delete_revenue(entry_id: str) -> None:
    delete_item("revenue", entry_id)


# ------------------------------------------------------------------ feedback
def put_feedback(item: dict) -> dict:
    item.setdefault("gsipk", "f")  # constant GSI partition; sorted by created_at
    return put_item("feedback", item)


def get_feedback(feedback_id: str) -> dict | None:
    return get_item("feedback", feedback_id)


def list_feedback() -> list[dict]:
    return query("feedback", "created", "gsipk", "f", "created_at", None, False)


def update_feedback(feedback_id: str, updates: dict) -> dict | None:
    return update_item("feedback", feedback_id, set_updates=updates)


def delete_feedback(feedback_id: str) -> None:
    delete_item("feedback", feedback_id)


# -------------------------------------------------------------------- visits
def record_visit(day_key: str) -> None:
    update_item("visits", "site", add_updates={"total": 1})
    update_item("visits", f"day-{day_key}", add_updates={"count": 1})


def get_visit_stats(day_key: str) -> tuple[int, int]:
    site = get_item("visits", "site") or {}
    today = get_item("visits", f"day-{day_key}") or {}
    return int(site.get("total", 0)), int(today.get("count", 0))
