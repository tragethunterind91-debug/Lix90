"""Watch-time economy engine — ads are the currency. ONLY signed-in free viewers carry
a balance (owner decision): VIP and staff watch unlimited; guests are untracked.

- new free account → 1 hour bonus (legacy accounts get it lazily on first quota touch)
- watching consumes real playback seconds (client pings every 15s)
- downloading an episode charges its full length upfront
- rewarded ads refill +30 min (mock until AdSense/GAM approval, 45s cooldown)
"""

from datetime import datetime, timezone

from lib import store

SIGNUP_BONUS_SECONDS = 3600  # 1 hour on account creation
REWARD_AD_SECONDS = 1800  # +30 min per rewarded ad
AD_COOLDOWN_SECONDS = 45
DEFAULT_EPISODE_SECONDS = 1800  # unknown-length episodes charge 30 min to download
MAX_BALANCE_SECONDS = 12600  # owner rule: an account can store at most 3.5 hours (210 min)


def is_limited(user: dict) -> bool:
    """Only role=user without an active VIP pass carries a watch-time balance."""
    from lib.security import is_vip

    return user.get("role") == "user" and not is_vip(user)


def balance_of(user: dict) -> int:
    return int(user.get("watch_balance_seconds") or 0)


def ensure_balance(user: dict) -> int:
    """One-time 1-hour grant for accounts created before the economy launched."""
    if not is_limited(user):
        return 0
    if user.get("watch_balance_seconds") is None:
        store.update_user(user["id"], {"watch_balance_seconds": SIGNUP_BONUS_SECONDS})
        return SIGNUP_BONUS_SECONDS
    return balance_of(user)


def consume(user_id: str, seconds: int) -> int:
    """Spend seconds from the balance (floored at 0). Returns the new balance."""
    user = store.get_user(user_id)
    if not user:
        return 0
    new_balance = max(0, balance_of(user) - seconds)
    store.update_user(user_id, {"watch_balance_seconds": new_balance})
    return new_balance


def cooldown_remaining(user: dict) -> int:
    last = user.get("last_ad_at")
    if not last:
        return 0
    try:
        elapsed = (datetime.now(timezone.utc) - datetime.fromisoformat(last)).total_seconds()
    except ValueError:
        return 0
    return max(0, int(AD_COOLDOWN_SECONDS - elapsed))


def grant_seconds(user_id: str, seconds: int) -> int:
    """Add seconds to the balance, capped at the 3.5 h store limit. Returns the new balance."""
    user = store.get_user(user_id)
    if not user:
        return 0
    new_balance = min(MAX_BALANCE_SECONDS, balance_of(user) + max(0, int(seconds)))
    store.update_user(user_id, {"watch_balance_seconds": new_balance})
    return new_balance


def grant_ad_reward(user_id: str) -> tuple[int, int]:
    """Refill +30 min. Returns (new_balance, cooldown_remaining)."""
    user = store.get_user(user_id)
    if not user:
        return 0, 0
    remaining = cooldown_remaining(user)
    if remaining > 0:
        return balance_of(user), remaining
    new_balance = grant_seconds(user_id, REWARD_AD_SECONDS)
    store.update_user(
        user_id,
        {"last_ad_at": datetime.now(timezone.utc).isoformat()},
    )
    return new_balance, 0
