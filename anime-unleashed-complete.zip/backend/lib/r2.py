"""Cloudflare R2 object storage (S3-compatible, boto3) — the production media store.

Env-gated: with R2_* keys present, new uploads land in the bucket and reads are served
as short-lived presigned-GET redirects (R2 handles byte-range natively, so <video> seeking
keeps working, and EC2 bandwidth stays flat). Without keys, everything falls back to
local disk. Key layout mirrors the legacy disk layout:
  {video_key}  ·  images/{name}  ·  audio/{name}  ·  subs/{name}
"""

import os
import threading

_client = None
_lock = threading.Lock()


def _endpoint() -> str:
    acct = os.environ.get("R2_ACCOUNT_ID", "").strip()
    return os.environ.get("R2_ENDPOINT", "").strip() or (f"https://{acct}.r2.cloudflarestorage.com" if acct else "")


def enabled() -> bool:
    return bool(
        os.environ.get("R2_ACCESS_KEY_ID", "").strip()
        and os.environ.get("R2_SECRET_ACCESS_KEY", "").strip()
        and os.environ.get("R2_BUCKET", "").strip()
        and _endpoint()
    )


def bucket() -> str:
    return os.environ["R2_BUCKET"].strip()


def client():
    global _client
    with _lock:
        if _client is None:
            import boto3
            from botocore.client import Config

            _client = boto3.client(
                "s3",
                endpoint_url=_endpoint(),
                aws_access_key_id=os.environ["R2_ACCESS_KEY_ID"].strip(),
                aws_secret_access_key=os.environ["R2_SECRET_ACCESS_KEY"].strip(),
                region_name="auto",
                config=Config(signature_version="s3v4"),
            )
    return _client


def upload_bytes(key: str, data: bytes, content_type: str) -> None:
    client().put_object(Bucket=bucket(), Key=key, Body=data, ContentType=content_type)


def upload_stream(key: str, fileobj, content_type: str) -> None:
    """Multipart-safe upload for large videos — streams from a spooled temp file.
    TransferConfig: multipart kicks in at 16 MB with 4 parallel parts (fast on EC2)."""
    from boto3.s3.transfer import TransferConfig

    cfg = TransferConfig(
        multipart_threshold=16 * 1024 * 1024,
        multipart_chunksize=16 * 1024 * 1024,
        max_concurrency=4,
        use_threads=True,
    )
    client().upload_fileobj(fileobj, bucket(), key, ExtraArgs={"ContentType": content_type}, Config=cfg)


def presign_get(key: str, expires: int = 3600, *, disposition: str | None = None) -> str:
    params: dict = {"Bucket": bucket(), "Key": key}
    if disposition:
        params["ResponseContentDisposition"] = disposition
    return client().generate_presigned_url("get_object", Params=params, ExpiresIn=expires)


def head_bytes(key: str, n: int = 16) -> bytes | None:
    """First n bytes of an object (range read) — used to sniff real container magic."""
    try:
        obj = client().get_object(Bucket=bucket(), Key=key, Range=f"bytes=0-{n - 1}")
        return obj["Body"].read()
    except Exception:
        return None


def exists(key: str) -> bool:
    try:
        client().head_object(Bucket=bucket(), Key=key)
        return True
    except Exception:
        return False


def delete_object(key: str) -> None:
    try:
        client().delete_object(Bucket=bucket(), Key=key)
    except Exception:
        pass


def ensure_cors() -> None:
    """Allow cross-origin GETs (fetch()-based subtitle loading, presigned media)."""
    client().put_bucket_cors(
        Bucket=bucket(),
        CORSConfiguration={
            "CORSRules": [
                {
                    "AllowedMethods": ["GET", "HEAD"],
                    "AllowedOrigins": ["*"],
                    "AllowedHeaders": ["Range", "Content-Type"],
                    "ExposeHeaders": ["ETag", "Content-Length", "Content-Range", "Accept-Ranges"],
                    "MaxAgeSeconds": 3600,
                }
            ]
        },
    )
