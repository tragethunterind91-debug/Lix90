"""IP intelligence for the owner's one-account-per-network rules.

- Free ip-api.com lookup (no key): country + ISP/Org/AS.
- VPN/datacenter detection via a keyword heuristic on the ISP/org/AS string
  (the free tier doesn't include the proxy/hosting flags; the heuristic
  catches Nord/Express/Surfshark/Tor and the big datacenter hosts).
- Results cached in DynamoDB (ip_intel) for 7 days.
- Fail-open: if the geo API is down, registration proceeds (the 1-IP rule
  still applies from our own database) — a dead API never bricks signups.
- Local/private addresses skip the lookup entirely.

The owner's rules enforced in auth.register:
  1 IP = 1 account · 1 country (India by default, ALLOWED_COUNTRIES env) ·
  1 user = 1 account (OTP-verified email is the identity).
"""

from datetime import datetime, timedelta, timezone

import httpx

from lib import store

VPN_KEYWORDS = (
    "vpn", "nord", "expressvpn", "surfshark", "cyberghost", "protonvpn", "mullvad",
    "tunnel", "windscribe", "ipvanish", "purevpn", "hide.me", "private internet",
    "vypr", "torguard", "hola", "tor exit", "digitalocean", "ovh", "hetzner",
    "linode", "vultr", "contabo", "m247", "leaseweb", "choopa", "datacamp",
    "packethub", "hostinger", "data center", "datacenter", "hosting",
)

_LOCAL_PREFIXES = (
    "10.", "192.168.", "127.", "169.254.", "0.",
    "172.16.", "172.17.", "172.18.", "172.19.", "172.20.", "172.21.", "172.22.",
    "172.23.", "172.24.", "172.25.", "172.26.", "172.27.", "172.28.", "172.29.",
    "172.30.", "172.31.",
)

_CACHE_DAYS = 7


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def lookup(ip: str) -> dict:
    """{ip, country_code, isp, org, vpn, local} — Global welcoming mode."""
    if not ip or ip.startswith(_LOCAL_PREFIXES):
        return {"ip": ip or "", "country_code": "GLOBAL", "isp": "", "org": "", "vpn": False, "local": True}
    cached = store.get_item("ip_intel", ip)
    if cached:
        fresh_before = (datetime.now(timezone.utc) - timedelta(days=_CACHE_DAYS)).isoformat()
        if cached.get("checked_at", "") > fresh_before:
            return cached
    try:
        r = httpx.get(
            f"http://ip-api.com/json/{ip}",
            params={"fields": "status,countryCode,isp,org,as,message"},
            timeout=4,
        )
        data = r.json()
    except Exception:
        return {"ip": ip, "country_code": "GLOBAL", "isp": "", "org": "", "vpn": False, "local": False}
    if data.get("status") != "success":
        return {"ip": ip, "country_code": "GLOBAL", "isp": "", "org": "", "vpn": False, "local": False}
    doc = {
        "id": ip,
        "country_code": data.get("countryCode", "GLOBAL"),
        "isp": data.get("isp", ""),
        "org": data.get("org", ""),
        "vpn": False,
        "checked_at": _now(),
    }
    store.put_item("ip_intel", doc)
    return doc
