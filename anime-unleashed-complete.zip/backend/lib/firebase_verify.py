"""Firebase ID-token verification without a service account.

Email+password sign-in happens in the browser (Firebase JS SDK with the project's public
web config). FastAPI then verifies the returned ID token against Google's public x509
certs — public-key checks only, so no Admin SDK credentials are required.
"""

import os
import time

import httpx
import jwt
from cryptography import x509
from cryptography.hazmat.primitives import serialization
from fastapi import HTTPException

PROJECT_ID = os.environ.get("FIREBASE_PROJECT_ID", "anime-unleashed")
# NB: "robot" (singular) — the "robots" variant 404s.
CERTS_URL = (
    "https://www.googleapis.com/robot/v1/metadata/x509/"
    "securetoken@system.gserviceaccount.com"
)

_cache: dict = {"keys": None, "fetched_at": 0.0}


async def _public_keys() -> dict:
    """Fetch Google's x509 certs and extract real RSA public keys (PyJWT can't
    parse raw certificates on this version)."""
    if _cache["keys"] and time.time() - _cache["fetched_at"] < 3600:
        return _cache["keys"]
    async with httpx.AsyncClient(timeout=10) as client:
        res = await client.get(CERTS_URL)
        res.raise_for_status()
        keys = {}
        for kid, cert_pem in res.json().items():
            cert = x509.load_pem_x509_certificate(cert_pem.encode())
            keys[kid] = cert.public_key().public_bytes(
                serialization.Encoding.PEM,
                serialization.PublicFormat.SubjectPublicKeyInfo,
            )
        _cache["keys"] = keys
        _cache["fetched_at"] = time.time()
    return _cache["keys"]


async def verify_firebase_id_token(token: str) -> dict:
    """Returns the token claims {sub (firebase uid), email, ...} or raises 401."""
    keys = await _public_keys()
    try:
        header = jwt.get_unverified_header(token)
        key = keys[header["kid"]]
        payload = jwt.decode(
            token,
            key=key,
            algorithms=["RS256"],
            audience=PROJECT_ID,
            issuer=f"https://securetoken.google.com/{PROJECT_ID}",
        )
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Firebase session expired — sign in again")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=401, detail="Invalid Firebase credentials")
    if not payload.get("sub") or not payload.get("email"):
        raise HTTPException(status_code=401, detail="Firebase token missing identity")
    return payload
