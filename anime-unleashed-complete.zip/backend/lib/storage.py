"""Local object store standing in for Cloudflare R2.

Videos live under MEDIA_ROOT, addressed by an opaque `video_key` ("uploaded through the
secure backend, never the browser"). Streaming supports HTTP byte-range requests so the
<video> element can seek; downloads go out as expiring signed links (lib/security).
"""

import os
import re
import uuid
from pathlib import Path

from lib import r2

MEDIA_ROOT = Path(os.environ.get("MEDIA_ROOT", "/app/backend/media"))
ALLOWED_EXTS = {".mp4", ".webm", ".mkv", ".mov"}
IMAGE_EXTS = {".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".webp": "image/webp", ".avif": "image/avif"}
IMAGE_MAX_BYTES = 5 * 1024 * 1024  # posters/thumbnails are small; refuse the rest
AUDIO_EXTS = {".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".ogg": "audio/ogg", ".opus": "audio/ogg", ".wav": "audio/wav"}
SUB_EXTS = {".vtt": "text/vtt", ".srt": "text/plain"}
AUDIO_MAX_BYTES = 50 * 1024 * 1024  # 50 MB — a full dub track fits easily
SUB_MAX_BYTES = 1 * 1024 * 1024  # 1 MB — subtitles are tiny
CHUNK = 1024 * 1024  # 1 MiB


def ensure_media_root() -> Path:
    MEDIA_ROOT.mkdir(parents=True, exist_ok=True)
    return MEDIA_ROOT


def new_video_key(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    if ext not in ALLOWED_EXTS:
        raise ValueError(f"Unsupported video extension: {ext or '(none)'}")
    return f"{uuid.uuid4().hex}{ext}"


async def save_upload(video_key: str, data_iter) -> int:
    """Persist an uploaded video (async iterator of chunks); returns bytes written.
    First bytes are checked against allowed video magic numbers — a renamed non-video
    dies before it lands. 2 GB cap. With R2 configured the object goes to the bucket
    (spooled to disk-backed temp for multipart upload); otherwise to the media folder."""
    import tempfile

    ensure_media_root() if not r2.enabled() else None
    written = 0
    video_confirmed = False
    with tempfile.SpooledTemporaryFile(max_size=8 * 1024 * 1024) as spool:
        async for chunk in data_iter:
            if written == 0 and not video_confirmed:
                head = chunk[:256]
                if _looks_like_executable(head):
                    raise ValueError("This file is an executable, not a video — uploads are screened for safety")
                if not _looks_like_video(head):
                    # renamed / container-odd files (very common with downloaded
                    # anime): ask ffprobe before rejecting — EC2 has ffmpeg
                    if not _ffprobe_first_chunk(chunk):
                        raise ValueError("File content doesn't look like a supported video (mp4/mkv/webm/mov)")
                    video_confirmed = True
            spool.write(chunk)
            written += len(chunk)
            if written > MAX_VIDEO_BYTES:
                raise ValueError("Video too large (max 2 GB)")
        if written == 0:
            raise ValueError("Empty file")
        if r2.enabled():
            spool.seek(0)
            r2.upload_stream(video_key, spool, content_type_for(video_key))
        else:
            path = MEDIA_ROOT / video_key
            spool.seek(0)
            with open(path, "wb") as out:
                while True:
                    block = spool.read(CHUNK)
                    if not block:
                        break
                    out.write(block)
    return written


MAX_VIDEO_BYTES = 2 * 1024 * 1024 * 1024  # 2 GB cap per upload


def _looks_like_video(head: bytes) -> bool:
    return (
        head[4:8] == b"ftyp"                    # mp4 / m4v / mov
        or b"ftyp" in head[:64]                 # mp4 with junk before the box
        or head.startswith(b"\x1aE\xdf\xa3")    # EBML — mkv / webm
        or (head[:4] == b"RIFF" and head[8:12] == b"AVI ")  # avi
        or head.startswith(b"FLV")              # flash video (common re-encodes)
        or head.startswith(b"\x00\x00\x01\xba") # mpeg-ps
        or (head[:1] == b"\x47" and head[188:189] == b"\x47")  # mpeg-ts
    ) and not _looks_like_executable(head)


def _ffprobe_first_chunk(chunk: bytes) -> bool:
    """Deep check for files whose magic bytes don't match: real videos pass
    ffprobe even when renamed or header-odd; text/zip/exe payloads never do."""
    import shutil
    import subprocess
    import tempfile

    if not shutil.which("ffprobe"):
        return False  # can't deep-check → fall back to strict (old behavior)
    try:
        with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as tmp:
            tmp.write(chunk[:2 * 1024 * 1024])
            path = tmp.name
        try:
            out = subprocess.run(
                ["ffprobe", "-v", "error", "-select_streams", "v:0", "-show_entries", "stream=codec_type", "-of", "csv=p=0", path],
                capture_output=True, text=True, timeout=30,
            )
            return "video" in out.stdout
        finally:
            os.unlink(path)
    except (OSError, subprocess.SubprocessError):
        return False


def _looks_like_executable(d: bytes) -> bool:
    """Screen for Windows PE / ELF / script payloads smuggled as media (virus wall)."""
    return (
        d.startswith(b"MZ")                     # Windows PE (.exe/.dll)
        or d.startswith(b"\x7fELF")             # Linux ELF
        or d.startswith(b"#!")                  # shell/python shebang
        or d.startswith(b"<?php")               # PHP webshell
        or d.startswith(b"PK\x03\x04")          # zip-based payload (docm/jar/apk)
    )


def delete_video(video_key: str | None) -> None:
    if not video_key:
        return
    if r2.enabled():
        r2.delete_object(Path(video_key).name)
    path = MEDIA_ROOT / Path(video_key).name  # basename guard against traversal
    try:
        path.unlink(missing_ok=True)
    except OSError:
        pass


def video_path(video_key: str) -> Path:
    return MEDIA_ROOT / Path(video_key).name


def video_exists(video_key: str) -> bool:
    """R2-aware existence check — legacy files on disk, new ones in the bucket."""
    if video_path(video_key).exists():
        return True
    return r2.enabled() and r2.exists(Path(video_key).name)


def video_size(video_key: str) -> int:
    p = video_path(video_key)
    if p.exists():
        return p.stat().st_size
    if r2.enabled():
        try:
            return int(r2.client().head_object(Bucket=r2.bucket(), Key=Path(video_key).name)["ContentLength"])
        except Exception:
            return 0
    return 0


def is_browser_playable(video_key: str) -> bool:
    """True only for a real MP4/MOV (ftyp at offset 4) — what browsers decode natively.
    Renamed MKV/AVI/TS files pass upload validation but cannot stream natively; the
    player must fall back to a converted H.264 variant for those."""
    path = video_path(video_key)
    head: bytes | None = None
    try:
        if path.exists():
            with path.open("rb") as fh:
                head = fh.read(12)
        elif r2.enabled():
            head = r2.head_bytes(video_key, 12)
    except OSError:
        return True
    if head is None:
        return True  # unreadable — don't block playback; converted variants remain the fallback
    return head[4:8] == b"ftyp"


def content_type_for(video_key: str) -> str:
    ext = Path(video_key).suffix.lower()
    return {
        ".mp4": "video/mp4",
        ".webm": "video/webm",
        ".mkv": "video/x-matroska",
        ".mov": "video/quicktime",
    }.get(ext, "application/octet-stream")


# --------------------------------------------------------------------- images


def new_image_name(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    if ext not in IMAGE_EXTS:
        raise ValueError(f"Unsupported image extension: {ext or '(none)'}")
    return f"{uuid.uuid4().hex}{ext}"


def save_image(name: str, data: bytes) -> int:
    """Persist an uploaded image — R2 bucket when configured, else media disk."""
    if len(data) > IMAGE_MAX_BYTES:
        raise ValueError("Image too large (max 5 MB)")
    if not _looks_like_image(data):
        raise ValueError("File content doesn't look like a supported image (png/jpg/webp/avif)")
    if r2.enabled():
        r2.upload_bytes(f"images/{Path(name).name}", data, image_content_type(name))
        return len(data)
    images = MEDIA_ROOT / "images"
    images.mkdir(parents=True, exist_ok=True)
    (images / Path(name).name).write_bytes(data)
    return len(data)


def _looks_like_image(data: bytes) -> bool:
    return not _looks_like_executable(data[:16]) and (
        data.startswith(b"\x89PNG\r\n\x1a\n")                       # png
        or data.startswith(b"\xff\xd8\xff")                         # jpeg
        or (data[:4] == b"RIFF" and data[8:12] == b"WEBP")          # webp
        or (data[4:8] == b"ftyp" and data[8:12] in (b"avif", b"avis", b"mif1"))  # avif/heif
    )


def image_path(name: str) -> Path:
    return MEDIA_ROOT / "images" / Path(name).name  # basename guard


def image_content_type(name: str) -> str:
    return IMAGE_EXTS.get(Path(name).suffix.lower(), "application/octet-stream")


# ------------------------------------------------------------- audio + subs
def new_audio_name(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    if ext not in AUDIO_EXTS:
        raise ValueError(f"Unsupported audio extension: {ext or '(none)'} (use mp3/m4a/ogg/wav)")
    return f"{uuid.uuid4().hex}{ext}"


def save_audio(name: str, data: bytes) -> int:
    if len(data) > AUDIO_MAX_BYTES:
        raise ValueError("Audio too large (max 50 MB)")
    if not _looks_like_audio(data):
        raise ValueError("File content doesn't look like a supported audio track")
    if r2.enabled():
        r2.upload_bytes(f"audio/{Path(name).name}", data, audio_content_type(name))
        return len(data)
    out = MEDIA_ROOT / "audio"
    out.mkdir(parents=True, exist_ok=True)
    (out / Path(name).name).write_bytes(data)
    return len(data)


def _looks_like_audio(d: bytes) -> bool:
    return not _looks_like_executable(d[:16]) and (
        d.startswith(b"ID3")                          # mp3 with tag
        or (len(d) > 2 and d[0] == 0xFF and (d[1] & 0xE0) == 0xE0)  # mp3 frame sync
        or d.startswith(b"OggS")                      # ogg/opus
        or (d[4:8] == b"ftyp" and d[8:12] in (b"M4A ", b"M4B ", b"isom"))  # m4a
        or (d[:4] == b"RIFF" and d[8:12] == b"WAVE")  # wav
    )


def audio_path(name: str) -> Path:
    return (MEDIA_ROOT / "audio" / Path(name).name).resolve()


def audio_content_type(name: str) -> str:
    return AUDIO_EXTS.get(Path(name).suffix.lower(), "application/octet-stream")


def new_sub_name(filename: str) -> str:
    ext = Path(filename).suffix.lower()
    if ext not in SUB_EXTS:
        raise ValueError("Subtitles must be .vtt or .srt")
    return f"{uuid.uuid4().hex}.vtt"  # srt gets converted on the way in


def save_subtitle(name: str, data: bytes) -> int:
    if len(data) > SUB_MAX_BYTES:
        raise ValueError("Subtitle file too large (max 1 MB)")
    try:
        text = data.decode("utf-8-sig")
    except UnicodeDecodeError as e:
        raise ValueError("Subtitle file must be UTF-8 text") from e
    if not text.lstrip().startswith("WEBVTT"):
        # treat everything that isn't already WebVTT as SRT and convert it
        text = srt_to_vtt(text)
    if not text.lstrip().startswith("WEBVTT"):
        raise ValueError("Not a valid subtitle file")
    if r2.enabled():
        r2.upload_bytes(f"subs/{Path(name).name}", text.encode("utf-8"), "text/vtt")
        return len(data)
    subs = MEDIA_ROOT / "subs"
    subs.mkdir(parents=True, exist_ok=True)
    (subs / Path(name).name).write_text(text, encoding="utf-8")
    return len(data)


def srt_to_vtt(text: str) -> str:
    """Minimal SRT→WebVTT: header + comma milliseconds become dots."""
    body = re.sub(r"^(\d+\s*$)", "", text, flags=re.MULTILINE)  # drop index lines
    body = re.sub(r"(\d{2}:\d{2}:\d{2}),(\d{3})", r"\1.\2", body)
    return "WEBVTT\n\n" + body.strip() + "\n"


def sub_path(name: str) -> Path:
    return (MEDIA_ROOT / "subs" / Path(name).name).resolve()
