"""Auth primitives: password hashing (passlib), session JWTs (pyjwt), cookie helpers,
and FastAPI dependencies for the current user / admin gate. Sessions are httpOnly cookies
the backend owns — the browser never sees or stores a token."""

import os
from datetime import datetime, timedelta, timezone

import jwt
from fastapi import HTTPException, Request
from passlib.hash import pbkdf2_sha256
from pydantic import BaseModel

SESSION_SECRET = os.environ.get("SESSION_SECRET", "animehub-dev-secret-change-me")
COOKIE_NAME = "ah_session"
SESSION_TTL_DAYS = 30
DOWNLOAD_TOKEN_TTL_SECONDS = 600  # signed download links are valid for 10 minutes


def hash_password(password: str) -> str:
    return pbkdf2_sha256.hash(password)


def verify_password(password: str, hashed: str) -> bool:
    try:
        return pbkdf2_sha256.verify(password, hashed)
    except Exception:
        return False


def create_session_token(user_id: str, role: str) -> str:
    payload = {
        "sub": user_id,
        "role": role,
        "purpose": "session",
        "exp": datetime.now(timezone.utc) + timedelta(days=SESSION_TTL_DAYS),
    }
    return jwt.encode(payload, SESSION_SECRET, algorithm="HS256")


def create_download_token(episode_id: str) -> str:
    """Time-limited signed token for a download link (the R2-signed-URL stand-in)."""
    payload = {
        "sub": episode_id,
        "purpose": "download",
        "exp": datetime.now(timezone.utc) + timedelta(seconds=DOWNLOAD_TOKEN_TTL_SECONDS),
    }
    return jwt.encode(payload, SESSION_SECRET, algorithm="HS256")


def decode_token(token: str, expected_purpose: str) -> dict:
    try:
        payload = jwt.decode(token, SESSION_SECRET, algorithms=["HS256"])
    except jwt.ExpiredSignatureError:
        raise HTTPException(status_code=401, detail="Link expired — generate a new one")
    except jwt.InvalidTokenError:
        raise HTTPException(status_code=401, detail="Invalid token")
    if payload.get("purpose") != expected_purpose:
        raise HTTPException(status_code=401, detail="Invalid token")
    return payload


def set_session_cookie(response, token: str) -> None:
    # Cross-origin deploys (frontend on Firebase Hosting, API on its own domain) need
    # SameSite=None + Secure — set SESSION_COOKIE_SAMESITE=none in that backend .env.
    samesite = os.environ.get("SESSION_COOKIE_SAMESITE", "lax")
    response.set_cookie(
        COOKIE_NAME,
        token,
        httponly=True,
        samesite=samesite,
        secure=samesite == "none",
        path="/",
        max_age=SESSION_TTL_DAYS * 24 * 60 * 60,
    )


def clear_session_cookie(response) -> None:
    # the delete must MATCH the set attributes exactly (secure/samesite) —
    # a mismatched delete_cookie is ignored by browsers and the session survives
    samesite = os.environ.get("SESSION_COOKIE_SAMESITE", "lax")
    response.delete_cookie(
        COOKIE_NAME,
        path="/",
        httponly=True,
        secure=samesite == "none",
        samesite=samesite,
    )


async def get_optional_user(request: Request):
    """Dependency: the signed-in user document, or None for guests (never raises)."""
    try:
        return await get_current_user(request)
    except HTTPException:
        return None


async def get_current_user(request: Request):
    """Dependency: the signed-in user document, or 401. Reads DynamoDB via lib.store —
    the single source of truth for users (Mongo shim removed post-migration)."""
    token = request.cookies.get(COOKIE_NAME)
    if not token:
        raise HTTPException(status_code=401, detail="Sign in required")
    payload = decode_token(token, "session")
    from lib import store

    user = store.get_user(payload["sub"])
    if not user:
        raise HTTPException(status_code=401, detail="Account no longer exists")
    if user.get("banned"):
        raise HTTPException(status_code=403, detail="Account banned — contact the admin")
    return user


def is_vip(user: dict) -> bool:
    """Admins ride free; everyone else needs an unexpired vip_until timestamp."""
    if user.get("role") == "admin":
        return True
    until = user.get("vip_until")
    if not until:
        return False
    try:
        return datetime.fromisoformat(until) > datetime.now(timezone.utc)
    except ValueError:
        return False


async def get_vip_user(request: Request):
    """Dependency for VIP-gated content (dub audio, subtitle tracks).
    Admins bypass; free users get 403 with the upsell message."""
    user = await get_current_user(request)
    if not is_vip(user):
        raise HTTPException(status_code=403, detail="VIP members only — go VIP for ₹66/2 months to unlock dub audio & subtitles")
    return user


async def get_admin_user(request: Request):
    user = await get_current_user(request)
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


async def get_worker_user(request: Request):
    """Studio staff dependency: admins + workers (workers get draft-only powers,
    enforced in the routers — they can never publish, delete, or touch admin data)."""
    user = await get_current_user(request)
    if user.get("role") not in ("admin", "worker"):
        raise HTTPException(status_code=403, detail="Studio staff access required")
    return user


def admin_emails() -> list[str]:
    """The owner's inbox — task applications go here by email (notebook rule)."""
    return [e.strip().lower() for e in os.environ.get("ADMIN_EMAILS", "").split(",") if e.strip()]


def is_owner(user: dict) -> bool:
    """Super-admin check: role=admin AND (is_owner flag OR the ADMIN_EMAILS seat)."""
    if user.get("role") != "admin":
        return False
    if user.get("is_owner"):
        return True
    admin_emails = [e.strip().lower() for e in os.environ.get("ADMIN_EMAILS", "").split(",") if e.strip()]
    return user.get("email", "").lower() in admin_emails


async def get_owner_user(request: Request):
    """Super-admin dependency — global stats + admin management (the notes' 'super admin')."""
    user = await get_current_user(request)
    if not is_owner(user):
        raise HTTPException(status_code=403, detail="Owner access required")
    return user


class UserPublic(BaseModel):
    id: str
    email: str
    display_name: str
    role: str
    vip_until: str | None = None
    is_owner: bool = False
    phone: str | None = None
    cf_balance: int = 0
