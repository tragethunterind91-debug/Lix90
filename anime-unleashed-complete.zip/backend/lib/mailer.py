"""Reusable SES email sender — OTP codes, publisher test results, notifications.

Uses the same SESv2 setup as lib/otp.py (region SES_REGION/AWS_REGION, sender
MAIL_FROM). send_email never raises: a mail failure must not break the API
action that triggered it (SES sandbox still limits recipients until
production access is granted).
"""

import os

import boto3


def send_email(to: str, subject: str, body: str) -> bool:
    """Fire-and-forget transactional mail. Returns True when SES accepted it."""
    if not to:
        return False
    region = os.environ.get("SES_REGION", os.environ.get("AWS_REGION", "ap-south-1"))
    sender = os.environ.get("MAIL_FROM", "noreply@animeunleashed.in")
    try:
        client = boto3.client("sesv2", region_name=region)
        client.send_email(
            FromEmailAddress=sender,
            Destination={"ToAddresses": [to]},
            Content={
                "Simple": {
                    "Subject": {"Data": subject, "Charset": "UTF-8"},
                    "Body": {"Text": {"Data": body, "Charset": "UTF-8"}},
                }
            },
        )
        return True
    except Exception:
        return False
