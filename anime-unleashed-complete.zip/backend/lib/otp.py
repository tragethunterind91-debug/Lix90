"""Email OTP — registration + password-reset codes, delivered through AWS SES
(free tier: 3,000 emails/month). Codes are 6 digits, stored as HMAC-SHA-256
hashes, expire in 10 minutes, single-use, max 5 wrong attempts.

SES sandbox note: until the owner enables production access in the AWS console,
SES only delivers to VERIFIED recipient identities. With OTP_DEBUG=true (the
sandbox), the code is returned to the API caller so flows stay testable.

Trusted domains only — the owner wants signups restricted to the top-10
consumer providers so throwaway/spam mailboxes can't farm watch-time bonuses.
"""

import hashlib
import hmac
import os
import secrets
from datetime import datetime, timedelta, timezone

import boto3

from lib import store

OTP_TTL_MINUTES = 10
MAX_ATTEMPTS = 5
CODE_LENGTH = 6

ALLOWED_DOMAINS = [
    "gmail.com",
    "yahoo.com",
    "yahoo.in",
    "outlook.com",
    "hotmail.com",
    "live.com",
    "icloud.com",
    "aol.com",
    "proton.me",
    "protonmail.com",
]

ALLOWED_DOMAINS_NOTE = "gmail.com, yahoo.com, yahoo.in, outlook.com, hotmail.com, live.com, icloud.com, aol.com, proton.me, protonmail.com"


def domain_of(email: str) -> str:
    return email.rsplit("@", 1)[-1].lower()


def is_allowed_email(email: str) -> bool:
    return domain_of(email) in ALLOWED_DOMAINS


def _key(email: str, purpose: str) -> str:
    return f"{purpose}:{email.lower()}"


def _hash(code: str) -> str:
    secret = os.environ.get("SESSION_SECRET", "animehub-dev-secret-change-me")
    return hmac.new(secret.encode(), code.encode(), hashlib.sha256).hexdigest()


def _send_email(email: str, code: str, purpose: str) -> None:
    region = os.environ.get("SES_REGION", os.environ.get("AWS_REGION", "ap-south-1"))
    sender = os.environ.get("MAIL_FROM", "noreply@animeunleashed.in")
    if purpose == "register":
        subject = "Your Anime-Unleashed verification code"
        body = (
            f"Welcome to Anime-Unleashed!\n\nYour verification code is: {code}\n"
            f"It expires in {OTP_TTL_MINUTES} minutes.\n\n"
            "If you didn't try to sign up, you can ignore this email."
        )
    else:
        subject = "Reset your Anime-Unleashed password"
        body = (
            f"Your password reset code is: {code}\n"
            f"It expires in {OTP_TTL_MINUTES} minutes.\n\n"
            "If you didn't request a reset, you can ignore this email — your password is unchanged."
        )
    client = boto3.client("sesv2", region_name=region)
    client.send_email(
        FromEmailAddress=sender,
        Destination={"ToAddresses": [email]},
        Content={
            "Simple": {
                "Subject": {"Data": subject, "Charset": "UTF-8"},
                "Body": {"Text": {"Data": body, "Charset": "UTF-8"}},
            }
        },
    )


def issue(email: str, purpose: str) -> str | None:
    """Create + email a fresh code. Returns the code ONLY when OTP_DEBUG=true,
    otherwise None (the code exists only in the email)."""
    code = f"{secrets.randbelow(10**CODE_LENGTH):06d}"
    now = datetime.now(timezone.utc)
    store.put_item(
        "otps",
        {
            "id": _key(email, purpose),
            "email": email.lower(),
            "purpose": purpose,
            "code_hash": _hash(code),
            "attempts": 0,
            "used": False,
            "expires_at": (now + timedelta(minutes=OTP_TTL_MINUTES)).isoformat(),
            "created_at": now.isoformat(),
        },
    )
    try:
        _send_email(email, code, purpose)
    except Exception:
        if os.environ.get("OTP_DEBUG", "").lower() != "true":
            raise  # production: surface the SES failure to the caller
    if os.environ.get("OTP_DEBUG", "").lower() == "true":
        return code
    return None


def verify(email: str, purpose: str, code: str) -> bool:
    row = store.get_item("otps", _key(email, purpose))
    if not row or row.get("used"):
        return False
    try:
        if datetime.fromisoformat(row["expires_at"]) < datetime.now(timezone.utc):
            return False
    except (ValueError, KeyError):
        return False
    if int(row.get("attempts") or 0) >= MAX_ATTEMPTS:
        return False
    if not hmac.compare_digest(row.get("code_hash", ""), _hash(code.strip())):
        store.update_item("otps", row["id"], set_updates={"attempts": int(row.get("attempts") or 0) + 1})
        return False
    store.update_item("otps", row["id"], set_updates={"used": True})
    return True


# ------------------------------------------------------------------ phone OTP
def sms_provider_configured() -> bool:
    """True when MSG91 or Twilio keys exist in the env."""
    return bool(
        os.environ.get("MSG91_AUTH_KEY")
        or (os.environ.get("TWILIO_SID") and os.environ.get("TWILIO_AUTH_TOKEN") and os.environ.get("TWILIO_FROM"))
    )


def _send_sms(phone: str, text: str) -> bool:
    sid = os.environ.get("TWILIO_SID", "")
    tok = os.environ.get("TWILIO_AUTH_TOKEN", "")
    frm = os.environ.get("TWILIO_FROM", "")
    if sid and tok and frm:
        import httpx

        r = httpx.post(
            f"https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json",
            data={"From": frm, "To": phone, "Body": text},
            auth=(sid, tok),
            timeout=10,
        )
        return r.status_code in (200, 201)
    key = os.environ.get("MSG91_AUTH_KEY", "")
    if key:
        import httpx

        r = httpx.get(
            "https://control.msg91.com/api/v5/otp",
            params={
                "template_id": os.environ.get("MSG91_TEMPLATE_ID", ""),
                "mobile": phone.lstrip("+"),
                "otp": "".join(ch for ch in text if ch.isdigit())[:6],
                "authkey": key,
            },
            timeout=10,
        )
        if r.status_code == 200:
            return True
        raise RuntimeError(f"MSG91 rejected the SMS: {r.text[:200]}")
    return False


def issue_phone(phone: str) -> str | None:
    """Phone OTP — SMS provider required (MSG91 or Twilio). Returns the code ONLY
    when OTP_DEBUG=true; raises RuntimeError when no provider is configured."""
    code = f"{secrets.randbelow(10**CODE_LENGTH):06d}"
    now = datetime.now(timezone.utc)
    store.put_item(
        "otps",
        {
            "id": _key(phone, "phone"),
            "email": phone.lower(),
            "purpose": "phone",
            "code_hash": _hash(code),
            "attempts": 0,
            "used": False,
            "expires_at": (now + timedelta(minutes=OTP_TTL_MINUTES)).isoformat(),
            "created_at": now.isoformat(),
        },
    )
    sent = _send_sms(phone, f"{code} is your Anime-Unleashed verification code")
    if not sent and not sms_provider_configured():
        raise RuntimeError("Phone OTP needs an SMS provider — the owner must add MSG91 or Twilio keys")
    if not sent:
        raise RuntimeError("The SMS provider rejected the message — try again shortly")
    if os.environ.get("OTP_DEBUG", "").lower() == "true":
        return code
    return None
