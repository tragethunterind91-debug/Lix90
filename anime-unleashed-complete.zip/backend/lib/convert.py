"""Convert system — one upload, many resolutions.

The worker uploads the video ONCE (to R2/local); ffmpeg (server-side) then derives
lower/upper resolution variants + an audio-only track. Admins edit episode details
freely afterwards — the file is never re-uploaded.

Variants live on the episode doc:
    video_variants: {
      "720p": {"key": "...-720p.mp4", "status": "ready", "size_bytes": 0},
      "audio": {"key": "audio/....m4a", "status": "ready", "size_bytes": 0},
    }
"""

import shutil
import subprocess  # nosec — ffmpeg binary, fixed args
import tempfile
from pathlib import Path

from lib import r2, storage, store

RESOLUTIONS: dict[str, tuple[int, int]] = {
    "1080p": (1920, 1080),
    "720p": (1280, 720),
    "480p": (854, 480),
    "360p": (640, 360),
    "240p": (426, 240),
    "144p": (256, 144),
}


def ffmpeg_available() -> bool:
    return shutil.which("ffmpeg") is not None


def variant_key(base_key: str, tag: str) -> str:
    """videos/abc.mp4 + 720p → abc-720p.mp4 (R2 flat namespace = basename)."""
    stem = Path(Path(base_key).name).stem
    ext = ".m4a" if tag == "audio" else ".mp4"
    return f"{stem}-{tag}{ext}"


def _source_to_temp(base_key: str) -> Path | None:
    """Pull the original down (or copy locally) so ffmpeg can read it."""
    local = storage.video_path(base_key)
    if local.exists():
        return local
    if r2.enabled() and r2.exists(Path(base_key).name):
        tmp = Path(tempfile.mkstemp(suffix=Path(base_key).suffix)[1])
        r2.client().download_file(r2.bucket(), Path(base_key).name, str(tmp))
        return tmp
    return None


def _push_variant(key: str, tmp: Path) -> int:
    size = tmp.stat().st_size
    if r2.enabled():
        with open(tmp, "rb") as handle:
            r2.upload_stream(key, handle, "video/mp4" if tmp.suffix == ".mp4" else "audio/mp4")
    else:
        if key.startswith("audio/"):
            storage.ensure_media_root()
            (storage.MEDIA_ROOT / "audio").mkdir(parents=True, exist_ok=True)
            (storage.MEDIA_ROOT / "audio" / Path(key).name).write_bytes(tmp.read_bytes())
        else:
            tmp.replace(storage.video_path(key))
    return size


def _set_variant(episode_id: str, tag: str, key: str | None, status: str, size: int = 0) -> None:
    ep = store.get_episode(episode_id)
    if not ep:
        return
    variants = dict(ep.get("video_variants") or {})
    if key is None:
        variants.pop(tag, None)
    else:
        variants[tag] = {"key": key, "status": status, "size_bytes": size}
    store.update_episode(episode_id, {"video_variants": variants})


def _transcode(src: Path, dst: Path, width: int, height: int) -> bool:
    """Lower→higher or higher→lower both allowed (the owner asked for both)."""
    try:
        subprocess.run(
            [
                "ffmpeg", "-y", "-i", str(src),
                "-vf", f"scale={width}:{height}",
                "-c:v", "libx264", "-preset", "veryfast", "-crf", "26",
                "-c:a", "aac", "-b:a", "128k",
                "-movflags", "+faststart",
                str(dst),
            ],
            check=True,
            capture_output=True,
            timeout=3600,
        )
    except (subprocess.SubprocessError, OSError):
        return False
    return True


def source_height(src: Path) -> int:
    """Probe the source's pixel height (0 when ffprobe can't tell)."""
    try:
        out = subprocess.run(
            ["ffprobe", "-v", "error", "-select_streams", "v:0",
             "-show_entries", "stream=height", "-of", "csv=p=0", str(src)],
            capture_output=True, text=True, timeout=60,
        )
        return int(out.stdout.strip() or 0)
    except (subprocess.SubprocessError, OSError, ValueError):
        return 0


def auto_generate(episode_id: str) -> None:
    """Upload-time hook (owner rule: watch BELOW the original too) — derives every
    variant smaller than or equal to the source height + audio-only + captions."""
    ep = store.get_episode(episode_id)
    if not ep or not ep.get("video_key"):
        return
    base_key = ep["video_key"]
    src = _source_to_temp(base_key)
    if src is None:
        return
    height = source_height(src)
    resolutions = [tag for tag, (_w, h) in RESOLUTIONS.items() if height and h <= height] or ["360p"]
    try:
        run_conversion(episode_id, resolutions, extract_audio=True)
    finally:
        if src != storage.video_path(base_key):
            src.unlink(missing_ok=True)


def delete_variant_objects(base_key: str) -> None:
    """Remove every DERIVED object for a base video (resolutions + audio + subs).
    Best-effort: missing objects are simply skipped."""
    for tag in list(RESOLUTIONS.keys()) + ["audio", "subtitle"]:
        try:
            r2.delete_object(variant_key(base_key, tag))
        except Exception:
            pass
    try:  # caption file pushed alongside subtitles
        r2.delete_object(f"{Path(Path(base_key).name).stem}.vtt")
    except Exception:
        pass


def run_conversion(episode_id: str, resolutions: list[str], extract_audio: bool = False) -> None:
    """Background job — writes per-variant status into the episode doc."""
    ep = store.get_episode(episode_id)
    if not ep or not ep.get("video_key"):
        return
    base_key = ep["video_key"]
    src = _source_to_temp(base_key)
    if src is None:
        for res in resolutions:
            _set_variant(episode_id, res, variant_key(base_key, res), "failed")
        return

    try:
        for res in resolutions:
            if res not in RESOLUTIONS:
                continue
            key = variant_key(base_key, res)
            _set_variant(episode_id, res, key, "processing")
            with tempfile.NamedTemporaryFile(suffix=".mp4", delete=False) as dst:
                dst_path = Path(dst.name)
            if _transcode(src, dst_path, *RESOLUTIONS[res]):
                size = _push_variant(key, dst_path)
                _set_variant(episode_id, res, key, "ready", size)
            else:
                _set_variant(episode_id, res, key, "failed")
            dst_path.unlink(missing_ok=True)

        if extract_audio:
            key = variant_key(base_key, "audio")
            _set_variant(episode_id, "audio", key, "processing")
            with tempfile.NamedTemporaryFile(suffix=".m4a", delete=False) as dst:
                dst_path = Path(dst.name)
            try:
                subprocess.run(
                    ["ffmpeg", "-y", "-i", str(src), "-vn", "-c:a", "aac", "-b:a", "160k", str(dst_path)],
                    check=True, capture_output=True, timeout=1200,
                )
                size = _push_variant(key, dst_path)
                _set_variant(episode_id, "audio", key, "ready", size)
            except (subprocess.SubprocessError, OSError):
                _set_variant(episode_id, "audio", key, "failed")
            dst_path.unlink(missing_ok=True)

        # owner ask: auto-extract embedded captions/subtitles (track 0) as .vtt
        sub_key = f"{Path(Path(base_key).name).stem}.vtt"
        with tempfile.NamedTemporaryFile(suffix=".vtt", delete=False) as dst:
            dst_path = Path(dst.name)
        try:
            subprocess.run(
                ["ffmpeg", "-y", "-i", str(src), "-map", "0:s:0", str(dst_path)],
                check=True, capture_output=True, timeout=600,
            )
            if dst_path.stat().st_size > 2:  # empty output = no embedded subs
                if r2.enabled():
                    with open(dst_path, "rb") as handle:
                        r2.upload_stream(sub_key, handle, "text/vtt")
                _set_variant(episode_id, "subtitle", sub_key, "ready", dst_path.stat().st_size)
                store.update_episode(episode_id, {"subtitle_key": sub_key})
            else:
                _set_variant(episode_id, "subtitle", None, "")  # no embedded subs — not a failure
        except (subprocess.SubprocessError, OSError):
            _set_variant(episode_id, "subtitle", None, "")  # source has no caption track
        dst_path.unlink(missing_ok=True)
    finally:
        if src != storage.video_path(base_key):
            src.unlink(missing_ok=True)  # only remove the temp copy we downloaded
