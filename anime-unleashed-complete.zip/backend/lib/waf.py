"""Layered request firewall ("10 walls") — middleware stack, zero external deps.

L1 security headers (server.py)          L6 executable-signature upload screen (storage.py)
L2 rate limits (lib/ratelimit.py)        L7 signed expiring downloads (videos router)
L3 THIS: hostile-pattern scanner         L8 VIP-gated premium tracks (get_vip_user)
L4 request-size caps (THIS)              L9 role guards + self-action blocks (routers)
L5 path-traversal + probe block (THIS)   L10 append-only audit trail (store/audit)
All cheap string checks per request — no DB calls, no server strain.
"""

import time

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse, Response

# L5 — common scanner probes get a bland 404 (never confirm what exists)
_SCANNER_PROBES = (
    "/.env", "/.git", "/wp-admin", "/wp-login", "/phpmyadmin", "/admin.php",
    "/xmlrpc.php", "/cgi-bin/", "/.aws", "/.ssh", "/.env.backup", "/config.json.bak",
    "/vendor/phpunit", "/.DS_Store", "/.htaccess", "/web.config", "/actuator",
)

# L3 — hostile patterns anywhere in the raw URL
_HOSTILE_URL = ("..", "%2e%2e", "%2f", "%5c", "\x00", "\r", "\n", "<script", "javascript:", "onerror=", "union+select", "select+*", " or 1=1", "' or '")


def _safe_int(raw: str | None, cap: int) -> int:
    try:
        return min(int(raw or "0"), cap)
    except ValueError:
        return 0


class WafMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        path = request.url.path.lower()
        query = request.url.query.lower()
        raw = f"{path}?{query}"

        # L5a — traversal / control chars / hostile URL patterns
        if any(p in raw for p in _HOSTILE_URL):
            return JSONResponse({"detail": "Bad request"}, status_code=400)

        # L5b — scanner probes (/.env, /wp-admin, …) — answer 404, log the probe
        if any(path.startswith(p) or path == p.rstrip("/") for p in _SCANNER_PROBES):
            print(f"[waf] scanner probe blocked: {path} from {request.client.host if request.client else '?'}")
            return JSONResponse({"detail": "Not Found"}, status_code=404)

        # L4 — request body size cap (JSON/API posts). Multipart uploads are exempt:
        # their own routes enforce the real caps (2 GB video / 50 MB audio / 5 MB image).
        is_multipart = "multipart/form-data" in request.headers.get("content-type", "")
        if not is_multipart:
            declared = _safe_int(request.headers.get("content-length"), 10 * 1024 * 1024)
            if declared > 2 * 1024 * 1024:  # 2 MB cap for anything that isn't a file upload
                return JSONResponse({"detail": "Request body too large"}, status_code=413)

        started = time.perf_counter()
        response = await call_next(request)
        took_ms = int((time.perf_counter() - started) * 1000)
        if path not in ("/api/visits",) and (took_ms > 1500 or response.status_code >= 500):
            print(f"[waf] slow/5xx {request.method} {path} -> {response.status_code} in {took_ms}ms")
        return response
