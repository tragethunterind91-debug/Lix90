"""In-process sliding-window rate limiter (single-instance deploys).

Keyed by "<scope>:<identifier>" (usually scope + client IP). Buckets self-prune:
expired events drop lazily, and every 512 calls a full sweep discards stale keys.
Good enough to stop credential stuffing and spam on this scale; swap for Redis
when the app runs multi-instance.
"""

import time
from collections import defaultdict

_buckets: dict[str, list[float]] = defaultdict(list)
_calls = 0


def allow(key: str, max_events: int, window_s: float) -> bool:
    """True if `key` may act now (max_events per window_s), False to reject with 429."""
    global _calls
    now = time.monotonic()
    _calls += 1

    fresh = [t for t in _buckets[key] if now - t < window_s]
    if len(fresh) >= max_events:
        _buckets[key] = fresh
        return False
    fresh.append(now)
    _buckets[key] = fresh

    if _calls % 512 == 0:  # opportunistic full sweep
        for k in list(_buckets):
            _buckets[k] = [t for t in _buckets[k] if now - t < max(window_s, 900)]
            if not _buckets[k]:
                del _buckets[k]
    return True


def client_ip(request) -> str:
    """First X-Forwarded-For hop when behind Caddy/nginx, else the socket peer."""
    fwd = request.headers.get("x-forwarded-for", "")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else "unknown"
