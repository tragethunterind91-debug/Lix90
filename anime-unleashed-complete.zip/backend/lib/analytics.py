"""Growth analytics — YouTube-Studio-style numbers for publishers + the admin console.

Every public signal lands as one small event row in analytics_events:
    view | download_video | download_audio | download_subtitle

Attribution rule: events carry the supplier_email of the creator whose approved
submission became the title. Worker uploads belong to the house (owner) and are
never attributed to a person. Recording is fire-and-forget — analytics can
never break a user flow.
"""

import uuid
from datetime import datetime, timedelta, timezone

from lib import store

TYPES = ("view", "download_video", "download_audio", "download_subtitle", "ad_reward", "link_reward")


def record_event(
    event_type: str,
    *,
    title_id: str = "",
    episode_id: str = "",
    supplier_email: str = "",
    user_id: str = "",
    country: str = "",
    minutes: float = 0.0,
) -> None:
    if event_type not in TYPES:
        return
    event = {
        "id": str(uuid.uuid4()),
        "type": event_type,
        "title_id": title_id,
        "episode_id": episode_id,
        "country": (country or "").strip() or "unknown",
        "minutes": round(float(minutes or 0), 1),
        "created_at": datetime.now(timezone.utc).isoformat(),
    }
    # DynamoDB GSI keys reject empty strings — omit the attribute when absent
    if supplier_email:
        event["supplier_email"] = supplier_email.strip().lower()
    if user_id:
        event["user_id"] = user_id
    try:
        store.put_item("analytics_events", event)
    except Exception:
        pass  # never break the user flow for analytics


# ------------------------------------------------------------------ aggregates
def aggregate(rows: list[dict]) -> dict:
    totals = {
        "views": 0,
        "watch_minutes": 0.0,
        "downloads_video": 0,
        "downloads_audio": 0,
        "downloads_subtitle": 0,
        "downloads_total": 0,
    }
    for r in rows:
        t = r.get("type")
        if t == "view":
            totals["views"] += 1
            totals["watch_minutes"] += float(r.get("minutes") or 0)
        elif t == "download_video":
            totals["downloads_video"] += 1
            totals["downloads_total"] += 1
        elif t == "download_audio":
            totals["downloads_audio"] += 1
            totals["downloads_total"] += 1
        elif t == "download_subtitle":
            totals["downloads_subtitle"] += 1
            totals["downloads_total"] += 1
    totals["watch_minutes"] = round(totals["watch_minutes"], 1)
    totals["watch_hours"] = round(totals["watch_minutes"] / 60, 1)
    return totals


def daily_series(rows: list[dict], days: int = 30) -> list[dict]:
    now = datetime.now(timezone.utc)
    out = []
    for i in range(days - 1, -1, -1):
        day = (now - timedelta(days=i)).strftime("%Y-%m-%d")
        out.append({
            "date": day,
            "views": sum(1 for r in rows if r.get("type") == "view" and (r.get("created_at") or "").startswith(day)),
        })
    return out


def monthly_series(rows: list[dict], months: int = 12) -> list[dict]:
    now = datetime.now(timezone.utc)
    keys = []
    year, month = now.year, now.month
    for _ in range(months):
        keys.append(f"{year:04d}-{month:02d}")
        year, month = (year, month - 1) if month > 1 else (year - 1, 12)
    keys.reverse()
    return [
        {"month": k, "views": sum(1 for r in rows if r.get("type") == "view" and (r.get("created_at") or "").startswith(k))}
        for k in keys
    ]


def location_rows(rows: list[dict], limit: int = 10) -> list[dict]:
    counts: dict[str, int] = {}
    for r in rows:
        if r.get("type") != "view":
            continue
        c = (r.get("country") or "unknown").strip() or "unknown"
        counts[c] = counts.get(c, 0) + 1
    ranked = sorted(counts.items(), key=lambda kv: kv[1], reverse=True)[:limit]
    return [{"country": k, "views": v} for k, v in ranked]


def trend_pct(rows: list[dict]) -> float:
    """% of views up or down — this calendar month vs the previous one."""
    now = datetime.now(timezone.utc)
    this_key = now.strftime("%Y-%m")
    prev = now.replace(day=1) - timedelta(days=1)
    prev_key = prev.strftime("%Y-%m")
    this_m = sum(1 for r in rows if r.get("type") == "view" and (r.get("created_at") or "").startswith(this_key))
    prev_m = sum(1 for r in rows if r.get("type") == "view" and (r.get("created_at") or "").startswith(prev_key))
    if prev_m == 0:
        return 100.0 if this_m else 0.0
    return round((this_m - prev_m) / prev_m * 100, 1)


def _shape(rows: list[dict], uploads: int) -> dict:
    return {
        "totals": aggregate(rows),
        "uploads": uploads,
        "trend_pct": trend_pct(rows),
        "daily": daily_series(rows),
        "monthly": monthly_series(rows),
        "locations": location_rows(rows),
    }


def publisher_growth(supplier_email: str, uploads: int) -> dict:
    """YT-Studio screen for one creator — every event on content they supplied."""
    rows = store.query("analytics_events", "supplier_created", "supplier_email", (supplier_email or "").lower())
    data = _shape(rows, uploads)
    
    # Calculate subscriber / followers count for this creator
    subscribers = 0
    if supplier_email:
        users = [u for u in store.scan("users") if (u.get("email") or "").lower() == supplier_email.lower()]
        if users:
            subscribers = int(users[0].get("followers_count") or 0)
    data["subscribers"] = subscribers
    return data


def admin_overview() -> dict:
    """Global console: totals + daily/monthly + locations across the whole platform."""
    rows = store.scan("analytics_events")
    return _shape(rows, uploads=store.count("titles"))
