"""Studio admin models: user management, revenue ledger, feedback inbox, visit stats.
Mirrors frontend/src/lib/types.ts — keep in sync."""

from typing import Optional

from pydantic import BaseModel, EmailStr, Field

Role = str  # "user" | "admin" | "worker" (owner's upload staff) | "creator" (YouTube-style supplier)


class AdminUserOut(BaseModel):
    id: str
    email: str
    display_name: str
    role: Role
    firebase_uid: Optional[str] = None
    vip_until: Optional[str] = None
    is_owner: bool = False
    created_at: str
    # extended controls (owner's growth update)
    account_id: Optional[str] = None
    country: Optional[str] = None
    region: Optional[str] = None
    watch_balance_seconds: Optional[int] = None
    cf_balance: Optional[int] = None
    lc_balance: Optional[int] = None
    banned: bool = False
    features: dict = {}


class AdminUserDetailOut(AdminUserOut):
    """Full account card for the admin: wallet + lifetime stats + recent history."""
    views: int = 0
    watch_minutes: float = 0
    downloads: int = 0
    history: list[dict] = []


class GrantIn(BaseModel):
    """Admin → user gifting or removal: watch-duration (VD), VIP days, CF, and LC/ZC."""
    watch_minutes: int = Field(default=0, ge=-10080, le=10080)
    vip_days: int = Field(default=0, ge=-3650, le=3650)
    cf: int = Field(default=0, ge=-100000, le=100000)
    lc: int = Field(default=0, ge=-100000, le=100000)


class FeatureToggleIn(BaseModel):
    key: str  # downloads | global_chat | refill_ads
    enabled: bool


class AirdropIn(BaseModel):
    """Send watch-duration / CF to EVERY account at once."""
    watch_minutes: int = Field(default=0, ge=0, le=12600)
    cf: int = Field(default=0, ge=0, le=1000)


class AirdropOut(BaseModel):
    users: int


class NoticeIn(BaseModel):
    title: str = Field(min_length=3, max_length=120)
    body: str = Field(min_length=3, max_length=1000)


class NoticeOut(BaseModel):
    id: str
    title: str
    body: str
    created_at: str


class VipPlan(BaseModel):
    """Admin-editable VIP plan — the Vip page + payments read this."""
    price_inr: int = Field(default=66, ge=1, le=100000)
    duration_days: int = Field(default=60, ge=1, le=3650)
    features: list[str] = []


class PlatformConfigIn(BaseModel):
    maintenance: Optional[bool] = None
    vip_plan: Optional[VipPlan] = None


class PlatformConfigOut(BaseModel):
    maintenance: bool = False
    vip_plan: VipPlan = VipPlan()


class AdminUserCreateIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=6, max_length=72)
    display_name: str = Field(min_length=2, max_length=40)
    role: Role = "admin"


class AuditOut(BaseModel):
    id: str
    actor: str
    action: str
    target: str
    created_at: str


class RoleUpdateIn(BaseModel):
    role: Role | None = None
    vip_until: str | None = None


class RevenueIn(BaseModel):
    amount: float = Field(gt=0, le=10_000_000)
    note: str = Field(default="", max_length=200)


class RevenueOut(BaseModel):
    id: str
    amount: float
    note: str
    created_at: str


class RevenueOut2(BaseModel):
    entries: list[RevenueOut]
    total: float


class FeedbackIn(BaseModel):
    name: str = Field(min_length=2, max_length=60)
    email: Optional[str] = Field(default=None, max_length=120)
    message: str = Field(min_length=5, max_length=1000)


class FeedbackOut(BaseModel):
    id: str
    name: str
    email: Optional[str] = None
    message: str
    resolved: bool
    created_at: str


class VisitStats(BaseModel):
    total: int
    today: int


class OwnerOverview(BaseModel):
    """Super-admin screen: the notes' global numbers + team + supplier queue."""

    titles: int
    episodes: int
    users: int
    total_views: int
    total_profit: float = 0.0
    total_visits: int = 0
    feedback_open: int = 0
    admins: int = 0
    workers: int = 0
    viewers: int = 0
    vip_active: int = 0
    pending_applications: int = 0
    pending_submissions: int = 0
    stale_supplier_titles: int = 0
