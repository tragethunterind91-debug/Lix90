"""Catalog models: titles, episodes, watchlist, uploads, download links.
Every model here has a hand-written mirror in frontend/src/lib/types.ts — keep in sync."""

from typing import Literal, Optional
from datetime import datetime

from pydantic import BaseModel, Field

AudioKind = Literal["Hindi Dub", "Tamil Dub", "Eng Sub", "Eng Dub", "Jap Audio"]
TitleType = Literal["series", "movie", "short", "documentary", "thriller", "ova"]
PublishStatus = Literal["published", "draft"]
ContentKind = Literal["anime", "movie", "cartoon", "kdrama", "webseries"]
# The TWO mutually-exclusive launch options for a published title:
# "upcoming" = Coming-Soon section with a live countdown; "listed" = normal Home listing.
# A single field guarantees a title can never be both at once. Drafts ignore it.
TitleVisibility = Literal["listed", "upcoming"]


class TitleIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    synopsis: str = Field(default="", max_length=4000)
    genres: list[str] = Field(default_factory=list, max_length=12)
    release_year: int = Field(ge=1930, le=2100)
    type: TitleType = "series"
    kind: ContentKind = "anime"
    studio: str = Field(default="", max_length=80)
    age_rating: str = Field(default="", max_length=10)
    original_language: str = Field(default="", max_length=30)
    airing_status: str = Field(default="", max_length=12)
    audio: list[AudioKind] = Field(default_factory=lambda: ["Eng Sub"])
    rating: Optional[float] = Field(default=None, ge=0, le=10)
    featured: bool = False
    poster_url: str = Field(default="", max_length=1000)
    status: PublishStatus = "draft"
    visibility: Optional[TitleVisibility] = None
    release_at: Optional[datetime] = None


class TitleUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=120)
    synopsis: Optional[str] = Field(default=None, max_length=4000)
    genres: Optional[list[str]] = Field(default=None, max_length=12)
    release_year: Optional[int] = Field(default=None, ge=1930, le=2100)
    type: Optional[TitleType] = None
    kind: Optional[ContentKind] = None
    studio: Optional[str] = Field(default=None, max_length=80)
    age_rating: Optional[str] = Field(default=None, max_length=10)
    original_language: Optional[str] = Field(default=None, max_length=30)
    airing_status: Optional[str] = Field(default=None, max_length=12)
    audio: Optional[list[AudioKind]] = None
    rating: Optional[float] = Field(default=None, ge=0, le=10)
    featured: Optional[bool] = None
    poster_url: Optional[str] = Field(default=None, max_length=1000)
    status: Optional[PublishStatus] = None
    visibility: Optional[TitleVisibility] = None
    release_at: Optional[datetime] = None


class TitleOut(BaseModel):
    id: str
    slug: str
    name: str
    synopsis: str = ""
    genres: list[str]
    release_year: int
    type: TitleType
    kind: ContentKind = "anime"
    studio: str = ""
    age_rating: str = ""
    original_language: str = ""
    airing_status: str = ""
    audio: list[str]
    rating: Optional[float] = None
    featured: bool
    poster_url: str = ""
    status: PublishStatus
    visibility: Optional[TitleVisibility] = None
    release_at: Optional[datetime] = None
    episode_count: int = 0
    views: int = 0
    created_at: str


class EpisodeIn(BaseModel):
    number: int = Field(ge=1, le=5000)
    season: int = Field(default=1, ge=1, le=99)
    name: str = Field(default="", max_length=160)
    description: str = Field(default="", max_length=2000)
    source: str = Field(default="", max_length=40)
    video_key: str = ""
    duration_seconds: Optional[int] = Field(default=None, ge=0)
    status: PublishStatus = "draft"
    resolution: Optional[str] = Field(default=None, max_length=10)
    dub_tag: Optional[str] = Field(default=None, max_length=20)
    thumbnail_url: Optional[str] = Field(default=None, max_length=1000)


class EpisodeUpdate(BaseModel):
    number: Optional[int] = Field(default=None, ge=1, le=5000)
    season: Optional[int] = Field(default=None, ge=1, le=99)
    name: Optional[str] = Field(default=None, max_length=160)
    description: Optional[str] = Field(default=None, max_length=2000)
    source: Optional[str] = Field(default=None, max_length=40)
    video_key: Optional[str] = None
    duration_seconds: Optional[int] = Field(default=None, ge=0)
    status: Optional[PublishStatus] = None
    resolution: Optional[str] = Field(default=None, max_length=10)
    dub_tag: Optional[str] = Field(default=None, max_length=20)
    thumbnail_url: Optional[str] = Field(default=None, max_length=1000)
    # admin can MOVE an episode to another playlist (title) at any time
    title_id: Optional[str] = None


class TranslateIn(BaseModel):
    target: Literal["hi", "en"]


class VideoVariantOut(BaseModel):
    key: str
    status: Literal["processing", "ready", "failed"]
    size_bytes: int = 0


class EpisodeOut(BaseModel):
    id: str
    title_id: str
    number: int
    season: int = 1
    name: str = ""
    description: str = ""
    source: str = ""
    video_key: str = ""
    size_bytes: int = 0
    duration_seconds: Optional[int] = None
    status: PublishStatus
    resolution: Optional[str] = None
    dub_tag: Optional[str] = None
    thumbnail_url: Optional[str] = None
    audio_key: Optional[str] = None
    subtitle_key: Optional[str] = None
    subtitle_variants: dict[str, str] = {}  # {"hi": "uuid.vtt", …} translated tracks
    video_variants: dict[str, VideoVariantOut] = {}  # convert system: 720p/480p/audio…
    created_at: str


class TitleDetail(TitleOut):
    episodes: list[EpisodeOut] = Field(default_factory=list)


class UploadOut(BaseModel):
    video_key: str
    size_bytes: int
    content_type: str


class ConvertIn(BaseModel):
    resolutions: list[Literal["1080p", "720p", "480p", "360p"]] = Field(default_factory=list)
    extract_audio: bool = False  # audio-only download track


class DownloadOptionsIn(BaseModel):
    format: Literal["video", "audio"] = "video"
    resolution: Optional[str] = None  # "720p" etc. — original when absent


class AttachVideoIn(BaseModel):
    video_key: str = Field(min_length=4, max_length=200)
    episode_id: str = Field(min_length=1, max_length=80)


class VideoLibItem(BaseModel):
    key: str
    size_bytes: int = 0
    attached_episode: str = ""
    uploaded_by: str = ""
    created_at: str = ""


class DownloadLink(BaseModel):
    url: str
    expires_at: str
    # none = serve as-is (audio/subtitles); preparing/ready = watermarked video flow
    watermark: str = "none"


class WatchlistOut(BaseModel):
    ids: list[str] = Field(default_factory=list)
    items: list[TitleOut] = Field(default_factory=list)


class TitleIdIn(BaseModel):
    title_id: str


class AdminStats(BaseModel):
    titles: int
    episodes: int
    users: int
    total_views: int
    total_profit: float = 0.0
    total_visits: int = 0
    feedback_open: int = 0


class DirectDownloadOut(BaseModel):
    """Direct video download — presigned original, capped for free users."""

    url: str
    remaining: int | None = None  # None = unlimited (VIP)
    vip: bool = False
