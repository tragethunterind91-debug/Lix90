"""Supplier (content-partner) program models — applications, link submissions, review
decisions. Mirrors frontend/src/lib/types.ts — keep in sync."""

from typing import Literal, Optional

from pydantic import BaseModel, Field

from models.catalog import ContentKind

AppStatus = Literal["pending", "approved", "rejected"]
SubmissionStatus = Literal["pending", "approved", "converted", "rejected"]


class SupplierApplyIn(BaseModel):
    channel_name: str = Field(min_length=2, max_length=80)
    channel_url: str = Field(min_length=5, max_length=300)
    content_type: str = Field(min_length=2, max_length=40)
    note: str = Field(min_length=10, max_length=1000)  # ownership proof + content plan


class SupplierApplicationOut(BaseModel):
    id: str
    user_id: str
    email: str
    channel_name: str
    channel_url: str
    content_type: str
    note: str
    status: AppStatus
    admin_note: str = ""
    created_at: str
    # channel verification (the notebook's Test 1 → 2 → 3 ladder)
    tests: dict[str, str] = Field(default_factory=dict)  # {"1": "passed"|"failed", ...}
    current_test: int = 1
    channel_verified: bool = False


class SubmissionIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    kind: ContentKind = "anime"
    language: str = Field(default="", max_length=30)
    description: str = Field(default="", max_length=2000)
    source_url: str = Field(min_length=5, max_length=500)  # the video link they supply
    thumbnail_url: str = Field(default="", max_length=1000)


class SupplierSubmissionOut(BaseModel):
    id: str
    user_id: str
    email: str
    title: str
    kind: ContentKind
    language: str = ""
    description: str = ""
    source_url: str
    thumbnail_url: str = ""
    status: SubmissionStatus
    admin_note: str = ""
    created_at: str


class SupplierMeOut(BaseModel):
    application: Optional[SupplierApplicationOut] = None
    submissions: list[SupplierSubmissionOut] = Field(default_factory=list)


class DecisionIn(BaseModel):
    status: Literal["approved", "rejected"]
    admin_note: str = Field(default="", max_length=300)


class PublisherVerifyIn(BaseModel):
    """Admin's verdict on one channel-verification test (1-3)."""

    test: int = Field(ge=1, le=3)
    passed: bool
    note: str = Field(default="", max_length=1000)  # the reason mailed on fail
