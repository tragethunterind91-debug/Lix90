"""Watch-time economy models — free accounts spend time, rewarded ads refill it.
Mirrors frontend/src/lib/types.ts (QuotaInfo / DownloadCheckOut) — keep in sync."""

from typing import Literal

from pydantic import BaseModel, Field


class QuotaOut(BaseModel):
    mode: Literal["limited", "unlimited"]
    balance_seconds: int = 0
    ad_cooldown_seconds: int = 0
    granted_per_ad: int = 1800


class ConsumeIn(BaseModel):
    episode_id: str = Field(min_length=1, max_length=80)
    seconds: int = Field(ge=1, le=120)
    # watch-time accounting rate (owner's rule): full video 1x, audio-only 0.5x,
    # subtitle-only reading 0.3x — 10 min of audio = 5 min of balance, etc.
    mode: str = Field(default="video", pattern=r"^(video|audio|subtitle)$")


class DownloadCheckIn(BaseModel):
    episode_id: str = Field(min_length=1, max_length=80)


class DownloadCheckOut(BaseModel):
    ok: bool
    balance_seconds: int = 0
    charged_seconds: int = 0


class RewardPoint(BaseModel):
    created_at: str
    minutes: float
    kind: str = "ad_reward"


class RewardHistoryOut(BaseModel):
    """The earn center's ledger: per-ad rewards + lifetime/today stats."""
    items: list[RewardPoint]
    total_ads: int
    minutes_total: float
    ads_today: int
    minutes_today: float
