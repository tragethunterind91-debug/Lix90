"""Task models — admin-created tasks whose reward is EXTRA watch-duration.
Mirrors frontend/src/lib/types.ts (Task/TaskClaim) — keep in sync."""

from typing import Optional
from datetime import datetime

from pydantic import BaseModel, Field


class TaskIn(BaseModel):
    title: str = Field(min_length=3, max_length=100)
    description: str = Field(default="", max_length=500)
    reward_seconds: int = Field(ge=60, le=7200)  # 1 min .. 2 hours of extra watch-time
    expires_at: Optional[datetime] = None  # None = permanent; set = countdown task
    # optional visit-link tasks: user opens the link, stays away ~15s, claims the reward
    link_url: Optional[str] = Field(default=None, max_length=2000)
    link_label: str = Field(default="", max_length=60)


class TaskOut(BaseModel):
    id: str
    title: str
    description: str = ""
    reward_seconds: int
    expires_at: Optional[str] = None  # ISO when it's a countdown task
    permanent: bool = True
    claimed: bool = False
    created_at: str
    link_url: Optional[str] = None
    link_label: str = ""
    link_claimed_by_me: bool = False


class TaskClaimOut(BaseModel):
    ok: bool
    reward_seconds: int = 0
    balance_seconds: int = 0
    note: str = ""
