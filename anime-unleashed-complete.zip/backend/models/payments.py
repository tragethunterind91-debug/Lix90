"""VIP pass models — FAKE Razorpay flow (per owner: "api keep fake").

The shapes mirror Razorpay's checkout contract (order_id, amount in paise, key_id)
so swapping in the real SDK later only touches routers/payments.py.
"""

from typing import Optional

from pydantic import BaseModel, Field


class VipOrderOut(BaseModel):
    order_id: str
    amount: int  # paise, Razorpay-style (6600 = ₹66)
    currency: str = "INR"
    key_id: str = "rzp_test_FAKE_not_real"
    test_mode: bool = True


class VipVerifyIn(BaseModel):
    order_id: str = Field(min_length=6, max_length=120)


class VipStatusOut(BaseModel):
    active: bool
    until: Optional[str] = None


# ------------------------------------------------- Cryptomus (real crypto checkout)
class CryptoInvoiceIn(BaseModel):
    plan_id: str  # server-side catalog only — the browser never sets prices


class CryptoInvoiceOut(BaseModel):
    order_id: str
    payment_url: str


class CryptoStatusOut(BaseModel):
    order_id: str
    status: str
    payment_url: str = ""



# ------------------------------------------------- Donations
class DonateIn(BaseModel):
    amount: float = Field(..., ge=0.1, description="Amount in INR or USD")
    currency: str = Field(default="INR", description="INR or USD")
    donor_name: Optional[str] = "Anonymous"
    note: Optional[str] = ""


class DonateOut(BaseModel):
    id: str
    amount: float
    currency: str
    donor_name: str
    note: str
    znq_network_cut: float
    environmental_protection_cut: float
    status: str
    created_at: str
