"""NFT & Auction models adhering to strict rules:
- 50+ NFTs with Low / Mid / High tiers
- Anime, Dragons, Creatures, Characters categories
- Limited Edition NFTs created by Admin
- 48h Auction House with 24h cancellation rule
- Seller choice / automatic highest bidder resolution
- Currency conversion: 1 Ad = 1 VD, 3 VD = 1 CF, 1 VD = 1 LC
"""

from typing import List, Optional
from pydantic import BaseModel, Field


# ---------------------------------------------------------------------------
# NFT Data Models
# ---------------------------------------------------------------------------

class NFTItem(BaseModel):
    id: str
    name: str
    description: str = ""
    media_url: str = ""
    media_type: str = "image"  # image, video, html, animation
    html: Optional[str] = ""
    category: str = "anime"  # anime, dragon, creature, character
    tier: str = "low"  # low, mid, high, limited
    edition: str = "common"  # common, limited
    price_lc: int = 50  # price in Coins (LC / CF)
    supply: int = 0  # 0 = infinite (common), >0 = limited cap
    minted: int = 0
    start_from: Optional[str] = None  # ISO date
    end_at: Optional[str] = None  # ISO date / fixed time limit
    active: bool = True
    created_at: str
    created_by: str = "system"


class NFTPurchaseIn(BaseModel):
    nft_id: str


class NFTTransferIn(BaseModel):
    owned_id: str
    recipient_email: str


class NFTAdminGrantIn(BaseModel):
    nft_id: str
    user_email: str


class NFTAdminRevokeIn(BaseModel):
    owned_id: str


class NFTCreateAdminIn(BaseModel):
    name: str
    description: Optional[str] = ""
    media_url: Optional[str] = ""
    media_type: str = "image"  # image, video, html, animation
    html: Optional[str] = ""
    category: str = "anime"  # anime, dragon, creature, character
    tier: str = "limited"  # low, mid, high, limited
    edition: str = "limited"  # common, limited
    price_lc: int = Field(..., ge=1, description="Purchase price in coins")
    supply: int = Field(default=10, ge=1, description="Maximum number of NFTs available")
    start_from: Optional[str] = None
    end_at: Optional[str] = None


class NFTOwnedItem(BaseModel):
    id: str
    owner_id: str
    owner_name: Optional[str] = "Otaku"
    owner_email: Optional[str] = ""
    nft_id: str
    nft: Optional[NFTItem] = None
    serial: int = 1
    acquired_at: str
    acquired_via: str = "purchase"  # purchase, gift, auction, transfer
    showcase: bool = False
    in_auction: bool = False


# ---------------------------------------------------------------------------
# Auction Models
# ---------------------------------------------------------------------------

class BidItem(BaseModel):
    user_id: str
    user_name: str
    amount: int
    created_at: str


class AuctionItem(BaseModel):
    id: str
    owned_id: str
    nft_id: str
    nft_name: str
    nft: Optional[NFTItem] = None
    serial: int = 1
    seller_id: str
    seller_name: str
    start_price: int
    current_price: int
    start_at: str
    ends_at: str  # max 48 hours from start_at
    can_cancel_until: str  # start_at + 24 hours
    status: str = "active"  # active, sold, cancelled, expired
    top_bidder_id: Optional[str] = ""
    top_bidder_name: Optional[str] = ""
    bid_count: int = 0
    top_bids: List[BidItem] = []
    settled_at: Optional[str] = None
    created_at: str


class CreateAuctionIn(BaseModel):
    owned_id: str
    start_price: int = Field(..., ge=1, description="Starting bid in coins")
    start_at: Optional[str] = None  # Scheduled start or immediate


class PlaceBidIn(BaseModel):
    amount: int = Field(..., ge=1, description="Bid amount in coins (must exceed current price)")


class SelectBuyerIn(BaseModel):
    buyer_id: str


# ---------------------------------------------------------------------------
# Reward / Ad Conversion Models (1 Ad = 1 VD, 3 VD = 1 CF, 1 VD = 1 LC)
# ---------------------------------------------------------------------------

class AdConversionIn(BaseModel):
    ad_tokens_to_convert: int = Field(..., ge=1, description="Number of VD (View Duration tokens from ads) to convert")
    target_currency: str = Field(default="CF", description="'CF' (3 VD = 1 CF) or 'LC' (1 VD = 1 LC)")


class AdConversionOut(BaseModel):
    vd_deducted: int
    cf_added: int
    lc_added: int
    current_cf_balance: int
    current_lc_balance: int
    formula_used: str



class LCConversionAttemptIn(BaseModel):
    lc_amount: int
    target: str = "CF"
