"""Growth-analytics output models — mirrors frontend/src/lib/types.ts (GrowthStats)."""

from pydantic import BaseModel


class GrowthTotals(BaseModel):
    views: int = 0
    watch_minutes: float = 0
    watch_hours: float = 0
    downloads_video: int = 0
    downloads_audio: int = 0
    downloads_subtitle: int = 0
    downloads_total: int = 0


class DayPoint(BaseModel):
    date: str
    views: int


class MonthPoint(BaseModel):
    month: str
    views: int


class LocationPoint(BaseModel):
    country: str
    views: int


class GrowthOut(BaseModel):
    totals: GrowthTotals
    uploads: int = 0
    subscribers: int = 0
    trend_pct: float = 0
    daily: list[DayPoint]
    monthly: list[MonthPoint]
    locations: list[LocationPoint]


class AdminAnalyticsOut(GrowthOut):
    """Same shape as the publisher screen — global scope (admin console)."""
