"""AniList import models. Search hits the public graphql.anilist.co API (no key);
if the network is unavailable the backend serves a small offline catalogue so the
Studio import flow always works ("api keep fake" fallback)."""

from typing import List, Optional

from pydantic import BaseModel, Field


class AniListResult(BaseModel):
    anilist_id: int
    name: str = Field(min_length=1, max_length=120)
    name_english: Optional[str] = None
    synopsis: str = ""
    genres: List[str] = []
    release_year: Optional[int] = None
    type: str = "series"  # series | movie
    episodes_count: int = 0
    rating: float = 0.0
    poster_url: str = ""
    studio: str = ""
    airing_status: str = ""
    source: str = "anilist"  # anilist | offline


class ImportedTitleOut(BaseModel):
    id: str
    slug: str
    name: str
    status: str = "draft"
