"""Chat layer models — personal (friends/DMs) + global (region rooms).
Mirrors frontend/src/lib/types.ts (Friend/ChatMessage/AccountInfo) — keep in sync."""

from typing import Literal

from pydantic import BaseModel, Field

Region = Literal["asia", "americas", "europe"]
FriendStatus = Literal["pending", "accepted", "declined", "blocked"]


class AccountOut(BaseModel):
    account_id: str
    display_name: str
    avatar_url: str = ""  # an emoji picked from the grid (no media in chat per the notes)
    country: Region = "asia"
    role: str
    vip_active: bool = False
    friends_limit: int = 15
    chat_free_limit: int = 0  # VIP: 300 free messages/day; free users spend CF
    member_since: str = ""
    cf_balance: int = 0  # chat fund — converted from watch-time (1 CF = 3 min)


class AccountUpdateIn(BaseModel):
    display_name: str | None = Field(default=None, min_length=2, max_length=40)
    avatar_url: str | None = Field(default=None, max_length=32)  # gradient key (cool avatars, no emojis)
    country: Region | None = None
    phone: str | None = Field(default=None, max_length=15)  # 1 number = 1 account
    downgrade_vip: bool = False  # Settings → downgrade: cancels VIP immediately


class FriendRequestIn(BaseModel):
    account_id: str = Field(min_length=4, max_length=10)  # add friends by ID no.


class FriendRespondIn(BaseModel):
    request_id: str = Field(min_length=1, max_length=80)
    action: Literal["accept", "decline", "block"]


class FriendOut(BaseModel):
    request_id: str
    user_id: str  # the OTHER person's id — used to open the DM thread
    account_id: str
    display_name: str
    avatar_url: str = ""
    status: FriendStatus
    created_at: str


class FriendsOut(BaseModel):
    friends: list[FriendOut] = Field(default_factory=list)
    incoming: list[FriendOut] = Field(default_factory=list)
    outgoing: list[FriendOut] = Field(default_factory=list)


class DmIn(BaseModel):
    peer_id: str = Field(min_length=1, max_length=80)
    text: str = Field(min_length=1, max_length=500)


class GlobalIn(BaseModel):
    text: str = Field(min_length=1, max_length=300)
    region: Region | None = None  # VIP-only: post to another continent's room


class ConvertIn(BaseModel):
    """The convert system: View-Duration ↔ CF. 1 CF = 3 minutes (the notes' ICF rate)."""

    direction: Literal["vd_to_cf", "cf_to_vd"]
    amount: int = Field(ge=1, le=10000)  # vd_to_cf: minutes · cf_to_vd: CF units


class ConvertOut(BaseModel):
    cf_balance: int
    balance_seconds: int


class ChatMessageOut(BaseModel):
    id: str
    from_id: str
    from_name: str
    from_avatar: str = ""
    text: str
    created_at: str
