"""Playlist + watch-history models. Mirrors frontend/src/lib/types.ts (keep in sync)."""

from typing import Optional

from pydantic import BaseModel, Field


class PlaylistIn(BaseModel):
    name: str = Field(min_length=1, max_length=80)


class PlaylistUpdate(BaseModel):
    name: Optional[str] = Field(default=None, min_length=1, max_length=80)
    is_public: Optional[bool] = None
    add_title_id: Optional[str] = None
    remove_title_id: Optional[str] = None


class TitleRef(BaseModel):
    id: str
    slug: str
    name: str
    poster_url: str


class PlaylistOut(BaseModel):
    id: str
    name: str
    owner_id: str
    is_public: bool
    title_ids: list[str] = Field(default_factory=list)
    titles: list[TitleRef] = Field(default_factory=list)
    created_at: str


class HistoryPing(BaseModel):
    title_id: str
    episode_id: str
    position_seconds: float = Field(default=0, ge=0)


class HistoryItem(BaseModel):
    episode_id: str
    title_id: str
    episode_number: int
    position_seconds: float
    title: TitleRef
    updated_at: str


class HistoryOut(BaseModel):
    items: list[HistoryItem] = Field(default_factory=list)
