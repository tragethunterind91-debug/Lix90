"""Auth request models. UserPublic mirrors lib/security.UserPublic."""

from typing import Literal, Optional

from pydantic import BaseModel, EmailStr, Field


class RegisterIn(BaseModel):
    email: EmailStr
    password: str = Field(min_length=8, max_length=72)
    display_name: str = Field(min_length=2, max_length=40)
    otp: str = Field(default="", max_length=8)  # 6-digit email code (required — verified signup)
    birth_year: int = Field(default=0, ge=1900, le=2100)  # owner rule: min age 9 years
    phone: str = Field(default="", max_length=15)  # owner rule: 1 number = 1 account
    phone_otp: str = Field(default="", max_length=8)  # SMS code (required when the SMS provider is live)


class OtpSendIn(BaseModel):
    email: EmailStr
    purpose: Literal["register", "reset"]


class PhoneOtpIn(BaseModel):
    phone: str = Field(min_length=10, max_length=15, pattern=r"^\+?[0-9]{10,13}$")


class PhoneVerifyIn(BaseModel):
    phone: str = Field(min_length=10, max_length=15, pattern=r"^\+?[0-9]{10,13}$")
    code: str = Field(min_length=4, max_length=8)


class ResetIn(BaseModel):
    email: EmailStr
    otp: str = Field(default="", max_length=8)
    new_password: str = Field(min_length=8, max_length=72)


class AccountRecoveryRequestIn(BaseModel):
    email_or_id: str = Field(..., min_length=3, max_length=100)
    user_note: str = Field(..., min_length=5, max_length=500)
    device_info: Optional[str] = None


class LoginIn(BaseModel):
    email: EmailStr
    password: str
    pin: str = Field(default="", max_length=12)  # required for admins when STUDIO_PIN is set


class FirebaseLoginIn(BaseModel):
    id_token: str = Field(min_length=20, max_length=3000)
    display_name: Optional[str] = Field(default=None, max_length=40)
    pin: str = Field(default="", max_length=12)  # required for admins when STUDIO_PIN is set
