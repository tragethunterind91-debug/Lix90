"""Direct image uploads (posters, thumbnails) — stored on the local media disk that
stands in for Cloudflare R2, served back through an API route. No external API."""

from pydantic import BaseModel


class ImageUploadOut(BaseModel):
    url: str
